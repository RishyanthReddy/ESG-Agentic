"""
Demo script for the Visualization Agent.

This script demonstrates the Visualization Agent that orchestrates the creation of all visualization 
data assets by calling NetworkXProvenanceTool and GraphSerializationTool.
"""

import json
from datetime import datetime
from src.agents.visualization import visualization_agent
from src.state.models import AppState


def main():
    """Demonstrate the Visualization Agent functionality."""
    print("=== Visualization Agent Demo ===\n")
    
    # Create sample agent traces
    print("1. Creating sample agent traces")
    agent_traces = [
        {
            "agent": "ingestion_agent",
            "action": "data_ingested",
            "data_source": "supplier_data.xlsx",
            "file_size": "2.5MB",
            "record_count": 1000,
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "agent": "credential_agent",
            "action": "credential_processed",
            "credential_id": "vlei-cred-001",
            "issuer": "did:example:issuer1",
            "subject": "did:example:subject1",
            "credential_type": "vLEI",
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "agent": "verification_agent",
            "action": "credential_verified",
            "credential_id": "vlei-cred-001",
            "verification_result": "verified",
            "verification_method": "blockchain",
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "agent": "modeling_agent",
            "action": "co2_calculated",
            "calculation_id": "co2-calc-001",
            "activity_type": "transportation",
            "co2_amount": 1250.5,
            "unit": "kg",
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "agent": "reporting_agent",
            "action": "report_generated",
            "report_type": "GRI",
            "report_id": "gri-report-001",
            "reporting_period": "2023-Q1",
            "timestamp": datetime.utcnow().isoformat()
        }
    ]
    
    print(f"   Created {len(agent_traces)} agent traces\n")
    
    # Create sample blockchain logs
    print("2. Creating sample blockchain logs")
    blockchain_logs = [
        {
            "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
            "data_hash": "a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 15732045,
            "gas_used": 21000,
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "transaction_hash": "0x1a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f7890",
            "data_hash": "f6e5d4c3b2a10987abcdef1234567890abcdef1234567890abcdef1234567890",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 15732102,
            "gas_used": 25000,
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "transaction_hash": "0x9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e",
            "data_hash": "0987f6e5d4c3b2a1abcdef1234567890abcdef1234567890abcdef1234567890",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 15732158,
            "gas_used": 30000,
            "timestamp": datetime.utcnow().isoformat()
        }
    ]
    
    print(f"   Created {len(blockchain_logs)} blockchain logs\n")
    
    # Create initial state
    print("3. Creating initial application state")
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        workflow_status="reporting_completed",
        workflow_step=5
    )
    
    print(f"   Initial state created with {len(state.agent_trace)} agent traces and {len(state.blockchain_log)} blockchain logs\n")
    
    # Run the visualization agent
    print("4. Running Visualization Agent")
    result = visualization_agent(state)
    
    if result["workflow_status"] == "visualization_generated":
        print("   Visualization generated successfully!\n")
        
        # Show visualization assets
        visualization_assets = result["visualization_assets"]
        print("5. Visualization Assets:")
        
        # Show provenance graph info
        provenance_graph = visualization_assets["provenance_graph"]
        print("   Provenance Graph:")
        print(f"     Nodes: {provenance_graph['node_count']}")
        print(f"     Edges: {provenance_graph['edge_count']}")
        print(f"     Created: {provenance_graph['created_at']}")
        
        # Show serialized graph info
        serialized_graph = visualization_assets["serialized_graph"]
        print("\n   Serialized Graph:")
        print(f"     Format: {serialized_graph['format']}")
        print(f"     Size: {serialized_graph['size']} characters")
        print(f"     Compressed: {serialized_graph['compressed']}")
        print(f"     Optimized: {serialized_graph['optimized']}")
        print(f"     Created: {serialized_graph['created_at']}")
        
        # Show sample of the JSON data
        print("\n   Sample JSON Data (first 300 characters):")
        json_sample = serialized_graph['json_data'][:300] + "..." if len(serialized_graph['json_data']) > 300 else serialized_graph['json_data']
        print(f"     {json_sample}")
        
        # Parse and show structure
        try:
            graph_data = json.loads(serialized_graph['json_data'])
            print(f"\n   Graph Structure:")
            print(f"     Nodes: {len(graph_data.get('nodes', []))}")
            print(f"     Links: {len(graph_data.get('links', []))}")
            
            if 'metadata' in graph_data:
                print(f"     Metadata: {graph_data['metadata']}")
                
        except json.JSONDecodeError as e:
            print(f"   Error parsing JSON: {e}")
        
        # Show agent trace update
        print(f"\n6. Agent Trace Update:")
        print(f"   Added visualization agent trace entry")
        print(f"   Updated workflow status: {result['workflow_status']}")
        
        # Show processing results
        if 'processing_results' in result and 'visualization_result' in result['processing_results']:
            viz_result = result['processing_results']['visualization_result']
            print(f"\n7. Processing Results:")
            print(f"   Success: {viz_result['success']}")
            print(f"   Nodes: {viz_result['node_count']}")
            print(f"   Edges: {viz_result['edge_count']}")
            print(f"   JSON Size: {viz_result['json_size']} characters")
            
    else:
        print("   Error generating visualization:")
        if 'errors' in result:
            for error in result['errors']:
                print(f"     {error}")
    
    print("\n=== Demo completed ===")
    print("\nNote: The Visualization Agent orchestrates the creation of visualization data assets")
    print("      by calling NetworkXProvenanceTool and GraphSerializationTool. It creates a")
    print("      NetworkX graph from agent traces and blockchain logs, then serializes it")
    print("      into JSON format optimized for 3D visualization engines like Three.js.")


if __name__ == "__main__":
    main()