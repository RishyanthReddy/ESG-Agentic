"""
Demo script for the Stakeholder Dashboard

This script demonstrates the Stakeholder Dashboard functionality for the VLEIs platform.
"""

import sys
import os
from datetime import datetime
import webbrowser
import time
import subprocess
import signal

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from loguru import logger


def demo_dashboard_overview():
    """Demonstrate dashboard overview and features"""
    print("VLEIs Stakeholder Dashboard Demo")
    print("=" * 50)
    print()
    
    print("Dashboard Features:")
    print("- Real-time ESG performance monitoring")
    print("- Interactive data provenance visualization")
    print("- Decarbonization pathway analysis")
    print("- Agent activity tracking")
    print("- Blockchain transaction monitoring")
    print("- Secure authentication")
    print("- Responsive design for all devices")
    print()


def demo_technology_stack():
    """Demonstrate the technology stack used"""
    print("Technology Stack:")
    print("=" * 30)
    print("Dashboard Framework: streamlit==1.28.1")
    print("Visualization: plotly==5.17.0, altair==5.2.0")
    print("Real-Time Updates: streamlit-autorefresh")
    print("Authentication: streamlit-authenticator")
    print("Layout Management: Custom CSS and HTML")
    print()


def demo_data_sources():
    """Demonstrate data sources for the dashboard"""
    print("Data Sources:")
    print("=" * 20)
    print("1. AppState - Central application state")
    print("   - ESG metrics and scores")
    print("   - Carbon footprint calculations")
    print("   - Verification results")
    print()
    
    print("2. Visualization Assets")
    print("   - Provenance graph data")
    print("   - Path highlighting information")
    print("   - NetworkX graph serialization")
    print()
    
    print("3. Agent Activity")
    print("   - Agent trace logs")
    print("   - Processing history")
    print()
    
    print("4. Blockchain Data")
    print("   - Transaction logs")
    print("   - Data hash records")
    print()


def demo_dashboard_components():
    """Demonstrate dashboard components"""
    print("Dashboard Components:")
    print("=" * 25)
    print("1. Key Metrics Dashboard")
    print("   - Carbon footprint metrics")
    print("   - ESG scores (Environmental, Social, Governance)")
    print("   - Verification statistics")
    print()
    
    print("2. Provenance Visualization")
    print("   - Interactive graph visualization")
    print("   - Path highlighting from source to blockchain")
    print("   - Node and edge statistics")
    print()
    
    print("3. Decarbonization Pathways")
    print("   - Emissions trend analysis")
    print("   - Scenario comparison charts")
    print("   - Business impact metrics")
    print()
    
    print("4. System Activity")
    print("   - Agent activity timeline")
    print("   - Blockchain transaction log")
    print("   - Performance metrics")
    print()


def demo_security_features():
    """Demonstrate dashboard security features"""
    print("Security Features:")
    print("=" * 20)
    print("1. User Authentication")
    print("   - Secure login with streamlit-authenticator")
    print("   - Role-based access control")
    print("   - Session management")
    print()
    
    print("2. Data Protection")
    print("   - Secure data handling")
    print("   - Encrypted communications")
    print("   - Access logging")
    print()


def demo_responsive_design():
    """Demonstrate responsive design features"""
    print("Responsive Design:")
    print("=" * 20)
    print("1. Multi-device Support")
    print("   - Desktop optimization")
    print("   - Tablet compatibility")
    print("   - Mobile responsiveness")
    print()
    
    print("2. Adaptive Layout")
    print("   - Flexible grid system")
    print("   - Dynamic component sizing")
    print("   - Touch-friendly controls")
    print()


def run_dashboard_demo():
    """Run the actual dashboard demo"""
    print("Running Dashboard Demo...")
    print("=" * 30)
    print("Starting Streamlit dashboard server...")
    print("Dashboard will be available at: http://localhost:8501")
    print("Press Ctrl+C to stop the demo")
    print()
    
    try:
        # Start Streamlit server
        process = subprocess.Popen([
            sys.executable, "-m", "streamlit", "run", 
            "src/dashboard/main_dashboard.py",
            "--server.port", "8501",
            "--server.headless", "true"
        ])
        
        # Give the server time to start
        time.sleep(3)
        
        # Try to open the browser
        try:
            webbrowser.open("http://localhost:8501")
            print("Browser opened successfully!")
        except Exception as e:
            print(f"Could not open browser automatically: {e}")
            print("Please manually navigate to http://localhost:8501")
        
        print("\nDashboard is now running!")
        print("Login credentials:")
        print("  Username: admin")
        print("  Password: admin123")
        print()
        print("Waiting for dashboard... (Press Ctrl+C to stop)")
        
        # Wait for the process
        process.wait()
        
    except KeyboardInterrupt:
        print("\n\nStopping dashboard server...")
        try:
            process.terminate()
            process.wait(timeout=5)
        except:
            process.kill()
        print("Dashboard server stopped.")


def main():
    """Main demo function"""
    print("VLEIs Stakeholder Dashboard Demo")
    print("=" * 50)
    print("This demo showcases the features of the Stakeholder Dashboard")
    print("for real-time, interactive ESG performance monitoring.\n")
    
    # Demo sections
    demo_dashboard_overview()
    demo_technology_stack()
    demo_data_sources()
    demo_dashboard_components()
    demo_security_features()
    demo_responsive_design()
    
    # Ask user if they want to run the actual dashboard
    print("=" * 50)
    run_demo = input("Would you like to run the actual dashboard demo? (y/N): ")
    
    if run_demo.lower() in ['y', 'yes']:
        run_dashboard_demo()
    else:
        print("Demo completed. To run the dashboard, use:")
        print("streamlit run src/dashboard/main_dashboard.py")


if __name__ == "__main__":
    main()