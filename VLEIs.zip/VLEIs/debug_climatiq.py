import httpx
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get API key
api_key = os.getenv("CLIMATIQ_API_KEY")
if not api_key:
    print("CLIMATIQ_API_KEY not found in environment")
    exit(1)

# Test data - trying different formats
test_cases = [
    {
        "name": "With region in emission_factor",
        "data": {
            "emission_factor": {
                "activity_id": "electricity-energy_source_grid-average",
                "data_version": "24.24",
                "region": "US"
            },
            "parameters": {
                "value": 100,
                "unit": "kwh"
            }
        }
    },
    {
        "name": "With Energy unit type",
        "data": {
            "emission_factor": {
                "activity_id": "electricity-energy_source_grid-average",
                "data_version": "24.24",
                "region": "US"
            },
            "parameters": {
                "value": 100,
                "unit": "Energy"
            }
        }
    },
    {
        "name": "Without region",
        "data": {
            "emission_factor": {
                "activity_id": "electricity-energy_source_grid-average",
                "data_version": "24.24"
            },
            "parameters": {
                "value": 100,
                "unit": "kwh"
            }
        }
    }
]

# Make requests
url = "https://api.climatiq.io/estimate"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

for test_case in test_cases:
    print(f"\nTesting: {test_case['name']}")
    print(f"Request data: {test_case['data']}")
    
    try:
        response = httpx.post(url, json=test_case['data'], headers=headers, timeout=30.0)
        print(f"Response status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Success! CO2e: {data.get('co2e')} {data.get('co2e_unit')}")
        else:
            print(f"Error: {response.text}")
            
    except Exception as e:
        print(f"Exception: {e}")