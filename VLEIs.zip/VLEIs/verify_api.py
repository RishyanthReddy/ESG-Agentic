"""
Simple test script to verify API endpoints work correctly
"""

import requests
import json
import time

def test_api_endpoints():
    """Test the API endpoints"""
    base_url = "http://localhost:8000"
    
    # Test root endpoint
    print("Testing root endpoint...")
    try:
        response = requests.get(f"{base_url}/")
        print(f"Root endpoint status: {response.status_code}")
        print(f"Root endpoint response: {response.json()}")
    except Exception as e:
        print(f"Error testing root endpoint: {e}")
    
    # Test health endpoint
    print("\nTesting health endpoint...")
    try:
        response = requests.get(f"{base_url}/health")
        print(f"Health endpoint status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"Health status: {data.get('status', 'Unknown')}")
            print(f"Components: {list(data.get('components', {}).keys())}")
    except Exception as e:
        print(f"Error testing health endpoint: {e}")
    
    # Test OpenAPI docs
    print("\nTesting OpenAPI documentation...")
    try:
        response = requests.get(f"{base_url}/docs")
        print(f"Docs endpoint status: {response.status_code}")
        
        response = requests.get(f"{base_url}/openapi.json")
        print(f"OpenAPI JSON endpoint status: {response.status_code}")
    except Exception as e:
        print(f"Error testing OpenAPI docs: {e}")
    
    print("\nAPI verification complete!")

if __name__ == "__main__":
    test_api_endpoints()