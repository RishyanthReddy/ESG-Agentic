import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { AppState } from '@/types/appState';

// Define the shape of our store
interface ESGStore {
  health: any | null;
  reports: any[];
  currentReport: any | null;
  
  // Actions
  fetchHealth: () => Promise<void>;
  fetchReports: () => Promise<void>;
  processJsonData: (data: any) => Promise<void>;
  processFileData: (file: File) => Promise<void>;
  verifyReport: (reportId: string) => Promise<void>;
  setCurrentReport: (report: any) => void;
  
  // Fallback state logging
  logState: () => void;
}

// API service functions
const api = {
  getHealth: async () => {
    const response = await fetch('http://localhost:8000/health');
    if (!response.ok) throw new Error('Failed to fetch health data');
    return response.json();
  },
  
  getReports: async () => {
    // This is a placeholder - in a real implementation, you would fetch reports
    return [];
  },
  
  processJsonData: async (data: any) => {
    const response = await fetch('http://localhost:8000/ingest/json', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ supplier_data: data }),
    });
    
    if (!response.ok) throw new Error('Failed to process JSON data');
    return response.json();
  },
  
  processFileData: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('http://localhost:8000/ingest/file', {
      method: 'POST',
      body: formData,
    });
    
    if (!response.ok) throw new Error('Failed to process file data');
    return response.json();
  },
  
  verifyReport: async (reportId: string) => {
    const response = await fetch(`http://localhost:8000/verify/${reportId}`);
    if (!response.ok) throw new Error('Failed to verify report');
    return response.json();
  }
};

// Create the Zustand store with persistence
export const useESGStore = create<ESGStore>()(
  persist(
    (set, get) => ({
      // State
      health: null,
      reports: [],
      currentReport: null,
      
      // Actions
      fetchHealth: async () => {
        try {
          const health = await api.getHealth();
          set({ health });
          get().logState();
        } catch (error) {
          console.error('Error fetching health:', error);
        }
      },
      
      fetchReports: async () => {
        try {
          const reports = await api.getReports();
          set({ reports });
          get().logState();
        } catch (error) {
          console.error('Error fetching reports:', error);
        }
      },
      
      processJsonData: async (data: any) => {
        try {
          const result = await api.processJsonData(data);
          // Update reports list
          const { reports } = get();
          set({ reports: [...reports, result] });
          get().logState();
        } catch (error) {
          console.error('Error processing JSON data:', error);
        }
      },
      
      processFileData: async (file: File) => {
        try {
          const result = await api.processFileData(file);
          // Update reports list
          const { reports } = get();
          set({ reports: [...reports, result] });
          get().logState();
        } catch (error) {
          console.error('Error processing file data:', error);
        }
      },
      
      verifyReport: async (reportId: string) => {
        try {
          const report = await api.verifyReport(reportId);
          set({ currentReport: report });
          get().logState();
        } catch (error) {
          console.error('Error verifying report:', error);
        }
      },
      
      setCurrentReport: (report: any) => {
        set({ currentReport: report });
        get().logState();
      },
      
      // Fallback state logging
      logState: () => {
        const state = get();
        console.log('ESG Store State:', {
          health: state.health,
          reportsCount: state.reports.length,
          hasCurrentReport: !!state.currentReport,
        });
      },
    }),
    {
      name: 'esg-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);