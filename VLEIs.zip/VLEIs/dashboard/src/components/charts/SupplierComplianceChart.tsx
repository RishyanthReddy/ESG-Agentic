'use client';

import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface ComplianceData {
  name: string;
  complianceRate: number;
}

interface ComplianceDistribution {
  name: string;
  value: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const SupplierComplianceChart: React.FC = () => {
  const [barData, setBarData] = useState<ComplianceData[]>([]);
  const [pieData, setPieData] = useState<ComplianceDistribution[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real implementation, this would fetch from an API
    // For now, we'll use mock data
    const fetchData = async () => {
      try {
        // Simulating API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const mockBarData: ComplianceData[] = [
          { name: 'Supplier A', complianceRate: 95 },
          { name: 'Supplier B', complianceRate: 87 },
          { name: 'Supplier C', complianceRate: 78 },
          { name: 'Supplier D', complianceRate: 92 },
          { name: 'Supplier E', complianceRate: 88 },
        ];
        
        const mockPieData: ComplianceDistribution[] = [
          { name: 'Compliant (90-100%)', value: 45 },
          { name: 'Mostly Compliant (75-89%)', value: 30 },
          { name: 'Partially Compliant (60-74%)', value: 15 },
          { name: 'Non-Compliant (<60%)', value: 10 },
        ];
        
        setBarData(mockBarData);
        setPieData(mockPieData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching compliance data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading supplier compliance chart...</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="h-80">
        <h3 className="text-lg font-semibold mb-4">Supplier Compliance Rates</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={barData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Bar dataKey="complianceRate" name="Compliance Rate (%)" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="h-80">
        <h3 className="text-lg font-semibold mb-4">Compliance Distribution</h3>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              labelLine={true}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default SupplierComplianceChart;