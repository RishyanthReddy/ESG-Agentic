'use client';

import React, { useState, useEffect, useRef } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CarbonDataPoint {
  time: string;
  carbonFootprint: number;
}

const RealTimeCarbonChart: React.FC = () => {
  const [data, setData] = useState<CarbonDataPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Initialize with some mock data
    const initialData: CarbonDataPoint[] = [];
    const now = new Date();
    
    for (let i = 9; i >= 0; i--) {
      const time = new Date(now.getTime() - i * 60000);
      initialData.push({
        time: time.toISOString().substr(11, 5), // HH:MM format
        carbonFootprint: Math.floor(Math.random() * 30) + 70, // Random value between 70-100
      });
    }
    
    setData(initialData);
    setLoading(false);

    // Simulate real-time data updates
    intervalRef.current = setInterval(() => {
      setData(prevData => {
        const newData = [...prevData];
        const now = new Date();
        const newTime = now.toISOString().substr(11, 5);
        
        // Add new data point
        newData.push({
          time: newTime,
          carbonFootprint: Math.floor(Math.random() * 30) + 70,
        });
        
        // Remove oldest data point if we have more than 10 points
        if (newData.length > 10) {
          newData.shift();
        }
        
        return newData;
      });
    }, 5000); // Update every 5 seconds

    // Cleanup interval on component unmount
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading real-time carbon chart...</div>;
  }

  return (
    <div className="w-full h-80">
      <h3 className="text-lg font-semibold mb-4">Real-time Carbon Footprint</h3>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis domain={[60, 110]} />
          <Tooltip />
          <Area 
            type="monotone" 
            dataKey="carbonFootprint" 
            name="Carbon Footprint (kg CO2e)" 
            stroke="#8884d8" 
            fill="#8884d8" 
            fillOpacity={0.3} 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RealTimeCarbonChart;