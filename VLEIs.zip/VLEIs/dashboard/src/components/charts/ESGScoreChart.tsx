'use client';

import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ESGDataPoint {
  date: string;
  esgScore: number;
  environmental: number;
  social: number;
  governance: number;
}

const ESGScoreChart: React.FC = () => {
  const [data, setData] = useState<ESGDataPoint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real implementation, this would fetch from an API
    // For now, we'll use mock data
    const fetchData = async () => {
      try {
        // Simulating API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const mockData: ESGDataPoint[] = [
          { date: '2024-01', esgScore: 75, environmental: 70, social: 80, governance: 75 },
          { date: '2024-02', esgScore: 78, environmental: 72, social: 82, governance: 80 },
          { date: '2024-03', esgScore: 82, environmental: 75, social: 85, governance: 85 },
          { date: '2024-04', esgScore: 80, environmental: 73, social: 84, governance: 83 },
          { date: '2024-05', esgScore: 85, environmental: 78, social: 88, governance: 86 },
          { date: '2024-06', esgScore: 87, environmental: 80, social: 90, governance: 88 },
        ];
        
        setData(mockData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching ESG data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading ESG score chart...</div>;
  }

  return (
    <div className="w-full h-80">
      <h3 className="text-lg font-semibold mb-4">ESG Score Trend</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis domain={[60, 100]} />
          <Tooltip />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="esgScore" 
            name="Overall ESG Score" 
            stroke="#8884d8" 
            activeDot={{ r: 8 }} 
          />
          <Line 
            type="monotone" 
            dataKey="environmental" 
            name="Environmental" 
            stroke="#82ca9d" 
          />
          <Line 
            type="monotone" 
            dataKey="social" 
            name="Social" 
            stroke="#ffc658" 
          />
          <Line 
            type="monotone" 
            dataKey="governance" 
            name="Governance" 
            stroke="#ff7300" 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ESGScoreChart;