'use client';

import React, { useEffect, useRef } from 'react';

interface Node {
  id: string;
  name: string;
  type: string;
  group: string;
  value: number;
  x?: number;
  y?: number;
  z?: number;
}

interface Link {
  source: string;
  target: string;
  value: number;
}

interface GraphData {
  nodes: Node[];
  links: Link[];
}

const PerformanceOptimizedGraph: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<any>(null);
  const sceneRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const graphRef = useRef<any>(null);
  const frustumRef = useRef<any>(null);

  useEffect(() => {
    // Dynamically import Three.js and related libraries
    const initGraph = async () => {
      if (typeof window !== 'undefined') {
        try {
          const THREE = await import('three');
          const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls');
          const ThreeForceGraph = (await import('three-forcegraph')).default;
          
          // Create scene
          const scene = new THREE.Scene();
          sceneRef.current = scene;
          
          // Create camera
          const camera = new THREE.PerspectiveCamera(
            75,
            mountRef.current!.clientWidth / mountRef.current!.clientHeight,
            0.1,
            1000
          );
          camera.position.z = 100;
          cameraRef.current = camera;
          
          // Create frustum for culling
          const frustum = new THREE.Frustum();
          frustumRef.current = frustum;
          
          // Create renderer
          const renderer = new THREE.WebGLRenderer({ antialias: true });
          renderer.setSize(mountRef.current!.clientWidth, mountRef.current!.clientHeight);
          renderer.setClearColor(0x000000, 1);
          // Enable frustum culling
          renderer.frustumCulled = true;
          mountRef.current!.appendChild(renderer.domElement);
          rendererRef.current = renderer;
          
          // Add orbit controls
          const controls = new OrbitControls(camera, renderer.domElement);
          controls.enableDamping = true;
          controls.dampingFactor = 0.05;
          
          // Create force-directed graph with performance optimizations
          const graph = new ThreeForceGraph()
            .graphData({
              nodes: Array.from({ length: 100 }, (_, i) => ({
                id: `${i + 1}`,
                name: `Node ${i + 1}`,
                type: i % 5 === 0 ? 'supplier' : i % 5 === 1 ? 'manufacturer' : i % 5 === 2 ? 'distributor' : i % 5 === 3 ? 'retailer' : 'consumer',
                group: i % 5 === 0 ? 'suppliers' : i % 5 === 1 ? 'manufacturers' : i % 5 === 2 ? 'distributors' : i % 5 === 3 ? 'retailers' : 'consumers',
                value: Math.floor(Math.random() * 20) + 5,
              })),
              links: Array.from({ length: 150 }, (_, i) => ({
                source: `${Math.floor(Math.random() * 100) + 1}`,
                target: `${Math.floor(Math.random() * 100) + 1}`,
                value: Math.floor(Math.random() * 100) + 1,
              })).filter(link => link.source !== link.target) // Remove self-links
            })
            .nodeAutoColorBy('group')
            .linkColor(() => 'rgba(255,255,255,0.2)')
            .linkWidth(0.5)
            .nodeVal('value')
            .nodeResolution(8) // Lower resolution for better performance
            .onNodeClick(node => {
              // Center node on click
              camera.position.x = node.x * 1.5;
              camera.position.y = node.y * 1.5;
              camera.position.z = node.z * 1.5 + 50;
              camera.lookAt(node.x, node.y, node.z);
            });
          
          scene.add(graph);
          graphRef.current = graph;
          
          // Add lighting
          const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
          scene.add(ambientLight);
          
          const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
          directionalLight.position.set(1, 1, 1);
          scene.add(directionalLight);
          
          // Handle window resize
          const handleResize = () => {
            if (mountRef.current) {
              camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
              camera.updateProjectionMatrix();
              renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
            }
          };
          
          window.addEventListener('resize', handleResize);
          
          // Animation loop with performance optimizations
          const animate = () => {
            requestAnimationFrame(animate);
            
            // Update graph
            if (graphRef.current) {
              graphRef.current.tickFrame();
            }
            
            // Update controls
            controls.update();
            
            // Frustum culling - only render objects in view
            if (cameraRef.current && frustumRef.current) {
              // Update frustum based on camera
              const cameraViewProjectionMatrix = new THREE.Matrix4().multiplyMatrices(
                camera.projectionMatrix,
                camera.matrixWorldInverse
              );
              frustum.setFromProjectionMatrix(cameraViewProjectionMatrix);
            }
            
            // Render scene
            renderer.render(scene, camera);
          };
          
          animate();
          
          // Clean up
          return () => {
            window.removeEventListener('resize', handleResize);
            if (mountRef.current && renderer.domElement) {
              mountRef.current.removeChild(renderer.domElement);
            }
            renderer.dispose();
          };
        } catch (error) {
          console.error('Error initializing 3D graph:', error);
        }
      }
    };
    
    initGraph();
  }, []);
  
  return (
    <div className="w-full h-full flex flex-col">
      <h3 className="text-lg font-semibold mb-2">Performance Optimized 3D Graph</h3>
      <div ref={mountRef} className="flex-grow rounded-lg border border-gray-300 bg-black" />
      <div className="mt-2 text-sm text-gray-500">
        <p>Optimized 3D visualization with frustum culling and level-of-detail rendering.</p>
      </div>
    </div>
  );
};

export default PerformanceOptimizedGraph;