'use client';

import React, { useEffect, useRef, useState } from 'react';

interface Node {
  id: string;
  name: string;
  type: string;
  group: string;
  value: number;
  x?: number;
  y?: number;
  z?: number;
}

interface Link {
  source: string;
  target: string;
  value: number;
}

interface GraphData {
  nodes: Node[];
  links: Link[];
}

interface PathSegment {
  source: string;
  target: string;
  co2_emissions?: number;
  distance?: number;
}

const PathHighlightingGraph3D: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<any>(null);
  const sceneRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const graphRef = useRef<any>(null);
  const highlightedPathRef = useRef<any[]>([]);
  const [pathSegments, setPathSegments] = useState<PathSegment[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Function to find shortest path between nodes
  const findShortestPath = (graphData: GraphData, sourceId: string, targetId: string): string[] => {
    // Create adjacency list representation
    const adjList: Record<string, string[]> = {};
    const nodes = new Set<string>();
    
    // Initialize adjacency list
    graphData.nodes.forEach(node => {
      adjList[node.id] = [];
      nodes.add(node.id);
    });
    
    // Populate adjacency list with edges
    graphData.links.forEach(link => {
      if (!adjList[link.source]) adjList[link.source] = [];
      if (!adjList[link.target]) adjList[link.target] = [];
      
      adjList[link.source].push(link.target);
      adjList[link.target].push(link.source);
      nodes.add(link.source);
      nodes.add(link.target);
    });
    
    // BFS to find shortest path
    const queue: string[] = [sourceId];
    const visited = new Set<string>();
    const previous: Record<string, string | null> = {};
    
    visited.add(sourceId);
    previous[sourceId] = null;
    
    while (queue.length > 0) {
      const currentNode = queue.shift()!;
      
      if (currentNode === targetId) {
        // Reconstruct path
        const path: string[] = [];
        let node: string | null = targetId;
        
        while (node !== null) {
          path.unshift(node);
          node = previous[node];
        }
        
        return path;
      }
      
      // Visit neighbors
      const neighbors = adjList[currentNode] || [];
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          previous[neighbor] = currentNode;
          queue.push(neighbor);
        }
      }
    }
    
    // No path found
    return [];
  };

  // Function to highlight path in 3D graph
  const highlightPath = (path: string[]) => {
    if (!graphRef.current || path.length === 0) return;
    
    try {
      // Clear previous highlights
      highlightedPathRef.current.forEach(obj => {
        if (obj.material && obj.originalMaterial) {
          obj.material.dispose();
          obj.material = obj.originalMaterial;
        }
      });
      highlightedPathRef.current = [];
      
      // Highlight nodes in the path
      path.forEach(nodeId => {
        const node = graphRef.current.graphData().nodes.find((n: Node) => n.id === nodeId);
        if (node && node.__threeObj) {
          const nodeObj = node.__threeObj;
          // Store original material
          if (!nodeObj.userData.originalMaterial) {
            nodeObj.userData.originalMaterial = nodeObj.material;
          }
          
          // Create highlighted material
          const THREE = require('three');
          const highlightMaterial = new THREE.MeshBasicMaterial({ 
            color: 0x00ff00, // Green highlight
            transparent: true,
            opacity: 0.8
          });
          
          nodeObj.material = highlightMaterial;
          highlightedPathRef.current.push({
            object: nodeObj,
            material: highlightMaterial,
            originalMaterial: nodeObj.userData.originalMaterial
          });
        }
      });
      
      // Highlight links in the path
      for (let i = 0; i < path.length - 1; i++) {
        const sourceId = path[i];
        const targetId = path[i + 1];
        
        const link = graphRef.current.graphData().links.find(
          (l: Link) => 
            (l.source === sourceId && l.target === targetId) || 
            (l.source === targetId && l.target === sourceId)
        );
        
        if (link && link.__lineObj) {
          const linkObj = link.__lineObj;
          // Store original material
          if (!linkObj.userData.originalMaterial) {
            linkObj.userData.originalMaterial = linkObj.material;
          }
          
          // Create highlighted material
          const THREE = require('three');
          const highlightMaterial = new THREE.LineBasicMaterial({ 
            color: 0x00ff00, // Green highlight
            linewidth: 3
          });
          
          linkObj.material = highlightMaterial;
          highlightedPathRef.current.push({
            object: linkObj,
            material: highlightMaterial,
            originalMaterial: linkObj.userData.originalMaterial
          });
        }
      }
      
      // Update the scene
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    } catch (err) {
      console.error('Error highlighting path:', err);
    }
  };

  // Function to calculate and display path
  const calculateAndDisplayPath = async (sourceId: string, targetId: string) => {
    if (!graphRef.current) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Get current graph data
      const graphData = graphRef.current.graphData();
      
      // Find shortest path
      const path = findShortestPath(graphData, sourceId, targetId);
      
      if (path.length === 0) {
        setError('No path found between selected nodes');
        setIsLoading(false);
        return;
      }
      
      // Highlight the path in 3D
      highlightPath(path);
      
      // Create path segments for display
      const segments: PathSegment[] = [];
      for (let i = 0; i < path.length - 1; i++) {
        segments.push({
          source: path[i],
          target: path[i + 1],
          co2_emissions: Math.floor(Math.random() * 100) + 10, // Mock data
          distance: Math.floor(Math.random() * 500) + 50 // Mock data
        });
      }
      
      setPathSegments(segments);
      setIsLoading(false);
    } catch (err) {
      setError('Error calculating path: ' + (err as Error).message);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Dynamically import Three.js and related libraries
    const initGraph = async () => {
      if (typeof window !== 'undefined') {
        try {
          const THREE = await import('three');
          const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls');
          const ThreeForceGraph = (await import('three-forcegraph')).default;
          
          // Create scene
          const scene = new THREE.Scene();
          sceneRef.current = scene;
          
          // Create camera
          const camera = new THREE.PerspectiveCamera(
            75,
            mountRef.current!.clientWidth / mountRef.current!.clientHeight,
            0.1,
            1000
          );
          camera.position.z = 100;
          cameraRef.current = camera;
          
          // Create renderer
          const renderer = new THREE.WebGLRenderer({ antialias: true });
          renderer.setSize(mountRef.current!.clientWidth, mountRef.current!.clientHeight);
          renderer.setClearColor(0x000000, 1);
          mountRef.current!.appendChild(renderer.domElement);
          rendererRef.current = renderer;
          
          // Add orbit controls
          const controls = new OrbitControls(camera, renderer.domElement);
          controls.enableDamping = true;
          controls.dampingFactor = 0.05;
          
          // Create force-directed graph
          const graph = new ThreeForceGraph()
            .graphData({
              nodes: [
                { id: '1', name: 'Raw Material Supplier', type: 'supplier', group: 'suppliers', value: 15 },
                { id: '2', name: 'Processing Plant', type: 'manufacturer', group: 'manufacturers', value: 25 },
                { id: '3', name: 'Quality Control Center', type: 'qc', group: 'qcs', value: 10 },
                { id: '4', name: 'Distribution Hub', type: 'distributor', group: 'distributors', value: 20 },
                { id: '5', name: 'Retail Store', type: 'retailer', group: 'retailers', value: 18 },
                { id: '6', name: 'End Consumer', type: 'consumer', group: 'consumers', value: 5 },
              ],
              links: [
                { source: '1', target: '2', value: 100 },
                { source: '2', target: '3', value: 90 },
                { source: '3', target: '4', value: 80 },
                { source: '4', target: '5', value: 70 },
                { source: '5', target: '6', value: 60 },
                { source: '2', target: '4', value: 85 },
              ]
            })
            .nodeAutoColorBy('group')
            .linkColor(() => 'rgba(255,255,255,0.2)')
            .linkWidth(1)
            .nodeVal('value')
            .nodeResolution(16)
            .linkDirectionalArrowLength(3)
            .linkDirectionalArrowRelPos(1)
            .onNodeClick(node => {
              // Center node on click
              camera.position.x = node.x * 1.5;
              camera.position.y = node.y * 1.5;
              camera.position.z = node.z * 1.5 + 50;
              camera.lookAt(node.x, node.y, node.z);
            });
          
          scene.add(graph);
          graphRef.current = graph;
          
          // Add lighting
          const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
          scene.add(ambientLight);
          
          const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
          directionalLight.position.set(1, 1, 1);
          scene.add(directionalLight);
          
          // Handle window resize
          const handleResize = () => {
            if (mountRef.current) {
              camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
              camera.updateProjectionMatrix();
              renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
            }
          };
          
          window.addEventListener('resize', handleResize);
          
          // Animation loop
          const animate = () => {
            requestAnimationFrame(animate);
            
            // Update graph
            if (graphRef.current) {
              graphRef.current.tickFrame();
            }
            
            // Update controls
            controls.update();
            
            // Render scene
            renderer.render(scene, camera);
          };
          
          animate();
          
          // Clean up
          return () => {
            window.removeEventListener('resize', handleResize);
            if (mountRef.current && renderer.domElement) {
              mountRef.current.removeChild(renderer.domElement);
            }
            renderer.dispose();
            
            // Dispose of highlighted materials
            highlightedPathRef.current.forEach(obj => {
              if (obj.material) {
                obj.material.dispose();
              }
            });
          };
        } catch (error) {
          console.error('Error initializing 3D graph:', error);
          setError('Failed to initialize 3D graph: ' + (error as Error).message);
        }
      }
    };
    
    initGraph();
  }, []);

  return (
    <div className="w-full h-full flex flex-col">
      <h3 className="text-lg font-semibold mb-2">3D Path Highlighting Graph</h3>
      <div className="flex flex-col md:flex-row gap-4">
        <div ref={mountRef} className="flex-grow rounded-lg border border-gray-300 bg-black h-96 md:h-[500px]" />
        
        <div className="md:w-1/3 flex flex-col gap-4">
          <div className="bg-white rounded-lg shadow p-4">
            <h4 className="font-semibold mb-2">Path Controls</h4>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div>
                <label className="block text-sm font-medium text-gray-700">Source Node</label>
                <select 
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  defaultValue="1"
                  id="source-node"
                >
                  <option value="1">Raw Material Supplier</option>
                  <option value="2">Processing Plant</option>
                  <option value="3">Quality Control Center</option>
                  <option value="4">Distribution Hub</option>
                  <option value="5">Retail Store</option>
                  <option value="6">End Consumer</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Target Node</label>
                <select 
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  defaultValue="6"
                  id="target-node"
                >
                  <option value="1">Raw Material Supplier</option>
                  <option value="2">Processing Plant</option>
                  <option value="3">Quality Control Center</option>
                  <option value="4">Distribution Hub</option>
                  <option value="5">Retail Store</option>
                  <option value="6">End Consumer</option>
                </select>
              </div>
            </div>
            <button
              onClick={() => {
                const source = (document.getElementById('source-node') as HTMLSelectElement).value;
                const target = (document.getElementById('target-node') as HTMLSelectElement).value;
                calculateAndDisplayPath(source, target);
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md transition duration-150 ease-in-out"
              disabled={isLoading}
            >
              {isLoading ? 'Calculating...' : 'Highlight Path'}
            </button>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 flex-grow">
            <h4 className="font-semibold mb-2">Path Information</h4>
            {error && (
              <div className="bg-red-50 text-red-700 p-2 rounded mb-2">
                {error}
              </div>
            )}
            
            {isLoading ? (
              <div className="flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            ) : pathSegments.length > 0 ? (
              <div>
                <div className="mb-3">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Path Found: {pathSegments.length + 1} nodes
                  </span>
                </div>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {pathSegments.map((segment, index) => (
                    <div key={index} className="border-l-2 border-green-500 pl-2 py-1">
                      <div className="flex justify-between">
                        <span className="font-medium">Step {index + 1}</span>
                        <span className="text-sm text-gray-500">
                          {segment.distance} km
                        </span>
                      </div>
                      <div className="text-sm">
                        Node {segment.source} → Node {segment.target}
                      </div>
                      <div className="text-xs text-gray-500">
                        CO2: {segment.co2_emissions} kg
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-gray-500 text-center py-4">
                <p>Select source and target nodes, then click "Highlight Path"</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="mt-2 text-sm text-gray-500">
        <p>Interactive 3D visualization with path highlighting. Drag to rotate, scroll to zoom.</p>
      </div>
    </div>
  );
};

export default PathHighlightingGraph3D;