'use client';

import React, { useEffect, useRef } from 'react';

interface Node {
  id: string;
  name: string;
  type: string;
  group: string;
  value: number;
}

interface Link {
  source: string;
  target: string;
  value: number;
}

interface GraphData {
  nodes: Node[];
  links: Link[];
}

const ProvenanceGraph3D: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<any>(null);
  const sceneRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const graphRef = useRef<any>(null);

  useEffect(() => {
    // Dynamically import Three.js and related libraries
    const initGraph = async () => {
      if (typeof window !== 'undefined') {
        try {
          const THREE = await import('three');
          const { OrbitControls } = await import('three/examples/jsm/controls/OrbitControls');
          const ThreeForceGraph = (await import('three-forcegraph')).default;
          
          // Create scene
          const scene = new THREE.Scene();
          sceneRef.current = scene;
          
          // Create camera
          const camera = new THREE.PerspectiveCamera(
            75,
            mountRef.current!.clientWidth / mountRef.current!.clientHeight,
            0.1,
            1000
          );
          camera.position.z = 100;
          cameraRef.current = camera;
          
          // Create renderer
          const renderer = new THREE.WebGLRenderer({ antialias: true });
          renderer.setSize(mountRef.current!.clientWidth, mountRef.current!.clientHeight);
          renderer.setClearColor(0x000000, 1);
          mountRef.current!.appendChild(renderer.domElement);
          rendererRef.current = renderer;
          
          // Add orbit controls
          const controls = new OrbitControls(camera, renderer.domElement);
          controls.enableDamping = true;
          controls.dampingFactor = 0.05;
          
          // Create force-directed graph
          const graph = new ThreeForceGraph()
            .graphData({
              nodes: [
                { id: '1', name: 'Supplier A', type: 'supplier', group: 'suppliers', value: 10 },
                { id: '2', name: 'Manufacturer B', type: 'manufacturer', group: 'manufacturers', value: 20 },
                { id: '3', name: 'Distributor C', type: 'distributor', group: 'distributors', value: 15 },
                { id: '4', name: 'Retailer D', type: 'retailer', group: 'retailers', value: 25 },
                { id: '5', name: 'Consumer E', type: 'consumer', group: 'consumers', value: 5 },
              ],
              links: [
                { source: '1', target: '2', value: 100 },
                { source: '2', target: '3', value: 90 },
                { source: '3', target: '4', value: 80 },
                { source: '4', target: '5', value: 70 },
              ]
            })
            .nodeAutoColorBy('group')
            .linkColor(() => 'rgba(255,255,255,0.2)')
            .linkWidth(1)
            .nodeVal('value')
            .nodeResolution(16)
            .linkDirectionalArrowLength(3)
            .linkDirectionalArrowRelPos(1)
            .onNodeClick(node => {
              // Center node on click
              camera.position.x = node.x * 1.5;
              camera.position.y = node.y * 1.5;
              camera.position.z = node.z * 1.5 + 50;
              camera.lookAt(node.x, node.y, node.z);
            });
          
          scene.add(graph);
          graphRef.current = graph;
          
          // Add lighting
          const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
          scene.add(ambientLight);
          
          const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
          directionalLight.position.set(1, 1, 1);
          scene.add(directionalLight);
          
          // Handle window resize
          const handleResize = () => {
            if (mountRef.current) {
              camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
              camera.updateProjectionMatrix();
              renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
            }
          };
          
          window.addEventListener('resize', handleResize);
          
          // Animation loop
          const animate = () => {
            requestAnimationFrame(animate);
            
            // Update graph
            if (graphRef.current) {
              graphRef.current.tickFrame();
            }
            
            // Update controls
            controls.update();
            
            // Render scene
            renderer.render(scene, camera);
          };
          
          animate();
          
          // Clean up
          return () => {
            window.removeEventListener('resize', handleResize);
            if (mountRef.current && renderer.domElement) {
              mountRef.current.removeChild(renderer.domElement);
            }
            renderer.dispose();
          };
        } catch (error) {
          console.error('Error initializing 3D graph:', error);
        }
      }
    };
    
    initGraph();
  }, []);
  
  return (
    <div className="w-full h-full flex flex-col">
      <h3 className="text-lg font-semibold mb-2">3D Provenance Graph</h3>
      <div ref={mountRef} className="flex-grow rounded-lg border border-gray-300 bg-black" />
      <div className="mt-2 text-sm text-gray-500">
        <p>Interactive 3D visualization of supply chain provenance. Drag to rotate, scroll to zoom.</p>
      </div>
    </div>
  );
};

export default ProvenanceGraph3D;