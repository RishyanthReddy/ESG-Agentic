'use client';

import React, { useState, useEffect } from 'react';

interface AuditStatus {
  id: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'verified';
  timestamp: string;
  details: string;
  evidenceHash?: string;
  verifier?: string;
}

const AuditStatusPanel: React.FC = () => {
  const [auditStatus, setAuditStatus] = useState<AuditStatus | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Simulate fetching audit status
  useEffect(() => {
    const fetchAuditStatus = async () => {
      try {
        setIsLoading(true);
        // In a real implementation, this would fetch from an actual API endpoint
        // const response = await fetch('/api/v1/audit/status');
        // const data = await response.json();
        
        // Simulate API response
        setTimeout(() => {
          const mockStatus: AuditStatus = {
            id: 'audit_12345',
            status: 'verified',
            timestamp: new Date().toISOString(),
            details: 'ESG compliance audit successfully completed with zero discrepancies',
            evidenceHash: '0x7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8',
            verifier: 'Blockchain Verification Network'
          };
          setAuditStatus(mockStatus);
          setIsLoading(false);
        }, 1000);
      } catch (err) {
        setError('Failed to fetch audit status');
        setIsLoading(false);
      }
    };

    fetchAuditStatus();
    
    // Set up polling for real-time updates
    const interval = setInterval(fetchAuditStatus, 30000); // Poll every 30 seconds
    
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-gray-200 text-gray-800';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'verified':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      case 'completed':
        return 'Completed';
      case 'failed':
        return 'Failed';
      case 'verified':
        return 'Verified';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">Audit Status</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">Last updated:</span>
          <span className="text-sm font-medium text-gray-700">
            {auditStatus ? new Date(auditStatus.timestamp).toLocaleTimeString() : 'N/A'}
          </span>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-md p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error loading audit status</h3>
              <div className="mt-2 text-sm text-red-700">
                <p>{error}</p>
              </div>
            </div>
          </div>
        </div>
      ) : auditStatus ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(auditStatus.status)}`}>
                {getStatusText(auditStatus.status)}
              </span>
              <span className="ml-3 text-sm text-gray-500">ID: {auditStatus.id}</span>
            </div>
            {auditStatus.status === 'verified' && (
              <div className="flex items-center">
                <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="ml-1 text-sm text-green-700 font-medium">Verified</span>
              </div>
            )}
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-gray-700">{auditStatus.details}</p>
          </div>

          {auditStatus.evidenceHash && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-1">Evidence Hash</h3>
              <div className="bg-gray-50 rounded-md p-3 font-mono text-sm text-gray-600 break-all">
                {auditStatus.evidenceHash}
              </div>
            </div>
          )}

          {auditStatus.verifier && (
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-1">Verified By</h3>
              <div className="bg-gray-50 rounded-md p-3 text-sm text-gray-600">
                {auditStatus.verifier}
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-700 mb-2">CLI Verification</h3>
            <div className="bg-gray-800 text-gray-100 p-3 rounded-md text-sm font-mono">
              python demo_scripts/audit_runner.py --audit-id {auditStatus.id}
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Run this command to verify the audit status via CLI
            </p>
          </div>
        </div>
      ) : (
        <div className="text-center py-8">
          <svg className="mx-auto h-12 w-12 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">No audit data</h3>
          <p className="mt-1 text-sm text-gray-500">No audit information available at this time.</p>
        </div>
      )}
    </div>
  );
};

export default AuditStatusPanel;