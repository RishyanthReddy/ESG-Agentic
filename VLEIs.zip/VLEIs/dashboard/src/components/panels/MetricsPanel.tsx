'use client';

import React, { useState, useEffect } from 'react';

interface Metric {
  name: string;
  value: number | string;
  unit?: string;
  change?: number;
  status: 'normal' | 'warning' | 'critical';
}

const MetricsPanel: React.FC = () => {
  const [metrics, setMetrics] = useState<Metric[]>([
    { name: 'API Response Time', value: 0, unit: 'ms', status: 'normal' },
    { name: 'System Uptime', value: '0.00', unit: '%', status: 'normal' },
    { name: 'Active Connections', value: 0, status: 'normal' },
    { name: 'Error Rate', value: 0, unit: '%', status: 'normal' },
    { name: 'Throughput', value: 0, unit: 'req/s', status: 'normal' },
    { name: 'Memory Usage', value: 0, unit: '%', status: 'normal' },
  ]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  useEffect(() => {
    // Simulate WebSocket connection for real-time updates
    const updateMetrics = () => {
      setMetrics(prevMetrics => 
        prevMetrics.map(metric => {
          // Generate realistic mock data
          switch (metric.name) {
            case 'API Response Time':
              return {
                ...metric,
                value: Math.floor(Math.random() * 100) + 50,
                status: Math.random() > 0.9 ? 'warning' : 'normal'
              };
            case 'System Uptime':
              return {
                ...metric,
                value: '99.99',
                status: 'normal'
              };
            case 'Active Connections':
              return {
                ...metric,
                value: Math.floor(Math.random() * 1000) + 500,
                status: Math.random() > 0.95 ? 'warning' : 'normal'
              };
            case 'Error Rate':
              const errorRate = Math.random() * 2;
              return {
                ...metric,
                value: errorRate.toFixed(2),
                status: errorRate > 1.5 ? 'critical' : errorRate > 0.5 ? 'warning' : 'normal'
              };
            case 'Throughput':
              return {
                ...metric,
                value: Math.floor(Math.random() * 500) + 100,
                status: Math.random() > 0.9 ? 'warning' : 'normal'
              };
            case 'Memory Usage':
              const memoryUsage = Math.random() * 100;
              return {
                ...metric,
                value: memoryUsage.toFixed(1),
                status: memoryUsage > 90 ? 'critical' : memoryUsage > 75 ? 'warning' : 'normal'
              };
            default:
              return metric;
          }
        })
      );
      
      setLastUpdated(new Date().toLocaleTimeString());
      setIsLoading(false);
    };

    // Initial update
    updateMetrics();
    
    // Set up interval to simulate real-time updates
    const interval = setInterval(updateMetrics, 3000);
    
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="border border-gray-200 rounded-lg p-4">
                <div className="h-4 bg-gray-200 rounded w-2/3 mb-2"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">System Metrics Dashboard</h2>
        <div className="text-sm text-gray-500">
          Last updated: {lastUpdated}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <div 
            key={index} 
            className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-medium text-gray-600">{metric.name}</h3>
              <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(metric.status)}`}>
                {metric.status}
              </span>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900">
                {metric.value}
                {metric.unit && <span className="text-sm font-normal text-gray-500 ml-1">{metric.unit}</span>}
              </p>
              {metric.change !== undefined && (
                <p className={`text-sm mt-1 ${metric.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metric.change >= 0 ? '↑' : '↓'} {Math.abs(metric.change)}% from last hour
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-200">
        <h3 className="text-lg font-medium text-gray-800 mb-3">Real-time Metrics</h3>
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600">
            Metrics are updated in real-time via WebSocket connection. 
            Critical metrics will trigger alerts when thresholds are exceeded.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MetricsPanel;