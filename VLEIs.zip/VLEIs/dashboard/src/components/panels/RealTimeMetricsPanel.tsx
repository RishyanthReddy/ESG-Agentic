'use client';

import React, { useState, useEffect, useRef } from 'react';

interface MetricDataPoint {
  timestamp: number;
  value: number;
}

interface RealTimeMetric {
  name: string;
  currentValue: number;
  history: MetricDataPoint[];
  unit: string;
  threshold?: {
    warning: number;
    critical: number;
  };
}

const RealTimeMetricsPanel: React.FC = () => {
  const [metrics, setMetrics] = useState<RealTimeMetric[]>([
    {
      name: 'API Response Time',
      currentValue: 0,
      history: [],
      unit: 'ms',
      threshold: { warning: 200, critical: 500 }
    },
    {
      name: 'Throughput',
      currentValue: 0,
      history: [],
      unit: 'req/s',
      threshold: { warning: 300, critical: 500 }
    },
    {
      name: 'Error Rate',
      currentValue: 0,
      history: [],
      unit: '%',
      threshold: { warning: 1, critical: 5 }
    },
    {
      name: 'Memory Usage',
      currentValue: 0,
      history: [],
      unit: '%',
      threshold: { warning: 75, critical: 90 }
    }
  ]);
  
  const [isConnected, setIsConnected] = useState(false);
  const [alerts, setAlerts] = useState<string[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    // Simulate WebSocket connection
    const connectWebSocket = () => {
      // In a real implementation, this would connect to an actual WebSocket server
      console.log('Connecting to WebSocket for real-time metrics...');
      setIsConnected(true);
      
      // Simulate receiving data
      const interval = setInterval(() => {
        setMetrics(prevMetrics => 
          prevMetrics.map(metric => {
            let newValue = metric.currentValue;
            
            // Generate realistic mock data based on metric type
            switch (metric.name) {
              case 'API Response Time':
                newValue = Math.floor(Math.random() * 300) + 50;
                break;
              case 'Throughput':
                newValue = Math.floor(Math.random() * 400) + 100;
                break;
              case 'Error Rate':
                newValue = parseFloat((Math.random() * 3).toFixed(2));
                break;
              case 'Memory Usage':
                newValue = parseFloat((Math.random() * 80 + 10).toFixed(1));
                break;
            }
            
            // Add to history (keep last 20 points)
            const newHistory = [...metric.history, { 
              timestamp: Date.now(), 
              value: newValue 
            }].slice(-20);
            
            // Check for alerts
            if (metric.threshold) {
              if (newValue >= metric.threshold.critical && 
                  (!metric.history.length || metric.history[metric.history.length - 1].value < metric.threshold.critical)) {
                const alertMsg = `CRITICAL: ${metric.name} reached ${newValue}${metric.unit}`;
                setAlerts(prev => [...prev, alertMsg]);
                // In a real app, this would trigger a toast notification
                console.log('ALERT:', alertMsg);
              } else if (newValue >= metric.threshold.warning && 
                         newValue < metric.threshold.critical &&
                         (!metric.history.length || metric.history[metric.history.length - 1].value < metric.threshold.warning)) {
                const alertMsg = `WARNING: ${metric.name} reached ${newValue}${metric.unit}`;
                setAlerts(prev => [...prev, alertMsg]);
                console.log('WARNING:', alertMsg);
              }
            }
            
            return {
              ...metric,
              currentValue: newValue,
              history: newHistory
            };
          })
        );
      }, 2000);
      
      return () => clearInterval(interval);
    };
    
    const cleanup = connectWebSocket();
    
    return () => {
      if (cleanup) cleanup();
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const getStatusColor = (value: number, threshold?: { warning: number; critical: number }) => {
    if (!threshold) return 'text-gray-700';
    
    if (value >= threshold.critical) return 'text-red-600 font-bold';
    if (value >= threshold.warning) return 'text-yellow-600 font-medium';
    return 'text-green-600';
  };

  const renderSparkline = (history: MetricDataPoint[]) => {
    if (history.length < 2) return <div className="h-8"></div>;
    
    // Find min and max values for scaling
    const values = history.map(point => point.value);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1; // Avoid division by zero
    
    // Create SVG path
    const points = history.map((point, index) => {
      const x = (index / (history.length - 1)) * 100;
      const y = 100 - ((point.value - min) / range) * 100;
      return `${x},${y}`;
    }).join(' ');
    
    return (
      <div className="h-8 w-full">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
          <polyline 
            points={points} 
            fill="none" 
            stroke="#4F46E5" 
            strokeWidth="2" 
            vectorEffect="non-scaling-stroke"
          />
        </svg>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Real-time Metrics</h2>
        <div className="flex items-center">
          <span className={`flex h-3 w-3 rounded-full mr-2 ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></span>
          <span className="text-sm text-gray-600">
            {isConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map((metric, index) => (
          <div key={index} className="border border-gray-200 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-medium text-gray-800">{metric.name}</h3>
              <span className={`text-xl font-bold ${getStatusColor(metric.currentValue, metric.threshold)}`}>
                {metric.currentValue}
                <span className="text-sm font-normal ml-1">{metric.unit}</span>
              </span>
            </div>
            
            <div className="mt-4">
              {renderSparkline(metric.history)}
            </div>
            
            <div className="mt-2 text-sm text-gray-500">
              {metric.history.length > 0 && (
                <span>
                  Last value: {metric.history[metric.history.length - 1].value}{metric.unit} · 
                  Trend: {metric.currentValue > metric.history[Math.max(0, metric.history.length - 2)].value ? '↑' : '↓'}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {alerts.length > 0 && (
        <div className="mt-6 pt-4 border-t border-gray-200">
          <h3 className="text-lg font-medium text-gray-800 mb-3">Recent Alerts</h3>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {alerts.slice(-5).map((alert, index) => (
              <div 
                key={index} 
                className={`p-3 rounded-lg text-sm ${
                  alert.startsWith('CRITICAL') 
                    ? 'bg-red-50 text-red-800 border border-red-200' 
                    : 'bg-yellow-50 text-yellow-800 border border-yellow-200'
                }`}
              >
                {alert}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default RealTimeMetricsPanel;