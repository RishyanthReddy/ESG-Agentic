'use client';

import { useEffect, useState } from 'react';
import { useESGStore } from '@/stores/esgStore';
import { MetricsPanel, RealTimeMetricsPanel } from '@/components/panels';
import { ESGScoreChart, SupplierComplianceChart, RealTimeCarbonChart } from '@/components/charts';
import { ProvenanceGraph3D, PerformanceOptimizedGraph } from '@/components/threejs';

export default function Dashboard() {
  const { health, reports, fetchHealth, fetchReports } = useESGStore();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        await Promise.all([
          fetchHealth(),
          fetchReports()
        ]);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [fetchHealth, fetchReports]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-xl">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">
            ESG Intelligence Platform Dashboard
          </h1>
          <div className="mt-2 text-sm text-gray-500">
            Real-time monitoring and verification of ESG compliance across supply chains
          </div>
        </div>
      </header>
      
      <main>
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          {/* Tab Navigation */}
          <div className="mb-6 border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'overview'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('metrics')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'metrics'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Real-time Metrics
              </button>
              <button
                onClick={() => setActiveTab('visualizations')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'visualizations'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Visualizations
              </button>
              <button
                onClick={() => setActiveTab('provenance')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'provenance'
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Provenance Graph
              </button>
            </nav>
          </div>

          {/* Tab Content */}
          <div className="px-4 py-6 sm:px-0">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-4">System Health</h2>
                  <div className="border-4 border-dashed border-gray-200 rounded-lg h-64 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-500">
                        System Health: {health?.status || 'Unknown'}
                      </p>
                      <p className="text-gray-500">
                        Reports Processed: {reports.length}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-4">Key Metrics</h2>
                  <MetricsPanel />
                </div>
                
                <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-4">ESG Score Trends</h2>
                  <ESGScoreChart />
                </div>
              </div>
            )}

            {activeTab === 'metrics' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">Real-time Metrics</h2>
                <RealTimeMetricsPanel />
              </div>
            )}

            {activeTab === 'visualizations' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-4">Supplier Compliance</h2>
                  <SupplierComplianceChart />
                </div>
                
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-xl font-bold text-gray-800 mb-4">Carbon Footprint</h2>
                  <RealTimeCarbonChart />
                </div>
              </div>
            )}

            {activeTab === 'provenance' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">3D Provenance Graph</h2>
                <div className="border-4 border-dashed border-gray-200 rounded-lg h-96 flex items-center justify-center">
                  <PerformanceOptimizedGraph />
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            ESG Intelligence Platform &copy; {new Date().getFullYear()} - Real-time Supply Chain Verification
          </p>
        </div>
      </footer>
    </div>
  );
}