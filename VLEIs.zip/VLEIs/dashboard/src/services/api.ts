// API service layer for the ESG Intelligence Platform

const API_BASE_URL = 'http://localhost:8000';

export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
}

class ApiService {
  // Generic fetch helper
  private async fetchHelper<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return { data, error: null };
    } catch (error) {
      return {
        data: null,
        error: error instanceof Error ? error.message : 'An unknown error occurred',
      };
    }
  }

  // Health endpoints
  async getHealth(): Promise<ApiResponse<any>> {
    return this.fetchHelper(`${API_BASE_URL}/health`);
  }

  // Ingestion endpoints
  async ingestJson(data: any): Promise<ApiResponse<any>> {
    return this.fetchHelper(`${API_BASE_URL}/ingest/json`, {
      method: 'POST',
      body: JSON.stringify({ supplier_data: data }),
    });
  }

  async ingestFile(file: File): Promise<ApiResponse<any>> {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`${API_BASE_URL}/ingest/file`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return { data, error: null };
    } catch (error) {
      return {
        data: null,
        error: error instanceof Error ? error.message : 'An unknown error occurred',
      };
    }
  }

  // Verification endpoints
  async verifyReport(reportId: string): Promise<ApiResponse<any>> {
    return this.fetchHelper(`${API_BASE_URL}/verify/${reportId}`);
  }
}

export const apiService = new ApiService();