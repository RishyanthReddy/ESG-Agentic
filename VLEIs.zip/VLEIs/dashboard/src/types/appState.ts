// Define TypeScript types for the application state

export interface HealthComponent {
  status: 'healthy' | 'degraded' | 'unhealthy' | 'timeout';
  response_time?: number;
  details?: string | object;
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  components: {
    llm?: HealthComponent;
    blockchain?: HealthComponent;
  };
}

export interface IngestRequest {
  supplier_data: Record<string, any>;
  config?: Record<string, any>;
}

export interface IngestResponse {
  status: string;
  message: string;
  final_state: Record<string, any>;
}

export interface VerificationResponse {
  report_id: string;
  report_data: Record<string, any> | null;
  vc_jwt: string | null;
  blockchain_hashes: string[];
  verification_status: string;
  message: string;
}

export interface AppState {
  health: HealthStatus | null;
  reports: IngestResponse[];
  currentReport: VerificationResponse | null;
}