# ESG Intelligence Platform Dashboard

This is a Next.js 15 dashboard for the ESG Intelligence Platform, built with React 19 and TypeScript.

## Features

- Real-time monitoring of ESG data
- Report verification capabilities
- Data ingestion through JSON or file upload
- System health monitoring
- State management with Zustand
- TypeScript type safety

## Tech Stack

- Next.js 15
- React 19
- TypeScript 5.3
- Zustand for state management
- Tailwind CSS for styling

## Getting Started

First, install the dependencies:

```bash
npm install
# or
yarn install
# or
pnpm install
```

Then, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the dashboard.

## Project Structure

```
dashboard/
├── src/
│   ├── app/                 # Next.js app router pages
│   ├── components/          # React components
│   ├── services/            # API service layer
│   ├── stores/              # Zustand stores
│   └── types/               # TypeScript types
├── public/                  # Static assets
├── package.json             # Project dependencies
└── tsconfig.json            # TypeScript configuration
```

## API Integration

The dashboard connects to the ESG Intelligence Platform API at `http://localhost:8000` with the following endpoints:

- `GET /` - Root endpoint
- `GET /health` - System health status
- `POST /ingest/json` - JSON data ingestion
- `POST /ingest/file` - File upload ingestion
- `GET /verify/{report_id}` - Report verification

## State Management

We use Zustand for state management with persistence to localStorage. The store includes:

- System health data
- Processed reports
- Current report being viewed
- State logging for fallback scenarios

## Fallback Scripts

The dashboard functionality is replicated in CLI scripts located in the `demo_scripts/` directory:

- `api_test_suite.sh` - Tests all API endpoints
- `state_simulation.py` - Maintains application state and demonstrates data flow
- `api_responses.json` - Documents API response structures

These scripts can be used as fallback mechanisms when the frontend is not available.