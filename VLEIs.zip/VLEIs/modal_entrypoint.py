"""
Modal Deployment Entrypoint for ESG Intelligence Platform

This module configures the application for deployment on the Modal platform
with GPU acceleration for ML workloads.
"""

import modal
from pathlib import Path

# Import the FastAPI app from main.py
from main import app as fastapi_app

# Create Modal image with required dependencies
image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install_from_requirements("requirements.txt")
    .apt_install("git")
)

# Create Modal app
app = modal.App(
    "esg-intelligence-platform",
    image=image
)

# Mount the current directory to make source code available
mounts = [
    modal.Mount.from_local_dir(
        Path(__file__).parent, 
        remote_path="/app",
        condition=lambda p: not any(part.startswith('.') for part in p.parts) and not p.name.endswith('.pyc')
    )
]

# Define GPU configuration
GPU_CONFIG = modal.gpu.A10G()


@app.function(
    gpu=GPU_CONFIG,
    mounts=mounts,
    allow_concurrent_inputs=10,
    container_idle_timeout=300,
    timeout=3600
)
@modal.asgi_app()
def fastapi():
    """
    Deploy the FastAPI application on Modal with GPU support.
    
    Returns:
        FastAPI app configured for Modal deployment
    """
    return fastapi_app


@app.function(
    gpu=GPU_CONFIG,
    mounts=mounts,
    timeout=3600
)
def run_anomaly_detection(supplier_data: dict):
    """
    Run anomaly detection with GPU acceleration.
    
    Args:
        supplier_data: Supplier ESG data for anomaly detection
        
    Returns:
        dict: Anomaly detection results
    """
    # Import the anomaly detection tool
    from src.tools.esg import Scope3AnomalyPredictorTool
    
    try:
        # Initialize the anomaly detection tool
        detector = Scope3AnomalyPredictorTool()
        
        # Run anomaly detection
        results = detector.run(supplier_data)
        
        return results
    except Exception as e:
        return {"error": str(e), "success": False}


@app.function(
    gpu=GPU_CONFIG,
    mounts=mounts,
    timeout=3600
)
def run_visualization_with_path_highlighting(state_data: dict):
    """
    Run visualization with path highlighting using GPU acceleration.
    
    Args:
        state_data: Application state data for visualization
        
    Returns:
        dict: Visualization data with path highlighting
    """
    # Import the visualization agent
    from src.agents.visualization import visualization_agent
    
    try:
        # Run visualization agent
        results = visualization_agent(state_data)
        
        return results
    except Exception as e:
        return {"error": str(e), "success": False}


@app.function(
    gpu=GPU_CONFIG,
    mounts=mounts,
    timeout=1800
)
def batch_process_esg_data(batch_data: list):
    """
    Batch process ESG data with GPU acceleration.
    
    Args:
        batch_data: List of supplier ESG data for processing
        
    Returns:
        list: Processed results for each data item
    """
    results = []
    
    # Process each item in the batch
    for data in batch_data:
        try:
            # Import necessary tools
            from src.tools.esg import Scope3AnomalyPredictorTool
            
            # Run anomaly detection on each item
            detector = Scope3AnomalyPredictorTool()
            result = detector.run(data)
            results.append(result)
        except Exception as e:
            results.append({"error": str(e), "success": False})
    
    return results


@app.local_entrypoint()
def main():
    """
    Local entrypoint for testing the Modal deployment.
    """
    print("ESG Intelligence Platform - Modal Deployment")
    print("Use 'modal deploy modal_entrypoint.py' to deploy to Modal")
    print("Use 'modal serve modal_entrypoint.py' for development")