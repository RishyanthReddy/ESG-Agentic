"""
Public Verification Portal for ESG Reports
This Streamlit app allows stakeholders to verify the authenticity of ESG reports
by entering a report ID and checking the associated cryptographic proofs.
"""

import streamlit as st
import requests
import json
import time
import os
from typing import Dict, Any, Optional

# Set page configuration
st.set_page_config(
    page_title="ESG Report Verification Portal",
    page_icon="✅",
    layout="centered"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .report-id-input {
        margin-bottom: 20px;
    }
    .verification-result {
        padding: 20px;
        border-radius: 10px;
        margin-top: 20px;
    }
    .success {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
    }
    .error {
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
    }
    .warning {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
    }
    .info {
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        color: #0c5460;
    }
    .verification-section {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 5px;
        padding: 15px;
        margin: 10px 0;
    }
    .verification-header {
        font-weight: bold;
        color: #495057;
        margin-bottom: 10px;
    }
    .verification-item {
        margin: 5px 0;
    }
    .status-icon {
        font-size: 1.2em;
        margin-right: 10px;
    }
    </style>
""", unsafe_allow_html=True)

# Main title and description
st.title("✅ ESG Report Verification Portal")
st.markdown("Verify the authenticity of ESG reports by entering the report ID below.")

# Information section about verification process
with st.expander("ℹ️ How Report Verification Works", expanded=False):
    st.markdown("""
    ### Verification Process
    
    1. **Report Retrieval**: System retrieves the requested ESG report and associated cryptographic proofs
    2. **Stored Proof Verification**: Verification using previously stored cryptographic proofs
    3. **Live Verification**: Real-time verification against external trusted services:
       - **Azure Verified ID**: Verifies the authenticity of Verifiable Credentials
       - **Infura Blockchain**: Confirms data integrity on the Ethereum blockchain
    4. **Result Display**: Comprehensive verification results showing both stored and live verification status
    
    This multi-layered approach ensures the integrity and authenticity of ESG reports through:
    - **Verifiable Credentials**: Cryptographically signed credentials
    - **Blockchain Anchoring**: Immutable proof of existence on the Ethereum blockchain
    - **Real-time Verification**: Direct validation against external trusted services
    """)

# Initialize session state
if 'verification_result' not in st.session_state:
    st.session_state.verification_result = None
if 'verification_in_progress' not in st.session_state:
    st.session_state.verification_in_progress = False

# Get backend API URL from environment or use default
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

def verify_report(report_id: str) -> Optional[Dict[Any, Any]]:
    """
    Call the backend verification endpoint to verify a report by ID
    
    Args:
        report_id (str): The ID of the report to verify
        
    Returns:
        Dict containing verification results or None if error
    """
    try:
        # Make request to verification endpoint
        response = requests.get(
            f"{API_BASE_URL}/verify/{report_id}",
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"Verification API returned status code {response.status_code}")
            try:
                error_data = response.json()
                st.error(f"Error details: {error_data.get('detail', 'Unknown error')}")
            except:
                st.error(f"Error response: {response.text}")
            return None
            
    except requests.exceptions.Timeout:
        st.error("Request timed out. The verification service may be busy. Please try again.")
        return None
    except requests.exceptions.ConnectionError:
        st.error("Could not connect to the verification service. Please check if the service is running.")
        return None
    except Exception as e:
        st.error(f"An unexpected error occurred: {str(e)}")
        return None

def display_verification_result(result: Dict[Any, Any]):
    """
    Display the verification result in a user-friendly format
    
    Args:
        result (Dict): The verification result from the API
    """
    if not result:
        st.markdown(
            "<div class='verification-result error'>"
            "<h3>❌ Verification Failed</h3>"
            "<p>No verification data available.</p>"
            "</div>",
            unsafe_allow_html=True
        )
        return
    
    # Display report information
    st.subheader("📋 Report Information")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Report ID:** {result.get('report_id', 'N/A')}")
    with col2:
        st.markdown(f"**Status:** {result.get('verification_status', 'N/A').title()}")
    
    st.markdown(f"**Message:** {result.get('message', 'N/A')}")
    
    # Create tabs for different verification aspects
    tab1, tab2, tab3 = st.tabs(["📄 Report Data", "🔐 Stored Proofs", "🔍 Live Verification"])
    
    # Tab 1: Report Data
    with tab1:
        report_data = result.get('report_data')
        if report_data:
            st.subheader("Report Details")
            st.json(report_data)
        else:
            st.info("No report data available.")
    
    # Tab 2: Stored Proofs
    with tab2:
        st.markdown("<div class='verification-section'>", unsafe_allow_html=True)
        st.markdown("<div class='verification-header'>Stored Cryptographic Proofs</div>", unsafe_allow_html=True)
        
        # Display VC JWT if available
        vc_jwt = result.get('vc_jwt')
        if vc_jwt:
            st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
            st.markdown("✅ <strong>Verifiable Credential (JWT)</strong>", unsafe_allow_html=True)
            with st.expander("Click to view VC JWT"):
                st.code(vc_jwt, language="json")
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
            st.markdown("❌ Verifiable Credential (JWT) not found", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
        
        # Display blockchain hashes if available
        blockchain_hashes = result.get('blockchain_hashes', [])
        if blockchain_hashes:
            st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
            st.markdown("✅ <strong>Blockchain Hashes</strong>", unsafe_allow_html=True)
            for i, hash_value in enumerate(blockchain_hashes):
                st.text(f"Hash {i+1}: {hash_value}")
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
            st.markdown("❌ Blockchain hashes not found", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Tab 3: Live Verification (Placeholder for future implementation)
    with tab3:
        st.info("🔄 Live verification with external services is in progress...")
        st.markdown("""
        In a full implementation, this section would show:
        - Real-time verification with Azure Verified ID
        - Blockchain verification via Infura
        - Detailed status of each verification step
        
        For now, please refer to the stored proofs for verification information.
        """)
        
        # This is where live verification would be implemented
        # In a production environment, this would make direct API calls to:
        # 1. Azure Verified ID service to verify the VC JWT
        # 2. Infura service to verify blockchain hashes on Ethereum
        
        st.markdown("<div class='verification-section'>", unsafe_allow_html=True)
        st.markdown("<div class='verification-header'>Live Verification Status</div>", unsafe_allow_html=True)
        
        st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
        st.markdown("⏳ <strong>Azure Verified ID Verification</strong> - Pending implementation", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("<div class='verification-item'>", unsafe_allow_html=True)
        st.markdown("⏳ <strong>Infura Blockchain Verification</strong> - Pending implementation", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)

# Create the input form
with st.form("verification_form"):
    report_id = st.text_input(
        "Report ID",
        placeholder="Enter the report ID to verify",
        help="Enter the unique identifier for the ESG report you want to verify",
        key="report_id_input"
    )
    
    submitted = st.form_submit_button("Verify Report")
    
    if submitted:
        if not report_id:
            st.warning("Please enter a report ID to verify.")
        else:
            # Set verification in progress
            st.session_state.verification_in_progress = True
            st.session_state.verification_result = None
            
            # Show progress indicator
            with st.spinner("Verifying report..."):
                # Perform verification
                result = verify_report(report_id)
                st.session_state.verification_result = result
                st.session_state.verification_in_progress = False

# Display verification result if available
if st.session_state.verification_result is not None:
    if st.session_state.verification_result:
        st.markdown(
            "<div class='verification-result success'>"
            "<h3>✅ Verification Successful</h3>"
            "<p>Report and associated cryptographic proofs retrieved successfully.</p>"
            "</div>",
            unsafe_allow_html=True
        )
        display_verification_result(st.session_state.verification_result)
    else:
        st.markdown(
            "<div class='verification-result error'>"
            "<h3>❌ Verification Failed</h3>"
            "<p>Please check the report ID and try again.</p>"
            "</div>",
            unsafe_allow_html=True
        )

# Footer
st.markdown("---")
st.caption("ESG Intelligence Platform - Ensuring transparency and trust in ESG reporting")