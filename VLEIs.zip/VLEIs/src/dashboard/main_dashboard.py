"""
Main Stakeholder Dashboard for VLEIs Platform

This Streamlit application provides a real-time, interactive dashboard for internal stakeholders
to monitor ESG performance, view provenance graphs, and analyze decarbonization pathways.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import altair as alt
import json
import os
from datetime import datetime
import networkx as nx
from typing import Dict, Any, List, Optional

# Add src to path so we can import our modules
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.state.models import AppState
from src.tools.esg import CarbonSutraTool, Scope3DataPoint

# Conditional import of streamlit authenticator for secure access
try:
    import streamlit_authenticator as stauth
    from streamlit_autorefresh import st_autorefresh
    AUTH_AVAILABLE = True
except ImportError:
    AUTH_AVAILABLE = False
    stauth = None
    st_autorefresh = lambda *args, **kwargs: None

# Page configuration
st.set_page_config(
    page_title="VLEIs Stakeholder Dashboard",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional UI
st.markdown("""
<style>
    .reportview-container {
        background: #f0f2f6;
    }
    .sidebar .sidebar-content {
        background: #ffffff;
    }
    .stDataFrame {
        border: 1px solid #e0e0e0;
        border-radius: 5px;
    }
    h1, h2, h3 {
        color: #1f3a5f;
    }
    .metric-card {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
    }
    .metric-value {
        font-size: 2em;
        font-weight: bold;
        color: #1f3a5f;
    }
    .metric-label {
        font-size: 1em;
        color: #666666;
    }
</style>
""", unsafe_allow_html=True)


def init_auth():
    """
    Initialize authentication if available.
    """
    if not AUTH_AVAILABLE:
        return None
    
    # Authentication setup
    # In a real application, these would be stored securely
    credentials = {
        "usernames": {
            "admin": {
                "name": "System Administrator",
                "password": "admin123"  # In practice, this should be hashed
            },
            "analyst": {
                "name": "Data Analyst", 
                "password": "analyst123"
            },
            "manager": {
                "name": "Compliance Manager",
                "password": "manager123"
            }
        }
    }

    # Hash passwords
    for username in credentials["usernames"]:
        credentials["usernames"][username]["password"] = stauth.Hasher([credentials["usernames"][username]["password"]]).generate()[0]

    authenticator = stauth.Authenticate(
        credentials,
        "vleis_dashboard_cookie",
        "vleis_dashboard_key",
        30
    )
    
    return authenticator


# Authentication widget
authenticator = init_auth()
if authenticator:
    authenticator.login()
    name = st.session_state["name"]
    authentication_status = st.session_state["authentication_status"]
    username = st.session_state["username"]
else:
    # Mock authentication for testing
    name, authentication_status, username = "Test User", True, "test"


def load_sample_state() -> AppState:
    """
    Load a sample AppState for demonstration purposes.
    In a real application, this would connect to the actual application state.
    """
    # Create sample data that mimics the AppState structure
    sample_data = {
        "workflow_status": "reporting_completed",
        "workflow_step": 5,
        "processing_results": {
            "carbon_metrics": {
                "total_carbon_footprint": {
                    "co2e": 1250.5,
                    "co2e_unit": "kg"
                },
                "carbon_footprints": [
                    {
                        "activity_id": "electricity-energy_source_grid-average",
                        "amount": 1000,
                        "unit": "kwh",
                        "region": "US",
                        "co2e": 500.2,
                        "co2e_unit": "kg"
                    },
                    {
                        "activity_id": "passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                        "amount": 2000,
                        "unit": "km",
                        "region": "US",
                        "co2e": 750.3,
                        "co2e_unit": "kg"
                    }
                ]
            },
            "esg_scores": {
                "environmental_score": 85.5,
                "social_score": 78.2,
                "governance_score": 92.1,
                "overall_score": 85.3
            },
            "verification_results": {
                "credentials_verified": 12,
                "credentials_pending": 3,
                "credentials_failed": 1
            }
        },
        "visualization_assets": {
            "provenance_graph": {
                "node_count": 15,
                "edge_count": 22,
                "created_at": datetime.utcnow().isoformat()
            },
            "serialized_graph": {
                "json_data": json.dumps({
                    "nodes": [
                        {"id": "supplier:abc_corp", "name": "ABC Corporation", "type": "supplier"},
                        {"id": "agent:ingestion", "name": "Ingestion Agent", "type": "agent"},
                        {"id": "artifact:esg_data", "name": "ESG Data Q1", "type": "artifact"},
                        {"id": "agent:verification", "name": "Verification Agent", "type": "agent"},
                        {"id": "blockchain:ethereum", "name": "Ethereum", "type": "blockchain"}
                    ],
                    "links": [
                        {"source": "supplier:abc_corp", "target": "agent:ingestion"},
                        {"source": "agent:ingestion", "target": "artifact:esg_data"},
                        {"source": "artifact:esg_data", "target": "agent:verification"},
                        {"source": "agent:verification", "target": "blockchain:ethereum"}
                    ]
                }),
                "format": "threejs",
                "size": 512,
                "compressed": True,
                "optimized": True,
                "created_at": datetime.utcnow().isoformat()
            },
            "highlighted_path": {
                "success": True,
                "path": ["supplier:abc_corp", "agent:ingestion", "artifact:esg_data", "agent:verification", "blockchain:ethereum"],
                "path_length": 4,
                "source": "supplier:abc_corp",
                "target": "blockchain:ethereum",
                "node_count": 5,
                "edge_count": 4
            }
        },
        "gri_reports": [],
        "sasb_reports": [],
        "tcfd_reports": [],
        "csrd_reports": [],
        "agent_trace": [
            {
                "agent": "ingestion_agent",
                "action": "data_ingested",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        "blockchain_log": [
            {
                "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                "data_hash": "a1b2c3d4e5f67890",
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    }
    
    return AppState(**sample_data)


def display_key_metrics(state: AppState):
    """
    Display key ESG metrics in the dashboard.
    """
    st.header("Key Performance Indicators")
    
    # Create columns for metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # Carbon footprint metric
    with col1:
        carbon_footprint = state.processing_results.get("carbon_metrics", {}).get("total_carbon_footprint", {})
        co2e_value = carbon_footprint.get("co2e", 0)
        co2e_unit = carbon_footprint.get("co2e_unit", "kg")
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{co2e_value:.1f} {co2e_unit}</div>
            <div class="metric-label">Total Carbon Footprint</div>
        </div>
        """, unsafe_allow_html=True)
    
    # ESG scores
    with col2:
        esg_scores = state.processing_results.get("esg_scores", {})
        env_score = esg_scores.get("environmental_score", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{env_score:.1f}/100</div>
            <div class="metric-label">Environmental Score</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        social_score = esg_scores.get("social_score", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{social_score:.1f}/100</div>
            <div class="metric-label">Social Score</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        gov_score = esg_scores.get("governance_score", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{gov_score:.1f}/100</div>
            <div class="metric-label">Governance Score</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Additional metrics row
    col5, col6, col7, col8 = st.columns(4)
    
    with col5:
        overall_score = esg_scores.get("overall_score", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{overall_score:.1f}/100</div>
            <div class="metric-label">Overall ESG Score</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col6:
        verification_results = state.processing_results.get("verification_results", {})
        verified_count = verification_results.get("credentials_verified", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{verified_count}</div>
            <div class="metric-label">Credentials Verified</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col7:
        pending_count = verification_results.get("credentials_pending", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{pending_count}</div>
            <div class="metric-label">Credentials Pending</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col8:
        failed_count = verification_results.get("credentials_failed", 0)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value">{failed_count}</div>
            <div class="metric-label">Credentials Failed</div>
        </div>
        """, unsafe_allow_html=True)


def display_provenance_graph(state: AppState):
    """
    Display the provenance graph visualization.
    """
    st.header("Data Provenance Visualization")
    
    # Check if visualization assets exist
    if not state.visualization_assets:
        st.info("No provenance graph data available.")
        return
    
    # Get serialized graph data
    serialized_graph = state.visualization_assets.get("serialized_graph", {})
    if not serialized_graph:
        st.info("No graph data available.")
        return
    
    # Parse the JSON data
    try:
        graph_data = json.loads(serialized_graph.get("json_data", "{}"))
    except json.JSONDecodeError:
        st.error("Error parsing graph data.")
        return
    
    # Create tabs for different views
    tab1, tab2 = st.tabs(["Graph Visualization", "Path Highlighting"])
    
    with tab1:
        # Display basic graph information
        provenance_info = state.visualization_assets.get("provenance_graph", {})
        st.subheader("Graph Statistics")
        col1, col2, col3 = st.columns(3)
        col1.metric("Nodes", provenance_info.get("node_count", 0))
        col2.metric("Edges", provenance_info.get("edge_count", 0))
        col3.metric("Last Updated", provenance_info.get("created_at", "N/A")[:10])
        
        # Display a simple visualization of the graph structure
        if graph_data:
            nodes = graph_data.get("nodes", [])
            links = graph_data.get("links", [])
            
            # Create a DataFrame for nodes
            if nodes:
                node_df = pd.DataFrame(nodes)
                st.subheader("Node Types")
                node_type_counts = node_df["type"].value_counts()
                fig = px.pie(values=node_type_counts.values, names=node_type_counts.index)
                st.plotly_chart(fig, use_container_width=True)
            
            # Create a DataFrame for links
            if links:
                link_df = pd.DataFrame(links)
                st.subheader("Data Flow")
                st.dataframe(link_df, use_container_width=True)
    
    with tab2:
        # Display path highlighting information
        highlighted_path = state.visualization_assets.get("highlighted_path", {})
        if highlighted_path.get("success"):
            st.subheader("Highlighted Path")
            st.success(f"Path from {highlighted_path.get('source')} to {highlighted_path.get('target')}")
            
            # Display path details
            path_nodes = highlighted_path.get("path", [])
            st.write("Path sequence:")
            for i, node in enumerate(path_nodes):
                st.write(f"{i+1}. {node}")
            
            # Path metrics
            col1, col2, col3 = st.columns(3)
            col1.metric("Path Length", highlighted_path.get("path_length", 0))
            col2.metric("Nodes in Path", highlighted_path.get("node_count", 0))
            col3.metric("Edges in Path", highlighted_path.get("edge_count", 0))
        else:
            st.info("No highlighted path available.")


def display_carbonsutra_visualizations(state: AppState):
    """
    Display CarbonSutra decarbonization pathway visualizations.
    """
    st.header("Decarbonization Pathways")
    
    # In a real implementation, this would fetch data from the CarbonSutra API
    # For this demo, we'll create sample data
    
    # Sample decarbonization data
    years = list(range(2023, 2031))
    current_emissions = [1200, 1150, 1300, 1250, 1180, 1100, 1050, 1000]
    projected_emissions = [1100, 1050, 1150, 1100, 1020, 950, 900, 850]
    target_emissions = [900, 850, 950, 900, 820, 750, 700, 650]
    
    # Create a DataFrame for the emissions data
    emissions_data = pd.DataFrame({
        "Year": years[:len(current_emissions)],
        "Current": current_emissions,
        "Projected": projected_emissions,
        "Target": target_emissions
    })
    
    # Melt the DataFrame for easier plotting
    emissions_melted = emissions_data.melt(id_vars=["Year"], var_name="Scenario", value_name="Emissions")
    
    # Create tabs for different visualizations
    tab1, tab2, tab3 = st.tabs(["Emissions Trend", "Scenario Comparison", "Key Metrics"])
    
    with tab1:
        # Line chart showing emissions trends
        fig = px.line(emissions_melted, x="Year", y="Emissions", color="Scenario", 
                      title="Emissions Trends by Scenario",
                      markers=True)
        fig.update_layout(
            xaxis_title="Year",
            yaxis_title="CO2 Emissions (tons)",
            legend_title="Scenario"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        # Bar chart comparing scenarios for the latest year
        latest_year_data = emissions_data[emissions_data["Year"] == emissions_data["Year"].max()]
        latest_year_melted = latest_year_data.melt(id_vars=["Year"], var_name="Scenario", value_name="Emissions")
        
        fig = px.bar(latest_year_melted, x="Scenario", y="Emissions",
                     title=f"Emissions Comparison for {emissions_data['Year'].max()}",
                     color="Scenario")
        fig.update_layout(
            xaxis_title="Scenario",
            yaxis_title="CO2 Emissions (tons)"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        # Display key business metrics
        st.subheader("Business Impact Metrics")
        
        # Calculate key metrics
        baseline_emissions = current_emissions[0]
        projected_reduction = baseline_emissions - projected_emissions[-1]
        target_reduction = baseline_emissions - target_emissions[-1]
        cost_savings = 125000  # Sample value
        roi_years = 2.8  # Sample value
        
        # Display metrics in cards
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Baseline Emissions", f"{baseline_emissions:,} tons")
        col2.metric("Projected Reduction", f"{projected_reduction:,} tons")
        col3.metric("Target Reduction", f"{target_reduction:,} tons")
        col4.metric("Cost Savings", f"${cost_savings:,}")
        
        col5, col6 = st.columns(2)
        col5.metric("ROI", f"{roi_years} years")
        col6.metric("Reduction Potential", f"{(target_reduction/baseline_emissions)*100:.1f}%")


def display_agent_activity(state: AppState):
    """
    Display agent activity and blockchain logs.
    """
    st.header("System Activity")
    
    # Create tabs for agent traces and blockchain logs
    tab1, tab2 = st.tabs(["Agent Activity", "Blockchain Transactions"])
    
    with tab1:
        if state.agent_trace:
            # Convert agent trace to DataFrame
            agent_df = pd.DataFrame(state.agent_trace)
            agent_df["timestamp"] = pd.to_datetime(agent_df["timestamp"])
            agent_df = agent_df.sort_values("timestamp", ascending=False)
            
            st.subheader("Recent Agent Activity")
            st.dataframe(agent_df, use_container_width=True)
            
            # Show agent activity chart
            if "agent" in agent_df.columns:
                agent_counts = agent_df["agent"].value_counts()
                fig = px.bar(x=agent_counts.index, y=agent_counts.values,
                             labels={"x": "Agent", "y": "Activity Count"},
                             title="Agent Activity Distribution")
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No agent activity data available.")
    
    with tab2:
        if state.blockchain_log:
            # Convert blockchain log to DataFrame
            blockchain_df = pd.DataFrame(state.blockchain_log)
            blockchain_df["timestamp"] = pd.to_datetime(blockchain_df["timestamp"])
            blockchain_df = blockchain_df.sort_values("timestamp", ascending=False)
            
            st.subheader("Recent Blockchain Transactions")
            st.dataframe(blockchain_df[["transaction_hash", "data_hash", "timestamp"]], use_container_width=True)
            
            # Show transaction timeline
            if not blockchain_df.empty:
                fig = px.scatter(blockchain_df, x="timestamp", y="gas_used",
                                 title="Blockchain Transaction Timeline",
                                 hover_data=["transaction_hash"])
                fig.update_layout(
                    xaxis_title="Timestamp",
                    yaxis_title="Gas Used"
                )
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No blockchain transaction data available.")


def main():
    """
    Main function for the Streamlit dashboard.
    """
    # Check authentication
    if AUTH_AVAILABLE and authentication_status is False:
        st.error("Username/password is incorrect")
        return
    elif AUTH_AVAILABLE and authentication_status is None:
        st.warning("Please enter your username and password")
        return
    
    # Authenticated content
    if AUTH_AVAILABLE:
        authenticator.logout("Logout", "sidebar")
        st.sidebar.title(f"Welcome {name}")
    
    # Auto-refresh every 60 seconds
    st_autorefresh(interval=60000, key="data_refresh")
    
    # Title
    st.title("🌍 VLEIs Stakeholder Dashboard")
    st.markdown("Real-time ESG performance monitoring and data provenance visualization")
    
    # Load sample state (in a real app, this would connect to the actual AppState)
    state = load_sample_state()
    
    # Display workflow status
    st.sidebar.subheader("Workflow Status")
    st.sidebar.write(f"Status: {state.workflow_status}")
    st.sidebar.write(f"Step: {state.workflow_step}")
    
    # Create tabs for different sections
    tab1, tab2, tab3, tab4 = st.tabs([
        "Key Metrics", 
        "Provenance Graph", 
        "Decarbonization Pathways", 
        "System Activity"
    ])
    
    with tab1:
        display_key_metrics(state)
    
    with tab2:
        display_provenance_graph(state)
    
    with tab3:
        display_carbonsutra_visualizations(state)
    
    with tab4:
        display_agent_activity(state)
    
    # Footer
    st.markdown("---")
    st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | VLEIs Platform v1.0")


if __name__ == "__main__":
    main()