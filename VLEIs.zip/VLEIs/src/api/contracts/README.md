# API Contracts and Mock Services

This directory contains the OpenAPI specifications for the ESG Intelligence Platform API, along with documentation and tools for API contract testing.

## OpenAPI Specification

The API is documented using OpenAPI 3.0 specification in [openapi.yaml](openapi.yaml). This specification includes:

- Complete endpoint definitions
- Request/response schemas
- Example data structures
- Server definitions

## Usage

You can view the API documentation using Swagger UI by:

1. Installing Swagger UI:
   ```bash
   npm install -g http-server
   ```

2. Serving the documentation:
   ```bash
   http-server . -o
   ```

Alternatively, you can copy the openapi.yaml content into the [Swagger Editor](https://editor.swagger.io/) to view and interact with the documentation.

## Demo Scripts

The [demo_scripts](../../demo_scripts/) directory contains bash scripts for testing and demonstrating the API functionality:

1. `health_check.sh` - Checks the health status of the API
2. `full_system_status.sh` - Performs a comprehensive check of all system components
3. `api_test_suite.sh` - Runs a complete test suite against all API endpoints
4. `frontend_fallback.md` - Documentation for using curl commands as a frontend alternative

## Contract Testing

API contracts are validated using Pact tests located in the [tests](../../tests/) directory:

- [test_api_contracts_and_scripts.py](../../tests/test_api_contracts_and_scripts.py) - Unit tests for API schema compliance and script execution
- [test_api_pact_contracts.py](../../tests/test_api_pact_contracts.py) - Pact contract tests for consumer/provider compatibility

## Fallback Configuration

The [.env.example](../../demo_scripts/.env.example) file in the demo_scripts directory provides environment configuration templates with fallback endpoint definitions for different environments.

## Endpoints Overview

The ESG Intelligence Platform API provides the following endpoints:

1. `GET /` - Root endpoint returning a welcome message
2. `GET /health` - Health check endpoint for system components
3. `POST /ingest/json` - JSON data ingestion and processing
4. `POST /ingest/file` - File upload ingestion and processing
5. `GET /verify/{report_id}` - Report verification by ID

Each endpoint is fully documented in the OpenAPI specification with examples and schema definitions.