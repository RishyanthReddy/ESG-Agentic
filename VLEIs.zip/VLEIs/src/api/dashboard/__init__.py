"""
Dashboard API package initialization
"""