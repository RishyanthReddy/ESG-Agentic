"""
Dashboard API models for request/response validation
"""
from pydantic import BaseModel
from typing import Dict, List, Optional, Any, Union
from datetime import datetime


class DashboardMetrics(BaseModel):
    """Model for dashboard metrics data"""
    timestamp: datetime
    api_response_time: Dict[str, Union[float, int]]
    accuracy: Dict[str, float]
    system_health: Dict[str, Any]
    
    
class ESGScoreData(BaseModel):
    """Model for ESG score data"""
    timestamp: datetime
    esg_scores: List[Dict[str, Any]]
    supplier_compliance: List[Dict[str, Any]]
    
    
class CarbonData(BaseModel):
    """Model for carbon footprint data"""
    timestamp: datetime
    carbon_emissions: List[Dict[str, Any]]
    reduction_targets: List[Dict[str, Any]]
    
    
class ProvenanceData(BaseModel):
    """Model for supply chain provenance data"""
    timestamp: datetime
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
    paths: List[Dict[str, Any]]
    
    
class DashboardResponse(BaseModel):
    """Model for consolidated dashboard response"""
    status: str
    message: str
    timestamp: datetime
    data: Optional[Dict[str, Any]] = None
    cache_hit: bool = False
    
    
class MetricsRequest(BaseModel):
    """Model for metrics request parameters"""
    time_range: str = "24h"
    refresh_cache: bool = False
    format: str = "json"
    
    
class RealTimeDataRequest(BaseModel):
    """Model for real-time data request"""
    data_type: str
    interval: int = 1000  # milliseconds