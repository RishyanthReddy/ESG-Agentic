"""
Dashboard API routes for FastAPI application
"""
from fastapi import APIRouter, WebSocket, Depends, Query
from fastapi.responses import JSONResponse
from typing import Dict, Any, Optional
import asyncio
import json
from datetime import datetime
from loguru import logger
from .models import (
    DashboardResponse, 
    MetricsRequest, 
    RealTimeDataRequest,
    DashboardMetrics,
    ESGScoreData,
    CarbonData,
    ProvenanceData
)
from .service import dashboard_service
from .cache import dashboard_cache


# Create router for dashboard endpoints
router = APIRouter(
    prefix="/api/v1/dashboard",
    tags=["dashboard"],
    responses={404: {"description": "Not found"}},
)


@router.get("/health", response_model=DashboardResponse)
async def dashboard_health():
    """Health check endpoint for dashboard API"""
    return DashboardResponse(
        status="success",
        message="Dashboard API is healthy",
        timestamp=datetime.now(),
        data={"service": "dashboard_api", "status": "operational"}
    )


@router.get("/metrics", response_model=DashboardResponse)
async def get_dashboard_metrics(
    time_range: str = Query("24h", description="Time range for metrics"),
    refresh_cache: bool = Query(False, description="Force refresh cache")
):
    """Get dashboard metrics data"""
    try:
        metrics_data = await dashboard_service.get_system_metrics(refresh_cache=refresh_cache)
        return DashboardResponse(
            status="success",
            message="Metrics data retrieved successfully",
            timestamp=datetime.now(),
            data=metrics_data
        )
    except Exception as e:
        logger.error(f"Error retrieving metrics data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve metrics data: {str(e)}",
            timestamp=datetime.now()
        )


@router.get("/esg-scores", response_model=DashboardResponse)
async def get_esg_scores(
    refresh_cache: bool = Query(False, description="Force refresh cache")
):
    """Get ESG scores data"""
    try:
        esg_data = await dashboard_service.get_esg_scores(refresh_cache=refresh_cache)
        return DashboardResponse(
            status="success",
            message="ESG scores data retrieved successfully",
            timestamp=datetime.now(),
            data=esg_data
        )
    except Exception as e:
        logger.error(f"Error retrieving ESG scores data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve ESG scores data: {str(e)}",
            timestamp=datetime.now()
        )


@router.get("/carbon-data", response_model=DashboardResponse)
async def get_carbon_data(
    refresh_cache: bool = Query(False, description="Force refresh cache")
):
    """Get carbon footprint data"""
    try:
        carbon_data = await dashboard_service.get_carbon_data(refresh_cache=refresh_cache)
        return DashboardResponse(
            status="success",
            message="Carbon data retrieved successfully",
            timestamp=datetime.now(),
            data=carbon_data
        )
    except Exception as e:
        logger.error(f"Error retrieving carbon data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve carbon data: {str(e)}",
            timestamp=datetime.now()
        )


@router.get("/provenance-data", response_model=DashboardResponse)
async def get_provenance_data(
    refresh_cache: bool = Query(False, description="Force refresh cache")
):
    """Get supply chain provenance data"""
    try:
        provenance_data = await dashboard_service.get_provenance_data(refresh_cache=refresh_cache)
        return DashboardResponse(
            status="success",
            message="Provenance data retrieved successfully",
            timestamp=datetime.now(),
            data=provenance_data
        )
    except Exception as e:
        logger.error(f"Error retrieving provenance data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve provenance data: {str(e)}",
            timestamp=datetime.now()
        )


@router.get("/consolidated", response_model=DashboardResponse)
async def get_consolidated_dashboard_data(
    refresh_cache: bool = Query(False, description="Force refresh cache")
):
    """Get consolidated dashboard data from all sources in a single call"""
    try:
        consolidated_data = await dashboard_service.get_consolidated_dashboard_data(refresh_cache=refresh_cache)
        return DashboardResponse(**consolidated_data)
    except Exception as e:
        logger.error(f"Error retrieving consolidated dashboard data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve consolidated dashboard data: {str(e)}",
            timestamp=datetime.now()
        )


@router.post("/cache/invalidate")
async def invalidate_dashboard_cache():
    """Invalidate dashboard cache"""
    try:
        count = dashboard_cache.invalidate_dashboard_cache()
        return {
            "status": "success",
            "message": f"Cache invalidated successfully. {count} keys removed."
        }
    except Exception as e:
        logger.error(f"Error invalidating cache: {e}")
        return {
            "status": "error",
            "message": f"Failed to invalidate cache: {str(e)}"
        }


@router.websocket("/ws/realtime")
async def websocket_realtime_data(websocket: WebSocket):
    """WebSocket endpoint for real-time dashboard updates"""
    await websocket.accept()
    
    try:
        # Send initial data
        initial_data = await dashboard_service.get_consolidated_dashboard_data()
        await websocket.send_text(json.dumps(initial_data, default=str))
        
        # Send updates every 5 seconds
        while True:
            await asyncio.sleep(5)
            realtime_data = await dashboard_service.get_consolidated_dashboard_data()
            await websocket.send_text(json.dumps(realtime_data, default=str))
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await websocket.close()


@router.get("/polling/realtime")
async def polling_realtime_data():
    """Polling endpoint for real-time dashboard updates"""
    try:
        realtime_data = await dashboard_service.get_consolidated_dashboard_data()
        return DashboardResponse(**realtime_data)
    except Exception as e:
        logger.error(f"Error retrieving real-time data: {e}")
        return DashboardResponse(
            status="error",
            message=f"Failed to retrieve real-time data: {str(e)}",
            timestamp=datetime.now()
        )