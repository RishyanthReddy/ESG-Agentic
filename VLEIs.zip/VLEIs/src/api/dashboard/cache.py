"""
Dashboard API caching utilities using Redis
"""
import redis
import json
import os
from typing import Optional, Any
from datetime import datetime, timedelta
from loguru import logger


class DashboardCache:
    """Cache manager for dashboard data using Redis"""
    
    def __init__(self):
        """Initialize Redis connection"""
        redis_host = os.getenv('REDIS_HOST', 'localhost')
        redis_port = int(os.getenv('REDIS_PORT', 6379))
        redis_db = int(os.getenv('REDIS_DB', 0))
        
        try:
            self.redis_client = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=redis_db,
                decode_responses=True
            )
            # Test connection
            self.redis_client.ping()
            self.enabled = True
            logger.info("Redis cache initialized successfully")
        except Exception as e:
            logger.warning(f"Redis cache initialization failed: {e}. Cache disabled.")
            self.enabled = False
    
    def get(self, key: str) -> Optional[Any]:
        """Get data from cache"""
        if not self.enabled:
            return None
            
        try:
            data = self.redis_client.get(key)
            if data:
                return json.loads(data)
        except Exception as e:
            logger.error(f"Cache get error: {e}")
        return None
    
    def set(self, key: str, data: Any, expire: int = 300) -> bool:
        """Set data in cache with expiration time (seconds)"""
        if not self.enabled:
            return False
            
        try:
            serialized_data = json.dumps(data, default=str)
            result = self.redis_client.setex(key, expire, serialized_data)
            return result
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete data from cache"""
        if not self.enabled:
            return False
            
        try:
            result = self.redis_client.delete(key)
            return result > 0
        except Exception as e:
            logger.error(f"Cache delete error: {e}")
            return False
    
    def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern"""
        if not self.enabled:
            return 0
            
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Cache clear pattern error: {e}")
            return 0
    
    def invalidate_dashboard_cache(self) -> int:
        """Invalidate all dashboard-related cache"""
        return self.clear_pattern("dashboard:*")


# Global cache instance
dashboard_cache = DashboardCache()