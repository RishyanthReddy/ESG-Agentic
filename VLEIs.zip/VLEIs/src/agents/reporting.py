"""
Regulatory Reporting Agent

This module implements an agent responsible for mapping incoming data to various 
regulatory frameworks defined in AppState.
"""

import uuid
import json
import os
from typing import Dict, Any
from datetime import datetime
from loguru import logger
from jinja2 import Environment, FileSystemLoader, select_autoescape
from jsonschema import validate, ValidationError

from src.state.models import AppState, GRIReport, SASBReport, TCFDReport, CSRDReport
from src.agents.transformation_utils import (
    transform_to_gri, 
    transform_to_sasb, 
    transform_to_tcfd, 
    transform_to_csrd
)


class RegulatoryReportingError(Exception):
    """Custom exception for regulatory reporting failures"""
    pass


def load_template(template_name: str) -> Any:
    """Load a Jinja2 template for report generation"""
    template_dir = os.path.join(os.path.dirname(__file__), "report_templates")
    env = Environment(
        loader=FileSystemLoader(template_dir),
        autoescape=select_autoescape(['json'])
    )
    return env.get_template(template_name)


def load_schema(schema_name: str) -> Dict[str, Any]:
    """Load a JSON schema for validation"""
    schema_path = os.path.join(os.path.dirname(__file__), "report_schemas", schema_name)
    with open(schema_path, 'r') as f:
        return json.load(f)


def validate_report(report_data: Dict[str, Any], schema_name: str) -> bool:
    """Validate report data against a JSON schema"""
    try:
        schema = load_schema(schema_name)
        validate(instance=report_data, schema=schema)
        return True
    except ValidationError as e:
        logger.error(f"Report validation failed: {e.message}")
        return False


def regulatory_reporting_agent(state: AppState) -> Dict[str, Any]:
    """
    Regulatory reporting agent that maps data to various regulatory frameworks.
    
    This agent is responsible for:
    1. Mapping incoming data to various regulatory frameworks (GRI, SASB, TCFD, CSRD)
    2. Creating regulatory reports with properly formatted data
    3. Populating state.regulatory_report with formatted data
    4. Using custom ESG standard mapping engine
    5. Using Jinja2 for report generation
    6. Using JSON Schema validation for regulatory compliance
    
    Args:
        state (AppState): The current application state containing data to map
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including regulatory reports
        
    Raises:
        RegulatoryReportingError: If there's an error during regulatory reporting
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Regulatory reporting agent processing data mapping task")
    
    try:
        # Extract data to be mapped - for this implementation, we'll use the current_credential
        # or the first credential in the credentials list, or data from reports
        data_to_map = None
        company_name = "Unknown Company"
        report_year = datetime.now().year
        
        if state.current_credential:
            data_to_map = state.current_credential
            company_name = state.current_credential.claims.get("organization", {}).get("name", company_name)
        elif state.credentials:
            data_to_map = state.credentials[0]
            company_name = state.credentials[0].claims.get("organization", {}).get("name", company_name)
        elif state.gri_reports:
            data_to_map = state.gri_reports[0]
            company_name = state.gri_reports[0].company_name or company_name
            report_year = state.gri_reports[0].report_year or report_year
        elif state.sasb_reports:
            data_to_map = state.sasb_reports[0]
            company_name = state.sasb_reports[0].company_name or company_name
            report_year = state.sasb_reports[0].report_year or report_year
        elif state.tcfd_reports:
            data_to_map = state.tcfd_reports[0]
            company_name = state.tcfd_reports[0].company_name or company_name
            report_year = state.tcfd_reports[0].report_year or report_year
        elif state.csrd_reports:
            data_to_map = state.csrd_reports[0]
            company_name = state.csrd_reports[0].company_name or company_name
            report_year = state.csrd_reports[0].report_year or report_year
        else:
            # If no data is available, create a basic report with minimal data
            logger.warning(f"[{request_id}] No data found for regulatory reporting, creating minimal report")
            data_to_map = {"type": "minimal"}
        
        # Transform data to each standard
        gri_data = transform_to_gri(state.current_credential)
        sasb_data = transform_to_sasb(state.current_credential)
        tcfd_data = transform_to_tcfd(state.current_credential)
        csrd_data = transform_to_csrd(state.current_credential)
        
        # Create proper reports with the transformed data
        gri_report = GRIReport(
            company_name=company_name,
            report_year=report_year,
            general_disclosure=gri_data["general_disclosure"],
            management_approach=gri_data["management_approach"],
            topic_specific_disclosure=gri_data["topic_specific_disclosure"]
        )
        
        sasb_report = SASBReport(
            company_name=company_name,
            report_year=report_year,
            environmental_indicators=sasb_data["environmental_indicators"],
            social_indicators=sasb_data["social_indicators"],
            governance_indicators=sasb_data["governance_indicators"]
        )
        
        tcfd_report = TCFDReport(
            company_name=company_name,
            report_year=report_year,
            governance=tcfd_data["governance"],
            strategy=tcfd_data["strategy"],
            risk_management=tcfd_data["risk_management"],
            metrics_and_targets=tcfd_data["metrics_and_targets"]
        )
        
        # Create CSRD report with detailed fields
        csrd_report = CSRDReport(
            company_name=company_name,
            report_year=report_year,
            business_model=csrd_data["business_model"],
            double_materiality_assessment=csrd_data["double_materiality_assessment"],
            impact_management_process=csrd_data["impact_management_process"],
            due_diligence=csrd_data["due_diligence"],
            policies=csrd_data["policies"],
            greenhouse_gas_emissions=csrd_data["greenhouse_gas_emissions"],
            climate_risks_and_opportunities=csrd_data["climate_risks_and_opportunities"],
            climate_targets_and_actions=csrd_data["climate_targets_and_actions"],
            pollution_emissions=csrd_data["pollution_emissions"],
            pollution_prevention_measures=csrd_data["pollution_prevention_measures"],
            water_consumption_and_discharge=csrd_data["water_consumption_and_discharge"],
            marine_resources_impact=csrd_data["marine_resources_impact"],
            biodiversity_impact=csrd_data["biodiversity_impact"],
            biodiversity_protection_measures=csrd_data["biodiversity_protection_measures"],
            resource_consumption=csrd_data["resource_consumption"],
            circular_economy_metrics=csrd_data["circular_economy_metrics"],
            workforce_demographics=csrd_data["workforce_demographics"],
            workforce_health_safety=csrd_data["workforce_health_safety"],
            workforce_training=csrd_data["workforce_training"],
            value_chain_workers_assessment=csrd_data["value_chain_workers_assessment"],
            value_chain_workers_improvement=csrd_data["value_chain_workers_improvement"],
            community_impact_assessment=csrd_data["community_impact_assessment"],
            community_engagement=csrd_data["community_engagement"],
            product_safety=csrd_data["product_safety"],
            consumer_protection=csrd_data["consumer_protection"],
            governance_body=csrd_data["governance_body"],
            executive_remuneration=csrd_data["executive_remuneration"],
            prevention_of_adverse_impacts=csrd_data["prevention_of_adverse_impacts"],
            breach_reporting=csrd_data["breach_reporting"]
        )
        
        # Generate reports using Jinja2 templates
        gri_template = load_template("gri_template.jinja2")
        sasb_template = load_template("sasb_template.jinja2")
        tcfd_template = load_template("tcfd_template.jinja2")
        csrd_template = load_template("csrd_template.jinja2")
        
        gri_report_json = gri_template.render(
            company_name=company_name,
            report_year=report_year,
            generated_date=datetime.now().isoformat(),
            general_disclosure=gri_data["general_disclosure"],
            management_approach=gri_data["management_approach"],
            topic_specific_disclosure=gri_data["topic_specific_disclosure"]
        )
        
        sasb_report_json = sasb_template.render(
            company_name=company_name,
            report_year=report_year,
            generated_date=datetime.now().isoformat(),
            environmental_indicators=sasb_data["environmental_indicators"],
            social_indicators=sasb_data["social_indicators"],
            governance_indicators=sasb_data["governance_indicators"]
        )
        
        tcfd_report_json = tcfd_template.render(
            company_name=company_name,
            report_year=report_year,
            generated_date=datetime.now().isoformat(),
            governance=tcfd_data["governance"],
            strategy=tcfd_data["strategy"],
            risk_management=tcfd_data["risk_management"],
            metrics_and_targets=tcfd_data["metrics_and_targets"]
        )
        
        csrd_report_json = csrd_template.render(
            company_name=company_name,
            report_year=report_year,
            generated_date=datetime.now().isoformat(),
            business_model=csrd_data["business_model"],
            double_materiality_assessment=csrd_data["double_materiality_assessment"],
            impact_management_process=csrd_data["impact_management_process"],
            due_diligence=csrd_data["due_diligence"],
            policies=csrd_data["policies"],
            greenhouse_gas_emissions=csrd_data["greenhouse_gas_emissions"],
            climate_risks_and_opportunities=csrd_data["climate_risks_and_opportunities"],
            climate_targets_and_actions=csrd_data["climate_targets_and_actions"],
            pollution_emissions=csrd_data["pollution_emissions"],
            pollution_prevention_measures=csrd_data["pollution_prevention_measures"],
            water_consumption_and_discharge=csrd_data["water_consumption_and_discharge"],
            marine_resources_impact=csrd_data["marine_resources_impact"],
            biodiversity_impact=csrd_data["biodiversity_impact"],
            biodiversity_protection_measures=csrd_data["biodiversity_protection_measures"],
            resource_consumption=csrd_data["resource_consumption"],
            circular_economy_metrics=csrd_data["circular_economy_metrics"],
            workforce_demographics=csrd_data["workforce_demographics"],
            workforce_health_safety=csrd_data["workforce_health_safety"],
            workforce_training=csrd_data["workforce_training"],
            value_chain_workers_assessment=csrd_data["value_chain_workers_assessment"],
            value_chain_workers_improvement=csrd_data["value_chain_workers_improvement"],
            community_impact_assessment=csrd_data["community_impact_assessment"],
            community_engagement=csrd_data["community_engagement"],
            product_safety=csrd_data["product_safety"],
            consumer_protection=csrd_data["consumer_protection"],
            governance_body=csrd_data["governance_body"],
            executive_remuneration=csrd_data["executive_remuneration"],
            prevention_of_adverse_impacts=csrd_data["prevention_of_adverse_impacts"],
            breach_reporting=csrd_data["breach_reporting"]
        )
        
        # Parse JSON strings back to dicts for validation
        gri_report_dict = json.loads(gri_report_json)
        sasb_report_dict = json.loads(sasb_report_json)
        tcfd_report_dict = json.loads(tcfd_report_json)
        csrd_report_dict = json.loads(csrd_report_json)
        
        # Validate reports against schemas
        gri_valid = validate_report(gri_report_dict, "gri_schema.json")
        sasb_valid = validate_report(sasb_report_dict, "sasb_schema.json")
        tcfd_valid = validate_report(tcfd_report_dict, "tcfd_schema.json")
        csrd_valid = validate_report(csrd_report_dict, "csrd_schema.json")
        
        # Create regulatory report structure
        regulatory_report = {
            "id": str(uuid.uuid4()),
            "company_name": company_name,
            "report_year": report_year,
            "generated_date": datetime.now().isoformat(),
            "frameworks": {
                "gri": {
                    "report_id": str(gri_report.id),
                    "standards": ["GRI 101", "GRI 102", "GRI 103", "GRI 200", "GRI 300", "GRI 400"],
                    "mapped_data": gri_report_dict,
                    "valid": gri_valid
                },
                "sasb": {
                    "report_id": str(sasb_report.id),
                    "standards": ["SASB Oil and Gas", "SASB Electric Utilities"],
                    "mapped_data": sasb_report_dict,
                    "valid": sasb_valid
                },
                "tcfd": {
                    "report_id": str(tcfd_report.id),
                    "standards": ["TCFD Recommendations"],
                    "mapped_data": tcfd_report_dict,
                    "valid": tcfd_valid
                },
                "csrd": {
                    "report_id": str(csrd_report.id),
                    "standards": ["ESRS"],
                    "mapped_data": csrd_report_dict,
                    "valid": csrd_valid
                }
            },
            "summary": {
                "compliance_status": "pending_review",
                "mapped_indicators": sum([1 for valid in [gri_valid, sasb_valid, tcfd_valid, csrd_valid] if valid]),
                "data_quality_score": sum([1 for valid in [gri_valid, sasb_valid, tcfd_valid, csrd_valid] if valid]) / 4.0
            }
        }
        
        # Prepare the result updates
        result_updates = {
            "workflow_status": "regulatory_report_generated",
            "regulatory_report": regulatory_report,
            "gri_reports": [*state.gri_reports, gri_report],
            "sasb_reports": [*state.sasb_reports, sasb_report],
            "tcfd_reports": [*state.tcfd_reports, tcfd_report],
            "csrd_reports": [*state.csrd_reports, csrd_report],
            "processing_results": {
                **state.processing_results,
                "regulatory_mapping_result": {
                    "success": True,
                    "mapped_frameworks": ["GRI", "SASB", "TCFD", "CSRD"],
                    "report_ids": [str(gri_report.id), str(sasb_report.id), str(tcfd_report.id), str(csrd_report.id)],
                    "validation_results": {
                        "gri": gri_valid,
                        "sasb": sasb_valid,
                        "tcfd": tcfd_valid,
                        "csrd": csrd_valid
                    }
                }
            },
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "regulatory_reporting_agent",
                    "request_id": request_id,
                    "action": "regulatory_report_generated",
                    "frameworks_mapped": ["GRI", "SASB", "TCFD", "CSRD"],
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
        
        logger.info(f"[{request_id}] Successfully generated regulatory reports for {company_name}")
        logger.info(f"[{request_id}] Mapped to frameworks: GRI, SASB, TCFD, CSRD")
        logger.info(f"[{request_id}] Validation results - GRI: {gri_valid}, SASB: {sasb_valid}, TCFD: {tcfd_valid}, CSRD: {csrd_valid}")
        
        return result_updates
        
    except Exception as e:
        error_msg = f"Regulatory reporting failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "regulatory_reporting_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "regulatory_reporting_agent",
                    "request_id": request_id,
                    "action": "regulatory_reporting_failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }