"""
Carbon Calculation Agent

This module implements a specialized agent responsible for orchestrating carbon
footprint calculations using the Climatiq API tool.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from loguru import logger
from src.state.models import AppState, vLEICredential
from src.tools.esg import ClimatiqApiTool, ActivityData, Scope3AnomalyPredictorTool, Scope3DataPoint
from src.tools.registry import ToolRegistry


class CarbonCalculationError(Exception):
    """Custom exception for carbon calculation agent failures"""
    pass


class AnomalyDetectionError(Exception):
    """Custom exception for anomaly detection agent failures"""
    pass


def carbon_calculation_agent(state: AppState) -> Dict[str, Any]:
    """
    Specialized agent responsible for orchestrating carbon footprint calculations.
    
    This agent extracts activity data from supplier data, uses the ClimatiqApiTool
    to calculate carbon footprints, and saves results to state.processing_results.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including carbon metrics
        
    Raises:
        CarbonCalculationError: If there's an error during carbon calculation
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    
    try:
        logger.info(f"[{request_id}] Carbon calculation agent started processing")
        
        # Extract supplier data from workflow_data
        supplier_data = state.workflow_data.get("supplier_data", {})
        if not supplier_data:
            logger.warning(f"[{request_id}] No supplier data found for carbon calculation")
            return {
                "workflow_status": "carbon_calculation_skipped",
                "errors": [*state.errors, "No supplier data available for carbon calculation"]
            }
        
        # Extract activity data from supplier data
        activity_data_list = _extract_activity_data(supplier_data, request_id)
        if not activity_data_list:
            logger.warning(f"[{request_id}] No activity data found for carbon calculation")
            return {
                "workflow_status": "carbon_calculation_skipped",
                "errors": [*state.errors, "No activity data found for carbon calculation"]
            }
        
        # Get Climatiq API tool from registry or create new instance
        tool_registry = ToolRegistry()
        climatiq_tool = tool_registry.get_tool("climatiq_api")
        if not climatiq_tool:
            logger.info(f"[{request_id}] ClimatiqApiTool not found in registry, creating new instance")
            climatiq_tool = ClimatiqApiTool()
            tool_registry.register_tool(climatiq_tool)
        
        # Calculate carbon footprints for each activity
        carbon_processing_results = state.processing_results.get("carbon_metrics", {})
        carbon_footprints = carbon_processing_results.get("carbon_footprints", [])
        
        logger.info(f"[{request_id}] Processing {len(activity_data_list)} activities for carbon calculation")
        
        for activity_data in activity_data_list:
            try:
                # Perform carbon calculation using Climatiq API tool
                result = climatiq_tool.run(activity_data)
                
                if result.get("success"):
                    # Add calculation result to carbon footprints
                    carbon_footprints.append({
                        "activity_id": activity_data.activity_id,
                        "amount": activity_data.amount,
                        "unit": activity_data.unit,
                        "region": activity_data.region,
                        "co2e": result["co2e"],
                        "co2e_unit": result["co2e_unit"],
                        "calculation_method": result["calculation_method"],
                        "calculation_origin": result["calculation_origin"],
                        "calculation_timestamp": datetime.utcnow().isoformat()
                    })
                    logger.info(f"[{request_id}] Successfully calculated CO2e for {activity_data.activity_id}: {result['co2e']} {result['co2e_unit']}")
                else:
                    logger.warning(f"[{request_id}] Carbon calculation failed for {activity_data.activity_id}")
                    # Add error to state
                    return {
                        "workflow_status": "carbon_calculation_failed",
                        "errors": [*state.errors, f"Carbon calculation failed for {activity_data.activity_id}"]
                    }
                    
            except Exception as e:
                logger.error(f"[{request_id}] Error calculating carbon footprint for {activity_data.activity_id}: {str(e)}")
                raise CarbonCalculationError(f"Failed to calculate carbon footprint: {str(e)}") from e
        
        # Update carbon metrics with carbon footprints
        carbon_processing_results["carbon_footprints"] = carbon_footprints
        
        # Calculate total carbon footprint
        total_co2e = sum([cf["co2e"] for cf in carbon_footprints])
        carbon_processing_results["total_carbon_footprint"] = {
            "co2e": total_co2e,
            "co2e_unit": "kg",
            "calculation_timestamp": datetime.utcnow().isoformat()
        }
        
        # Log agent trace
        agent_trace_entry = {
            "agent": "carbon_calculation_agent",
            "request_id": request_id,
            "action": "carbon_footprint_calculation",
            "activities_processed": len(activity_data_list),
            "total_co2e": total_co2e,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info(f"[{request_id}] Carbon calculation agent completed successfully. Total CO2e: {total_co2e} kg")
        
        # Prepare state updates
        state_updates = {
            "workflow_status": "carbon_calculation_completed",
            "processing_results": {
                **state.processing_results,
                "carbon_metrics": carbon_processing_results,
                "carbon_calculation": {
                    "status": "completed",
                    "activities_processed": len(activity_data_list),
                    "total_co2e": total_co2e,
                    "co2e_unit": "kg"
                }
            },
            "agent_trace": [
                *state.agent_trace,
                agent_trace_entry
            ]
        }
        
        return state_updates
        
    except Exception as e:
        logger.error(f"[{request_id}] Unexpected error in carbon calculation agent: {str(e)}")
        raise CarbonCalculationError(f"Carbon calculation agent failed: {str(e)}") from e


def anomaly_detection_agent(state: AppState) -> Dict[str, Any]:
    """
    Dedicated agent to manage and run anomaly detection models, flagging potential issues in real time.
    
    This agent extracts ESG metrics data from the application state, uses the Scope3AnomalyPredictorTool
    to detect anomalies, and updates the processing results with anomaly detection findings.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including anomaly detection results
        
    Raises:
        AnomalyDetectionError: If there's an error during anomaly detection
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    
    try:
        logger.info(f"[{request_id}] Anomaly detection agent started processing")
        
        # Extract supplier data from workflow_data
        supplier_data = state.workflow_data.get("supplier_data", {})
        if not supplier_data:
            logger.warning(f"[{request_id}] No supplier data found for anomaly detection")
            return {
                "workflow_status": "anomaly_detection_skipped",
                "errors": [*state.errors, "No supplier data available for anomaly detection"]
            }
        
        # Extract Scope 3 data from supplier data
        scope3_data = supplier_data.get("scope3_data", [])
        if not scope3_data:
            logger.warning(f"[{request_id}] No Scope 3 data found for anomaly detection")
            return {
                "workflow_status": "anomaly_detection_skipped",
                "errors": [*state.errors, "No Scope 3 data found for anomaly detection"]
            }
        
        # Convert to Scope3DataPoint objects if needed
        if scope3_data and isinstance(scope3_data[0], dict):
            try:
                scope3_data_points = [Scope3DataPoint(**data_point) for data_point in scope3_data]
            except Exception as e:
                logger.error(f"[{request_id}] Error converting Scope 3 data to data points: {str(e)}")
                raise AnomalyDetectionError(f"Failed to convert Scope 3 data: {str(e)}") from e
        else:
            scope3_data_points = scope3_data
        
        # Get Scope3AnomalyPredictorTool from registry or create new instance
        tool_registry = ToolRegistry()
        anomaly_tool = tool_registry.get_tool("scope3_anomaly_predictor")
        if not anomaly_tool:
            logger.info(f"[{request_id}] Scope3AnomalyPredictorTool not found in registry, creating new instance")
            anomaly_tool = Scope3AnomalyPredictorTool()
            tool_registry.register_tool(anomaly_tool)
        
        # Run anomaly detection
        logger.info(f"[{request_id}] Detecting anomalies in {len(scope3_data_points)} Scope 3 data points")
        anomaly_results = anomaly_tool.run(scope3_data_points)
        
        if not anomaly_results.get("success"):
            logger.error(f"[{request_id}] Anomaly detection failed: {anomaly_results.get('error', 'Unknown error')}")
            return {
                "workflow_status": "anomaly_detection_failed",
                "errors": [*state.errors, f"Anomaly detection failed: {anomaly_results.get('error', 'Unknown error')}"]
            }
        
        # Log agent trace
        agent_trace_entry = {
            "agent": "anomaly_detection_agent",
            "request_id": request_id,
            "action": "anomaly_detection",
            "data_points_processed": len(scope3_data_points),
            "anomalies_detected": anomaly_results["anomaly_count"],
            "anomaly_percentage": anomaly_results["anomaly_percentage"],
            "timestamp": datetime.utcnow().isoformat()
        }
        
        logger.info(f"[{request_id}] Anomaly detection agent completed successfully. "
                    f"Anomalies detected: {anomaly_results['anomaly_count']} "
                    f"({anomaly_results['anomaly_percentage']:.2f}%)")
        
        # Prepare state updates
        state_updates = {
            "workflow_status": "anomaly_detection_completed",
            "processing_results": {
                **state.processing_results,
                "anomaly_detection": anomaly_results
            },
            "agent_trace": [
                *state.agent_trace,
                agent_trace_entry
            ]
        }
        
        return state_updates
        
    except Exception as e:
        logger.error(f"[{request_id}] Unexpected error in anomaly detection agent: {str(e)}")
        raise AnomalyDetectionError(f"Anomaly detection agent failed: {str(e)}") from e


def _extract_activity_data(supplier_data: Dict[str, Any], request_id: str) -> List[ActivityData]:
    """
    Extract activity data from supplier data for carbon footprint calculation.
    
    Args:
        supplier_data: The supplier data containing activity information
        request_id: Request ID for traceability
        
    Returns:
        List[ActivityData]: List of activity data objects for carbon calculation
    """
    activity_data_list = []
    
    # Check if supplier data contains explicit activity data
    if "activity_data" in supplier_data:
        activities = supplier_data["activity_data"]
        if isinstance(activities, list):
            for activity in activities:
                try:
                    activity_data = ActivityData(**activity)
                    activity_data_list.append(activity_data)
                except Exception as e:
                    logger.warning(f"[{request_id}] Skipping invalid activity data: {str(e)}")
        elif isinstance(activities, dict):
            try:
                activity_data = ActivityData(**activities)
                activity_data_list.append(activity_data)
            except Exception as e:
                logger.warning(f"[{request_id}] Skipping invalid activity data: {str(e)}")
    
    # If no explicit activity data, try to infer from ESG metrics
    elif "esg_metrics" in supplier_data:
        esg_metrics = supplier_data["esg_metrics"]
        if isinstance(esg_metrics, dict):
            # Try to extract common activity types
            if "energy_consumption_kwh" in esg_metrics:
                activity_data_list.append(ActivityData(
                    activity_id="electricity-supply_grid-source_residual_mix",
                    amount=esg_metrics["energy_consumption_kwh"],
                    unit="kwh",
                    region=supplier_data.get("hq_location", "AU"),  # Changed to AU to match working example
                    data_version="^3"
                ))
            
            if "vehicle_distance_km" in esg_metrics:
                activity_data_list.append(ActivityData(
                    activity_id="passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                    amount=esg_metrics["vehicle_distance_km"],
                    unit="km",
                    region=supplier_data.get("hq_location", "AU"),  # Changed to AU to match working example
                    data_version="^3"
                ))
            
            if "freight_ton_km" in esg_metrics:
                activity_data_list.append(ActivityData(
                    activity_id="freight_transport-road_vehicle_type_all-fuel_source_all-weight_na-distance_na-unknown",
                    amount=esg_metrics["freight_ton_km"],
                    unit="ton*km",
                    region=supplier_data.get("hq_location", "AU"),  # Changed to AU to match working example
                    data_version="^3"
                ))
    
    # Try to extract from generic supplier data fields
    else:
        # Check for common energy consumption fields
        for field in ["energy_consumption", "electricity_usage", "power_consumption"]:
            if field in supplier_data and isinstance(supplier_data[field], (int, float)):
                activity_data_list.append(ActivityData(
                    activity_id="electricity-energy_source_grid-average",
                    amount=supplier_data[field],
                    unit="kwh",
                    region=supplier_data.get("hq_location", "US")  # Default to US if not specified
                ))
                break
        
        # Check for common transportation fields
        for field in ["vehicle_distance", "mileage", "distance_traveled"]:
            if field in supplier_data and isinstance(supplier_data[field], (int, float)):
                activity_data_list.append(ActivityData(
                    activity_id="passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                    amount=supplier_data[field],
                    unit="km",
                    region=supplier_data.get("hq_location", "US")  # Default to US if not specified
                ))
                break
    
    logger.info(f"[{request_id}] Extracted {len(activity_data_list)} activities for carbon calculation")
    return activity_data_list