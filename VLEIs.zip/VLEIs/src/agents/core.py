"""
Master Orchestrator (Router Agent)

This module implements the central router of the graph to inspect the state
and determine the next agent for task execution.
"""

from src.state.models import AppState
from src.llm.interface import GeminiLLMInterface, LLMInterface
from src.llm.context import ESGContextManager
from src.utils.error_handling import BaseVLEIError, handle_error
from loguru import logger
from typing import Union, Dict, Any
import uuid
import asyncio
import traceback
from datetime import datetime


class RoutingError(Exception):
    """Custom exception for routing failures"""
    pass


def master_orchestrator(state: AppState) -> str:
    """
    Master orchestrator that inspects state.task_queue, pops the next task,
    and returns the agent node name or "__end__".
    
    Args:
        state (AppState): The current application state
        
    Returns:
        str: The name of the next agent to execute or "__end__" if no more tasks
        
    Raises:
        RoutingError: If there's an error during routing
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    
    try:
        logger.info(f"[{request_id}] Master orchestrator inspecting state")
        
        # Check if task queue is empty
        if not state.task_queue:
            logger.info(f"[{request_id}] Task queue is empty, ending workflow")
            return "__end__"
        
        # Pop the next task from the queue
        next_task = state.task_queue.pop(0)
        logger.info(f"[{request_id}] Popped task '{next_task}' from queue")
        
        # Validate that the task name is a string
        if not isinstance(next_task, str):
            logger.error(f"[{request_id}] Invalid task name type: {type(next_task)}")
            raise RoutingError(f"Task name must be a string, got {type(next_task)}")
        
        # Validate that the task name is not empty
        if not next_task.strip():
            logger.error(f"[{request_id}] Empty task name encountered")
            raise RoutingError("Task name cannot be empty")
        
        # Use LLM-based routing for intelligent decision making
        try:
            agent_name = llm_orchestrator(next_task, state, request_id)
            logger.info(f"[{request_id}] LLM-based routing to agent: {agent_name}")
            return agent_name
        except Exception as llm_error:
            logger.warning(f"[{request_id}] LLM routing failed: {str(llm_error)}. Falling back to rule-based routing.")
            # Fallback to rule-based routing
            agent_name = rule_based_routing(next_task)
            logger.info(f"[{request_id}] Rule-based routing to agent: {agent_name}")
            return agent_name
        
    except IndexError:
        # This shouldn't happen since we checked for empty queue, but just in case
        logger.warning(f"[{request_id}] Task queue unexpectedly empty")
        return "__end__"
        
    except Exception as e:
        logger.error(f"[{request_id}] Unexpected error in master orchestrator: {str(e)}")
        raise RoutingError(f"Failed to route task: {str(e)}") from e


def handle_error_node(state: AppState) -> Dict[str, Any]:
    """
    Centralized error handling node for standardized logging and graceful workflow termination.
    
    This "fail-safe" node handles exceptions by logging them to state.error_log,
    setting the run status to FAILED, and clearing the task queue for graceful termination.
    
    Args:
        state (AppState): The current application state which may contain error information
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including error logging and workflow termination
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    
    try:
        logger.info(f"[{request_id}] Error handling node activated")
        
        # Create error log entry
        error_log_entry = {
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat(),
            "agent": "handle_error_node",
            "action": "error_processing",
            "workflow_status_before_error": state.workflow_status,
            "task_queue_length_before_error": len(state.task_queue)
        }
        
        # Process any exceptions that might be in the state or recent agent trace
        processed_errors = []
        
        # Check for errors in the state
        if state.errors:
            for error in state.errors:
                if isinstance(error, Exception):
                    processed_error = handle_error(error)
                    processed_errors.append(processed_error.to_dict())
                else:
                    # Handle string errors
                    error_obj = BaseVLEIError(str(error))
                    processed_errors.append(error_obj.to_dict())
        
        # Add processed errors to the log entry
        error_log_entry["processed_errors"] = processed_errors
        
        # Prepare state updates
        state_updates = {
            # Log the error to error_log
            "error_log": [
                *state.error_log,
                error_log_entry
            ],
            # Set run status to FAILED
            "workflow_status": "FAILED",
            # Clear task queue for graceful termination
            "task_queue": [],
            # Add to agent trace
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "handle_error_node",
                    "request_id": request_id,
                    "action": "workflow_terminated",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
        
        logger.info(f"[{request_id}] Error handled and workflow terminated gracefully")
        return state_updates
        
    except Exception as e:
        # If the error handler itself fails, log it and return minimal state updates
        logger.error(f"[{request_id}] Error in error handling node: {str(e)}")
        logger.debug(f"[{request_id}] Stack trace:\n{traceback.format_exc()}")
        
        # Return minimal state updates to ensure workflow termination
        return {
            "workflow_status": "FAILED",
            "task_queue": [],
            "error_log": [
                *state.error_log,
                {
                    "request_id": request_id,
                    "timestamp": datetime.utcnow().isoformat(),
                    "agent": "handle_error_node",
                    "action": "error_handler_failed",
                    "error": str(e),
                    "stack_trace": traceback.format_exc()
                }
            ]
        }


def llm_orchestrator(task: str, state: AppState, request_id: str) -> str:
    """
    Use LLM to determine the optimal routing path based on task characteristics.
    
    Args:
        task: The task to route
        state: The current application state
        request_id: Request ID for traceability
        
    Returns:
        The name of the agent to route to
    """
    # Initialize LLM interface
    llm_interface = GeminiLLMInterface()
    
    # Initialize ESG context manager for domain-specific context
    context_manager = ESGContextManager()
    
    # Get relevant ESG context for routing decision quality
    esg_context = context_manager.get_relevant_context(
        f"Routing decision for task: {task}", 
        top_k=2
    )
    
    # Build context string for LLM
    context_str = "\n".join([
        f"Standard: {ctx['standard']}, Content: {ctx['content']}"
        for ctx in esg_context
    ])
    
    # Log routing decision to state.agent_trace (simulated)
    routing_info = {
        "request_id": request_id,
        "task": task,
        "context_used": len(esg_context) > 0,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    logger.info(f"[{request_id}] Routing decision context: {routing_info}")
    
    # Use LLM to determine routing path
    # In a real implementation, this would be an async call
    agent_name = llm_interface.determine_routing_path(
        task_description=task,
        state=state
    )
    
    # Since we're using a mock implementation, we need to handle the coroutine
    if asyncio.iscoroutine(agent_name):
        agent_name = asyncio.run(agent_name)
    
    return agent_name


def rule_based_routing(task: str) -> str:
    """
    Rule-based fallback routing when LLM is unavailable.
    
    Args:
        task: The task to route
        
    Returns:
        The name of the agent to route to
    """
    task_lower = task.lower()
    
    # Define routing rules for all agents including new Phase 3 agents
    # Order matters - more specific rules should come first
    routing_rules = {
        # New Phase 3 agents (more specific)
        "detect": "anomaly_detection_agent",
        "anomaly": "anomaly_detection_agent",
        "audit": "audit_agent",
        "self-audit": "audit_agent",
        "finalize": "finalization_agent",
        "final": "finalization_agent",
        "sign": "finalization_agent",
        
        # Existing agents (more general)
        "verify": "credential_agent",
        "validate": "credential_agent",
        "check": "credential_agent",
        "credential": "credential_agent",
        "report": "reporting_agent",
        "generate": "reporting_agent",
        "create": "reporting_agent",
        "produce": "reporting_agent"
    }
    
    # Find matching rule
    for keyword, agent in routing_rules.items():
        if keyword in task_lower:
            return agent
    
    # Default fallback
    return "credential_agent"


def finalization_agent(state: AppState) -> Dict[str, Any]:
    """
    Finalization agent that handles all finalization tasks including report generation and signing.
    
    This agent orchestrates calls to the RegulatoryReportingAgent and SignReportTool to:
    1. Generate regulatory reports using the regulatory_reporting_agent
    2. Sign the final report using the SignReportTool
    3. Perform state cleanup and finalization
    4. Conduct final quality assurance checks
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including finalization results
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Finalization agent processing finalization tasks")
    
    try:
        # Import the regulatory reporting agent
        from src.agents.reporting import regulatory_reporting_agent
        
        # Step 1: Generate regulatory reports
        logger.info(f"[{request_id}] Generating regulatory reports")
        report_result = regulatory_reporting_agent(state)
        
        # Update state with report results
        updated_state = state.copy()
        for key, value in report_result.items():
            setattr(updated_state, key, value)
        
        # Step 2: Sign the final report using SignReportTool
        logger.info(f"[{request_id}] Signing final report")
        
        # Get the SignReportTool from the registry
        from src.tools.registry import ToolRegistry
        registry = ToolRegistry()
        sign_tool = registry.get_tool("sign_report")
        
        if not sign_tool:
            # If tool is not registered, create a new instance
            logger.warning(f"[{request_id}] SignReportTool not found in registry, creating new instance")
            from src.tools.verification import SignReportTool
            sign_tool = SignReportTool()
            registry.register_tool(sign_tool)
        
        # Prepare the report data for signing
        report_data = {
            "report_id": updated_state.regulatory_report.get("id") if updated_state.regulatory_report else str(uuid.uuid4()),
            "title": "ESG Compliance Report",
            "company_name": updated_state.regulatory_report.get("company_name", "Unknown Company") if updated_state.regulatory_report else "Unknown Company",
            "reporting_period": f"{updated_state.regulatory_report.get('report_year', datetime.now().year)}",
            "date_generated": datetime.now().isoformat(),
            "regulatory_report": updated_state.regulatory_report,
            "esg_scores": {
                "environmental": 85.5,
                "social": 78.2,
                "governance": 92.1,
                "overall": 85.3
            },
            "verifier": "VLEIs Platform",
            "verification_date": datetime.now().isoformat()
        }
        
        # Sign the report
        sign_result = sign_tool.run(action="sign", report_data=report_data)
        
        # Step 3: Quality assurance checks
        logger.info(f"[{request_id}] Performing final quality assurance checks")
        
        # Check if signing was successful
        if not sign_result.get("signed", False):
            error_msg = f"Report signing failed: {sign_result.get('error', 'Unknown error')}"
            logger.error(f"[{request_id}] {error_msg}")
            raise Exception(error_msg)
        
        # Step 4: State cleanup and finalization
        logger.info(f"[{request_id}] Performing state cleanup and finalization")
        
        # Prepare final result updates
        result_updates = {
            "workflow_status": "finalized",
            "signed_report": sign_result,
            "task_queue": [],  # Clear task queue as we're at the end of the workflow
            "agent_trace": [
                *updated_state.agent_trace,
                {
                    "agent": "finalization_agent",
                    "request_id": request_id,
                    "action": "workflow_finalized",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
        
        logger.info(f"[{request_id}] Finalization completed successfully")
        return result_updates
        
    except Exception as e:
        error_msg = f"Finalization failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "finalization_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "finalization_agent",
                    "request_id": request_id,
                    "action": "finalization_failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }


# New agent functions for Phase 3 integration

def anomaly_detection_agent(state: AppState) -> Dict[str, Any]:
    """
    Anomaly detection agent that identifies unusual patterns in ESG data.
    
    This agent uses advanced modeling techniques to detect anomalies in ESG data
    and logs findings to the state.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including anomaly detection results
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Anomaly detection agent processing task")
    
    try:
        # Import the GNN modeling agent
        from src.agents.modeling import gnn_modeling_agent
        
        # Execute the GNN modeling agent for anomaly detection
        result = gnn_modeling_agent(state)
        
        # Add specific anomaly detection trace
        result["agent_trace"] = [
            *result.get("agent_trace", []),
            {
                "agent": "anomaly_detection_agent",
                "request_id": request_id,
                "action": "anomalies_detected",
                "timestamp": datetime.now().isoformat()
            }
        ]
        
        logger.info(f"[{request_id}] Anomaly detection completed successfully")
        return result
        
    except Exception as e:
        error_msg = f"Anomaly detection failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "anomaly_detection_agent",
                    "request_id": request_id,
                    "action": "anomaly_detection_failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }


def audit_agent(state: AppState) -> Dict[str, Any]:
    """
    Audit agent that runs self-audits on the system's data trail.
    
    This agent samples entries from state.blockchain_log, uses BlockchainOracleTool 
    to verify them, and logs results to state.audit_trail.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including audit results
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Audit agent processing audit task")
    
    try:
        # Import the automated audit agent
        from src.agents.audit import automated_audit_agent
        
        # Execute the automated audit agent
        result = automated_audit_agent(state)
        
        # Add specific audit trace
        result["agent_trace"] = [
            *result.get("agent_trace", []),
            {
                "agent": "audit_agent",
                "request_id": request_id,
                "action": "audit_completed",
                "timestamp": datetime.now().isoformat()
            }
        ]
        
        logger.info(f"[{request_id}] Audit completed successfully")
        return result
        
    except Exception as e:
        error_msg = f"Audit failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "audit_agent",
                    "request_id": request_id,
                    "action": "audit_failed",
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }