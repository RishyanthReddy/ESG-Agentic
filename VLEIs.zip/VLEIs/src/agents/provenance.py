"""
Provenance Agent

This module implements an agent responsible for logging key data events to
the blockchain testnet via InfuraBlockchainTool.
"""

import hashlib
import json
from typing import Dict, Any
from datetime import datetime
from src.state.models import AppState
from src.tools.provenance import InfuraBlockchainTool
from src.tools.registry import ToolRegistry
from loguru import logger
import uuid


class ProvenanceError(Exception):
    """Custom exception for provenance logging failures"""
    pass


def _serialize_state_for_hashing(state: AppState) -> str:
    """
    Serialize state for consistent hashing.
    
    Args:
        state (AppState): The state to serialize
        
    Returns:
        str: JSON string representation of the state data to be hashed
    """
    # Extract relevant data for hashing
    data_to_hash = {}
    
    if state.current_credential:
        data_to_hash["current_credential"] = state.current_credential.model_dump()
    elif state.credentials:
        # Hash the first credential if no current credential
        data_to_hash["credential"] = state.credentials[0].model_dump()
    else:
        # If no credentials, hash other relevant state data
        data_to_hash["workflow_status"] = state.workflow_status
        data_to_hash["workflow_step"] = state.workflow_step
        data_to_hash["workflow_data"] = state.workflow_data
    
    # Create consistent JSON string for hashing
    return json.dumps(data_to_hash, sort_keys=True, separators=(',', ':'))


def _create_selective_data_snapshot(state: AppState) -> Dict[str, Any]:
    """
    Create a selective data snapshot for blockchain logging.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Selective data snapshot
    """
    snapshot = {
        "timestamp": datetime.utcnow().isoformat(),
        "workflow_status": state.workflow_status,
        "workflow_step": state.workflow_step
    }
    
    # Include current credential or first credential if available
    if state.current_credential:
        snapshot["credential_id"] = str(state.current_credential.id)
        snapshot["credential_issuer"] = state.current_credential.issuer
        snapshot["credential_subject"] = state.current_credential.subject
    elif state.credentials:
        snapshot["credential_id"] = str(state.credentials[0].id)
        snapshot["credential_issuer"] = state.credentials[0].issuer
        snapshot["credential_subject"] = state.credentials[0].subject
    
    return snapshot


def provenance_agent(state: AppState) -> Dict[str, Any]:
    """
    Provenance agent that orchestrates blockchain logging tasks using InfuraBlockchainTool.
    
    This agent is responsible for:
    1. Taking state snapshots for selective logging
    2. Creating SHA-256 hash of the data
    3. Calling the InfuraBlockchainTool to log the hash to the blockchain
    4. Appending the real transaction hash to state.blockchain_log
    
    Args:
        state (AppState): The current application state containing data to log
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including blockchain log results
        
    Raises:
        ProvenanceError: If there's an error during provenance logging
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Provenance agent processing blockchain logging task")
    
    try:
        # Get the InfuraBlockchainTool from the registry
        registry = ToolRegistry()
        blockchain_tool = registry.get_tool("infura_blockchain")
        
        if not blockchain_tool:
            # If tool is not registered, create a new instance
            logger.warning(f"[{request_id}] InfuraBlockchainTool not found in registry, creating new instance")
            blockchain_tool = InfuraBlockchainTool()
        
        # Create a selective data snapshot for logging
        data_snapshot = _create_selective_data_snapshot(state)
        logger.info(f"[{request_id}] Created data snapshot for blockchain logging")
        
        # Serialize the data snapshot to JSON string for hashing
        try:
            data_json = json.dumps(data_snapshot, sort_keys=True, separators=(',', ':'))
        except Exception as e:
            raise ProvenanceError(f"Failed to serialize data snapshot for hashing: {str(e)}")
        
        # Create SHA-256 hash of the data snapshot
        data_hash = hashlib.sha256(data_json.encode('utf-8')).hexdigest()
        logger.info(f"[{request_id}] Created SHA-256 hash of data snapshot: {data_hash[:16]}...")
        
        # Get private key from environment or config
        # In a real implementation, this would be securely managed
        private_key = state.config.get("blockchain_private_key")
        if not private_key:
            raise ProvenanceError("Blockchain private key not found in state configuration")
        
        # Log the data hash to the blockchain
        logger.info(f"[{request_id}] Logging data hash to blockchain...")
        blockchain_result = blockchain_tool.run(data_hash, private_key)
        
        # Extract data ID for logging
        data_id = None
        if state.current_credential:
            data_id = str(state.current_credential.id)
        elif state.credentials:
            data_id = str(state.credentials[0].id)
        else:
            data_id = "state_snapshot"
        
        # Prepare blockchain log entry
        log_entry = {
            "data_id": data_id,
            "data_hash": data_hash,
            "transaction_hash": blockchain_result["transaction_hash"],
            "timestamp": datetime.utcnow().isoformat(),
            "status": "success" if blockchain_result["success"] else "failed"
        }
        
        # Prepare the result updates
        result_updates = {
            "workflow_status": "data_logged_to_blockchain",
            "blockchain_log": [*state.blockchain_log, log_entry],
            "processing_results": {
                **state.processing_results,
                "blockchain_log_result": blockchain_result
            },
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "provenance_agent",
                    "request_id": request_id,
                    "action": "data_logged_to_blockchain",
                    "data_id": data_id,
                    "data_hash": data_hash,
                    "transaction_hash": blockchain_result["transaction_hash"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
        
        logger.info(f"[{request_id}] Successfully logged data to blockchain")
        logger.info(f"[{request_id}] Transaction hash: {blockchain_result['transaction_hash']}")
        
        return result_updates
        
    except Exception as e:
        error_msg = f"Provenance logging failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "blockchain_logging_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "provenance_agent",
                    "request_id": request_id,
                    "action": "blockchain_logging_failed",
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }