"""
Ingestion Agent (The "Front Door")

This module implements the ingestion agent that serves as the entry point for all
incoming data, processing state.supplier_data and populating state.task_queue with
initial tasks.
"""

from src.state.models import AppState
from loguru import logger
from typing import Dict, Any, List
from pydantic import ValidationError
import uuid


class IngestionError(Exception):
    """Custom exception for ingestion failures"""
    pass


def ingestion_agent(state: AppState) -> Dict[str, Any]:
    """
    Ingestion agent that processes incoming supplier data and populates the task queue
    with initial tasks.
    
    Args:
        state (AppState): The current application state containing supplier_data
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including populated task_queue
        
    Raises:
        IngestionError: If there's an error during ingestion
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Ingestion agent processing incoming data")
    
    try:
        # Extract supplier data from workflow_data
        supplier_data = state.workflow_data.get("supplier_data", {})
        
        # Check if we have file upload data that needs processing
        file_upload_data = state.workflow_data.get("file_upload_data")
        if file_upload_data:
            # Process file upload data first
            supplier_data = _process_file_upload(file_upload_data, request_id)
        
        # Validate supplier data
        validated_data = _validate_supplier_data(supplier_data, request_id)
        
        # Process the validated data
        processed_data = _process_supplier_data(validated_data, request_id)
        
        # Generate initial tasks based on the data
        initial_tasks = _generate_initial_tasks(processed_data, request_id)
        
        # Log the ingestion process
        logger.info(f"[{request_id}] Successfully processed supplier data, generated {len(initial_tasks)} initial tasks")
        
        # Return state updates
        return {
            "workflow_status": "data_ingested",
            "workflow_data": {
                **state.workflow_data,
                "processed_supplier_data": processed_data
            },
            "task_queue": initial_tasks,
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "ingestion_agent",
                    "request_id": request_id,
                    "action": "data_processed",
                    "tasks_generated": len(initial_tasks),
                    "timestamp": __import__('datetime').datetime.utcnow().isoformat()
                }
            ]
        }
        
    except ValidationError as ve:
        error_msg = f"Data validation error: {str(ve)}"
        logger.error(f"[{request_id}] {error_msg}")
        raise IngestionError(error_msg) from ve
        
    except Exception as e:
        error_msg = f"Unexpected error in ingestion agent: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        raise IngestionError(error_msg) from e


def _process_file_upload(file_upload_data: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Process file upload data using the FileUploadTool.
    
    Args:
        file_upload_data: Data about the file upload
        request_id: Request ID for traceability
        
    Returns:
        Dict[str, Any]: Processed supplier data
    """
    logger.info(f"[{request_id}] Processing file upload data")
    
    try:
        from src.tools.ingestion import FileUploadTool
        
        # Extract file data
        file_content = file_upload_data.get("content")
        file_name = file_upload_data.get("name", "unknown_file")
        
        # Additional parameters for the tool
        tool_params = {
            "data_type_hint": file_upload_data.get("data_type_hint"),
            "company_name": file_upload_data.get("company_name"),
            "format_mapping": file_upload_data.get("format_mapping", {})
        }
        
        # Process the file
        tool = FileUploadTool()
        supplier_data = tool.run(file_content, file_name, **tool_params)
        
        logger.info(f"[{request_id}] File upload processed successfully")
        return supplier_data
        
    except Exception as e:
        error_msg = f"Error processing file upload: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        raise IngestionError(error_msg) from e


def _validate_supplier_data(supplier_data: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Validate the incoming supplier data.
    
    Args:
        supplier_data: Raw supplier data to validate
        request_id: Request ID for traceability
        
    Returns:
        Dict[str, Any]: Validated supplier data
        
    Raises:
        ValidationError: If data validation fails
    """
    logger.info(f"[{request_id}] Validating supplier data")
    
    # Check if supplier_data is a dictionary
    if not isinstance(supplier_data, dict):
        raise ValidationError("Supplier data must be a dictionary", model=AppState)
    
    # Check for required fields (basic validation)
    required_fields = ["company_name", "data_type"]
    missing_fields = [field for field in required_fields if field not in supplier_data]
    
    if missing_fields:
        raise ValidationError(f"Missing required fields: {missing_fields}", model=AppState)
    
    # Additional validation based on data_type
    data_type = supplier_data.get("data_type")
    if data_type not in ["vlei_credential", "gri_report", "sasb_report", "esg_data"]:
        logger.warning(f"[{request_id}] Unknown data type: {data_type}")
    
    # Validate company_name is not empty
    company_name = supplier_data.get("company_name")
    if not company_name or company_name == "Unknown Company":
        logger.warning(f"[{request_id}] Company name not provided or is default value")
    
    logger.info(f"[{request_id}] Supplier data validation passed")
    return supplier_data


def _process_supplier_data(supplier_data: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Process the validated supplier data.
    
    Args:
        supplier_data: Validated supplier data
        request_id: Request ID for traceability
        
    Returns:
        Dict[str, Any]: Processed supplier data
    """
    logger.info(f"[{request_id}] Processing supplier data")
    
    # In a real implementation, this would do more complex processing
    # For now, we'll just return the validated data with some additional metadata
    processed_data = {
        **supplier_data,
        "processing_timestamp": __import__('datetime').datetime.utcnow().isoformat(),
        "processing_id": request_id
    }
    
    logger.info(f"[{request_id}] Supplier data processed successfully")
    return processed_data


def _generate_initial_tasks(processed_data: Dict[str, Any], request_id: str) -> List[str]:
    """
    Generate initial tasks based on the processed data.
    
    Args:
        processed_data: Processed supplier data
        request_id: Request ID for traceability
        
    Returns:
        List[str]: List of initial tasks to be added to the task queue
    """
    logger.info(f"[{request_id}] Generating initial tasks")
    
    # Determine tasks based on data type
    data_type = processed_data.get("data_type", "")
    initial_tasks = []
    
    if data_type == "vlei_credential":
        initial_tasks = [
            "verify_vlei_credential",
            "log_to_blockchain",
            "map_to_regulatory_frameworks"
        ]
    elif data_type == "gri_report":
        initial_tasks = [
            "validate_gri_report",
            "analyze_gri_data",
            "map_to_regulatory_frameworks"
        ]
    elif data_type == "sasb_report":
        initial_tasks = [
            "validate_sasb_report",
            "analyze_sasb_data",
            "map_to_regulatory_frameworks"
        ]
    elif data_type == "esg_data":
        initial_tasks = [
            "process_esg_data",
            "verify_data_sources",
            "map_to_regulatory_frameworks"
        ]
    else:
        # Default tasks for unknown data types
        initial_tasks = [
            "verify_data_integrity",
            "categorize_data",
            "map_to_regulatory_frameworks"
        ]
    
    logger.info(f"[{request_id}] Generated {len(initial_tasks)} initial tasks: {initial_tasks}")
    return initial_tasks