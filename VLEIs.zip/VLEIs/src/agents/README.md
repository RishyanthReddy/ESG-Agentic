# LLM Orchestration in Master Router

This module enhances the master orchestrator with LLM-powered routing for dynamic optimal processing pathway determination.

## Features

- **LLM Integration**: Uses LLMInterface for intelligent routing decisions
- **Decision Logic**: LLM-based complexity assessment and routing
- **Logging Framework**: Structured logging of all routing decisions to `state.agent_trace`
- **Error Recovery**: Fallback to rule-based routing on LLM failure
- **Context Injection**: ESG context for improved routing decision quality

## Tech Stack

- **LLM Integration**: LLMInterface for routing decisions
- **Decision Logic**: LLM-based complexity assessment and routing
- **Logging Framework**: Structured logging of all routing decisions
- **Error Recovery**: Fallback to rule-based routing on LLM failure
- **Context Injection**: ESG context for routing decision quality

## Agent Types

### 1. Ingestion Agent (The "Front Door")

**Module:** [src/agents/ingestion.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/ingestion.py)

The Ingestion Agent serves as the entry point for all incoming data. It processes `state.supplier_data` and populates `state.task_queue` with initial tasks based on the data type.

#### Features
- **Data Validation:** Pydantic validation of incoming supplier data
- **Task Generation:** Intelligent task prioritization and sequencing
- **Error Handling:** Graceful handling of malformed input data
- **State Management:** AppState manipulation for task queue population

#### Supported Data Types
1. `vlei_credential` - Verifiable Legal Entity Identifier credentials
2. `gri_report` - Global Reporting Initiative reports
3. `sasb_report` - Sustainability Accounting Standards Board reports
4. `esg_data` - Generic ESG data
5. Other/Unknown - Default processing flow

#### Generated Tasks
Based on the data type, the following tasks are generated:

- **vLEI Credentials:**
  - `verify_vlei_credential`
  - `log_to_blockchain`
  - `map_to_regulatory_frameworks`

- **GRI Reports:**
  - `validate_gri_report`
  - `analyze_gri_data`
  - `map_to_regulatory_frameworks`

- **SASB Reports:**
  - `validate_sasb_report`
  - `analyze_sasb_data`
  - `map_to_regulatory_frameworks`

- **Generic ESG Data:**
  - `process_esg_data`
  - `verify_data_sources`
  - `map_to_regulatory_frameworks`

- **Unknown Data Types:**
  - `verify_data_integrity`
  - `categorize_data`
  - `map_to_regulatory_frameworks`

### 2. Master Orchestrator (Router Agent)

**Module:** [src/agents/core.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/core.py)

The Master Orchestrator serves as the central router that inspects the state's task queue, pops the next task, and determines which agent should execute it.

#### Features
- **Intelligent Routing:** LLM-based routing decisions with ESG context
- **Fallback Mechanism:** Rule-based routing when LLM is unavailable
- **Traceability:** Logging of all routing decisions to `state.agent_trace`

### LLM Interface

The LLM interface is defined in [src/llm/interface.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/llm/interface.py) and includes:

- `LLMInterface`: Abstract base class defining the contract for LLM operations
- `GeminiLLMInterface`: Concrete implementation using the Gemini client

### ESG Context Integration

The orchestrator integrates with the ESG Context Manager to provide domain-specific context for routing decisions, improving the quality of LLM-based routing.

## Testing

### Unit Tests

Unit tests are located in [tests/test_llm_orchestrator.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_llm_orchestrator.py) and cover:

- LLM interface usage in routing logic
- Rule-based fallback when LLM fails
- Routing decision logging
- Various error scenarios

Run with:
```bash
python -m pytest tests/test_llm_orchestrator.py -v
```

### Integration Tests

Integration tests are located in [tests/test_llm_orchestrator_integration.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_llm_orchestrator_integration.py) and cover:

- Intelligent routing decisions
- End-to-end workflow with LLM-powered routing
- Performance impact of routing with LLM calls
- Decision quality validation
- Error recovery to rule-based routing

Run with:
```bash
python -m pytest tests/test_llm_orchestrator_integration.py -v
```

### 3. Credential Agent

**Module:** [src/agents/credential_agent.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/credential_agent.py)

The Credential Agent processes credential-related tasks such as verification and validation.

### 4. Reporting Agent

**Module:** [src/agents/reporting_agent.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/reporting_agent.py)

The Reporting Agent handles reporting tasks such as generation and formatting.

### 5. Verification Agent

**Module:** [src/agents/verification.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/verification.py)

The Verification Agent is responsible for orchestrating verification tasks using the live GleifVerifierTool to verify vLEI credentials.

#### Features
- **Tool Integration:** Uses GleifVerifierTool for real-time vLEI credential verification
- **State Management:** Updates vLEICredential objects in state.credentials with verification results
- **Error Handling:** Graceful handling of verification failures and errors
- **Traceability:** Logging of all verification activities to `state.agent_trace`

#### Workflow
1. Extracts the vLEI credential that needs to be verified from the state
2. Calls the GleifVerifierTool to perform the verification against the live GLEIF API
3. Updates the vLEICredential object in state.credentials with the verification result
4. Records the verification activity in state.agent_trace

## Agent Interface

All agents follow a consistent interface pattern:

```python
def agent_function(state: AppState) -> Dict[str, Any]:
    """
    Process the current state and return updates.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state
    """
    # Agent-specific logic
    return {
        "field_to_update": new_value,
        # ... other updates
    }
```

## Usage

To use an agent, simply call it with the current AppState:

```python
from src.agents.ingestion import ingestion_agent
from src.state.models import AppState

# Create initial state with supplier data
state = AppState(
    workflow_data={
        "supplier_data": {
            "company_name": "Example Corp",
            "data_type": "vlei_credential",
            # ... other data
        }
    }
)

# Process with the ingestion agent
updates = ingestion_agent(state)

# Apply updates to the state
updated_state = state.copy(update=updates)
```

## Testing

Each agent includes comprehensive unit and integration tests:

- **Unit Tests:** Validate individual agent functionality, data validation, and error handling
- **Integration Tests:** Verify agent behavior in complete workflow contexts and with realistic data

Run tests with:
```bash
# Unit tests
python -m pytest tests/test_ingestion_agent.py -v

# Integration tests
python -m pytest tests/test_ingestion_agent_integration.py -v
```