"""
Automated Audit Agent

This module implements an agent that periodically runs self-audits on the system's
data trail using BlockchainOracleTool to ensure ongoing data integrity.
"""

import uuid
import random
from datetime import datetime
from typing import Dict, Any, List, Optional
from loguru import logger
from src.state.models import AppState, AuditTrailEntry
from src.tools.audit import BlockchainOracleTool, OracleError
from src.tools.registry import ToolRegistry


class AuditError(Exception):
    """Custom exception for audit agent failures"""
    pass


def _sample_blockchain_logs(blockchain_logs: List[Dict[str, Any]], sample_size: int = 5) -> List[Dict[str, Any]]:
    """
    Sample entries from blockchain logs using statistical sampling.
    
    Args:
        blockchain_logs (List[Dict[str, Any]]): List of blockchain log entries
        sample_size (int): Number of entries to sample
        
    Returns:
        List[Dict[str, Any]]: Sampled blockchain log entries
    """
    if not blockchain_logs:
        return []
    
    if len(blockchain_logs) <= sample_size:
        return blockchain_logs
    
    # Use random sampling for statistical coverage
    return random.sample(blockchain_logs, sample_size)


def automated_audit_agent(state: AppState) -> Dict[str, Any]:
    """
    Agent that periodically runs self-audits on system's data trail using 
    BlockchainOracleTool to ensure ongoing data integrity.
    
    This agent samples entries from state.blockchain_log, uses BlockchainOracleTool 
    to verify them, and logs results to state.audit_trail.
    
    Args:
        state (AppState): The current application state
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including audit results
        
    Raises:
        AuditError: If there's an error during audit
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    
    try:
        logger.info(f"[{request_id}] Automated audit agent started processing")
        
        # Get the BlockchainOracleTool from the registry
        registry = ToolRegistry.get_instance()
        oracle_tool = registry.get_tool("blockchain_oracle")
        if not oracle_tool:
            raise AuditError("BlockchainOracleTool not found in tool registry")
        
        # Sample entries from blockchain_log
        sampled_logs = _sample_blockchain_logs(state.blockchain_log, sample_size=5)
        logger.info(f"[{request_id}] Sampling {len(sampled_logs)} entries from blockchain log")
        
        if not sampled_logs:
            logger.info(f"[{request_id}] No blockchain log entries to audit")
            return {
                "workflow_status": "audit_completed",
                "agent_trace": [
                    *state.agent_trace,
                    {
                        "agent": "automated_audit_agent",
                        "request_id": request_id,
                        "action": "audit_skipped",
                        "reason": "no_blockchain_entries",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ]
            }
        
        # Perform audit on sampled entries
        audit_results = []
        successful_audits = 0
        failed_audits = 0
        
        for log_entry in sampled_logs:
            transaction_hash = log_entry.get("transaction_hash")
            if not transaction_hash:
                failed_audits += 1
                continue
                
            try:
                # Run verification on this specific transaction
                verification_result = oracle_tool.run(state, transaction_hash)
                
                # Process verification results
                if verification_result.get("success"):
                    successful_audits += 1
                    verification_details = verification_result.get("results", [{}])[0]
                    audit_results.append({
                        "transaction_hash": transaction_hash,
                        "verified": True,
                        "match": verification_details.get("match", False),
                        "error": None
                    })
                else:
                    failed_audits += 1
                    verification_details = verification_result.get("results", [{}])[0]
                    audit_results.append({
                        "transaction_hash": transaction_hash,
                        "verified": False,
                        "match": False,
                        "error": verification_details.get("error")
                    })
                    
            except Exception as e:
                failed_audits += 1
                audit_results.append({
                    "transaction_hash": transaction_hash,
                    "verified": False,
                    "match": False,
                    "error": str(e)
                })
                logger.error(f"[{request_id}] Audit failed for transaction {transaction_hash}: {str(e)}")
        
        # Create audit trail entries
        audit_trail_entries = []
        for result in audit_results:
            audit_entry = AuditTrailEntry(
                audit_type="blockchain_verification",
                transaction_hash=result["transaction_hash"],
                verification_result=result["match"] if result["verified"] else False,
                details={
                    "verified": result["verified"],
                    "match": result["match"],
                    "error": result["error"]
                }
            )
            audit_trail_entries.append(audit_entry)
        
        logger.info(f"[{request_id}] Audit completed: {successful_audits} successful, {failed_audits} failed")
        
        # Prepare state updates
        result_updates = {
            "workflow_status": "audit_completed",
            "audit_trail": [*state.audit_trail, *audit_trail_entries],
            "processing_results": {
                **state.processing_results,
                "audit_result": {
                    "total_audited": len(sampled_logs),
                    "successful_audits": successful_audits,
                    "failed_audits": failed_audits,
                    "audit_results": audit_results
                }
            },
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "automated_audit_agent",
                    "request_id": request_id,
                    "action": "audit_completed",
                    "sampled_entries": len(sampled_logs),
                    "successful_audits": successful_audits,
                    "failed_audits": failed_audits,
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
        
        return result_updates
        
    except Exception as e:
        error_msg = f"Audit agent failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        logger.error(f"[{request_id}] Traceback: {str(e)}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "audit_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "automated_audit_agent",
                    "request_id": request_id,
                    "action": "audit_failed",
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }