import logging
import uuid
from typing import Dict, Any, Tuple, Optional
import networkx as nx
from datetime import datetime
from src.state.models import AppState
from src.tools.visualization import NetworkXProvenanceTool, GraphSerializationTool, ShortestPathTool
from src.tools.registry import ToolRegistry

logger = logging.getLogger(__name__)


class VisualizationError(Exception):
    """Custom exception for visualization generation failures"""
    pass


def _find_data_point_nodes(graph: nx.Graph, data_point_id: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Find source and target nodes for a specific data point.
    
    Args:
        graph (nx.Graph): The provenance graph
        data_point_id (str): The ID of the data point to trace
        
    Returns:
        Tuple[Optional[str], Optional[str]]: Source and target node IDs for the data point path
    """
    # Find the artifact node that matches the data point ID
    source_node = None
    target_node = None
    
    # Look for the data point as an artifact
    for node_id, node_data in graph.nodes(data=True):
        node_type = node_data.get('type', 'unknown')
        # Check if this is an artifact with matching ID
        if node_type == 'artifact' and data_point_id in node_id:
            source_node = node_id
            break
    
    # If we didn't find by node ID, try to find by artifact name or other attributes
    if not source_node:
        for node_id, node_data in graph.nodes(data=True):
            node_type = node_data.get('type', 'unknown')
            if node_type == 'artifact':
                # Check if the artifact name or ID contains the data point ID
                artifact_name = node_data.get('name', '')
                if data_point_id in node_id or data_point_id in artifact_name:
                    source_node = node_id
                    break
    
    # Find the target node (typically a blockchain node or final report)
    # For now, we'll use the first blockchain node as the target
    for node_id, node_data in graph.nodes(data=True):
        node_type = node_data.get('type', 'unknown')
        if node_type == 'blockchain':
            target_node = node_id
            break
    
    # If no blockchain node, try to find a final artifact
    if not target_node:
        # Find artifacts that are not inputs to any other agents (leaf nodes)
        artifact_nodes = [node_id for node_id, node_data in graph.nodes(data=True) 
                         if node_data.get('type') == 'artifact']
        # Find artifacts with no outgoing edges (leaf nodes)
        leaf_artifacts = [node for node in artifact_nodes 
                         if graph.out_degree(node) == 0]
        if leaf_artifacts:
            target_node = leaf_artifacts[0]
        elif artifact_nodes:
            target_node = artifact_nodes[-1]  # Last artifact as fallback
    
    return source_node, target_node


def _find_path_nodes(graph: nx.Graph) -> Tuple[Optional[str], Optional[str]]:
    """
    Find suitable source and target nodes for path highlighting.
    
    Tries to find a path from supplier -> agent -> artifact -> blockchain
    Falls back to other combinations if needed.
    
    Args:
        graph (nx.Graph): The provenance graph
        
    Returns:
        Tuple[Optional[str], Optional[str]]: Source and target node IDs, or (None, None) if no suitable pair found
    """
    # Get all nodes by type
    suppliers = []
    agents = []
    artifacts = []
    blockchains = []
    
    for node_id, node_data in graph.nodes(data=True):
        node_type = node_data.get('type', 'unknown')
        if node_type == 'supplier':
            suppliers.append(node_id)
        elif node_type == 'agent':
            agents.append(node_id)
        elif node_type == 'artifact':
            artifacts.append(node_id)
        elif node_type == 'blockchain':
            blockchains.append(node_id)
    
    # Try supplier -> blockchain (full chain)
    if suppliers and blockchains:
        return suppliers[0], blockchains[0]
    
    # Try supplier -> agent
    if suppliers and agents:
        return suppliers[0], agents[0]
    
    # Try agent -> artifact
    if agents and artifacts:
        return agents[0], artifacts[0]
    
    # Try artifact -> blockchain
    if artifacts and blockchains:
        return artifacts[0], blockchains[0]
    
    # Try agent -> blockchain
    if agents and blockchains:
        return agents[0], blockchains[0]
    
    # No suitable pair found
    return None, None


def visualization_agent(state: AppState) -> Dict[str, Any]:
    """
    Visualization agent that orchestrates the creation of visualization data assets.
    
    This agent is responsible for:
    1. Calling NetworkXProvenanceTool to create a NetworkX graph from agent traces and blockchain logs
    2. Calling ShortestPathTool to find a highlighted path in the graph for visualization
    3. Calling GraphSerializationTool to convert the graph into JSON format for 3D visualization
    4. Saving the visualization assets to state.visualization_assets
    
    Args:
        state (AppState): The current application state containing agent traces and blockchain logs
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including visualization assets
        
    Raises:
        WorkflowError: If there's an error during visualization generation
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Visualization agent processing visualization generation task")
    
    try:
        # Check if we have the required data for visualization
        if not state.agent_trace and not state.blockchain_log:
            raise VisualizationError("No agent traces or blockchain logs found for visualization")
        
        # Get the NetworkXProvenanceTool from the registry
        registry = ToolRegistry()
        provenance_tool = registry.get_tool("networkx_provenance")
        
        if not provenance_tool:
            # If tool is not registered, create a new instance
            logger.warning(f"[{request_id}] NetworkXProvenanceTool not found in registry, creating new instance")
            provenance_tool = NetworkXProvenanceTool()
        
        # Create the provenance graph using agent traces and blockchain logs
        logger.info(f"[{request_id}] Creating provenance graph from agent traces and blockchain logs")
        provenance_result = provenance_tool.run(list(state.agent_trace), list(state.blockchain_log))
        
        if not provenance_result["success"]:
            raise WorkflowError(f"Failed to create provenance graph: {provenance_result.get('error', 'Unknown error')}")
        
        # Get the graph from the provenance result
        graph = provenance_result["graph"]
        
        # Initialize highlighted path data
        highlighted_path = {
            "success": False,
            "message": "No suitable source/target nodes found for path highlighting"
        }
        
        # Try to find a path to highlight
        try:
            # Get the ShortestPathTool from the registry
            shortest_path_tool = registry.get_tool("shortest_path")
            
            if not shortest_path_tool:
                # If tool is not registered, create a new instance
                logger.warning(f"[{request_id}] ShortestPathTool not found in registry, creating new instance")
                shortest_path_tool = ShortestPathTool()
            
            # Check if we're doing granular traceability for a specific data point
            if state.trace_data_point:
                logger.info(f"[{request_id}] Performing granular traceability for data point: {state.trace_data_point}")
                # Find source and target nodes for the specific data point
                source_node, target_node = _find_data_point_nodes(graph, state.trace_data_point)
                
                if source_node and target_node:
                    logger.info(f"[{request_id}] Finding path for data point '{state.trace_data_point}' from '{source_node}' to '{target_node}'")
                    highlighted_path = shortest_path_tool.run(graph, source_node, target_node)
                    logger.info(f"[{request_id}] Data point path highlighting {'succeeded' if highlighted_path['success'] else 'failed'}")
                else:
                    logger.warning(f"[{request_id}] Could not find source/target nodes for data point: {state.trace_data_point}")
                    if not source_node:
                        logger.warning(f"[{request_id}] Source node for data point '{state.trace_data_point}' not found")
                    if not target_node:
                        logger.warning(f"[{request_id}] Target node for data point '{state.trace_data_point}' not found")
            else:
                # Use the default path finding logic
                logger.info(f"[{request_id}] Performing general path highlighting")
                # Find suitable source and target nodes
                source_node, target_node = _find_path_nodes(graph)
                
                if source_node and target_node:
                    logger.info(f"[{request_id}] Finding shortest path from '{source_node}' to '{target_node}'")
                    highlighted_path = shortest_path_tool.run(graph, source_node, target_node)
                    logger.info(f"[{request_id}] Path highlighting {'succeeded' if highlighted_path['success'] else 'failed'}")
                else:
                    logger.info(f"[{request_id}] No suitable source/target nodes found for path highlighting")
        except Exception as e:
            logger.error(f"[{request_id}] Error during path highlighting: {str(e)}")
            highlighted_path = {
                "success": False,
                "error": f"Error during path highlighting: {str(e)}"
            }
        
        # Get the GraphSerializationTool from the registry
        serialization_tool = registry.get_tool("graph_serialization")
        
        if not serialization_tool:
            # If tool is not registered, create a new instance
            logger.warning(f"[{request_id}] GraphSerializationTool not found in registry, creating new instance")
            serialization_tool = GraphSerializationTool()
        
        # Serialize the graph for 3D visualization
        logger.info(f"[{request_id}] Serializing graph for 3D visualization")
        serialization_result = serialization_tool.run(graph, format="threejs", optimize=True, compress=True)
        
        if not serialization_result["success"]:
            raise WorkflowError(f"Failed to serialize graph: {serialization_result.get('error', 'Unknown error')}")
        
        # Prepare visualization assets
        visualization_assets = {
            "provenance_graph": {
                "node_count": provenance_result["node_count"],
                "edge_count": provenance_result["edge_count"],
                "validation": provenance_result["validation"],
                "created_at": provenance_result["timestamp"]
            },
            "serialized_graph": {
                "json_data": serialization_result["serialized_graph"],
                "format": serialization_result["format"],
                "size": serialization_result["size"],
                "compressed": serialization_result["compressed"],
                "optimized": serialization_result["optimized"],
                "created_at": serialization_result["timestamp"]
            },
            "highlighted_path": highlighted_path,
            "metadata": {
                "request_id": request_id,
                "agent": "visualization_agent",
                "timestamp": datetime.utcnow().isoformat()
            }
        }
        
        # Add granular traceability information if applicable
        if state.trace_data_point:
            visualization_assets["granular_traceability"] = {
                "data_point_id": state.trace_data_point,
                "path_analysis": highlighted_path
            }
        
        # Prepare the result updates
        result_updates = {
            "workflow_status": "visualization_generated",
            "visualization_assets": visualization_assets,
            "processing_results": {
                **state.processing_results,
                "visualization_result": {
                    "success": True,
                    "node_count": provenance_result["node_count"],
                    "edge_count": provenance_result["edge_count"],
                    "json_size": serialization_result["size"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            },
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "visualization_agent",
                    "request_id": request_id,
                    "action": "visualization_generated",
                    "node_count": provenance_result["node_count"],
                    "edge_count": provenance_result["edge_count"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
        
        logger.info(f"[{request_id}] Successfully generated visualization assets")
        logger.info(f"[{request_id}] Graph: {provenance_result['node_count']} nodes, {provenance_result['edge_count']} edges")
        logger.info(f"[{request_id}] JSON Size: {serialization_result['size']} characters")
        
        return result_updates
        
    except Exception as e:
        error_msg = f"Visualization generation failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "visualization_generation_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "visualization_agent",
                    "request_id": request_id,
                    "action": "visualization_generation_failed",
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }