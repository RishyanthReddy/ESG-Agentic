"""
Verification Agent

This module implements an agent responsible for orchestrating verification tasks
using both the live GleifVerifierTool and AzureVerifiedIDTool to verify credentials.
"""

from typing import Dict, Any
from src.state.models import AppState, vLEICredential, VerificationStatus
from src.tools.verification import GleifVerifierTool, AzureVerifiedIDTool
from src.tools.registry import ToolRegistry
from loguru import logger
import uuid


class VerificationError(Exception):
    """Custom exception for verification failures"""
    pass


def verification_agent(state: AppState) -> Dict[str, Any]:
    """
    Verification agent that orchestrates verification tasks using both AzureVerifiedIDTool and GleifVerifierTool.
    
    This agent is responsible for:
    1. Extracting the credential that needs to be verified from the state
    2. Determining the credential type and routing to appropriate tools
    3. Calling the appropriate verification tools (Azure or GLEIF) to perform the verification
    4. Updating the vLEICredential object in state.verifiable_credentials with the result
    
    Args:
        state (AppState): The current application state containing the credential to verify
        
    Returns:
        Dict[str, Any]: Updates to apply to the state including verification results
        
    Raises:
        VerificationError: If there's an error during verification
    """
    # Generate a request ID for traceability
    request_id = str(uuid.uuid4())
    logger.info(f"[{request_id}] Verification agent processing verification task")
    
    try:
        # Get tools from the registry
        registry = ToolRegistry()
        
        # Get both tools
        gleif_tool = registry.get_tool("gleif_verifier")
        azure_tool = registry.get_tool("azure_verified_id")
        
        # If tools are not registered, create new instances
        if not gleif_tool:
            logger.warning(f"[{request_id}] GleifVerifierTool not found in registry, creating new instance")
            gleif_tool = GleifVerifierTool()
            
        if not azure_tool:
            logger.warning(f"[{request_id}] AzureVerifiedIDTool not found in registry, creating new instance")
            azure_tool = AzureVerifiedIDTool()
        
        # Extract the credential to verify
        credential_to_verify = state.current_credential
        
        if not credential_to_verify:
            # If no current credential, look in the credentials list for one to verify
            pending_credentials = [
                cred for cred in state.credentials 
                if cred.verification_status == VerificationStatus.PENDING
            ]
            
            if pending_credentials:
                credential_to_verify = pending_credentials[0]
            else:
                raise VerificationError("No credential found for verification")
        
        logger.info(f"[{request_id}] Verifying credential {credential_to_verify.id}")
        
        # Determine credential type and route to appropriate tool(s)
        verification_results = []
        
        # Check if it's an Azure credential (based on issuer or claims)
        if _is_azure_credential(credential_to_verify):
            logger.info(f"[{request_id}] Routing credential to Azure Verified ID tool")
            azure_result = azure_tool.run("verify", presentation_request={
                "credential": credential_to_verify.dict()
            })
            verification_results.append({
                "tool": "azure_verified_id",
                "result": azure_result
            })
        
        # Check if it's a GLEIF credential (based on subject format or claims)
        if _is_gleif_credential(credential_to_verify):
            logger.info(f"[{request_id}] Routing credential to GLEIF Verifier tool")
            gleif_result = gleif_tool.run(credential_to_verify)
            verification_results.append({
                "tool": "gleif_verifier",
                "result": gleif_result
            })
        
        # If no specific tool was matched, try both
        if not verification_results:
            logger.info(f"[{request_id}] No specific credential type detected, trying both tools")
            # Try GLEIF first as default
            gleif_result = gleif_tool.run(credential_to_verify)
            verification_results.append({
                "tool": "gleif_verifier",
                "result": gleif_result
            })
            
            # Also try Azure
            azure_result = azure_tool.run("verify", presentation_request={
                "credential": credential_to_verify.dict()
            })
            verification_results.append({
                "tool": "azure_verified_id",
                "result": azure_result
            })
        
        # Consolidate verification results
        consolidated_result = _consolidate_verification_results(verification_results)
        
        # Update the credential with verification results
        updated_credential = credential_to_verify.copy()
        if consolidated_result["verified"]:
            updated_credential.verification_status = VerificationStatus.VERIFIED
        else:
            updated_credential.verification_status = VerificationStatus.FAILED
        
        # Store detailed verification results in the credential claims
        updated_credential.claims["verification_details"] = verification_results
        updated_credential.claims["consolidated_result"] = consolidated_result
        
        # Update the credentials list with the verified credential
        updated_credentials = state.credentials.copy()
        credential_found = False
        for i, cred in enumerate(updated_credentials):
            if cred.id == updated_credential.id:
                updated_credentials[i] = updated_credential
                credential_found = True
                break
        
        # If credential wasn't in the list, add it
        if not credential_found:
            updated_credentials.append(updated_credential)
        
        # Prepare the result updates
        result_updates = {
            "workflow_status": "credential_verified",
            "credentials": updated_credentials,
            "processing_results": {
                **state.processing_results,
                "verification_results": verification_results,
                "consolidated_result": consolidated_result
            },
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "verification_agent",
                    "request_id": request_id,
                    "action": "credential_verified",
                    "credential_id": str(credential_to_verify.id),
                    "verified": consolidated_result["verified"],
                    "tools_used": [r["tool"] for r in verification_results],
                    "timestamp": __import__('datetime').datetime.utcnow().isoformat()
                }
            ]
        }
        
        # Update current_credential if it was the one being verified
        if state.current_credential and state.current_credential.id == updated_credential.id:
            result_updates["current_credential"] = updated_credential
        
        logger.info(f"[{request_id}] Successfully verified credential {credential_to_verify.id}")
        logger.info(f"[{request_id}] Consolidated verification result: {consolidated_result['verified']}")
        
        return result_updates
        
    except Exception as e:
        error_msg = f"Verification failed: {str(e)}"
        logger.error(f"[{request_id}] {error_msg}")
        
        # Add error to state
        return {
            "errors": [*state.errors, error_msg],
            "workflow_status": "verification_failed",
            "agent_trace": [
                *state.agent_trace,
                {
                    "agent": "verification_agent",
                    "request_id": request_id,
                    "action": "verification_failed",
                    "error": str(e),
                    "timestamp": __import__('datetime').datetime.utcnow().isoformat()
                }
            ]
        }


def _is_azure_credential(credential: vLEICredential) -> bool:
    """
    Determine if a credential should be verified using Azure Verified ID.
    
    Args:
        credential (vLEICredential): The credential to check
        
    Returns:
        bool: True if it's an Azure credential, False otherwise
    """
    # Check issuer for Azure-related identifiers
    if "azure" in credential.issuer.lower() or "microsoft" in credential.issuer.lower():
        return True
    
    # Check claims for Azure-specific fields
    if "azp" in credential.claims or "appid" in credential.claims:
        return True
    
    return False


def _is_gleif_credential(credential: vLEICredential) -> bool:
    """
    Determine if a credential should be verified using GLEIF Verifier.
    
    Args:
        credential (vLEICredential): The credential to check
        
    Returns:
        bool: True if it's a GLEIF credential, False otherwise
    """
    # Check subject for LEI format (DID with LEI)
    if credential.subject.startswith("did:lei:"):
        return True
    
    # Check claims for LEI
    if "lei" in credential.claims:
        return True
    
    return False


def _consolidate_verification_results(results: list) -> Dict[str, Any]:
    """
    Consolidate results from multiple verification tools.
    
    Args:
        results (list): List of verification results from different tools
        
    Returns:
        Dict[str, Any]: Consolidated verification result
    """
    if not results:
        return {
            "verified": False,
            "reason": "No verification results available",
            "tools_used": []
        }
    
    # If we have results from multiple tools, we need to consolidate them
    verified_count = 0
    total_count = len(results)
    reasons = []
    tools_used = []
    
    for result in results:
        tools_used.append(result["tool"])
        verification_result = result["result"]
        
        # Check if this tool's verification was successful
        if isinstance(verification_result, dict) and verification_result.get("verified", False):
            verified_count += 1
            reason = verification_result.get("reason", "Verified")
        elif isinstance(verification_result, dict) and "verification_requested" in verification_result:
            # For Azure, verification_requested means the process started
            if verification_result.get("verification_requested", False):
                verified_count += 1
                reason = "Verification requested"
            else:
                reason = verification_result.get("error", "Verification failed")
        else:
            reason = "Verification failed"
            
        reasons.append(f"{result['tool']}: {reason}")
    
    # Consolidate based on results
    if verified_count == total_count:
        # All tools verified successfully
        consolidated_verified = True
        consolidated_reason = "All verification tools confirmed the credential"
    elif verified_count > 0:
        # Some tools verified successfully
        consolidated_verified = True
        consolidated_reason = f"Partial verification success: {', '.join(reasons)}"
    else:
        # No tools verified successfully
        consolidated_verified = False
        consolidated_reason = f"All verification tools failed: {', '.join(reasons)}"
    
    return {
        "verified": consolidated_verified,
        "reason": consolidated_reason,
        "tools_used": tools_used,
        "details": results
    }