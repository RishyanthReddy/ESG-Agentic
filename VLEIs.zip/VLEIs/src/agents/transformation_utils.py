"""
Transformation utilities for mapping internal data model to regulatory standards
"""

from typing import Dict, Any, Optional
from src.state.models import vLEICredential, GRIReport, SASBReport, TCFDReport, CSRDReport


def transform_to_gri(credential: Optional[vLEICredential], existing_gri: Optional[GRIReport] = None) -> Dict[str, Any]:
    """
    Transform internal data model to GRI format
    
    Args:
        credential: vLEI credential containing ESG data
        existing_gri: Existing GRI report to enhance
        
    Returns:
        Dict containing GRI-formatted data
    """
    # Initialize with existing data if available
    if existing_gri:
        gri_data = {
            "general_disclosure": existing_gri.general_disclosure or {},
            "management_approach": existing_gri.management_approach or {},
            "topic_specific_disclosure": existing_gri.topic_specific_disclosure or {}
        }
    else:
        gri_data = {
            "general_disclosure": {},
            "management_approach": {},
            "topic_specific_disclosure": {}
        }
    
    # If we have a credential, extract relevant data
    if credential and credential.claims:
        org_info = credential.claims.get("organization", {})
        
        # Populate general disclosure
        gri_data["general_disclosure"].update({
            "company_name": org_info.get("name"),
            "company_description": org_info.get("description"),
            "primary_sector": org_info.get("sector"),
            "operating_countries": org_info.get("countries", []),
            "number_of_employees": org_info.get("employee_count")
        })
        
        # Populate management approach
        gri_data["management_approach"].update({
            "policies": credential.claims.get("policies", {}),
            "governance": credential.claims.get("governance", {}),
            "strategies": credential.claims.get("strategies", {})
        })
        
        # Populate topic-specific disclosure
        gri_data["topic_specific_disclosure"].update({
            "environmental": credential.claims.get("environmental", {}),
            "social": credential.claims.get("social", {}),
            "economic": credential.claims.get("economic", {})
        })
    
    return gri_data


def transform_to_sasb(credential: Optional[vLEICredential], existing_sasb: Optional[SASBReport] = None) -> Dict[str, Any]:
    """
    Transform internal data model to SASB format
    
    Args:
        credential: vLEI credential containing ESG data
        existing_sasb: Existing SASB report to enhance
        
    Returns:
        Dict containing SASB-formatted data
    """
    # Initialize with existing data if available
    if existing_sasb:
        sasb_data = {
            "environmental_indicators": existing_sasb.environmental_indicators or {},
            "social_indicators": existing_sasb.social_indicators or {},
            "governance_indicators": existing_sasb.governance_indicators or {}
        }
    else:
        sasb_data = {
            "environmental_indicators": {},
            "social_indicators": {},
            "governance_indicators": {}
        }
    
    # If we have a credential, extract relevant data
    if credential and credential.claims:
        # Populate environmental indicators
        sasb_data["environmental_indicators"].update({
            "emissions": credential.claims.get("environmental", {}).get("emissions", {}),
            "energy_consumption": credential.claims.get("environmental", {}).get("energy", {}),
            "water_usage": credential.claims.get("environmental", {}).get("water", {})
        })
        
        # Populate social indicators
        sasb_data["social_indicators"].update({
            "workforce_health_safety": credential.claims.get("social", {}).get("workforce", {}),
            "product_safety": credential.claims.get("social", {}).get("products", {}),
            "data_security": credential.claims.get("social", {}).get("data", {})
        })
        
        # Populate governance indicators
        sasb_data["governance_indicators"].update({
            "ethics_reporting": credential.claims.get("governance", {}).get("ethics", {}),
            "financial_reporting": credential.claims.get("governance", {}).get("financial", {}),
            "systemic_risk_management": credential.claims.get("governance", {}).get("risk", {})
        })
    
    return sasb_data


def transform_to_tcfd(credential: Optional[vLEICredential], existing_tcfd: Optional[TCFDReport] = None) -> Dict[str, Any]:
    """
    Transform internal data model to TCFD format
    
    Args:
        credential: vLEI credential containing ESG data
        existing_tcfd: Existing TCFD report to enhance
        
    Returns:
        Dict containing TCFD-formatted data
    """
    # Initialize with existing data if available
    if existing_tcfd:
        tcfd_data = {
            "governance": existing_tcfd.governance or {},
            "strategy": existing_tcfd.strategy or {},
            "risk_management": existing_tcfd.risk_management or {},
            "metrics_and_targets": existing_tcfd.metrics_and_targets or {}
        }
    else:
        tcfd_data = {
            "governance": {},
            "strategy": {},
            "risk_management": {},
            "metrics_and_targets": {}
        }
    
    # If we have a credential, extract relevant data
    if credential and credential.claims:
        # Populate governance
        tcfd_data["governance"].update({
            "climate_related_risks": credential.claims.get("governance", {}).get("climate_risks", {}),
            "board_oversight": credential.claims.get("governance", {}).get("board_oversight", {}),
            "management_roles": credential.claims.get("governance", {}).get("management_roles", {})
        })
        
        # Populate strategy
        tcfd_data["strategy"].update({
            "climate_related_risks": credential.claims.get("strategies", {}).get("climate_risks", {}),
            "resilience_analysis": credential.claims.get("strategies", {}).get("resilience", {}),
            "financial_impacts": credential.claims.get("strategies", {}).get("financial_impacts", {})
        })
        
        # Populate risk management
        tcfd_data["risk_management"].update({
            "risk_identification": credential.claims.get("risk_management", {}).get("identification", {}),
            "risk_assessment": credential.claims.get("risk_management", {}).get("assessment", {}),
            "risk_mitigation": credential.claims.get("risk_management", {}).get("mitigation", {})
        })
        
        # Populate metrics and targets
        tcfd_data["metrics_and_targets"].update({
            "emission_metrics": credential.claims.get("metrics", {}).get("emissions", {}),
            "intensity_metrics": credential.claims.get("metrics", {}).get("intensity", {}),
            "targets": credential.claims.get("targets", {})
        })
    
    return tcfd_data


def transform_to_csrd(credential: Optional[vLEICredential], existing_csrd: Optional[CSRDReport] = None) -> Dict[str, Any]:
    """
    Transform internal data model to CSRD/ESRS format
    
    Args:
        credential: vLEI credential containing ESG data
        existing_csrd: Existing CSRD report to enhance
        
    Returns:
        Dict containing CSRD-formatted data with detailed ESRS-aligned fields
    """
    # Initialize with existing data if available
    if existing_csrd:
        csrd_data = {
            # ESRS Cross-Cutting Disclosures
            "business_model": existing_csrd.business_model or {},
            "double_materiality_assessment": existing_csrd.double_materiality_assessment or {},
            "impact_management_process": existing_csrd.impact_management_process or {},
            "due_diligence": existing_csrd.due_diligence or {},
            "policies": existing_csrd.policies or {},
            
            # ESRS Environmental Disclosures
            "greenhouse_gas_emissions": existing_csrd.greenhouse_gas_emissions or {},
            "climate_risks_and_opportunities": existing_csrd.climate_risks_and_opportunities or {},
            "climate_targets_and_actions": existing_csrd.climate_targets_and_actions or {},
            "pollution_emissions": existing_csrd.pollution_emissions or {},
            "pollution_prevention_measures": existing_csrd.pollution_prevention_measures or {},
            "water_consumption_and_discharge": existing_csrd.water_consumption_and_discharge or {},
            "marine_resources_impact": existing_csrd.marine_resources_impact or {},
            "biodiversity_impact": existing_csrd.biodiversity_impact or {},
            "biodiversity_protection_measures": existing_csrd.biodiversity_protection_measures or {},
            "resource_consumption": existing_csrd.resource_consumption or {},
            "circular_economy_metrics": existing_csrd.circular_economy_metrics or {},
            
            # ESRS Social Disclosures
            "workforce_demographics": existing_csrd.workforce_demographics or {},
            "workforce_health_safety": existing_csrd.workforce_health_safety or {},
            "workforce_training": existing_csrd.workforce_training or {},
            "value_chain_workers_assessment": existing_csrd.value_chain_workers_assessment or {},
            "value_chain_workers_improvement": existing_csrd.value_chain_workers_improvement or {},
            "community_impact_assessment": existing_csrd.community_impact_assessment or {},
            "community_engagement": existing_csrd.community_engagement or {},
            "product_safety": existing_csrd.product_safety or {},
            "consumer_protection": existing_csrd.consumer_protection or {},
            
            # ESRS Governance Disclosures
            "governance_body": existing_csrd.governance_body or {},
            "executive_remuneration": existing_csrd.executive_remuneration or {},
            "prevention_of_adverse_impacts": existing_csrd.prevention_of_adverse_impacts or {},
            "breach_reporting": existing_csrd.breach_reporting or {}
        }
    else:
        csrd_data = {
            # ESRS Cross-Cutting Disclosures
            "business_model": {},
            "double_materiality_assessment": {},
            "impact_management_process": {},
            "due_diligence": {},
            "policies": {},
            
            # ESRS Environmental Disclosures
            "greenhouse_gas_emissions": {},
            "climate_risks_and_opportunities": {},
            "climate_targets_and_actions": {},
            "pollution_emissions": {},
            "pollution_prevention_measures": {},
            "water_consumption_and_discharge": {},
            "marine_resources_impact": {},
            "biodiversity_impact": {},
            "biodiversity_protection_measures": {},
            "resource_consumption": {},
            "circular_economy_metrics": {},
            
            # ESRS Social Disclosures
            "workforce_demographics": {},
            "workforce_health_safety": {},
            "workforce_training": {},
            "value_chain_workers_assessment": {},
            "value_chain_workers_improvement": {},
            "community_impact_assessment": {},
            "community_engagement": {},
            "product_safety": {},
            "consumer_protection": {},
            
            # ESRS Governance Disclosures
            "governance_body": {},
            "executive_remuneration": {},
            "prevention_of_adverse_impacts": {},
            "breach_reporting": {}
        }
    
    # If we have a credential, extract relevant data
    if credential and credential.claims:
        org_info = credential.claims.get("organization", {})
        
        # Populate cross-cutting disclosure
        csrd_data["business_model"].update({
            "description": org_info.get("description"),
            "business_model": credential.claims.get("business_model", {}),
            "value_chain": credential.claims.get("value_chain", {})
        })
        
        csrd_data["double_materiality_assessment"].update(
            credential.claims.get("materiality_assessment", {})
        )
        
        csrd_data["impact_management_process"].update(
            credential.claims.get("impact_management", {})
        )
        
        csrd_data["due_diligence"].update(
            credential.claims.get("due_diligence", {})
        )
        
        csrd_data["policies"].update(
            credential.claims.get("policies", {})
        )
        
        # Populate environmental disclosure - ESRS E1 Climate Change
        csrd_data["greenhouse_gas_emissions"].update(
            credential.claims.get("environmental", {}).get("ghg_emissions", {})
        )
        
        csrd_data["climate_risks_and_opportunities"].update(
            credential.claims.get("environmental", {}).get("climate_risks", {})
        )
        
        csrd_data["climate_targets_and_actions"].update(
            credential.claims.get("targets", {}).get("climate", {})
        )
        
        # ESRS E2 Pollution
        csrd_data["pollution_emissions"].update(
            credential.claims.get("environmental", {}).get("pollution", {})
        )
        
        # ESRS E3 Water and Marine Resources
        csrd_data["water_consumption_and_discharge"].update(
            credential.claims.get("environmental", {}).get("water", {})
        )
        
        # ESRS E4 Biodiversity and Ecosystems
        csrd_data["biodiversity_impact"].update(
            credential.claims.get("environmental", {}).get("biodiversity", {})
        )
        
        # ESRS E5 Resource Use and Circular Economy
        csrd_data["resource_consumption"].update(
            credential.claims.get("environmental", {}).get("resources", {})
        )
        
        # Populate social disclosure - ESRS S1 Own Workforce
        csrd_data["workforce_demographics"].update(
            credential.claims.get("social", {}).get("workforce", {}).get("demographics", {})
        )
        
        csrd_data["workforce_health_safety"].update(
            credential.claims.get("social", {}).get("workforce", {}).get("health_safety", {})
        )
        
        # ESRS S2 Workers in Value Chain
        csrd_data["value_chain_workers_assessment"].update(
            credential.claims.get("social", {}).get("value_chain_workers", {})
        )
        
        # ESRS S3 Affected Communities
        csrd_data["community_impact_assessment"].update(
            credential.claims.get("social", {}).get("communities", {})
        )
        
        # ESRS S4 Consumers and End-Users
        csrd_data["product_safety"].update(
            credential.claims.get("social", {}).get("products", {})
        )
        
        # Populate governance disclosure - ESRS G1 Governance
        csrd_data["governance_body"].update(
            credential.claims.get("governance", {}).get("body", {})
        )
        
        csrd_data["executive_remuneration"].update(
            credential.claims.get("governance", {}).get("remuneration", {})
        )
        
        csrd_data["prevention_of_adverse_impacts"].update(
            credential.claims.get("governance", {}).get("prevention", {})
        )
        
        csrd_data["breach_reporting"].update(
            credential.claims.get("governance", {}).get("breaches", {})
        )
    
    return csrd_data