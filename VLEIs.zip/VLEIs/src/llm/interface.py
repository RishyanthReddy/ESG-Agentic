"""
LLM Interface for Agent Communication

This module defines the standardized interface for all agents to communicate with the LLM,
ensuring consistency and separation of concerns.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Union
from src.state.models import AppState


class LLMInterface(ABC):
    """
    Abstract base class for LLM interfaces.
    Defines the contract for LLM operations that agents can use.
    """
    
    @abstractmethod
    def reason_about_esg_data(self, 
                                  query: str, 
                                  context: Optional[str] = None,
                                  state: Optional[AppState] = None) -> str:
        """
        Reason about ESG data using the LLM.
        
        Args:
            query: The query or instruction for the LLM
            context: Additional context to provide to the LLM
            state: The current application state
            
        Returns:
            The LLM's response
        """
        pass
    
    @abstractmethod
    def determine_routing_path(self, 
                                   task_description: str,
                                   task_complexity: Optional[str] = None,
                                   supplier_risk: Optional[str] = None,
                                   state: Optional[AppState] = None) -> str:
        """
        Determine the optimal routing path based on task characteristics.
        
        Args:
            task_description: Description of the task to be routed
            task_complexity: Complexity level of the task
            supplier_risk: Risk level of the supplier (if applicable)
            state: The current application state
            
        Returns:
            The name of the agent to route to
        """
        pass
    
    @abstractmethod
    def assess_data_complexity(self, 
                                   data: Dict[str, Any],
                                   state: Optional[AppState] = None) -> str:
        """
        Assess the complexity of data to inform routing decisions.
        
        Args:
            data: The data to assess
            state: The current application state
            
        Returns:
            A complexity assessment (e.g., "low", "medium", "high")
        """
        pass


class GeminiLLMInterface(LLMInterface):
    """
    Concrete implementation of LLMInterface using the Gemini client.
    """
    
    def __init__(self):
        """
        Initialize the Gemini LLM interface.
        """
        # For now, we'll implement a placeholder that simulates LLM behavior
        # In a real implementation, this would connect to the actual Gemini client
        self.is_available = True
    
    def reason_about_esg_data(self, 
                                  query: str, 
                                  context: Optional[str] = None,
                                  state: Optional[AppState] = None) -> str:
        """
        Reason about ESG data using the LLM.
        
        Args:
            query: The query or instruction for the LLM
            context: Additional context to provide to the LLM
            state: The current application state
            
        Returns:
            The LLM's response
        """
        # This is a placeholder implementation
        # In a real implementation, this would call the actual Gemini API
        full_prompt = f"Context: {context}\n\nQuery: {query}" if context else query
        return f"LLM response to: {full_prompt[:100]}..."
    
    def determine_routing_path(self, 
                                   task_description: str,
                                   task_complexity: Optional[str] = None,
                                   supplier_risk: Optional[str] = None,
                                   state: Optional[AppState] = None) -> str:
        """
        Determine the optimal routing path based on task characteristics.
        
        Args:
            task_description: Description of the task to be routed
            task_complexity: Complexity level of the task
            supplier_risk: Risk level of the supplier (if applicable)
            state: The current application state
            
        Returns:
            The name of the agent to route to
        """
        # This is a placeholder implementation
        # In a real implementation, this would use the LLM to make routing decisions
        if "credential" in task_description.lower():
            return "credential_agent"
        elif "report" in task_description.lower():
            return "reporting_agent"
        else:
            return "credential_agent"  # Default fallback
    
    def assess_data_complexity(self, 
                                   data: Dict[str, Any],
                                   state: Optional[AppState] = None) -> str:
        """
        Assess the complexity of data to inform routing decisions.
        
        Args:
            data: The data to assess
            state: The current application state
            
        Returns:
            A complexity assessment (e.g., "low", "medium", "high")
        """
        # This is a placeholder implementation
        # In a real implementation, this would use the LLM to assess complexity
        return "medium"