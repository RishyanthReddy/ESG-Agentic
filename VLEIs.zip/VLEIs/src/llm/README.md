# ESG Context Management System

This module provides context management for ESG (Environmental, Social, and Governance) reasoning. It loads and caches regulation information from various ESG standards (GRI, SASB, TCFD, etc.) and provides methods for domain context injection into LLM prompts.

## Features

- **Context Loading**: Loads ESG regulation data from JSON files
- **Semantic Search**: Uses sentence transformers to find relevant context based on semantic similarity
- **Caching**: Implements LRU caching and TTL-based cache invalidation
- **Prompt Building**: Generates reasoning prompts with relevant ESG context
- **Template Engine**: Uses Jinja2 for prompt template generation

## Tech Stack

- **Context Storage**: In-memory caching with LRU eviction
- **Knowledge Base**: JSON files for ESG regulation definitions
- **Template Engine**: Jinja2 for prompt template generation
- **Context Retrieval**: Semantic search using sentence-transformers for relevant context selection
- **Cache Management**: TTL-based cache invalidation for updated regulations

## Installation

The required dependencies are included in the main [requirements.txt](../../requirements.txt) file:

```bash
pip install -r requirements.txt
```

Key dependencies:
- `sentence-transformers` - for semantic search capabilities
- `jinja2` - for template rendering
- `torch` - for transformer models

## Usage

```python
from src.llm.context import ESGContextManager

# Initialize the context manager
context_manager = ESGContextManager()

# Get relevant context for a query
query = "What are the key requirements for ESG reporting under the GRI standards?"
relevant_context = context_manager.get_relevant_context(query, top_k=3)

# Build a reasoning prompt with context
prompt = context_manager.build_reasoning_prompt(query)
```

## Data Structure

The ESG regulation data is stored in JSON files in the [context_data](context_data/) directory:

- [gri_standards.json](context_data/gri_standards.json) - Global Reporting Initiative standards
- [sasb_standards.json](context_data/sasb_standards.json) - Sustainability Accounting Standards Board standards
- [tcfd_recommendations.json](context_data/tcfd_recommendations.json) - Task Force on Climate-related Financial Disclosures recommendations

## API

### ESGContextManager

#### `__init__(context_data_dir="src/llm/context_data", cache_ttl=3600)`
Initialize the ESG Context Manager.

- `context_data_dir`: Directory containing ESG regulation JSON files
- `cache_ttl`: Time-to-live for cached context data in seconds

#### `get_relevant_context(query, top_k=3)`
Retrieve relevant context based on semantic similarity.

- `query`: Query string to find relevant context for
- `top_k`: Number of top relevant contexts to return

#### `build_reasoning_prompt(query, template=None)`
Build a reasoning prompt with relevant ESG context.

- `query`: The query to build context for
- `template`: Optional Jinja2 template string

#### `refresh_context_data()`
Refresh context data from files, clearing caches.

## Testing

Unit tests are located in [tests/test_esg_context.py](../../tests/test_esg_context.py) and can be run with:

```bash
python -m pytest tests/test_esg_context.py -v
```

Integration tests are located in [tests/test_esg_context_integration.py](../../tests/test_esg_context_integration.py) and can be run with:

```bash
python tests/test_esg_context_integration.py
```

## Demo

A demonstration script is available at [demo_context_manager.py](demo_context_manager.py):

```bash
python src/llm/demo_context_manager.py
```

## Implementation Details

The ESG Context Manager uses the following techniques:

1. **Semantic Search**: Uses the `all-MiniLM-L6-v2` sentence transformer model to encode text and compute cosine similarity between queries and regulation content.

2. **Caching**: Implements two levels of caching:
   - LRU cache for embeddings using `functools.lru_cache`
   - TTL-based cache invalidation for data freshness

3. **Template Engine**: Uses Jinja2 templates for flexible prompt generation.

4. **Data Structure**: JSON files organized by ESG standard for easy maintenance and extension.