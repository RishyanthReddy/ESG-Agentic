"""
Gemini LLM Client

This module implements a robust and secure connection to the Gemini 2.0 Flash model,
serving as the core reasoning engine.
"""

import os
import httpx
import asyncio
from typing import Optional, Dict, Any, List
from loguru import logger
import json
from config import settings


class LLMError(Exception):
    """Custom exception for LLM-related errors"""
    pass


class GeminiClient:
    """
    Client for interacting with the Gemini 2.0 Flash model via the Glama API.
    """
    
    def __init__(self, 
                 api_key: Optional[str] = None,
                 base_url: str = "https://glama.ai/api/gemini/v2.0",
                 timeout: int = 30):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: The API key for authentication (defaults to GLAMA_API_KEY from settings)
            base_url: The base URL for the Gemini API
            timeout: Request timeout in seconds
        """
        self.api_key = api_key or settings.GLAMA_API_KEY
        self.base_url = base_url
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)
        
        if not self.api_key:
            raise LLMError("API key is required for Gemini client")
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.aclose()
    
    async def generate_content(self, 
                             prompt: str,
                             model: str = "gemini-2.0-flash",
                             temperature: float = 0.7,
                             max_tokens: int = 1000) -> str:
        """
        Generate content using the Gemini model.
        
        Args:
            prompt: The prompt to send to the model
            model: The model to use
            temperature: The temperature for generation (0.0 to 1.0)
            max_tokens: Maximum number of tokens to generate
            
        Returns:
            The generated content
            
        Raises:
            LLMError: If there's an error during content generation
        """
        url = f"{self.base_url}/generate"
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model,
            "prompt": prompt,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            response = await self.client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            return data.get("content", "")
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error occurred: {e}")
            raise LLMError(f"HTTP error: {e}")
        except httpx.RequestError as e:
            logger.error(f"Request error occurred: {e}")
            raise LLMError(f"Request error: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise LLMError(f"JSON decode error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            raise LLMError(f"Unexpected error: {e}")
    
    async def chat_completion(self,
                            messages: List[Dict[str, str]],
                            model: str = "gemini-2.0-flash",
                            temperature: float = 0.7,
                            max_tokens: int = 1000) -> str:
        """
        Generate a chat completion using the Gemini model.
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            model: The model to use
            temperature: The temperature for generation (0.0 to 1.0)
            max_tokens: Maximum number of tokens to generate
            
        Returns:
            The generated content
            
        Raises:
            LLMError: If there's an error during content generation
        """
        url = f"{self.base_url}/chat"
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        try:
            response = await self.client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            return data.get("content", "")
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error occurred: {e}")
            raise LLMError(f"HTTP error: {e}")
        except httpx.RequestError as e:
            logger.error(f"Request error occurred: {e}")
            raise LLMError(f"Request error: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            raise LLMError(f"JSON decode error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            raise LLMError(f"Unexpected error: {e}")