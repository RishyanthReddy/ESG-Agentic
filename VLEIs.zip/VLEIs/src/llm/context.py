"""
ESG Context Management for ESG Reasoning
"""
import os
import json
import time
from typing import Dict, List, Any, Optional
from functools import lru_cache
from jinja2 import Template
from sentence_transformers import SentenceTransformer
from sentence_transformers.util import cos_sim
import numpy as np


class ESGContextManager:
    """
    Manages ESG domain knowledge and regulatory context for LLM reasoning.
    
    This class loads and caches regulation information (GRI, SASB, etc.) and provides
    methods for domain context injection into LLM prompts.
    """
    
    def __init__(self, context_data_dir: str = "src/llm/context_data", cache_ttl: int = 3600):
        """
        Initialize the ESGContextManager.
        
        Args:
            context_data_dir: Directory containing ESG regulation JSON files
            cache_ttl: Time-to-live for cached context data in seconds
        """
        self.context_data_dir = context_data_dir
        self.cache_ttl = cache_ttl
        self._cache_timestamps = {}
        self._embeddings_cache = {}
        
        # Initialize the sentence transformer model for semantic search
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Load all regulation data
        self.regulation_data = self._load_regulation_data()
        
    def _load_regulation_data(self) -> Dict[str, Any]:
        """
        Load regulation data from JSON files.
        
        Returns:
            Dictionary containing all regulation data
        """
        regulation_data = {}
        
        if not os.path.exists(self.context_data_dir):
            raise FileNotFoundError(f"Context data directory not found: {self.context_data_dir}")
            
        for filename in os.listdir(self.context_data_dir):
            if filename.endswith('.json'):
                file_path = os.path.join(self.context_data_dir, filename)
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    standard_name = data.get('standard', filename.replace('.json', ''))
                    regulation_data[standard_name] = data
                    
        return regulation_data
    
    def _is_cache_valid(self, key: str) -> bool:
        """
        Check if cache is still valid based on TTL.
        
        Args:
            key: Cache key to check
            
        Returns:
            True if cache is valid, False otherwise
        """
        if key not in self._cache_timestamps:
            return False
        return (time.time() - self._cache_timestamps[key]) < self.cache_ttl
    
    def _update_cache_timestamp(self, key: str):
        """
        Update the timestamp for a cache entry.
        
        Args:
            key: Cache key to update
        """
        self._cache_timestamps[key] = time.time()
    
    @lru_cache(maxsize=128)
    def _get_regulation_embeddings(self, standard: str) -> Dict[str, np.ndarray]:
        """
        Get embeddings for regulation content using LRU cache.
        
        Args:
            standard: The regulation standard name
            
        Returns:
            Dictionary of embeddings for regulation content
        """
        if standard not in self.regulation_data:
            return {}
            
        embeddings = {}
        standard_data = self.regulation_data[standard]
        
        # Create embeddings for different parts of the regulation data
        if 'topics' in standard_data:
            for i, topic in enumerate(standard_data['topics']):
                topic_text = f"{topic.get('title', '')} {topic.get('description', '')}"
                embeddings[f"topic_{i}"] = self.model.encode(topic_text)
                
        if 'core_elements' in standard_data:
            for i, element in enumerate(standard_data['core_elements']):
                element_text = f"{element.get('element', '')} {element.get('description', '')}"
                embeddings[f"element_{i}"] = self.model.encode(element_text)
                
        if 'industries' in standard_data:
            for i, industry in enumerate(standard_data['industries']):
                industry_text = f"{industry.get('name', '')}"
                embeddings[f"industry_{i}"] = self.model.encode(industry_text)
                
        return embeddings
    
    def get_relevant_context(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """
        Retrieve relevant context based on semantic similarity.
        
        Args:
            query: Query string to find relevant context for
            top_k: Number of top relevant contexts to return
            
        Returns:
            List of relevant context items
        """
        query_embedding = self.model.encode(query)
        relevant_contexts = []
        
        # Search across all regulation standards
        for standard, data in self.regulation_data.items():
            embeddings = self._get_regulation_embeddings(standard)
            
            # Calculate similarities
            for key, embedding in embeddings.items():
                similarity = cos_sim(query_embedding, embedding).item()
                context_item = {
                    'standard': standard,
                    'similarity': similarity,
                    'content': self._get_content_by_key(standard, key)
                }
                relevant_contexts.append(context_item)
        
        # Sort by similarity and return top_k
        relevant_contexts.sort(key=lambda x: x['similarity'], reverse=True)
        return relevant_contexts[:top_k]
    
    def _get_content_by_key(self, standard: str, key: str) -> Dict[str, Any]:
        """
        Get content by key from regulation data.
        
        Args:
            standard: The regulation standard
            key: Key to identify the content
            
        Returns:
            Content dictionary
        """
        data = self.regulation_data[standard]
        content = {'standard': standard}
        
        if key.startswith('topic_'):
            index = int(key.split('_')[1])
            if 'topics' in data and index < len(data['topics']):
                content.update(data['topics'][index])
        elif key.startswith('element_'):
            index = int(key.split('_')[1])
            if 'core_elements' in data and index < len(data['core_elements']):
                content.update(data['core_elements'][index])
        elif key.startswith('industry_'):
            index = int(key.split('_')[1])
            if 'industries' in data and index < len(data['industries']):
                content.update(data['industries'][index])
                
        return content
    
    def build_reasoning_prompt(self, query: str, template: Optional[str] = None) -> str:
        """
        Build a reasoning prompt with relevant ESG context.
        
        Args:
            query: The query to build context for
            template: Optional Jinja2 template string
            
        Returns:
            Formatted prompt with context
        """
        # Get relevant context
        relevant_context = self.get_relevant_context(query)
        
        # Default template if none provided
        if template is None:
            template = """
You are an ESG (Environmental, Social, and Governance) expert. Use the following context to answer the question according to ESG standards and regulations.

Context:
{% for context in relevant_context %}
Standard: {{ context.standard }}
Content: {{ context.content }}
Similarity: {{ "%.2f"|format(context.similarity) }}
---
{% endfor %}

Question: {{ query }}

Please provide a detailed answer based on the ESG context provided above.
"""
        
        # Render template with context
        t = Template(template)
        return t.render(relevant_context=relevant_context, query=query)
    
    def refresh_context_data(self):
        """
        Refresh context data from files, clearing caches.
        """
        # Clear LRU cache
        self._get_regulation_embeddings.cache_clear()
        
        # Clear internal caches
        self._cache_timestamps.clear()
        self._embeddings_cache.clear()
        
        # Reload regulation data
        self.regulation_data = self._load_regulation_data()