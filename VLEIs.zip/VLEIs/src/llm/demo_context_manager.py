"""
Demo script for ESG Context Manager
"""
import os
import sys

# Add the parent directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.llm.context import ESGContextManager


def main():
    """Demonstrate the ESG Context Manager functionality."""
    print("ESG Context Manager Demo")
    print("=" * 50)
    
    # Initialize the context manager
    print("Initializing ESG Context Manager...")
    context_manager = ESGContextManager()
    print(f"Loaded {len(context_manager.regulation_data)} regulation standards\n")
    
    # Show available standards
    print("Available ESG Standards:")
    for standard in context_manager.regulation_data.keys():
        print(f"  - {standard}")
    print()
    
    # Test queries
    queries = [
        "What are the key requirements for ESG reporting under the GRI standards?",
        "How should companies report their climate-related financial disclosures according to TCFD?",
        "What are the SASB standards for the oil and gas industry?"
    ]
    
    for i, query in enumerate(queries, 1):
        print(f"Query {i}: {query}")
        print("-" * 40)
        
        # Get relevant context
        relevant_context = context_manager.get_relevant_context(query, top_k=2)
        
        print(f"Retrieved {len(relevant_context)} relevant contexts:")
        for j, ctx in enumerate(relevant_context):
            print(f"  {j+1}. Standard: {ctx['standard']}")
            print(f"     Similarity: {ctx['similarity']:.3f}")
            if 'title' in ctx['content']:
                print(f"     Title: {ctx['content']['title']}")
            if 'description' in ctx['content']:
                print(f"     Description: {ctx['content']['description'][:100]}...")
            print()
        
        # Build reasoning prompt
        prompt = context_manager.build_reasoning_prompt(query)
        print(f"Generated prompt length: {len(prompt)} characters")
        print("=" * 50)
        print()


if __name__ == "__main__":
    main()