"""
Centralized Prompt Management

This module implements a PromptManager class for loading, managing, and rendering
LLM prompts from a centralized YAML configuration file.
"""

import os
import yaml
from typing import Dict, Any, Optional
from jinja2 import Environment, BaseLoader, Template
from loguru import logger
import json


class PromptError(Exception):
    """Custom exception for prompt management failures"""
    pass


class PromptManager:
    """
    Centralized prompt manager for loading and rendering LLM prompts.
    
    This class loads prompts from a YAML configuration file and provides
    methods for rendering them with dynamic context using Jinja2 templates.
    """
    
    _instance = None
    _initialized = False
    
    def __new__(cls):
        """
        Singleton pattern implementation.
        
        Returns:
            PromptManager: The single instance of PromptManager
        """
        if cls._instance is None:
            cls._instance = super(PromptManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """
        Initialize the PromptManager.
        
        Sets up the Jinja2 environment and loads prompts from the YAML file.
        """
        if self._initialized:
            return
            
        self._initialized = True
        self.prompts: Dict[str, Dict[str, Any]] = {}
        self.templates: Dict[str, Template] = {}
        self._cache: Dict[str, str] = {}
        
        # Set up Jinja2 environment
        self.jinja_env = Environment(loader=BaseLoader())
        
        # Load prompts from YAML file
        self._load_prompts()
        
        logger.info("PromptManager initialized successfully")
    
    def _load_prompts(self):
        """
        Load prompts from the prompts.yaml file.
        
        Raises:
            PromptError: If there's an error loading or parsing the prompts file
        """
        try:
            # Get the directory where this file is located
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up one level to the project root
            project_root = os.path.dirname(current_dir)
            # Path to prompts.yaml
            prompts_file = os.path.join(project_root, "prompts.yaml")
            
            logger.info(f"Loading prompts from {prompts_file}")
            
            # Check if file exists
            if not os.path.exists(prompts_file):
                raise PromptError(f"Prompts file not found: {prompts_file}")
            
            # Load and parse YAML
            with open(prompts_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            # Validate structure
            if not isinstance(data, dict) or 'prompts' not in data:
                raise PromptError("Invalid prompts file structure: missing 'prompts' key")
            
            # Store prompts
            self.prompts = data['prompts']
            
            # Pre-compile templates for better performance
            for prompt_key, prompt_data in self.prompts.items():
                if 'template' in prompt_data:
                    template = self.jinja_env.from_string(prompt_data['template'])
                    self.templates[prompt_key] = template
            
            logger.info(f"Successfully loaded {len(self.prompts)} prompts")
            
        except yaml.YAMLError as e:
            raise PromptError(f"Error parsing prompts.yaml: {str(e)}")
        except Exception as e:
            raise PromptError(f"Error loading prompts: {str(e)}")
    
    def get_prompt(self, prompt_key: str) -> Dict[str, Any]:
        """
        Get a prompt by its key.
        
        Args:
            prompt_key (str): The key of the prompt to retrieve
            
        Returns:
            Dict[str, Any]: The prompt data
            
        Raises:
            PromptError: If the prompt key is not found
        """
        if prompt_key not in self.prompts:
            raise PromptError(f"Prompt '{prompt_key}' not found")
        
        return self.prompts[prompt_key]
    
    def render_prompt(self, prompt_key: str, **context) -> str:
        """
        Render a prompt template with the provided context.
        
        Args:
            prompt_key (str): The key of the prompt to render
            **context: Context variables to render the template with
            
        Returns:
            str: The rendered prompt
            
        Raises:
            PromptError: If there's an error rendering the prompt
        """
        try:
            # Check cache first
            cache_key = self._generate_cache_key(prompt_key, context)
            if cache_key in self._cache:
                logger.debug(f"Cache hit for prompt '{prompt_key}'")
                return self._cache[cache_key]
            
            # Get template
            if prompt_key not in self.templates:
                if prompt_key not in self.prompts:
                    raise PromptError(f"Prompt '{prompt_key}' not found")
                
                # Compile template on-demand if not pre-compiled
                prompt_template = self.prompts[prompt_key].get('template')
                if not prompt_template:
                    raise PromptError(f"Prompt '{prompt_key}' has no template")
                
                template = self.jinja_env.from_string(prompt_template)
                self.templates[prompt_key] = template
            else:
                template = self.templates[prompt_key]
            
            # Render template
            rendered_prompt = template.render(**context)
            
            # Cache the result
            self._cache[cache_key] = rendered_prompt
            
            logger.debug(f"Rendered prompt '{prompt_key}' with context: {list(context.keys())}")
            return rendered_prompt
            
        except Exception as e:
            raise PromptError(f"Error rendering prompt '{prompt_key}': {str(e)}")
    
    def _generate_cache_key(self, prompt_key: str, context: Dict[str, Any]) -> str:
        """
        Generate a cache key for a prompt and context combination.
        
        Args:
            prompt_key (str): The prompt key
            context (Dict[str, Any]): The context dictionary
            
        Returns:
            str: A cache key
        """
        # Create a simple hashable representation of the context
        try:
            context_str = json.dumps(context, sort_keys=True, default=str)
            return f"{prompt_key}:{hash(context_str)}"
        except Exception:
            # Fallback if we can't serialize the context
            return f"{prompt_key}:{id(context)}"
    
    def list_prompts(self) -> Dict[str, str]:
        """
        List all available prompts with their descriptions.
        
        Returns:
            Dict[str, str]: A dictionary mapping prompt keys to their descriptions
        """
        return {
            key: prompt.get('description', 'No description available')
            for key, prompt in self.prompts.items()
        }
    
    def get_prompt_names(self) -> list:
        """
        Get a list of all prompt names/keys.
        
        Returns:
            list: A list of prompt keys
        """
        return list(self.prompts.keys())
    
    def clear_cache(self):
        """
        Clear the prompt rendering cache.
        """
        self._cache.clear()
        logger.info("Prompt cache cleared")
    
    def reload_prompts(self):
        """
        Reload prompts from the YAML file.
        """
        self._load_prompts()
        self.clear_cache()
        logger.info("Prompts reloaded from file")


# Global instance
prompt_manager = PromptManager()