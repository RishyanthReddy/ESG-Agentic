"""
Centralized Error Handling Framework

This module implements a robust error handling system with custom exceptions
for graceful failure and clear logging.
"""

import traceback
import uuid
from typing import Optional, Dict, Any
from loguru import logger
from datetime import datetime


class BaseVLEIError(Exception):
    """Base exception class for all VLEI system errors"""
    
    def __init__(self, message: str, error_code: Optional[str] = None, 
                 details: Optional[Dict[str, Any]] = None):
        """
        Initialize the base error.
        
        Args:
            message: Error message
            error_code: Unique error code for identification
            details: Additional error details/context
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code or str(uuid.uuid4())
        self.details = details or {}
        self.timestamp = datetime.utcnow()
        self.request_id = self.details.get('request_id', str(uuid.uuid4()))
        
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert error to dictionary representation.
        
        Returns:
            Dictionary representation of the error
        """
        return {
            'error_code': self.error_code,
            'message': self.message,
            'details': self.details,
            'timestamp': self.timestamp.isoformat(),
            'request_id': self.request_id,
            'type': self.__class__.__name__
        }
    
    def __str__(self):
        return f"[{self.error_code}] {self.message}"


class APIFailureError(BaseVLEIError):
    """Exception raised when an API call fails"""
    
    def __init__(self, message: str, status_code: Optional[int] = None,
                 url: Optional[str] = None, response_body: Optional[str] = None,
                 error_code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        """
        Initialize the API failure error.
        
        Args:
            message: Error message
            status_code: HTTP status code
            url: URL that failed
            response_body: Response body from the failed request
            error_code: Unique error code for identification
            details: Additional error details/context
        """
        super().__init__(message, error_code, details)
        self.status_code = status_code
        self.url = url
        self.response_body = response_body
        
        # Add API-specific details
        self.details.update({
            'status_code': status_code,
            'url': url,
            'response_body': response_body
        })


class DataValidationError(BaseVLEIError):
    """Exception raised when data validation fails"""
    
    def __init__(self, message: str, field: Optional[str] = None, 
                 value: Optional[Any] = None, error_code: Optional[str] = None,
                 details: Optional[Dict[str, Any]] = None):
        """
        Initialize the data validation error.
        
        Args:
            message: Error message
            field: Field that failed validation
            value: Value that failed validation
            error_code: Unique error code for identification
            details: Additional error details/context
        """
        super().__init__(message, error_code, details)
        self.field = field
        self.value = value
        
        # Add validation-specific details
        self.details.update({
            'field': field,
            'value': value
        })


class ConfigurationError(BaseVLEIError):
    """Exception raised when configuration is invalid or missing"""
    
    def __init__(self, message: str, config_key: Optional[str] = None,
                 error_code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        """
        Initialize the configuration error.
        
        Args:
            message: Error message
            config_key: Configuration key that is invalid/missing
            error_code: Unique error code for identification
            details: Additional error details/context
        """
        super().__init__(message, error_code, details)
        self.config_key = config_key
        
        # Add config-specific details
        self.details.update({
            'config_key': config_key
        })


class WorkflowError(BaseVLEIError):
    """Exception raised when workflow execution fails"""
    
    def __init__(self, message: str, workflow_step: Optional[str] = None,
                 error_code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        """
        Initialize the workflow error.
        
        Args:
            message: Error message
            workflow_step: Workflow step where error occurred
            error_code: Unique error code for identification
            details: Additional error details/context
        """
        super().__init__(message, error_code, details)
        self.workflow_step = workflow_step
        
        # Add workflow-specific details
        self.details.update({
            'workflow_step': workflow_step
        })


def handle_error(error: Exception, context: Optional[Dict[str, Any]] = None) -> BaseVLEIError:
    """
    Handle an error by converting it to a standardized format and logging it.
    
    Args:
        error: The error to handle
        context: Additional context for the error
        
    Returns:
        Standardized error object
    """
    # If it's already one of our custom errors, just log it
    if isinstance(error, BaseVLEIError):
        standardized_error = error
    else:
        # Convert standard exceptions to our custom errors
        if isinstance(error, ValueError):
            standardized_error = DataValidationError(
                message=str(error),
                error_code="DATA_VALIDATION_ERROR"
            )
        elif isinstance(error, KeyError):
            standardized_error = ConfigurationError(
                message=str(error),
                error_code="CONFIGURATION_ERROR"
            )
        else:
            # Generic error for other exception types
            standardized_error = BaseVLEIError(
                message=str(error),
                error_code="GENERIC_ERROR"
            )
    
    # Add context if provided
    if context:
        standardized_error.details.update(context)
    
    # Log the error with rich context
    logger.error(
        f"[{standardized_error.request_id}] "
        f"{standardized_error.__class__.__name__}: {standardized_error.message}"
    )
    
    # Log stack trace for debugging
    logger.debug(
        f"[{standardized_error.request_id}] "
        f"Stack trace:\n{traceback.format_exc()}"
    )
    
    return standardized_error


def log_error(error: BaseVLEIError) -> None:
    """
    Log an error with rich context.
    
    Args:
        error: The error to log
    """
    logger.error(
        f"[{error.request_id}] "
        f"{error.__class__.__name__}: {error.message}"
    )
    
    # Log additional details if available
    if error.details:
        logger.debug(f"[{error.request_id}] Error details: {error.details}")
    
    # Log stack trace for debugging
    logger.debug(
        f"[{error.request_id}] "
        f"Stack trace:\n{traceback.format_exc()}"
    )


def safe_execute(func, *args, **kwargs):
    """
    Execute a function safely, catching and handling any exceptions.
    
    Args:
        func: Function to execute
        *args: Positional arguments for the function
        **kwargs: Keyword arguments for the function
        
    Returns:
        Tuple of (result, error) where result is the function result or None,
        and error is None or a BaseVLEIError
    """
    try:
        result = func(*args, **kwargs)
        return result, None
    except Exception as e:
        error = handle_error(e)
        return None, error