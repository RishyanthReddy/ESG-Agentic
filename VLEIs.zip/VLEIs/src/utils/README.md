# Centralized Error Handling Framework

This module implements a robust error handling system with custom exceptions for graceful failure and clear logging.

## Features

- **Exception Hierarchy**: Custom exception classes extending base exceptions
- **Error Context**: Rich error context with request IDs and stack traces
- **Logging Integration**: Structured error logging with loguru
- **Error Propagation**: Controlled error propagation through workflow
- **Recovery Strategies**: Configurable error recovery and retry logic

## Exception Hierarchy

The framework provides a comprehensive hierarchy of custom exceptions:

- `BaseVLEIError` - Base exception class for all VLEI system errors
  - `APIFailureError` - Exception raised when an API call fails
  - `DataValidationError` - Exception raised when data validation fails
  - `ConfigurationError` - Exception raised when configuration is invalid or missing
  - `WorkflowError` - Exception raised when workflow execution fails

## Usage

### Creating Custom Exceptions

```python
from src.utils.error_handling import APIFailureError, DataValidationError

# Create an API failure error
api_error = APIFailureError(
    "API service unavailable",
    status_code=503,
    url="https://api.example.com/data"
)

# Create a data validation error
validation_error = DataValidationError(
    "Invalid email format",
    field="email",
    value="invalid-email"
)
```

### Handling Errors

```python
from src.utils.error_handling import handle_error, safe_execute

# Handle an error with context
try:
    # Some operation that might fail
    result = risky_operation()
except Exception as e:
    error = handle_error(e, {"operation": "risky_operation"})
    # Process the standardized error

# Safely execute a function
result, error = safe_execute(risky_function, arg1, arg2)
if error:
    # Handle the error
    print(f"Error occurred: {error.message}")
else:
    # Use the result
    print(f"Success: {result}")
```

## API

### BaseVLEIError

Base exception class for all VLEI system errors.

**Parameters:**
- `message` (str): Error message
- `error_code` (str, optional): Unique error code for identification
- `details` (dict, optional): Additional error details/context

### APIFailureError

Exception raised when an API call fails.

**Parameters:**
- `message` (str): Error message
- `status_code` (int, optional): HTTP status code
- `url` (str, optional): URL that failed
- `response_body` (str, optional): Response body from the failed request
- `error_code` (str, optional): Unique error code for identification
- `details` (dict, optional): Additional error details/context

### DataValidationError

Exception raised when data validation fails.

**Parameters:**
- `message` (str): Error message
- `field` (str, optional): Field that failed validation
- `value` (Any, optional): Value that failed validation
- `error_code` (str, optional): Unique error code for identification
- `details` (dict, optional): Additional error details/context

### ConfigurationError

Exception raised when configuration is invalid or missing.

**Parameters:**
- `message` (str): Error message
- `config_key` (str, optional): Configuration key that is invalid/missing
- `error_code` (str, optional): Unique error code for identification
- `details` (dict, optional): Additional error details/context

### WorkflowError

Exception raised when workflow execution fails.

**Parameters:**
- `message` (str): Error message
- `workflow_step` (str, optional): Workflow step where error occurred
- `error_code` (str, optional): Unique error code for identification
- `details` (dict, optional): Additional error details/context

### handle_error(error, context=None)

Handle an error by converting it to a standardized format and logging it.

**Parameters:**
- `error` (Exception): The error to handle
- `context` (dict, optional): Additional context for the error

**Returns:**
- `BaseVLEIError`: Standardized error object

### safe_execute(func, *args, **kwargs)

Execute a function safely, catching and handling any exceptions.

**Parameters:**
- `func` (callable): Function to execute
- `*args`: Positional arguments for the function
- `**kwargs`: Keyword arguments for the function

**Returns:**
- `tuple`: Tuple of (result, error) where result is the function result or None, and error is None or a BaseVLEIError

## Testing

### Unit Tests

Unit tests are located in [tests/test_error_handling.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_error_handling.py) and cover:

- Custom exception classes and hierarchy
- Error context information capture
- Error logging with proper formatting
- Exception catching and processing

Run with:
```bash
python -m pytest tests/test_error_handling.py -v
```

### Integration Tests

Integration tests are located in [tests/test_error_handling_integration.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_error_handling_integration.py) and cover:

- Error handling in full workflows
- Error propagation from agents
- System stability under various error conditions
- Error information reaching appropriate handlers
- Performance impact of error handling framework

Run with:
```bash
python -m pytest tests/test_error_handling_integration.py -v
```