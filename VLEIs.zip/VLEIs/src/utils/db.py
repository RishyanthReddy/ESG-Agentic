"""
Database module for storing and retrieving report provenance data.

This module implements a file-based database using TinyDB to store mappings
between report IDs and cryptographic proofs for the public verification portal.
"""

import os
import json
import base64
from typing import Dict, Any, Optional
from cryptography.fernet import Fernet
from tinydb import TinyDB, Query
from tinydb.storages import JSONStorage
from tinydb.middlewares import CachingMiddleware
from loguru import logger

# Database file path
DB_FILE = "data/report_provenance.json"
DB_ENCRYPTION_KEY_FILE = "data/db.key"

# Ensure data directory exists
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)


class EncryptedStorage(JSONStorage):
    """
    Custom storage middleware for encrypting TinyDB data at rest.
    """
    
    def __init__(self, filename, encryption_key=None):
        """
        Initialize encrypted storage.
        
        Args:
            filename: Path to the database file
            encryption_key: Encryption key for data encryption (base64 encoded)
        """
        super().__init__(filename)
        if encryption_key:
            self.cipher = Fernet(encryption_key)
        else:
            self.cipher = None
    
    def read(self):
        """
        Read and decrypt data from the database file.
        
        Returns:
            Decrypted data or None if file doesn't exist
        """
        try:
            raw_data = super().read()
            if raw_data and self.cipher:
                # Convert to string if needed
                if isinstance(raw_data, bytes):
                    raw_data = raw_data.decode('utf-8')
                # Decrypt the data
                decrypted_data = self.cipher.decrypt(raw_data.encode('utf-8'))
                return json.loads(decrypted_data)
            return raw_data
        except Exception as e:
            logger.error(f"Error reading encrypted database: {e}")
            return None
    
    def write(self, data):
        """
        Encrypt and write data to the database file.
        
        Args:
            data: Data to write to the database
        """
        try:
            if self.cipher:
                # Convert data to JSON string
                json_data = json.dumps(data, indent=2, ensure_ascii=False)
                # Encrypt the data
                encrypted_data = self.cipher.encrypt(json_data.encode('utf-8'))
                # Write encrypted data
                super().write(encrypted_data.decode('utf-8'))
            else:
                super().write(data)
        except Exception as e:
            logger.error(f"Error writing encrypted database: {e}")


def _get_encryption_key():
    """
    Get or generate encryption key for database encryption.
    
    Returns:
        Encryption key (base64 encoded)
    """
    # Check if key file exists
    if os.path.exists(DB_ENCRYPTION_KEY_FILE):
        with open(DB_ENCRYPTION_KEY_FILE, 'rb') as f:
            return f.read()
    
    # Generate new key
    key = Fernet.generate_key()
    # Save key to file
    with open(DB_ENCRYPTION_KEY_FILE, 'wb') as f:
        f.write(key)
    
    return key


def _get_db():
    """
    Get database instance with caching and encryption.
    
    Returns:
        TinyDB instance
    """
    # Get encryption key
    encryption_key = _get_encryption_key()
    
    # Create database with caching and encryption
    db = TinyDB(DB_FILE, storage=CachingMiddleware(EncryptedStorage))
    return db


def store_report_proofs(report_id: str, proofs: Dict[str, Any]) -> int:
    """
    Store mapping between report ID and cryptographic proofs.
    
    Args:
        report_id: Unique identifier for the report
        proofs: Dictionary containing cryptographic proofs
        
    Returns:
        Document ID of the stored record
    """
    try:
        # Get database instance
        db = _get_db()
        
        # Create query object
        Report = Query()
        
        # Check if report already exists
        existing = db.get(Report.report_id == report_id)
        
        if existing:
            # Update existing record
            doc_id = existing.doc_id
            db.update({
                'report_id': report_id,
                'proofs': proofs
            }, doc_ids=[doc_id])
            logger.info(f"Updated proofs for report {report_id} (doc_id: {doc_id})")
        else:
            # Insert new record
            doc_id = db.insert({
                'report_id': report_id,
                'proofs': proofs
            })
            logger.info(f"Stored proofs for report {report_id} (doc_id: {doc_id})")
        
        # Flush cache to ensure data is written
        db.storage.flush()
        
        return doc_id
    except Exception as e:
        logger.error(f"Error storing proofs for report {report_id}: {e}")
        raise


def get_report_proofs(report_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve cryptographic proofs for a given report ID.
    
    Args:
        report_id: Unique identifier for the report
        
    Returns:
        Dictionary containing cryptographic proofs or None if not found
    """
    try:
        # Get database instance
        db = _get_db()
        
        # Create query object
        Report = Query()
        
        # Search for report
        result = db.get(Report.report_id == report_id)
        
        if result:
            logger.info(f"Retrieved proofs for report {report_id}")
            return result['proofs']
        else:
            logger.warning(f"No proofs found for report {report_id}")
            return None
    except Exception as e:
        logger.error(f"Error retrieving proofs for report {report_id}: {e}")
        raise


def backup_database(backup_path: str) -> bool:
    """
    Create a backup of the database file.
    
    Args:
        backup_path: Path where backup should be stored
        
    Returns:
        True if backup was successful, False otherwise
    """
    try:
        # Ensure backup directory exists
        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
        
        # Get database instance and flush cache
        db = _get_db()
        db.storage.flush()
        db.close()
        
        # Copy database file to backup location
        with open(DB_FILE, 'rb') as src, open(backup_path, 'wb') as dst:
            dst.write(src.read())
        
        logger.info(f"Database backed up to {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Error backing up database: {e}")
        return False


def restore_database(backup_path: str) -> bool:
    """
    Restore database from backup.
    
    Args:
        backup_path: Path to the backup file
        
    Returns:
        True if restore was successful, False otherwise
    """
    try:
        # Check if backup file exists
        if not os.path.exists(backup_path):
            logger.error(f"Backup file {backup_path} does not exist")
            return False
        
        # Close existing database connection
        db = _get_db()
        db.close()
        
        # Copy backup file to database location
        with open(backup_path, 'rb') as src, open(DB_FILE, 'wb') as dst:
            dst.write(src.read())
        
        logger.info(f"Database restored from {backup_path}")
        return True
    except Exception as e:
        logger.error(f"Error restoring database: {e}")
        return False