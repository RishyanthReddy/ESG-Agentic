"""
LangGraph Wiring and Compilation

This module constructs the StatefulGraph using the Pydantic AppState
and compiles it into a runnable LCEL object.
"""

from langgraph.graph import StateGraph, START, END
from src.state.models import AppState
from src.agents.core import master_orchestrator
from src.agents.credential_agent import credential_agent
from src.agents.reporting_agent import reporting_agent
from src.agents.verification import verification_agent


def build_graph():
    """
    Build and compile the LangGraph workflow.
    
    Returns:
        CompiledGraph: The compiled graph ready for execution
    """
    # Create StatefulGraph with AppState as the state type
    workflow = StateGraph(AppState)
    
    # Register all agent nodes
    workflow.add_node("credential_agent", credential_agent)
    workflow.add_node("reporting_agent", reporting_agent)
    workflow.add_node("verification_agent", verification_agent)
    
    # Set the entry point
    workflow.add_edge(START, "credential_agent")
    
    # Add conditional edges based on master_orchestrator output
    workflow.add_conditional_edges(
        "credential_agent",
        master_orchestrator,
        {
            "credential_agent": "credential_agent",
            "reporting_agent": "reporting_agent",
            "verification_agent": "verification_agent",
            "__end__": END
        }
    )
    
    workflow.add_conditional_edges(
        "reporting_agent",
        master_orchestrator,
        {
            "credential_agent": "credential_agent",
            "reporting_agent": "reporting_agent",
            "verification_agent": "verification_agent",
            "__end__": END
        }
    )
    
    workflow.add_conditional_edges(
        "verification_agent",
        master_orchestrator,
        {
            "credential_agent": "credential_agent",
            "reporting_agent": "reporting_agent",
            "verification_agent": "verification_agent",
            "__end__": END
        }
    )
    
    # Compile the graph into a runnable LCEL object
    app = workflow.compile()
    
    return app


# Build and export the compiled graph
graph = build_graph()