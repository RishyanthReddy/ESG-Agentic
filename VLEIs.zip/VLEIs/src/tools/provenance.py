"""
Infura Blockchain Tool

This module implements a tool for logging data provenance to the Ethereum blockchain
using Infura's API to connect to the Sepolia testnet.
"""

import json
from typing import Dict, Any, Optional
from web3 import Web3
from eth_account import Account
from loguru import logger
from src.tools.registry import BaseTool
from config import settings


class BlockchainError(Exception):
    """Custom exception for blockchain operation failures"""
    pass


class InfuraBlockchainTool(BaseTool):
    """
    Tool for logging data provenance to the Ethereum blockchain via Infura.
    
    This tool connects to the Sepolia testnet using Infura's API to log data
    hashes to the blockchain for immutable provenance tracking.
    """
    
    def __init__(self):
        """Initialize the Infura Blockchain Tool"""
        super().__init__(
            name="infura_blockchain",
            description="Logs data provenance to Ethereum blockchain via Infura's Sepolia testnet"
        )
        
        # Get Infura API key from settings (loaded from .env file)
        self.infura_api_key = settings.INFURA_API_KEY
        if not self.infura_api_key:
            raise BlockchainError("INFURA_API_KEY not found in environment variables")
        
        # Configure Sepolia testnet endpoint
        self.infura_url = f"https://sepolia.infura.io/v3/{self.infura_api_key}"
        
        # Initialize Web3 connection
        self.web3 = Web3(Web3.HTTPProvider(self.infura_url))
        
        # Check connection
        if not self.web3.is_connected():
            raise BlockchainError("Failed to connect to Infura Sepolia endpoint")
        
        logger.info("InfuraBlockchainTool initialized successfully")
        logger.info(f"Connected to Sepolia testnet with chain ID: {self.web3.eth.chain_id}")
    
    def get_connection_info(self) -> Dict[str, Any]:
        """
        Get information about the blockchain connection.
        
        Returns:
            Dict[str, Any]: Connection information
        """
        return {
            "network": "Sepolia Testnet",
            "chain_id": self.web3.eth.chain_id,
            "endpoint": self.infura_url,
            "connected": self.web3.is_connected()
        }
    
    def _prepare_transaction(self, data_hash: str, private_key: str) -> Dict[str, Any]:
        """
        Prepare a transaction for sending to the blockchain.
        
        Args:
            data_hash (str): The hash of the data to be logged
            private_key (str): Private key for signing the transaction
            
        Returns:
            Dict[str, Any]: The prepared transaction
        """
        # Derive account from private key
        account = Account.from_key(private_key)
        address = account.address
        
        # Get current nonce
        nonce = self.web3.eth.get_transaction_count(address)
        
        # Estimate gas with a safety margin
        try:
            gas_estimate = self.web3.eth.estimate_gas({
                'from': address,
                'to': address,  # Self-transfer with data
                'data': self.web3.to_bytes(text=data_hash)
            })
            # Add 20% buffer to gas estimate
            gas_estimate = int(gas_estimate * 1.2)
        except Exception:
            # Fallback gas limit if estimation fails
            gas_estimate = 100000
        
        # Get dynamic gas price with a small premium for faster confirmation
        try:
            gas_price = self.web3.eth.gas_price
            # Add 10% premium for faster confirmation
            gas_price = int(gas_price * 1.1)
        except Exception:
            # Fallback gas price if fetching fails
            gas_price = self.web3.to_wei(20, 'gwei')
        
        # Prepare transaction
        transaction = {
            'nonce': nonce,
            'to': address,  # Send to self
            'value': 0,  # No ETH transfer
            'gas': gas_estimate,
            'gasPrice': gas_price,
            'data': self.web3.to_bytes(text=data_hash)
        }
        
        logger.info(f"Prepared transaction with gas limit: {gas_estimate}, gas price: {gas_price}")
        return transaction
    
    def _sign_and_send_transaction(self, transaction: Dict[str, Any], private_key: str) -> str:
        """
        Sign and send a transaction to the blockchain.
        
        Args:
            transaction (Dict[str, Any]): The transaction to sign and send
            private_key (str): Private key for signing the transaction
            
        Returns:
            str: The transaction hash
        """
        try:
            # Sign transaction
            signed_txn = self.web3.eth.account.sign_transaction(transaction, private_key)
            
            # Send transaction
            tx_hash = self.web3.eth.send_raw_transaction(signed_txn.rawTransaction)
            
            # Convert to hex string
            tx_hash_hex = self.web3.to_hex(tx_hash)
            
            logger.info(f"Transaction sent with hash: {tx_hash_hex}")
            
            # Wait for transaction receipt with timeout
            tx_receipt = self.web3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
            
            if tx_receipt.status == 1:
                logger.info(f"Transaction successful with hash: {tx_hash_hex}")
                logger.info(f"Block number: {tx_receipt.blockNumber}")
                logger.info(f"Gas used: {tx_receipt.gasUsed}")
                return tx_hash_hex
            else:
                raise BlockchainError(f"Transaction failed with hash: {tx_hash_hex}")
                
        except Exception as e:
            logger.error(f"Error in sign and send transaction: {str(e)}")
            raise BlockchainError(f"Failed to sign and send transaction: {str(e)}")
    
    def run(self, data_hash: str, private_key: str) -> Dict[str, Any]:
        """
        Log a data hash to the Ethereum blockchain via Infura.
        
        Args:
            data_hash (str): The SHA-256 hash of the data to be logged
            private_key (str): The private key for signing transactions
            
        Returns:
            Dict[str, Any]: Result containing the transaction hash and status
            
        Raises:
            BlockchainError: If the blockchain operation fails
        """
        try:
            logger.info(f"Logging data hash to blockchain: {data_hash}")
            
            # Validate data hash
            if not data_hash or not isinstance(data_hash, str):
                raise BlockchainError("Invalid data_hash provided")
            
            # Validate private key
            if not private_key or not isinstance(private_key, str):
                raise BlockchainError("Invalid private_key provided")
            
            # Validate Ethereum address from private key
            try:
                account = Account.from_key(private_key)
                address = account.address
                logger.info(f"Using account: {address}")
            except Exception as e:
                raise BlockchainError(f"Invalid private key: {str(e)}")
            
            # Check account balance
            try:
                balance = self.web3.eth.get_balance(address)
                balance_eth = self.web3.from_wei(balance, 'ether')
                logger.info(f"Account balance: {balance_eth} ETH")
                
                # Check if balance is sufficient for a reasonable transaction
                if balance == 0:
                    raise BlockchainError(f"Insufficient funds in account {address}")
            except Exception as e:
                logger.warning(f"Could not check account balance: {str(e)}")
            
            # Prepare transaction
            transaction = self._prepare_transaction(data_hash, private_key)
            
            # Sign and send transaction
            tx_hash = self._sign_and_send_transaction(transaction, private_key)
            
            return {
                "success": True,
                "transaction_hash": tx_hash,
                "message": "Data successfully logged to blockchain",
                "data_hash": data_hash,
                "account": address,
                "timestamp": __import__('datetime').datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Blockchain operation failed: {str(e)}")
            raise BlockchainError(f"Failed to log data to blockchain: {str(e)}")