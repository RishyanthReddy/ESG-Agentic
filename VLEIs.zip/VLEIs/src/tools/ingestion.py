"""
File Upload Tool

This module implements a tool for handling data submissions from suppliers
via file uploads (CSV/Excel), ensuring system inclusivity.
"""

import pandas as pd
from typing import Dict, Any
from loguru import logger
from src.tools.registry import BaseTool
import os
import tempfile
from io import BytesIO
import json
import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend


class FileUploadError(Exception):
    """Custom exception for file upload failures"""
    pass


class FileSignatureError(Exception):
    """Custom exception for file signature verification failures"""
    pass


class FileUploadTool(BaseTool):
    """
    Tool for processing supplier data from CSV or Excel files.
    
    This tool reads uploaded files and converts them to the canonical supplier_data
    format that can be processed by the ingestion agent.
    """
    
    def __init__(self):
        """Initialize the File Upload Tool"""
        super().__init__(
            name="file_upload",
            description="Processes supplier data from CSV or Excel files into canonical format"
        )
        
        # Supported file extensions
        self.supported_extensions = {'.csv', '.xlsx', '.xls'}
    
    def run(self, file_content: bytes, file_name: str, **kwargs) -> Dict[str, Any]:
        """
        Process an uploaded file and convert it to canonical supplier_data format.
        
        Args:
            file_content (bytes): The content of the uploaded file
            file_name (str): The name of the uploaded file
            **kwargs: Additional parameters (not used currently)
            
            Supported kwargs:
                - data_type_hint (str): Hint for data type inference
                - company_name (str): Company name if known
                - format_mapping (dict): Custom column mapping
                - verify_signature (bool): Whether to verify file signature (default: False)
                - public_key_path (str): Path to public key for signature verification
                - signature_content (bytes): Content of signature file if separate
            
        Returns:
            Dict[str, Any]: The processed supplier_data in canonical format
            
        Raises:
            FileUploadError: If there's an error processing the file
            FileSignatureError: If signature verification fails
        """
        try:
            logger.info(f"Processing uploaded file: {file_name}")
            
            # Extract optional parameters
            data_type_hint = kwargs.get('data_type_hint')
            company_name = kwargs.get('company_name')
            format_mapping = kwargs.get('format_mapping', {})
            verify_signature = kwargs.get('verify_signature', False)
            public_key_path = kwargs.get('public_key_path')
            signature_content = kwargs.get('signature_content')
            
            # Validate file extension
            file_ext = os.path.splitext(file_name)[1].lower()
            if file_ext not in self.supported_extensions:
                raise FileUploadError(f"Unsupported file format: {file_ext}. Supported formats: {self.supported_extensions}")
            
            # Verify signature if requested
            if verify_signature:
                self._verify_file_signature(file_content, file_name, public_key_path, signature_content)
            
            # Process the file based on its extension
            if file_ext == '.csv':
                supplier_data = self._process_csv(file_content, data_type_hint, company_name, format_mapping)
            elif file_ext in ['.xlsx', '.xls']:
                supplier_data = self._process_excel(file_content, file_ext, data_type_hint, company_name, format_mapping)
            else:
                raise FileUploadError(f"Unsupported file format: {file_ext}")
            
            logger.info(f"Successfully processed file {file_name} into supplier_data format")
            return supplier_data
            
        except Exception as e:
            error_msg = f"Failed to process file {file_name}: {str(e)}"
            logger.error(error_msg)
            raise FileUploadError(error_msg) from e
    
    def _verify_file_signature(self, file_content: bytes, file_name: str, 
                              public_key_path: str = None, signature_content: bytes = None) -> None:
        """
        Verify the digital signature of a file.
        
        Args:
            file_content: Content of the file to verify
            file_name: Name of the file
            public_key_path: Path to the public key file
            signature_content: Content of the signature file
            
        Raises:
            FileSignatureError: If signature verification fails
        """
        if not public_key_path:
            raise FileSignatureError("Public key path is required for signature verification")
        
        if not os.path.exists(public_key_path):
            raise FileSignatureError(f"Public key file not found: {public_key_path}")
        
        # If signature content is not provided, look for a .sig file
        if not signature_content:
            signature_file_path = file_name + ".sig"
            if os.path.exists(signature_file_path):
                with open(signature_file_path, 'rb') as f:
                    signature_content = f.read()
            else:
                raise FileSignatureError(f"Signature file not found: {signature_file_path}")
        
        try:
            # Load the public key
            with open(public_key_path, 'rb') as f:
                public_key = serialization.load_pem_public_key(
                    f.read(),
                    backend=default_backend()
                )
            
            # Parse signature metadata
            signature_metadata = json.loads(signature_content)
            
            # Calculate file hash
            file_hash = hashlib.sha256(file_content).hexdigest()
            
            # Check if the hash matches
            if file_hash != signature_metadata.get("file_hash"):
                raise FileSignatureError("File hash does not match signature metadata")
            
            # Verify the signature
            signature = bytes.fromhex(signature_metadata.get("signature"))
            public_key.verify(
                signature,
                file_hash.encode('utf-8'),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            logger.info(f"File signature verified successfully for {file_name}")
            
        except FileSignatureError:
            raise
        except Exception as e:
            raise FileSignatureError(f"Signature verification failed: {str(e)}") from e
    
    def _process_csv(self, file_content: bytes, data_type_hint: str = None, 
                     company_name: str = None, format_mapping: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Process a CSV file and convert it to supplier_data format.
        
        Args:
            file_content (bytes): The content of the CSV file
            data_type_hint (str): Hint for data type inference
            company_name (str): Company name if known
            format_mapping (Dict[str, str]): Custom column mapping
            
        Returns:
            Dict[str, Any]: The processed supplier_data
        """
        try:
            # Read CSV content into a pandas DataFrame
            df = pd.read_csv(BytesIO(file_content))
            
            # Apply format mapping if provided
            if format_mapping:
                df = df.rename(columns=format_mapping)
            
            # Convert to supplier_data format
            return self._dataframe_to_supplier_data(df, data_type_hint, company_name)
            
        except pd.errors.EmptyDataError:
            raise FileUploadError("CSV file is empty")
        except pd.errors.ParserError as e:
            raise FileUploadError(f"Error parsing CSV file: {str(e)}")
        except Exception as e:
            raise FileUploadError(f"Unexpected error processing CSV file: {str(e)}")
    
    def _process_excel(self, file_content: bytes, file_ext: str, data_type_hint: str = None,
                       company_name: str = None, format_mapping: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Process an Excel file and convert it to supplier_data format.
        
        Args:
            file_content (bytes): The content of the Excel file
            file_ext (str): The file extension (.xlsx or .xls)
            data_type_hint (str): Hint for data type inference
            company_name (str): Company name if known
            format_mapping (Dict[str, str]): Custom column mapping
            
        Returns:
            Dict[str, Any]: The processed supplier_data
        """
        try:
            # Read Excel content into a pandas DataFrame
            # For Excel files, we'll read the first sheet
            df = pd.read_excel(BytesIO(file_content), sheet_name=0)
            
            # Apply format mapping if provided
            if format_mapping:
                df = df.rename(columns=format_mapping)
            
            # Convert to supplier_data format
            return self._dataframe_to_supplier_data(df, data_type_hint, company_name)
            
        except pd.errors.EmptyDataError:
            raise FileUploadError("Excel file is empty or contains no data")
        except Exception as e:
            raise FileUploadError(f"Error processing Excel file: {str(e)}")
    
    def _dataframe_to_supplier_data(self, df: pd.DataFrame, data_type_hint: str = None,
                                    company_name: str = None) -> Dict[str, Any]:
        """
        Convert a pandas DataFrame to the canonical supplier_data format.
        
        Args:
            df (pd.DataFrame): The DataFrame to convert
            data_type_hint (str): Hint for data type inference
            company_name (str): Company name if known
            
        Returns:
            Dict[str, Any]: The supplier_data in canonical format
        """
        try:
            # Check if DataFrame is empty
            if df.empty:
                raise FileUploadError("Data frame is empty")
            
            # Get basic information from the DataFrame
            row_count, col_count = df.shape
            logger.info(f"Processing DataFrame with {row_count} rows and {col_count} columns")
            
            # Convert DataFrame to dictionary format
            # For simplicity, we'll assume the first row contains the data
            # In a real implementation, this would be more sophisticated
            if row_count > 0:
                # Get the first row as a dictionary
                first_row = df.iloc[0].to_dict()
                
                # Handle NaN values by converting them to None
                processed_row = {k: (v if pd.notna(v) else None) for k, v in first_row.items()}
                
                # Try to determine data_type based on column names or content
                data_type = data_type_hint or self._infer_data_type(processed_row, list(df.columns))
                
                # Create supplier_data structure
                supplier_data = {
                    "company_name": company_name or processed_row.get("company_name", processed_row.get("Company Name", "Unknown Company")),
                    "data_type": data_type,
                }
                
                # Add all other fields
                for key, value in processed_row.items():
                    # Skip fields we've already handled
                    if key.lower() not in ["company_name", "data_type"]:
                        supplier_data[key] = value
                
                # If we couldn't determine a data_type, try to infer from column names
                if supplier_data["data_type"] is None:
                    supplier_data["data_type"] = self._infer_data_type_from_columns(list(df.columns))
                
                # If still None, default to "esg_data"
                if supplier_data["data_type"] is None:
                    supplier_data["data_type"] = "esg_data"
                
                logger.info(f"Inferred data type: {supplier_data['data_type']}")
                return supplier_data
            else:
                # If no rows, create a minimal structure
                return {
                    "company_name": company_name or "Unknown Company",
                    "data_type": data_type_hint or "esg_data"
                }
                
        except Exception as e:
            raise FileUploadError(f"Error converting DataFrame to supplier_data: {str(e)}")
    
    def _infer_data_type(self, row_data: Dict[str, Any], columns: list) -> str:
        """
        Infer the data type from row data and column names.
        
        Args:
            row_data (Dict[str, Any]): The row data
            columns (list): The column names
            
        Returns:
            str: The inferred data type
        """
        # Look for specific indicators in the data
        data_type_indicators = {
            "vlei_credential": ["issuer", "subject", "credential", "lei", "legal_entity_id"],
            "gri_report": ["gri", "report_year", "economic", "environmental", "social", "gri_data"],
            "sasb_report": ["sasb", "industry", "metrics", "sasb_data"],
            "esg_data": ["esg", "carbon", "emissions", "sustainability", "esg_metrics"]
        }
        
        # Check row data for indicators
        all_text = " ".join(str(v).lower() for v in row_data.values() if v is not None)
        column_text = " ".join(str(c).lower() for c in columns)
        combined_text = all_text + " " + column_text
        
        for data_type, indicators in data_type_indicators.items():
            for indicator in indicators:
                if indicator in combined_text:
                    return data_type
        
        return None
    
    def _infer_data_type_from_columns(self, columns: list) -> str:
        """
        Infer the data type from column names only.
        
        Args:
            columns (list): The column names
            
        Returns:
            str: The inferred data type
        """
        column_text = " ".join(str(c).lower() for c in columns)
        
        # Same logic as above but only with column names
        data_type_indicators = {
            "vlei_credential": ["issuer", "subject", "credential", "lei", "legal_entity_id"],
            "gri_report": ["gri", "report_year", "economic", "environmental", "social", "gri_data"],
            "sasb_report": ["sasb", "industry", "metrics", "sasb_data"],
            "esg_data": ["esg", "carbon", "emissions", "sustainability", "esg_metrics"]
        }
        
        for data_type, indicators in data_type_indicators.items():
            for indicator in indicators:
                if indicator in column_text:
                    return data_type
        
        return None