"""
NetworkX Provenance Tool

This module implements a tool for constructing formal graph data models of supply
chain data flow using NetworkX library.
"""

import networkx as nx
from typing import Dict, Any, List, Optional
from loguru import logger
from src.tools.registry import BaseTool


class NetworkXProvenanceTool(BaseTool):
    """
    Tool for constructing formal graph data models of supply chain data flow using NetworkX.
    
    This tool takes agent traces and blockchain logs to create NetworkX DiGraphs with
    suppliers, agents, and artifacts as nodes, representing the complete provenance
    of data and processes in the supply chain.
    """
    
    def __init__(self):
        """Initialize the NetworkX Provenance Tool."""
        super().__init__(
            name="networkx_provenance",
            description="Constructs formal graph data model of supply chain data flow using NetworkX"
        )
        
        logger.info("NetworkXProvenanceTool initialized")
    
    def _create_node_id(self, node_type: str, identifier: str) -> str:
        """
        Create a unique node ID based on type and identifier.
        
        Args:
            node_type (str): Type of node (supplier, agent, artifact, etc.)
            identifier (str): Unique identifier for the node
            
        Returns:
            str: Unique node ID
        """
        return f"{node_type}:{identifier}"
    
    def _add_node_with_attributes(self, graph: nx.DiGraph, node_id: str, node_type: str, 
                                 attributes: Dict[str, Any]) -> None:
        """
        Add a node with attributes to the graph.
        
        Args:
            graph (nx.DiGraph): The graph to add the node to
            node_id (str): Unique identifier for the node
            node_type (str): Type of the node
            attributes (Dict[str, Any]): Node attributes
        """
        # Add the node type as an attribute
        attributes['type'] = node_type
        
        # Add timestamp if not present
        if 'timestamp' not in attributes:
            from datetime import datetime
            attributes['timestamp'] = datetime.utcnow().isoformat()
        
        # Add the node to the graph
        graph.add_node(node_id, **attributes)
        logger.debug(f"Added node {node_id} with attributes: {attributes}")
    
    def _process_agent_trace(self, graph: nx.DiGraph, trace_data: Dict[str, Any]) -> None:
        """
        Process agent trace data and add nodes and edges to the graph.
        
        Args:
            graph (nx.DiGraph): The graph to update
            trace_data (Dict[str, Any]): Agent trace data
        """
        # Extract agent information
        agent_id = trace_data.get('agent_id', 'unknown_agent')
        agent_node_id = self._create_node_id('agent', agent_id)
        
        # Add agent node
        agent_attributes = {
            'name': trace_data.get('agent_name', agent_id),
            'role': trace_data.get('agent_role', 'unknown'),
            'status': trace_data.get('status', 'unknown'),
            'timestamp': trace_data.get('timestamp')
        }
        self._add_node_with_attributes(graph, agent_node_id, 'agent', agent_attributes)
        
        # Process input artifacts
        input_artifacts = trace_data.get('input_artifacts', [])
        for artifact in input_artifacts:
            artifact_id = artifact.get('id', str(hash(str(artifact))))
            artifact_node_id = self._create_node_id('artifact', artifact_id)
            
            # Add artifact node
            artifact_attributes = {
                'name': artifact.get('name', artifact_id),
                'type': artifact.get('type', 'unknown'),
                'size': artifact.get('size', 0),
                'hash': artifact.get('hash', ''),
                'timestamp': artifact.get('timestamp')
            }
            self._add_node_with_attributes(graph, artifact_node_id, 'artifact', artifact_attributes)
            
            # Add edge from artifact to agent
            graph.add_edge(artifact_node_id, agent_node_id, 
                          relationship='consumed_by', 
                          timestamp=trace_data.get('timestamp'))
        
        # Process output artifacts
        output_artifacts = trace_data.get('output_artifacts', [])
        for artifact in output_artifacts:
            artifact_id = artifact.get('id', str(hash(str(artifact))))
            artifact_node_id = self._create_node_id('artifact', artifact_id)
            
            # Add artifact node (or update if it exists)
            artifact_attributes = {
                'name': artifact.get('name', artifact_id),
                'type': artifact.get('type', 'unknown'),
                'size': artifact.get('size', 0),
                'hash': artifact.get('hash', ''),
                'timestamp': artifact.get('timestamp'),
                'produced_by': agent_id
            }
            self._add_node_with_attributes(graph, artifact_node_id, 'artifact', artifact_attributes)
            
            # Add edge from agent to artifact
            graph.add_edge(agent_node_id, artifact_node_id, 
                          relationship='produced', 
                          timestamp=artifact.get('timestamp'))
        
        # Process supplier information if available
        supplier_info = trace_data.get('supplier_info')
        if supplier_info:
            supplier_id = supplier_info.get('id', 'unknown_supplier')
            supplier_node_id = self._create_node_id('supplier', supplier_id)
            
            # Add supplier node
            supplier_attributes = {
                'name': supplier_info.get('name', supplier_id),
                'location': supplier_info.get('location', 'unknown'),
                'certifications': supplier_info.get('certifications', []),
                'timestamp': supplier_info.get('timestamp')
            }
            self._add_node_with_attributes(graph, supplier_node_id, 'supplier', supplier_attributes)
            
            # Add edge from supplier to agent
            graph.add_edge(supplier_node_id, agent_node_id, 
                          relationship='provides_service_to', 
                          timestamp=trace_data.get('timestamp'))
    
    def _process_blockchain_log(self, graph: nx.DiGraph, blockchain_data: Dict[str, Any]) -> None:
        """
        Process blockchain log data and add nodes and edges to the graph.
        
        Args:
            graph (nx.DiGraph): The graph to update
            blockchain_data (Dict[str, Any]): Blockchain log data
        """
        # Extract transaction information
        tx_hash = blockchain_data.get('transaction_hash')
        if not tx_hash:
            logger.warning("Blockchain log missing transaction hash")
            return
        
        blockchain_node_id = self._create_node_id('blockchain', tx_hash)
        
        # Add blockchain node
        blockchain_attributes = {
            'tx_hash': tx_hash,
            'data_hash': blockchain_data.get('data_hash', ''),
            'account': blockchain_data.get('account', ''),
            'block_number': blockchain_data.get('block_number', 0),
            'gas_used': blockchain_data.get('gas_used', 0),
            'timestamp': blockchain_data.get('timestamp')
        }
        self._add_node_with_attributes(graph, blockchain_node_id, 'blockchain', blockchain_attributes)
        
        # Link to relevant artifact if possible
        data_hash = blockchain_data.get('data_hash')
        if data_hash:
            # Look for artifacts with matching hash
            for node_id, node_data in graph.nodes(data=True):
                if (node_data.get('type') == 'artifact' and 
                    node_data.get('hash') == data_hash):
                    # Add edge from artifact to blockchain entry
                    graph.add_edge(node_id, blockchain_node_id, 
                                  relationship='recorded_on_chain',
                                  timestamp=blockchain_data.get('timestamp'))
    
    def create_provenance_graph(self, agent_traces: List[Dict[str, Any]], 
                               blockchain_logs: List[Dict[str, Any]]) -> nx.DiGraph:
        """
        Create a provenance graph from agent traces and blockchain logs.
        
        Args:
            agent_traces (List[Dict[str, Any]]): List of agent trace data
            blockchain_logs (List[Dict[str, Any]]): List of blockchain log data
            
        Returns:
            nx.DiGraph: NetworkX directed graph representing the provenance
        """
        # Create a new directed graph
        graph = nx.DiGraph()
        
        # Add metadata to the graph
        graph.graph['name'] = 'Supply Chain Provenance Graph'
        graph.graph['created_at'] = __import__('datetime').datetime.utcnow().isoformat()
        graph.graph['node_count'] = 0
        graph.graph['edge_count'] = 0
        
        logger.info("Creating provenance graph from agent traces and blockchain logs")
        
        # Process agent traces
        for trace in agent_traces:
            try:
                self._process_agent_trace(graph, trace)
            except Exception as e:
                logger.error(f"Error processing agent trace: {str(e)}")
                continue
        
        # Process blockchain logs
        for log in blockchain_logs:
            try:
                self._process_blockchain_log(graph, log)
            except Exception as e:
                logger.error(f"Error processing blockchain log: {str(e)}")
                continue
        
        # Update graph metadata
        graph.graph['node_count'] = graph.number_of_nodes()
        graph.graph['edge_count'] = graph.number_of_edges()
        
        logger.info(f"Provenance graph created with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges")
        
        return graph
    
    def validate_graph(self, graph: nx.DiGraph) -> Dict[str, Any]:
        """
        Validate the structure of the provenance graph.
        
        Args:
            graph (nx.DiGraph): The graph to validate
            
        Returns:
            Dict[str, Any]: Validation results
        """
        results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'node_count': graph.number_of_nodes(),
            'edge_count': graph.number_of_edges(),
            'node_types': {}
        }
        
        # Check if graph is empty
        if graph.number_of_nodes() == 0:
            results['warnings'].append("Graph is empty")
        
        # Count node types
        for node_id, node_data in graph.nodes(data=True):
            node_type = node_data.get('type', 'unknown')
            results['node_types'][node_type] = results['node_types'].get(node_type, 0) + 1
        
        # Check for required node types
        required_types = ['agent']
        for req_type in required_types:
            if req_type not in results['node_types']:
                results['warnings'].append(f"No {req_type} nodes found in graph")
        
        # Check for nodes without required attributes
        for node_id, node_data in graph.nodes(data=True):
            if 'type' not in node_data:
                results['errors'].append(f"Node {node_id} missing 'type' attribute")
            
            # Check timestamp
            if 'timestamp' not in node_data:
                results['warnings'].append(f"Node {node_id} missing 'timestamp' attribute")
        
        # Update validation status
        if results['errors']:
            results['is_valid'] = False
        
        logger.info(f"Graph validation completed: {results['node_count']} nodes, {results['edge_count']} edges")
        return results
    
    def serialize_graph(self, graph: nx.DiGraph, format: str = 'json') -> str:
        """
        Serialize the graph to a string representation.
        
        Args:
            graph (nx.DiGraph): The graph to serialize
            format (str): Serialization format ('json', 'graphml', 'gexf')
            
        Returns:
            str: Serialized graph representation
        """
        if format.lower() == 'json':
            # Use node_link_data for JSON serialization
            data = nx.node_link_data(graph)
            import json
            return json.dumps(data, indent=2)
        
        elif format.lower() == 'graphml':
            # For GraphML, we need to write to a string buffer
            import io
            try:
                buffer = io.StringIO()
                nx.write_graphml_xml(graph, buffer)
                return buffer.getvalue()
            except Exception as e:
                # Fallback to binary buffer if string buffer fails
                buffer = io.BytesIO()
                nx.write_graphml_xml(graph, buffer)
                return buffer.getvalue().decode('utf-8')
        
        elif format.lower() == 'gexf':
            # For GEXF, we need to write to a string buffer
            import io
            try:
                buffer = io.StringIO()
                nx.write_gexf(graph, buffer)
                return buffer.getvalue()
            except Exception as e:
                # Fallback to binary buffer if string buffer fails
                buffer = io.BytesIO()
                nx.write_gexf(graph, buffer)
                return buffer.getvalue().decode('utf-8')
        
        else:
            raise ValueError(f"Unsupported serialization format: {format}")
    
    def run(self, agent_traces: List[Dict[str, Any]], 
            blockchain_logs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Execute the NetworkX Provenance Tool.
        
        Args:
            agent_traces (List[Dict[str, Any]]): List of agent trace data
            blockchain_logs (List[Dict[str, Any]]): List of blockchain log data
            
        Returns:
            Dict[str, Any]: Result containing the graph and metadata
        """
        try:
            logger.info("Executing NetworkX Provenance Tool")
            
            # Validate inputs
            if not isinstance(agent_traces, list):
                raise ValueError("agent_traces must be a list")
            
            if not isinstance(blockchain_logs, list):
                raise ValueError("blockchain_logs must be a list")
            
            # Create the provenance graph
            graph = self.create_provenance_graph(agent_traces, blockchain_logs)
            
            # Validate the graph
            validation_result = self.validate_graph(graph)
            
            # Serialize the graph
            graph_json = self.serialize_graph(graph, 'json')
            
            result = {
                'success': True,
                'graph': graph,
                'graph_json': graph_json,
                'validation': validation_result,
                'node_count': graph.number_of_nodes(),
                'edge_count': graph.number_of_edges(),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }
            
            logger.info(f"NetworkX Provenance Tool completed successfully: {result['node_count']} nodes, {result['edge_count']} edges")
            return result
            
        except Exception as e:
            logger.error(f"NetworkX Provenance Tool failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }


class GraphSerializationTool(BaseTool):
    """
    Tool for converting NetworkX graph into structured JSON format for 3D rendering engines like Three.js.
    
    This tool uses networkx.node_link_data to convert graph into JSON with nodes and links arrays,
    optimized for web-based 3D visualization.
    """
    
    def __init__(self):
        """Initialize the Graph Serialization Tool."""
        super().__init__(
            name="graph_serialization",
            description="Converts NetworkX graph into structured JSON format for 3D rendering engines like Three.js"
        )
        
        logger.info("GraphSerializationTool initialized")
    
    def optimize_for_visualization(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Optimize graph data for 3D visualization.
        
        Args:
            data (Dict[str, Any]): Graph data in node-link format
            
        Returns:
            Dict[str, Any]: Optimized graph data for visualization
        """
        # Create a copy of the data to avoid modifying the original
        optimized_data = data.copy()
        
        # Add visualization-specific metadata
        optimized_data['metadata'] = {
            'format': 'threejs-compatible',
            'version': '1.0',
            'created_at': __import__('datetime').datetime.utcnow().isoformat(),
            'node_count': len(data.get('nodes', [])),
            'link_count': len(data.get('links', [])) if 'links' in data else len(data.get('edges', []))
        }
        
        # Optimize node data for visualization
        if 'nodes' in optimized_data:
            for node in optimized_data['nodes']:
                # Add position attributes for 3D layout
                node['x'] = 0.0
                node['y'] = 0.0
                node['z'] = 0.0
                
                # Add visualization properties
                node['size'] = 1.0
                node['opacity'] = 1.0
                
                # Map node type to color
                node_type = node.get('type', 'unknown')
                color_map = {
                    'agent': '#ff7f0e',      # Orange
                    'artifact': '#1f77b4',   # Blue
                    'supplier': '#2ca02c',   # Green
                    'blockchain': '#d62728'  # Red
                }
                node['color'] = color_map.get(node_type, '#7f7f7f')  # Default gray
                
                # Add label
                node['label'] = node.get('name', node.get('id', 'Unknown'))
        
        # Optimize link/edge data for visualization
        links_key = 'links' if 'links' in optimized_data else 'edges'
        if links_key in optimized_data:
            for link in optimized_data[links_key]:
                # Add visualization properties
                link['width'] = 2.0
                link['opacity'] = 0.8
                
                # Map relationship type to color
                relationship = link.get('relationship', 'unknown')
                color_map = {
                    'produced': '#1f77b4',          # Blue
                    'consumed_by': '#ff7f0e',       # Orange
                    'provides_service_to': '#2ca02c', # Green
                    'recorded_on_chain': '#d62728'   # Red
                }
                link['color'] = color_map.get(relationship, '#7f7f7f')  # Default gray
        
        logger.debug(f"Optimized graph data for visualization with {optimized_data['metadata']['node_count']} nodes")
        return optimized_data
    
    def validate_threejs_compatibility(self, data: Dict[str, Any]) -> bool:
        """
        Validate that the JSON data is compatible with Three.js.
        
        Args:
            data (Dict[str, Any]): Graph data to validate
            
        Returns:
            bool: True if compatible, False otherwise
        """
        # Check required fields
        required_fields = ['nodes', 'links'] if 'links' in data else ['nodes', 'edges']
        for field in required_fields:
            if field not in data:
                logger.error(f"Missing required field: {field}")
                return False
        
        # Check nodes structure
        if not isinstance(data['nodes'], list):
            logger.error("Nodes field must be a list")
            return False
        
        # Check links/edges structure
        links_key = 'links' if 'links' in data else 'edges'
        if not isinstance(data[links_key], list):
            logger.error(f"{links_key} field must be a list")
            return False
        
        # Check that all nodes have an ID
        for i, node in enumerate(data['nodes']):
            if 'id' not in node:
                logger.error(f"Node {i} missing 'id' field")
                return False
        
        # Check that all links have source and target
        for i, link in enumerate(data[links_key]):
            if 'source' not in link or 'target' not in link:
                logger.error(f"Link {i} missing 'source' or 'target' field")
                return False
        
        logger.debug("Graph data is compatible with Three.js")
        return True
    
    def serialize_for_threejs(self, graph: nx.Graph, optimize: bool = True) -> str:
        """
        Serialize NetworkX graph to Three.js compatible JSON.
        
        Args:
            graph (nx.Graph): NetworkX graph to serialize
            optimize (bool): Whether to optimize for visualization
            
        Returns:
            str: JSON string compatible with Three.js
        """
        # Convert graph to node-link format
        # Use 'links' for consistency with d3.js/Three.js
        data = nx.node_link_data(graph, edges="links")
        
        # Optimize for visualization if requested
        if optimize:
            data = self.optimize_for_visualization(data)
        
        # Validate compatibility
        if not self.validate_threejs_compatibility(data):
            raise ValueError("Graph data is not compatible with Three.js")
        
        # Convert to JSON string
        import json
        try:
            json_str = json.dumps(data, indent=2)
            logger.info(f"Graph serialized to Three.js compatible JSON ({len(json_str)} characters)")
            return json_str
        except Exception as e:
            logger.error(f"Failed to serialize graph to JSON: {str(e)}")
            raise
    
    def compress_json(self, json_str: str) -> str:
        """
        Compress JSON string for efficient web transfer.
        
        Args:
            json_str (str): JSON string to compress
            
        Returns:
            str: Compressed JSON string
        """
        import json
        try:
            # Parse and re-serialize without indentation to minimize size
            data = json.loads(json_str)
            compressed_json = json.dumps(data, separators=(',', ':'))
            logger.info(f"JSON compressed from {len(json_str)} to {len(compressed_json)} characters")
            return compressed_json
        except Exception as e:
            logger.error(f"Failed to compress JSON: {str(e)}")
            raise
    
    def run(self, graph: nx.Graph, format: str = 'threejs', optimize: bool = True, 
            compress: bool = False) -> Dict[str, Any]:
        """
        Execute the Graph Serialization Tool.
        
        Args:
            graph (nx.Graph): NetworkX graph to serialize
            format (str): Output format ('threejs', 'json')
            optimize (bool): Whether to optimize for visualization
            compress (bool): Whether to compress the output
            
        Returns:
            Dict[str, Any]: Result containing the serialized graph
        """
        try:
            logger.info(f"Executing Graph Serialization Tool (format: {format}, optimize: {optimize}, compress: {compress})")
            
            # Validate input
            if not isinstance(graph, nx.Graph):
                raise ValueError("Input must be a NetworkX graph")
            
            # Serialize based on format
            if format.lower() == 'threejs':
                json_str = self.serialize_for_threejs(graph, optimize)
            elif format.lower() == 'json':
                # Use standard NetworkX serialization
                import json
                data = nx.node_link_data(graph, edges="links")
                json_str = json.dumps(data, indent=2)
            else:
                raise ValueError(f"Unsupported format: {format}")
            
            # Compress if requested
            if compress:
                json_str = self.compress_json(json_str)
            
            result = {
                'success': True,
                'serialized_graph': json_str,
                'format': format,
                'optimized': optimize,
                'compressed': compress,
                'size': len(json_str),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }
            
            logger.info(f"Graph Serialization Tool completed successfully (size: {result['size']} characters)")
            return result
            
        except Exception as e:
            logger.error(f"Graph Serialization Tool failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }


class ShortestPathTool(BaseTool):
    """
    Tool for finding shortest paths between nodes in a NetworkX graph using Dijkstra's algorithm.
    
    This tool traces data provenance by finding the shortest path between source and target nodes
    in a supply chain provenance graph.
    """
    
    def __init__(self):
        """Initialize the Shortest Path Tool."""
        super().__init__(
            name="shortest_path",
            description="Find shortest path between nodes in a NetworkX graph using Dijkstra's algorithm for data provenance tracing"
        )
        
        logger.info("ShortestPathTool initialized")
    
    def run(self, graph: nx.Graph, source: str, target: str, weight: str = None) -> Dict[str, Any]:
        """
        Execute the Shortest Path Tool to find the shortest path between two nodes.
        
        Args:
            graph (nx.Graph): NetworkX graph to search
            source (str): Source node ID
            target (str): Target node ID
            weight (str, optional): Edge attribute to use as weight for path calculation
            
        Returns:
            Dict[str, Any]: Result containing the path or error information
        """
        try:
            logger.info(f"Executing Shortest Path Tool from '{source}' to '{target}'")
            
            # Validate inputs
            if not isinstance(graph, nx.Graph):
                raise ValueError("graph must be a NetworkX graph instance")
            
            if not isinstance(source, str):
                raise ValueError("source must be a string")
            
            if not isinstance(target, str):
                raise ValueError("target must be a string")
            
            # Check if nodes exist in the graph
            if source not in graph:
                raise nx.NodeNotFound(f"Source node '{source}' not found in graph")
            
            if target not in graph:
                raise nx.NodeNotFound(f"Target node '{target}' not found in graph")
            
            # Find shortest path using Dijkstra's algorithm
            try:
                path = nx.dijkstra_path(graph, source, target, weight=weight)
                path_length = nx.dijkstra_path_length(graph, source, target, weight=weight)
            except nx.NetworkXNoPath:
                return {
                    'success': False,
                    'error': f"No path found between '{source}' and '{target}'",
                    'source': source,
                    'target': target,
                    'timestamp': __import__('datetime').datetime.utcnow().isoformat()
                }
            
            # Get edge data for the path
            path_edges = []
            for i in range(len(path) - 1):
                edge_data = graph.get_edge_data(path[i], path[i+1])
                path_edges.append({
                    'source': path[i],
                    'target': path[i+1],
                    'data': edge_data
                })
            
            result = {
                'success': True,
                'path': path,
                'path_length': path_length,
                'path_edges': path_edges,
                'source': source,
                'target': target,
                'weight_attribute': weight,
                'node_count': len(path),
                'edge_count': len(path_edges),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }
            
            logger.info(f"Shortest path found: {len(path)} nodes, {len(path_edges)} edges")
            return result
            
        except Exception as e:
            logger.error(f"Shortest Path Tool failed: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'source': source if 'source' in locals() else None,
                'target': target if 'target' in locals() else None,
                'timestamp': __import__('datetime').datetime.utcnow().isoformat()
            }
