"""
Blockchain Oracle Tool

This module implements a specialized oracle tool for verifying data consistency
between on-chain provenance logs and original off-chain data sources.
"""

import hashlib
import json
from typing import Dict, Any, List, Optional
from web3 import Web3
from loguru import logger
from src.tools.registry import BaseTool
from src.state.models import AppState
from config import settings


class OracleError(Exception):
    """Custom exception for oracle verification failures"""
    pass


class BlockchainOracleTool(BaseTool):
    """
    Tool for performing cross-system verification by checking consistency between 
    on-chain provenance logs and original off-chain data sources.
    
    This tool takes a transaction hash from state.blockchain_log, queries the 
    blockchain via live Infura API to retrieve the logged data hash, then 
    re-calculates the hash from the original data to assert consistency.
    """
    
    def __init__(self):
        """Initialize the Blockchain Oracle Tool"""
        super().__init__(
            name="blockchain_oracle",
            description="Verifies data consistency between on-chain provenance logs and off-chain data sources"
        )
        
        # Get Infura API key from settings (loaded from .env file)
        self.infura_api_key = settings.INFURA_API_KEY
        if not self.infura_api_key:
            raise OracleError("INFURA_API_KEY not found in environment variables")
        
        # Configure Sepolia testnet endpoint
        self.infura_url = f"https://sepolia.infura.io/v3/{self.infura_api_key}"
        
        # Initialize Web3 connection
        self.web3 = Web3(Web3.HTTPProvider(self.infura_url))
        
        # Check connection
        if not self.web3.is_connected():
            raise OracleError("Failed to connect to Infura Sepolia endpoint")
        
        logger.info("BlockchainOracleTool initialized successfully")
        logger.info(f"Connected to Sepolia testnet with chain ID: {self.web3.eth.chain_id}")
    
    def _get_transaction_data(self, transaction_hash: str) -> str:
        """
        Retrieve transaction data from the blockchain using the transaction hash.
        
        Args:
            transaction_hash (str): The hash of the transaction to retrieve
            
        Returns:
            str: The data stored in the transaction
            
        Raises:
            OracleError: If the transaction cannot be retrieved or parsed
        """
        try:
            logger.info(f"Retrieving transaction data for hash: {transaction_hash}")
            
            # Get transaction details
            transaction = self.web3.eth.get_transaction(transaction_hash)
            
            # Extract data from transaction
            tx_data = transaction.get('data') or transaction.get('input')
            if not tx_data:
                raise OracleError(f"No data found in transaction {transaction_hash}")
            
            # Convert hex data to string
            if isinstance(tx_data, bytes):
                data_str = self.web3.to_text(tx_data)
            else:
                # Remove '0x' prefix if present
                if tx_data.startswith('0x'):
                    tx_data = tx_data[2:]
                # Convert hex to string
                try:
                    data_str = bytes.fromhex(tx_data).decode('utf-8')
                except Exception:
                    # If decoding fails, return as-is
                    data_str = tx_data
            
            logger.info(f"Successfully retrieved transaction data")
            return data_str.strip('\x00')  # Remove null bytes
            
        except Exception as e:
            logger.error(f"Error retrieving transaction data: {str(e)}")
            raise OracleError(f"Failed to retrieve transaction data: {str(e)}")
    
    def _recompute_data_hash(self, data: Dict[str, Any]) -> str:
        """
        Recompute the SHA-256 hash of the data.
        
        Args:
            data (Dict[str, Any]): The data to hash
            
        Returns:
            str: The SHA-256 hash of the data as a hex string
        """
        # Serialize data to JSON with sorted keys for consistent hashing
        data_json = json.dumps(data, sort_keys=True, separators=(',', ':'))
        
        # Compute SHA-256 hash
        data_hash = hashlib.sha256(data_json.encode('utf-8')).hexdigest()
        
        logger.info(f"Recomputed data hash: {data_hash}")
        return data_hash
    
    def _find_original_data(self, app_state: AppState, blockchain_entry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Find the original data that corresponds to a blockchain entry.
        
        Args:
            app_state (AppState): The current application state
            blockchain_entry (Dict[str, Any]): The blockchain log entry
            
        Returns:
            Dict[str, Any]: The original data
            
        Raises:
            OracleError: If the original data cannot be found
        """
        data_hash = blockchain_entry.get("data_hash")
        if not data_hash:
            raise OracleError("No data_hash found in blockchain entry")
        
        # Look for data in various state fields
        # Check current_credential
        if app_state.current_credential and str(app_state.current_credential.id) == blockchain_entry.get("data_id"):
            return app_state.current_credential.model_dump(mode="json")
        
        # Check credentials list
        for credential in app_state.credentials:
            if str(credential.id) == blockchain_entry.get("data_id"):
                return credential.model_dump(mode="json")
        
        # Check workflow_data
        if "supplier_data" in app_state.workflow_data:
            supplier_data = app_state.workflow_data["supplier_data"]
            # Try to match by hash
            supplier_json = json.dumps(supplier_data, sort_keys=True, separators=(',', ':'))
            supplier_hash = hashlib.sha256(supplier_json.encode('utf-8')).hexdigest()
            if supplier_hash == data_hash:
                return supplier_data
        
        # Check processing_results
        for key, value in app_state.processing_results.items():
            if isinstance(value, dict):
                try:
                    result_json = json.dumps(value, sort_keys=True, separators=(',', ':'))
                    result_hash = hashlib.sha256(result_json.encode('utf-8')).hexdigest()
                    if result_hash == data_hash:
                        return value
                except Exception:
                    continue
        
        raise OracleError(f"Original data not found for blockchain entry with hash {data_hash}")
    
    def run(self, app_state: AppState, transaction_hash: Optional[str] = None) -> Dict[str, Any]:
        """
        Verify consistency between on-chain provenance log and original off-chain data.
        
        Args:
            app_state (AppState): The current application state containing blockchain_log
            transaction_hash (str, optional): Specific transaction hash to verify. 
                                             If not provided, verifies all entries.
            
        Returns:
            Dict[str, Any]: Verification results
            
        Raises:
            OracleError: If the verification process fails
        """
        try:
            logger.info("Starting blockchain oracle verification")
            
            # Get blockchain log entries to verify
            blockchain_logs = app_state.blockchain_log
            if not blockchain_logs:
                raise OracleError("No blockchain log entries found in app state")
            
            # Filter by specific transaction hash if provided
            if transaction_hash:
                blockchain_logs = [log for log in blockchain_logs if log.get("transaction_hash") == transaction_hash]
                if not blockchain_logs:
                    raise OracleError(f"No blockchain log entry found for transaction hash: {transaction_hash}")
            
            results = []
            verified_count = 0
            total_count = len(blockchain_logs)
            
            # Verify each blockchain log entry
            for blockchain_entry in blockchain_logs:
                entry_result = {
                    "transaction_hash": blockchain_entry.get("transaction_hash"),
                    "verified": False,
                    "on_chain_hash": None,
                    "off_chain_hash": None,
                    "match": False,
                    "error": None
                }
                
                try:
                    # Get transaction hash
                    tx_hash = blockchain_entry.get("transaction_hash")
                    if not tx_hash:
                        entry_result["error"] = "No transaction hash in blockchain entry"
                        results.append(entry_result)
                        continue
                    
                    # Retrieve on-chain data hash
                    on_chain_data = self._get_transaction_data(tx_hash)
                    entry_result["on_chain_hash"] = on_chain_data
                    
                    # Find original off-chain data
                    original_data = self._find_original_data(app_state, blockchain_entry)
                    
                    # Recompute hash of original data
                    off_chain_hash = self._recompute_data_hash(original_data)
                    entry_result["off_chain_hash"] = off_chain_hash
                    
                    # Compare hashes
                    match = on_chain_data == off_chain_hash
                    entry_result["match"] = match
                    entry_result["verified"] = True
                    
                    if match:
                        verified_count += 1
                        logger.info(f"Verification successful for transaction {tx_hash}")
                    else:
                        logger.warning(f"Hash mismatch for transaction {tx_hash}")
                        
                except Exception as e:
                    entry_result["error"] = str(e)
                    logger.error(f"Verification failed for transaction {tx_hash}: {str(e)}")
                
                results.append(entry_result)
            
            # Prepare final result
            success = verified_count == total_count
            verification_result = {
                "success": success,
                "verified_entries": verified_count,
                "total_entries": total_count,
                "results": results,
                "message": f"Verified {verified_count}/{total_count} blockchain entries"
            }
            
            if success:
                logger.info(f"Blockchain oracle verification completed successfully: {verified_count}/{total_count} verified")
            else:
                logger.warning(f"Blockchain oracle verification completed with issues: {verified_count}/{total_count} verified")
            
            return verification_result
            
        except Exception as e:
            logger.error(f"Blockchain oracle verification failed: {str(e)}")
            raise OracleError(f"Blockchain oracle verification failed: {str(e)}")