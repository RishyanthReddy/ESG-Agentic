"""
Unified Tool Registry

This module implements a centralized registry for all tools to promote code
reuse and decouple tool implementation from agent logic.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import threading


class BaseTool(ABC):
    """Abstract base class for all tools"""
    
    def __init__(self, name: str, description: str = ""):
        """
        Initialize a tool with a name and description.
        
        Args:
            name (str): The name of the tool
            description (str): A description of what the tool does
        """
        self.name = name
        self.description = description
    
    @abstractmethod
    def run(self, **kwargs) -> Any:
        """
        Execute the tool with the given parameters.
        
        Args:
            **kwargs: Tool-specific parameters
            
        Returns:
            Any: The result of tool execution
        """
        pass


class ToolRegistry:
    """Singleton registry for managing tools across the application"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        """Implement singleton pattern with thread safety"""
        if cls._instance is None:
            with cls._lock:
                # Double-checked locking pattern
                if cls._instance is None:
                    cls._instance = super(ToolRegistry, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize the tool registry"""
        # Ensure initialization only happens once
        if not hasattr(self, '_initialized'):
            self._tools: Dict[str, BaseTool] = {}
            self._initialized = True
    
    def register_tool(self, tool: BaseTool) -> None:
        """
        Register a tool in the registry.
        
        Args:
            tool (BaseTool): The tool to register
            
        Raises:
            ValueError: If tool is not a BaseTool instance or name already exists
        """
        if not isinstance(tool, BaseTool):
            raise ValueError("Tool must be an instance of BaseTool")
        
        if tool.name in self._tools:
            raise ValueError(f"Tool with name '{tool.name}' already registered")
        
        self._tools[tool.name] = tool
    
    def get_tool(self, name: str) -> Optional[BaseTool]:
        """
        Retrieve a tool by name.
        
        Args:
            name (str): The name of the tool to retrieve
            
        Returns:
            Optional[BaseTool]: The tool if found, None otherwise
        """
        return self._tools.get(name)
    
    def unregister_tool(self, name: str) -> bool:
        """
        Remove a tool from the registry.
        
        Args:
            name (str): The name of the tool to remove
            
        Returns:
            bool: True if tool was removed, False if not found
        """
        if name in self._tools:
            del self._tools[name]
            return True
        return False
    
    def list_tools(self) -> Dict[str, str]:
        """
        List all registered tools with their descriptions.
        
        Returns:
            Dict[str, str]: A dictionary mapping tool names to descriptions
        """
        return {name: tool.description for name, tool in self._tools.items()}
    
    def clear(self) -> None:
        """Clear all tools from the registry"""
        self._tools.clear()