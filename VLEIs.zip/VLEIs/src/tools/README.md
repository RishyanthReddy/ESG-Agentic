# Tools Framework

## Overview

The tools framework implements specialized components that perform specific functions within the ESG Intelligence Platform. Tools are designed to be reusable components that can be accessed by multiple agents through a centralized registry.

## Tool Types

### 1. GLEIF vLEI Verification Tool

**Module:** [src/tools/verification.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/verification.py)

The GLEIF vLEI Verification Tool implements real-time validation of vLEI credentials by connecting directly to the live GLEIF Verifier API.

#### Features
- **HTTP Client:** Uses httpx for GLEIF API communication
- **API Integration:** Connects to GLEIF vLEI Verifier API endpoints
- **Authentication:** API key management for GLEIF services
- **Response Parsing:** JSON response parsing and validation
- **Error Handling:** API error handling with retry logic

#### Usage

```python
from src.tools.verification import GleifVerifierTool
from src.state.models import vLEICredential

# Create the tool
verifier = GleifVerifierTool()

# Create a credential to verify
credential = vLEICredential(
    issuer="did:example:issuer",
    subject="did:example:subject",
    claims={"lei": "12345678901234567890"}
)

# Verify the credential
result = verifier.run(credential)

# Check verification result
if result["verified"]:
    print("Credential is valid")
else:
    print("Credential verification failed")
```

### 2. Infura Blockchain Tool

**Module:** [src/tools/provenance.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/provenance.py)

The Infura Blockchain Tool implements logging of data provenance to the Ethereum blockchain using Infura's API to connect to the Sepolia testnet.

#### Features
- **Blockchain Connection:** Connects to Ethereum Sepolia testnet via Infura
- **Transaction Management:** Handles gas estimation, transaction signing, and broadcasting
- **Confirmation Tracking:** Waits for transaction confirmation and returns transaction hash
- **Error Handling:** Comprehensive error handling for blockchain operations

#### Usage

```python
from src.tools.provenance import InfuraBlockchainTool

# Create the tool
blockchain_tool = InfuraBlockchainTool()

# Log data to blockchain
data_hash = "sha256-hash-of-data-to-log"
private_key = "your-ethereum-private-key"

# Log the data hash to blockchain
result = blockchain_tool.run(data_hash, private_key)

# Check result
if result["success"]:
    print(f"Data logged with transaction hash: {result['transaction_hash']}")
else:
    print("Failed to log data to blockchain")
```

### 3. Tool Registry

**Module:** [src/tools/registry.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/registry.py)

The Tool Registry implements a centralized registry for all tools to promote code reuse and decouple tool implementation from agent logic.

#### Features
- **Singleton Pattern:** Ensures a single registry instance across the application
- **Thread Safety:** Safe concurrent access from multiple agents
- **Dynamic Registration:** Register, lookup, and unregister tools at runtime
- **Tool Discovery:** List all available tools with descriptions

#### Usage

```python
from src.tools.registry import ToolRegistry
from src.tools.verification import GleifVerifierTool

# Get the registry instance (singleton)
registry = ToolRegistry()

# Create and register a tool
verifier = GleifVerifierTool()
registry.register_tool(verifier)

# Retrieve a tool
tool = registry.get_tool("gleif_verifier")

# List all tools
tools = registry.list_tools()
print(tools)  # {"gleif_verifier": "Verifies vLEI credentials against the GLEIF vLEI Verifier API"}
```

## Tool Interface

All tools follow a consistent interface pattern by extending the BaseTool abstract class:

```python
from src.tools.registry import BaseTool

class ExampleTool(BaseTool):
    def __init__(self):
        super().__init__(
            name="example_tool",
            description="Description of what the tool does"
        )
    
    def run(self, **kwargs):
        """
        Execute the tool with the given parameters.
        
        Args:
            **kwargs: Tool-specific parameters
            
        Returns:
            Any: The result of tool execution
        """
        # Tool-specific logic
        return result
```

## Testing

Each tool includes comprehensive unit and integration tests:

- **Unit Tests:** Validate tool interface compliance, mock API responses, error handling, and data validation
- **Integration Tests:** Verify tool behavior in complete workflow contexts, performance under load, and error recovery

Run tests with:
```bash
# Unit tests
python -m pytest tests/test_gleif_verifier.py -v
python -m pytest tests/test_blockchain_tool.py -v

# Integration tests
python -m pytest tests/test_gleif_verifier_integration.py -v
python -m pytest tests/test_blockchain_tool_integration.py -v
```