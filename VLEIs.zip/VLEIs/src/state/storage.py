"""
In-memory storage for reports and their cryptographic proofs

This module provides a simple in-memory storage solution for storing and retrieving
reports and their associated cryptographic proofs. In a production environment,
this would be replaced with a proper database implementation.
"""

from typing import Dict, Any, Optional, List
from src.state.models import AppState, GRIReport, SASBReport, TCFDReport, CSRDReport
import json
from uuid import UUID


class ReportStorage:
    """
    Simple in-memory storage for reports and their cryptographic proofs.
    In a production environment, this would be replaced with a proper database implementation.
    """
    
    def __init__(self):
        """Initialize the in-memory storage"""
        # Store reports with their IDs as keys
        self._reports: Dict[str, Dict[str, Any]] = {}
        # Store cryptographic proofs with report IDs as keys
        self._proofs: Dict[str, Dict[str, Any]] = {}
    
    def store_report_and_proofs(self, app_state: AppState) -> List[str]:
        """
        Store reports and their cryptographic proofs from an AppState object.
        
        Args:
            app_state (AppState): The application state containing reports and proofs
            
        Returns:
            List[str]: List of report IDs that were stored
        """
        stored_report_ids = []
        
        # Store GRI reports
        for report in app_state.gri_reports:
            report_id = str(report.id)
            self._reports[report_id] = report.model_dump(mode="json")
            # Extract cryptographic proofs if available
            self._proofs[report_id] = {
                "vc_jwt": self._extract_vc_jwt(app_state, report_id),
                "blockchain_hashes": self._extract_blockchain_hashes(app_state, report_id),
                "report_type": "GRI"
            }
            stored_report_ids.append(report_id)
        
        # Store SASB reports
        for report in app_state.sasb_reports:
            report_id = str(report.id)
            self._reports[report_id] = report.model_dump(mode="json")
            # Extract cryptographic proofs if available
            self._proofs[report_id] = {
                "vc_jwt": self._extract_vc_jwt(app_state, report_id),
                "blockchain_hashes": self._extract_blockchain_hashes(app_state, report_id),
                "report_type": "SASB"
            }
            stored_report_ids.append(report_id)
        
        # Store TCFD reports
        for report in app_state.tcfd_reports:
            report_id = str(report.id)
            self._reports[report_id] = report.model_dump(mode="json")
            # Extract cryptographic proofs if available
            self._proofs[report_id] = {
                "vc_jwt": self._extract_vc_jwt(app_state, report_id),
                "blockchain_hashes": self._extract_blockchain_hashes(app_state, report_id),
                "report_type": "TCFD"
            }
            stored_report_ids.append(report_id)
        
        # Store CSRD reports
        for report in app_state.csrd_reports:
            report_id = str(report.id)
            self._reports[report_id] = report.model_dump(mode="json")
            # Extract cryptographic proofs if available
            self._proofs[report_id] = {
                "vc_jwt": self._extract_vc_jwt(app_state, report_id),
                "blockchain_hashes": self._extract_blockchain_hashes(app_state, report_id),
                "report_type": "CSRD"
            }
            stored_report_ids.append(report_id)
        
        return stored_report_ids
    
    def _extract_vc_jwt(self, app_state: AppState, report_id: str) -> Optional[str]:
        """
        Extract VC JWT from the AppState for a given report ID.
        
        Args:
            app_state (AppState): The application state
            report_id (str): The report ID
            
        Returns:
            Optional[str]: The VC JWT if found, None otherwise
        """
        # In a real implementation, this would extract the actual VC JWT
        # For demonstration, we'll generate a mock JWT
        return f"mock_vc_jwt_for_report_{report_id}"
    
    def _extract_blockchain_hashes(self, app_state: AppState, report_id: str) -> List[str]:
        """
        Extract blockchain hashes from the AppState for a given report ID.
        
        Args:
            app_state (AppState): The application state
            report_id (str): The report ID
            
        Returns:
            List[str]: List of blockchain hashes
        """
        # Extract blockchain hashes from the blockchain_log
        hashes = []
        for log_entry in app_state.blockchain_log:
            if log_entry.get("data_id") == report_id:
                hashes.append(log_entry.get("transaction_hash", ""))
        return hashes
    
    def get_report(self, report_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a report by its ID.
        
        Args:
            report_id (str): The report ID
            
        Returns:
            Optional[Dict[str, Any]]: The report data if found, None otherwise
        """
        return self._reports.get(report_id)
    
    def get_proofs(self, report_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve cryptographic proofs for a report by its ID.
        
        Args:
            report_id (str): The report ID
            
        Returns:
            Optional[Dict[str, Any]]: The cryptographic proofs if found, None otherwise
        """
        return self._proofs.get(report_id)


# Global instance for the application
report_storage = ReportStorage()