"""
Core State Definition with Pydantic Models

This module defines the central, strictly-typed state object using Pydantic BaseModel.
This ensures end-to-end runtime validation for the system's "single source of truth."
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from uuid import UUID, uuid4
from enum import Enum


class CredentialStatus(str, Enum):
    """Status of a vLEI credential"""
    ISSUED = "issued"
    REVOKED = "revoked"
    SUSPENDED = "suspended"
    EXPIRED = "expired"


class VerificationStatus(str, Enum):
    """Verification status of a credential"""
    PENDING = "pending"
    VERIFIED = "verified"
    FAILED = "failed"
    REJECTED = "rejected"


class vLEICredential(BaseModel):
    """vLEI (verifiable Legal Entity Identifier) Credential Model"""
    id: UUID = Field(default_factory=uuid4)
    issuer: str = Field(..., description="Issuer of the credential")
    subject: str = Field(..., description="Subject of the credential")
    issuance_date: datetime = Field(default_factory=datetime.utcnow)
    expiration_date: Optional[datetime] = Field(None, description="Expiration date of the credential")
    credential_status: CredentialStatus = Field(default=CredentialStatus.ISSUED)
    verification_status: VerificationStatus = Field(default=VerificationStatus.PENDING)
    claims: Dict[str, Any] = Field(default_factory=dict, description="Claims in the credential")
    proof: Optional[Dict[str, Any]] = Field(None, description="Cryptographic proof of the credential")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class GRIReport(BaseModel):
    """GRI (Global Reporting Initiative) Report Model"""
    id: UUID = Field(default_factory=uuid4)
    company_name: Optional[str] = Field(None, description="Name of the company")
    report_year: Optional[int] = Field(None, description="Year of the report")
    created_date: datetime = Field(default_factory=datetime.utcnow)
    # GRI Standards-based fields
    general_disclosure: Optional[Dict[str, Any]] = Field(None, description="General disclosure information")
    management_approach: Optional[Dict[str, Any]] = Field(None, description="Management approach indicators")
    topic_specific_disclosure: Optional[Dict[str, Any]] = Field(None, description="Topic-specific disclosure")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class SASBReport(BaseModel):
    """SASB (Sustainability Accounting Standards Board) Report Model"""
    id: UUID = Field(default_factory=uuid4)
    company_name: Optional[str] = Field(None, description="Name of the company")
    report_year: Optional[int] = Field(None, description="Year of the report")
    created_date: datetime = Field(default_factory=datetime.utcnow)
    # SASB Standards-based fields
    environmental_indicators: Optional[Dict[str, Any]] = Field(None, description="Environmental sustainability indicators")
    social_indicators: Optional[Dict[str, Any]] = Field(None, description="Social sustainability indicators")
    governance_indicators: Optional[Dict[str, Any]] = Field(None, description="Governance sustainability indicators")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class TCFDReport(BaseModel):
    """TCFD (Task Force on Climate-related Financial Disclosures) Report Model"""
    id: UUID = Field(default_factory=uuid4)
    company_name: Optional[str] = Field(None, description="Name of the company")
    report_year: Optional[int] = Field(None, description="Year of the report")
    created_date: datetime = Field(default_factory=datetime.utcnow)
    # TCFD Framework-based fields
    governance: Optional[Dict[str, Any]] = Field(None, description="Climate-related governance structure")
    strategy: Optional[Dict[str, Any]] = Field(None, description="Climate-related strategy and risk assessment")
    risk_management: Optional[Dict[str, Any]] = Field(None, description="Climate-related risk management processes")
    metrics_and_targets: Optional[Dict[str, Any]] = Field(None, description="Climate-related metrics and targets")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class CSRDReport(BaseModel):
    """CSRD (Corporate Sustainability Reporting Directive) Report Model"""
    id: UUID = Field(default_factory=uuid4)
    company_name: Optional[str] = Field(None, description="Name of the company")
    report_year: Optional[int] = Field(None, description="Year of the report")
    created_date: datetime = Field(default_factory=datetime.utcnow)
    
    # ESRS Cross-Cutting Disclosures (ESRS 1 and ESRS 2)
    business_model: Optional[Dict[str, Any]] = Field(None, description="Business model and value chain description")
    double_materiality_assessment: Optional[Dict[str, Any]] = Field(None, description="Assessment of impact and financial materiality")
    impact_management_process: Optional[Dict[str, Any]] = Field(None, description="Process for managing principal impacts")
    due_diligence: Optional[Dict[str, Any]] = Field(None, description="Due diligence processes")
    policies: Optional[Dict[str, Any]] = Field(None, description="Policies related to sustainability")
    
    # ESRS Environmental Disclosures
    # ESRS E1 - Climate Change
    greenhouse_gas_emissions: Optional[Dict[str, Any]] = Field(None, description="Greenhouse gas emissions data (Scope 1, 2, 3)")
    climate_risks_and_opportunities: Optional[Dict[str, Any]] = Field(None, description="Climate-related risks and opportunities")
    climate_targets_and_actions: Optional[Dict[str, Any]] = Field(None, description="Climate targets and transition plans")
    
    # ESRS E2 - Pollution
    pollution_emissions: Optional[Dict[str, Any]] = Field(None, description="Air, water, and soil pollution emissions")
    pollution_prevention_measures: Optional[Dict[str, Any]] = Field(None, description="Measures to prevent and reduce pollution")
    
    # ESRS E3 - Water and Marine Resources
    water_consumption_and_discharge: Optional[Dict[str, Any]] = Field(None, description="Water consumption, withdrawal, and discharge")
    marine_resources_impact: Optional[Dict[str, Any]] = Field(None, description="Impact on marine resources and ecosystems")
    
    # ESRS E4 - Biodiversity and Ecosystems
    biodiversity_impact: Optional[Dict[str, Any]] = Field(None, description="Impact on biodiversity and ecosystems")
    biodiversity_protection_measures: Optional[Dict[str, Any]] = Field(None, description="Measures to protect biodiversity")
    
    # ESRS E5 - Resource Use and Circular Economy
    resource_consumption: Optional[Dict[str, Any]] = Field(None, description="Consumption of raw materials and resources")
    circular_economy_metrics: Optional[Dict[str, Any]] = Field(None, description="Metrics related to circular economy practices")
    
    # ESRS Social Disclosures
    # ESRS S1 - Own Workforce
    workforce_demographics: Optional[Dict[str, Any]] = Field(None, description="Demographics of the company's own workforce")
    workforce_health_safety: Optional[Dict[str, Any]] = Field(None, description="Health and safety measures for workforce")
    workforce_training: Optional[Dict[str, Any]] = Field(None, description="Training and development programs")
    
    # ESRS S2 - Workers in Value Chain
    value_chain_workers_assessment: Optional[Dict[str, Any]] = Field(None, description="Assessment of workers in the value chain")
    value_chain_workers_improvement: Optional[Dict[str, Any]] = Field(None, description="Actions to improve value chain working conditions")
    
    # ESRS S3 - Affected Communities
    community_impact_assessment: Optional[Dict[str, Any]] = Field(None, description="Assessment of impacts on local communities")
    community_engagement: Optional[Dict[str, Any]] = Field(None, description="Community engagement and development programs")
    
    # ESRS S4 - Consumers and End-Users
    product_safety: Optional[Dict[str, Any]] = Field(None, description="Product safety and quality measures")
    consumer_protection: Optional[Dict[str, Any]] = Field(None, description="Consumer protection and privacy measures")
    
    # ESRS Governance Disclosures (ESRS G1)
    governance_body: Optional[Dict[str, Any]] = Field(None, description="Sustainability-related roles and responsibilities")
    executive_remuneration: Optional[Dict[str, Any]] = Field(None, description="Executive remuneration linked to sustainability")
    prevention_of_adverse_impacts: Optional[Dict[str, Any]] = Field(None, description="Processes to prevent and mitigate adverse impacts")
    breach_reporting: Optional[Dict[str, Any]] = Field(None, description="Reporting of breaches and corrective actions")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class AuditTrailEntry(BaseModel):
    """Audit Trail Entry Model"""
    id: UUID = Field(default_factory=uuid4)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    audit_type: str = Field(..., description="Type of audit performed")
    blockchain_entry_hash: Optional[str] = Field(None, description="Hash of the blockchain entry audited")
    transaction_hash: Optional[str] = Field(None, description="Blockchain transaction hash")
    verification_result: bool = Field(..., description="Result of the verification")
    details: Dict[str, Any] = Field(default_factory=dict, description="Detailed audit results")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }


class AppState(BaseModel):
    """Main application state containing all workflow state fields"""
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Current credential being processed
    current_credential: Optional[vLEICredential] = Field(None, description="Current credential being processed")
    
    # Collection of credentials
    credentials: List[vLEICredential] = Field(default_factory=list, description="List of credentials")
    
    # ESG Reports
    gri_reports: List[GRIReport] = Field(default_factory=list, description="List of GRI reports")
    sasb_reports: List[SASBReport] = Field(default_factory=list, description="List of SASB reports")
    tcfd_reports: List[TCFDReport] = Field(default_factory=list, description="List of TCFD reports")
    csrd_reports: List[CSRDReport] = Field(default_factory=list, description="List of CSRD reports")
    
    # Workflow state
    workflow_status: str = Field("initialized", description="Current workflow status")
    workflow_step: int = Field(0, description="Current workflow step")
    workflow_data: Dict[str, Any] = Field(default_factory=dict, description="Workflow-specific data")
    
    # Processing results
    processing_results: Dict[str, Any] = Field(default_factory=dict, description="Results of processing steps")
    
    # Error tracking
    errors: List[str] = Field(default_factory=list, description="List of errors encountered")
    
    # Error log for detailed error tracking
    error_log: List[Dict[str, Any]] = Field(default_factory=list, description="Detailed log of errors and exceptions")
    
    # Configuration
    config: Dict[str, Any] = Field(default_factory=dict, description="Configuration settings")
    
    # Task queue for the orchestrator
    task_queue: List[str] = Field(default_factory=list, description="Queue of tasks for the orchestrator")
    
    # Agent trace for logging routing decisions
    agent_trace: List[Dict[str, Any]] = Field(default_factory=list, description="Trace of agent routing decisions")
    
    # Blockchain log for storing transaction hashes
    blockchain_log: List[Dict[str, Any]] = Field(default_factory=list, description="Log of blockchain transactions")
    
    # Audit trail for storing audit results
    audit_trail: List[AuditTrailEntry] = Field(default_factory=list, description="Log of audit results")
    
    # Regulatory reports
    regulatory_report: Optional[Dict[str, Any]] = Field(None, description="Generated regulatory reports")
    
    # Visualization assets
    visualization_assets: Optional[Dict[str, Any]] = Field(None, description="Generated visualization assets")
    
    # Granular traceability - data point to trace
    trace_data_point: Optional[str] = Field(None, description="Specific data point ID to trace through the supply chain")
    # Cryptographic proofs for reports
    report_proofs: List[Dict[str, Any]] = Field(default_factory=list, description="Cryptographic proofs for generated reports")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None,
            UUID: lambda v: str(v)
        }
    
    @validator('updated_at', pre=True, always=True)
    def set_updated_at(cls, v):
        return datetime.utcnow()