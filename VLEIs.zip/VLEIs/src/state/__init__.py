# src/state/__init__.py
# This file makes the state directory a Python package