"""
WebSocket Module Initialization

This module initializes the WebSocket functionality for the ESG Intelligence Platform.
"""

from .manager import ConnectionManager
from .routes import router as websocket_router

__all__ = ["ConnectionManager", "websocket_router"]