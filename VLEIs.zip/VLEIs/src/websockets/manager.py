"""
WebSocket Connection Manager

This module manages WebSocket connections and provides methods for broadcasting messages
to all connected clients.
"""

from fastapi import WebSocket
from typing import List
import json
import asyncio
from loguru import logger


class ConnectionManager:
    """
    Manages WebSocket connections and message broadcasting.
    """
    
    def __init__(self):
        """Initialize the connection manager."""
        self.active_connections: List[WebSocket] = []
        self.message_queue: asyncio.Queue = asyncio.Queue()
        
    async def connect(self, websocket: WebSocket):
        """
        Accept a WebSocket connection and add it to the active connections list.
        
        Args:
            websocket: The WebSocket connection to accept
        """
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connection established. Total connections: {len(self.active_connections)}")
        
    def disconnect(self, websocket: WebSocket):
        """
        Remove a WebSocket connection from the active connections list.
        
        Args:
            websocket: The WebSocket connection to remove
        """
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"WebSocket connection closed. Total connections: {len(self.active_connections)}")
            
    async def send_personal_message(self, message: str, websocket: WebSocket):
        """
        Send a message to a specific WebSocket connection.
        
        Args:
            message: The message to send
            websocket: The WebSocket connection to send the message to
        """
        try:
            await websocket.send_text(message)
        except Exception as e:
            logger.error(f"Error sending personal message: {e}")
            self.disconnect(websocket)
            
    async def broadcast(self, message: str):
        """
        Broadcast a message to all active WebSocket connections.
        
        Args:
            message: The message to broadcast
        """
        # Add message to queue for persistence
        await self.message_queue.put(message)
        
        # Broadcast to all connections
        disconnected_connections = []
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception as e:
                logger.error(f"Error broadcasting message: {e}")
                disconnected_connections.append(connection)
                
        # Remove disconnected connections
        for connection in disconnected_connections:
            self.disconnect(connection)
            
    async def get_message_history(self, limit: int = 10) -> List[str]:
        """
        Get recent message history from the queue.
        
        Args:
            limit: Maximum number of messages to retrieve
            
        Returns:
            List of recent messages
        """
        messages = []
        temp_queue = asyncio.Queue()
        
        # Get all messages from the queue
        while not self.message_queue.empty():
            try:
                message = self.message_queue.get_nowait()
                messages.append(message)
                await temp_queue.put(message)
            except asyncio.QueueEmpty:
                break
                
        # Put messages back into the original queue
        while not temp_queue.empty():
            try:
                message = temp_queue.get_nowait()
                await self.message_queue.put(message)
            except asyncio.QueueEmpty:
                break
                
        # Return only the last 'limit' messages
        return messages[-limit:] if len(messages) > limit else messages