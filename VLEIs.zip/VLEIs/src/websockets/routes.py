"""
WebSocket Routes

This module defines WebSocket endpoints for real-time communication.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import json
from typing import Dict, Any
import asyncio
from datetime import datetime
from loguru import logger

from src.websockets.manager import ConnectionManager

# Initialize the connection manager
manager = ConnectionManager()

# Initialize the router
router = APIRouter()

# Security scheme
security = HTTPBearer()

# Simulated authentication tokens (in a real app, this would be more sophisticated)
VALID_TOKENS = {
    "demo_token": "Demo User",
    "cli_token": "CLI Client"
}


async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """
    Verify the authentication token for WebSocket connections.
    
    Args:
        credentials: The HTTP authorization credentials
        
    Returns:
        The user information if token is valid
        
    Raises:
        HTTPException: If token is invalid
    """
    token = credentials.credentials
    if token not in VALID_TOKENS:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return VALID_TOKENS[token]


@router.websocket("/ws/dashboard")
async def websocket_dashboard(websocket: WebSocket):
    """
    WebSocket endpoint for real-time dashboard updates.
    
    Args:
        websocket: The WebSocket connection
    """
    # Accept the connection
    await manager.connect(websocket)
    
    try:
        # Send initial connection message
        initial_message = {
            "type": "connection_ack",
            "timestamp": datetime.now().isoformat(),
            "message": "Connected to real-time dashboard updates"
        }
        await manager.send_personal_message(json.dumps(initial_message), websocket)
        
        # Send recent message history
        history = await manager.get_message_history()
        for message in history:
            await manager.send_personal_message(message, websocket)
        
        # Listen for messages
        while True:
            data = await websocket.receive_text()
            # Echo the message back (in a real app, this might trigger some action)
            response = {
                "type": "echo",
                "timestamp": datetime.now().isoformat(),
                "received": data
            }
            await manager.send_personal_message(json.dumps(response), websocket)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("Dashboard WebSocket client disconnected")
    except Exception as e:
        logger.error(f"Error in dashboard WebSocket: {e}")
        manager.disconnect(websocket)


@router.websocket("/ws/realtime")
async def websocket_realtime(websocket: WebSocket, token: str = None):
    """
    WebSocket endpoint for general real-time updates.
    
    Args:
        websocket: The WebSocket connection
        token: Authentication token (passed as query parameter)
    """
    # Verify token if provided
    if token:
        if token not in VALID_TOKENS:
            await websocket.close(code=4000, reason="Invalid authentication token")
            return
    else:
        # For demo purposes, we'll allow connections without token
        pass
    
    # Accept the connection
    await manager.connect(websocket)
    
    try:
        # Send initial connection message
        initial_message = {
            "type": "connection_ack",
            "timestamp": datetime.now().isoformat(),
            "message": "Connected to real-time updates"
        }
        await manager.send_personal_message(json.dumps(initial_message), websocket)
        
        # Listen for messages
        while True:
            data = await websocket.receive_text()
            # Process the message and broadcast to all clients
            message_data = {
                "type": "broadcast",
                "timestamp": datetime.now().isoformat(),
                "sender": "client",
                "data": data
            }
            await manager.broadcast(json.dumps(message_data))
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("Real-time WebSocket client disconnected")
    except Exception as e:
        logger.error(f"Error in real-time WebSocket: {e}")
        manager.disconnect(websocket)


# Polling endpoints for fallback
@router.get("/poll/dashboard")
async def poll_dashboard_updates(token: str = Depends(verify_token)):
    """
    Polling endpoint for dashboard updates (fallback for WebSocket).
    
    Args:
        token: Authentication token
        
    Returns:
        Recent dashboard updates
    """
    try:
        # Get recent message history
        history = await manager.get_message_history(5)
        
        # Format response
        updates = []
        for message in history:
            try:
                parsed_message = json.loads(message)
                updates.append(parsed_message)
            except json.JSONDecodeError:
                # If message is not JSON, wrap it
                updates.append({
                    "type": "raw_message",
                    "timestamp": datetime.now().isoformat(),
                    "data": message
                })
        
        return {
            "status": "success",
            "data": updates,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error in dashboard polling endpoint: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving dashboard updates"
        )


@router.get("/poll/realtime")
async def poll_realtime_updates(token: str = Depends(verify_token)):
    """
    Polling endpoint for real-time updates (fallback for WebSocket).
    
    Args:
        token: Authentication token
        
    Returns:
        Recent real-time updates
    """
    try:
        # Get recent message history
        history = await manager.get_message_history(10)
        
        # Format response
        updates = []
        for message in history:
            try:
                parsed_message = json.loads(message)
                updates.append(parsed_message)
            except json.JSONDecodeError:
                # If message is not JSON, wrap it
                updates.append({
                    "type": "raw_message",
                    "timestamp": datetime.now().isoformat(),
                    "data": message
                })
        
        return {
            "status": "success",
            "data": updates,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error in real-time polling endpoint: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error retrieving real-time updates"
        )


@router.post("/broadcast")
async def broadcast_message(
    message: Dict[str, Any],
    token: HTTPAuthorizationCredentials = Depends(verify_token)
):
    """
    Broadcast a message to all connected WebSocket clients.
    
    Args:
        message: The message to broadcast
        token: Authentication token
        
    Returns:
        Confirmation of broadcast
    """
    try:
        # Add timestamp and type if not present
        if "timestamp" not in message:
            message["timestamp"] = datetime.now().isoformat()
        if "type" not in message:
            message["type"] = "server_broadcast"
            
        # Convert to JSON string
        message_str = json.dumps(message)
        
        # Broadcast the message
        await manager.broadcast(message_str)
        
        return {
            "status": "success",
            "message": "Message broadcasted to all connected clients",
            "data": message
        }
    except Exception as e:
        logger.error(f"Error broadcasting message: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error broadcasting message"
        )