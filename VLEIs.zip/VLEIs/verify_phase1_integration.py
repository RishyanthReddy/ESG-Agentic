"""
Simple verification script for Phase 1 Integration Test
"""

import os
from pathlib import Path


def test_integration_test_file():
    """Test that the Phase 1 integration test file exists and has required components"""
    print("Testing Phase 1 Integration Test configuration...")
    
    # Check test file exists
    test_path = Path("tests/test_phase1_integration.py")
    if not test_path.exists():
        print("❌ Phase 1 integration test file not found")
        return False
    print("✓ Phase 1 integration test file exists")
    
    # Check test file content
    try:
        with open(test_path, "r") as f:
            test_content = f.read()
        
        # Check for required imports
        required_imports = [
            "import pytest",
            "import httpx",
            "import asyncio",
            "from src.state.models import AppState"
        ]
        
        for import_stmt in required_imports:
            if import_stmt not in test_content:
                print(f"❌ Required import missing: {import_stmt}")
                return False
        print("✓ All required imports present")
        
        # Check for required test functions
        required_tests = [
            "test_end_to_end_integration_stream_endpoint",
            "test_end_to_end_integration_with_minimal_data",
            "test_data_flow_validation",
            "test_performance_validation",
            "test_credential_verification_status",
            "test_blockchain_transaction_hash_validity",
            "test_error_scenario_handling"
        ]
        
        for test_func in required_tests:
            if f"def {test_func}" not in test_content:
                print(f"❌ Required test function missing: {test_func}")
                return False
        print("✓ All required test functions present")
        
        # Check for tech stack components
        tech_stack_elements = [
            "httpx",  # HTTP Testing
            "AppState",  # Response Validation with Pydantic
            "pytest",  # Assertion Framework
            "transaction_hash",  # Blockchain transaction validation
        ]
        
        for element in tech_stack_elements:
            if element not in test_content:
                print(f"❌ Tech stack element missing: {element}")
                return False
        print("✓ All tech stack elements present")
        
    except Exception as e:
        print(f"❌ Error reading test file: {e}")
        return False
    
    print("\n🎉 Phase 1 Integration Test configuration tests passed!")
    return True


def test_test_data():
    """Test that test data is properly defined"""
    print("\nTesting test data configuration...")
    
    try:
        with open("tests/test_phase1_integration.py", "r") as f:
            test_content = f.read()
        
        # Check for test data
        if "TEST_SUPPLIER_DATA" not in test_content:
            print("❌ TEST_SUPPLIER_DATA not defined")
            return False
        print("✓ TEST_SUPPLIER_DATA defined")
        
        if "TEST_CONFIG" not in test_content:
            print("❌ TEST_CONFIG not defined")
            return False
        print("✓ TEST_CONFIG defined")
        
        # Check for proper data structure
        if '"company_name"' not in test_content:
            print("❌ Company name not in test data")
            return False
        print("✓ Company name in test data")
        
    except Exception as e:
        print(f"❌ Error checking test data: {e}")
        return False
    
    print("\n🎉 Test data configuration tests passed!")
    return True


def test_httpx_usage():
    """Test that httpx is properly used for API testing"""
    print("\nTesting httpx usage...")
    
    try:
        with open("tests/test_phase1_integration.py", "r") as f:
            test_content = f.read()
        
        # Check for httpx client usage
        if "httpx.AsyncClient" not in test_content:
            print("❌ httpx.AsyncClient not used")
            return False
        print("✓ httpx.AsyncClient used")
        
        # Check for async/await pattern
        if "async def" not in test_content:
            print("❌ Async functions not defined")
            return False
        print("✓ Async functions defined")
        
        # Check for proper API endpoint testing
        if "/ingest/stream" not in test_content:
            print("❌ /ingest/stream endpoint not tested")
            return False
        print("✓ /ingest/stream endpoint tested")
        
    except Exception as e:
        print(f"❌ Error checking httpx usage: {e}")
        return False
    
    print("\n🎉 httpx usage tests passed!")
    return True


if __name__ == "__main__":
    test_ok = test_integration_test_file()
    data_ok = test_test_data()
    httpx_ok = test_httpx_usage()
    
    if test_ok and data_ok and httpx_ok:
        print("\n🎉 Phase 1 Integration Test verification successful!")
        exit(0)
    else:
        print("\n❌ Phase 1 Integration Test verification failed!")
        exit(1)