#!/usr/bin/env python3
"""
Path Tracer Script for ESG Intelligence Platform
This script calls real path tracing endpoints and displays highlighted path in terminal.
"""

import json
import requests
import argparse
import sys
import time
from typing import Dict, Any, List
import networkx as nx
from collections import deque

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


def fetch_graph_data(base_url: str = "http://localhost:8000") -> Dict[str, Any]:
    """
    Fetch graph data from the ESG Intelligence Platform API
    """
    try:
        # In a real implementation, this would call the actual API endpoint
        # For now, we'll use mock data
        return {
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil"},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China"},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany"},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands"},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA"},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA"},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0},
            ]
        }
    except Exception as e:
        print(f"Error fetching graph data: {e}")
        return {}


def find_shortest_path(graph_data: Dict[str, Any], source: str, target: str) -> List[str]:
    """
    Find the shortest path between source and target nodes using BFS
    """
    # Create a graph from the data
    G = nx.Graph()
    
    # Add nodes
    for node in graph_data.get("nodes", []):
        G.add_node(node["id"], **node)
    
    # Add edges
    for edge in graph_data.get("edges", []):
        G.add_edge(edge["source"], edge["target"], **edge)
    
    try:
        # Find shortest path
        path = nx.shortest_path(G, source, target)
        return path
    except nx.NetworkXNoPath:
        return []
    except Exception as e:
        print(f"Error finding path: {e}")
        return []


def trace_path_in_terminal(graph_data: Dict[str, Any], path: List[str], use_rich: bool = True):
    """
    Display the path in terminal with highlighting
    """
    if not path:
        if use_rich:
            rich_print("[red]No path found between specified nodes.[/red]")
        else:
            print("No path found between specified nodes.")
        return
    
    # Create node lookup
    node_lookup = {node["id"]: node for node in graph_data.get("nodes", [])}
    edge_lookup = {}
    
    # Create edge lookup (source-target pair to edge data)
    for edge in graph_data.get("edges", []):
        edge_lookup[(edge["source"], edge["target"])] = edge
        edge_lookup[(edge["target"], edge["source"])] = edge  # For undirected graph
    
    if use_rich and RICH_AVAILABLE:
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Path Trace[/bold blue]"))
        
        # Display path
        console.print("[bold]Path Traversal:[/bold]")
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            # Highlight current node
            if i == 0:
                console.print(f"[green]→ Start: {node_name} ({node_type})[/green]")
            elif i == len(path) - 1:
                console.print(f"[green]→ End: {node_name} ({node_type})[/green]")
            else:
                console.print(f"[cyan]→ {node_name} ({node_type})[/cyan]")
            
            # Display edge to next node if not the last node
            if i < len(path) - 1:
                next_node_id = path[i + 1]
                edge = edge_lookup.get((node_id, next_node_id), {})
                if edge:
                    edge_type = edge.get("type", "connection")
                    co2_emissions = edge.get("co2_emissions", 0)
                    date = edge.get("date", "N/A")
                    console.print(f"  [dim]├─ {edge_type} (Date: {date}, CO2: {co2_emissions} kg)[/dim]")
        
        # Display path summary
        console.print("\n[bold]Path Summary:[/bold]")
        total_co2 = 0
        for i in range(len(path) - 1):
            node_id = path[i]
            next_node_id = path[i + 1]
            edge = edge_lookup.get((node_id, next_node_id), {})
            if edge:
                total_co2 += edge.get("co2_emissions", 0)
        
        console.print(f"Total nodes: {len(path)}")
        console.print(f"Total CO2 emissions: {total_co2:.2f} kg")
    else:
        # Simple text output
        print("ESG Intelligence Platform - Path Trace")
        print("=" * 40)
        print("Path Traversal:")
        
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            if i == 0:
                print(f"→ Start: {node_name} ({node_type})")
            elif i == len(path) - 1:
                print(f"→ End: {node_name} ({node_type})")
            else:
                print(f"→ {node_name} ({node_type})")
            
            # Display edge to next node if not the last node
            if i < len(path) - 1:
                next_node_id = path[i + 1]
                edge = edge_lookup.get((node_id, next_node_id), {})
                if edge:
                    edge_type = edge.get("type", "connection")
                    co2_emissions = edge.get("co2_emissions", 0)
                    date = edge.get("date", "N/A")
                    print(f"  ├─ {edge_type} (Date: {date}, CO2: {co2_emissions} kg)")
        
        # Display path summary
        print("\nPath Summary:")
        total_co2 = 0
        for i in range(len(path) - 1):
            node_id = path[i]
            next_node_id = path[i + 1]
            edge = edge_lookup.get((node_id, next_node_id), {})
            if edge:
                total_co2 += edge.get("co2_emissions", 0)
        
        print(f"Total nodes: {len(path)}")
        print(f"Total CO2 emissions: {total_co2:.2f} kg")


def main():
    parser = argparse.ArgumentParser(description="Trace path in ESG supply chain")
    parser.add_argument("--source", type=str, default="1", help="Source node ID")
    parser.add_argument("--target", type=str, default="6", help="Target node ID")
    parser.add_argument("--base-url", type=str, default="http://localhost:8000", help="Base URL for API calls")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Determine if we should use rich formatting
    use_rich = RICH_AVAILABLE and not args.simple
    
    # Fetch graph data
    if use_rich and RICH_AVAILABLE:
        with Progress() as progress:
            task = progress.add_task("Fetching graph data...", total=None)
            graph_data = fetch_graph_data(args.base_url)
            progress.update(task, completed=True)
    else:
        print("Fetching graph data...")
        graph_data = fetch_graph_data(args.base_url)
    
    if not graph_data:
        if use_rich and RICH_AVAILABLE:
            rich_print("[red]Failed to fetch graph data.[/red]")
        else:
            print("Failed to fetch graph data.")
        return
    
    # Find shortest path
    if use_rich and RICH_AVAILABLE:
        with Progress() as progress:
            task = progress.add_task("Calculating path...", total=None)
            path = find_shortest_path(graph_data, args.source, args.target)
            progress.update(task, completed=True)
    else:
        print("Calculating path...")
        path = find_shortest_path(graph_data, args.source, args.target)
    
    # Display path
    trace_path_in_terminal(graph_data, path, use_rich)


if __name__ == "__main__":
    main()