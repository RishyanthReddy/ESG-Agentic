#!/usr/bin/env python3
"""
Chart Data Export Script for ESG Intelligence Platform
This script exports chart data as images for presentation backup.
"""

import json
import matplotlib.pyplot as plt
import numpy as np
import argparse
from datetime import datetime
import os

try:
    import plotly.graph_objects as go
    import plotly.express as px
    PLOTLY_AVAILABLE = True
    try:
        # Test if kaleido is available for image export
        import plotly.io as pio
        # Test if kaleido scope is available
        if hasattr(pio, 'kaleido') and pio.kaleido is not None:
            pio.kaleido.scope.chromium_args = ("--disable-gpu", "--disable-dev-shm-usage")
            KALEIDO_AVAILABLE = True
        else:
            KALEIDO_AVAILABLE = False
            print("Warning: Kaleido scope not available. Plotly image export will be limited.")
    except (ImportError, AttributeError):
        KALEIDO_AVAILABLE = False
        print("Warning: Kaleido not available. Plotly image export will be limited.")
except ImportError:
    PLOTLY_AVAILABLE = False
    KALEIDO_AVAILABLE = False
    print("Warning: Plotly not available. Some export features will be limited.")

def export_esg_score_chart(output_dir: str = "demo_scripts") -> None:
    """
    Export ESG score trend chart as image
    """
    # Mock data
    dates = ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06']
    esg_scores = [75, 78, 82, 80, 85, 87]
    environmental_scores = [70, 72, 75, 73, 78, 80]
    social_scores = [80, 82, 85, 84, 88, 90]
    governance_scores = [75, 80, 85, 83, 86, 88]
    
    # Matplotlib version
    plt.figure(figsize=(12, 6))
    plt.plot(dates, esg_scores, marker='o', linewidth=2, label='Overall ESG Score', color='#8884d8')
    plt.plot(dates, environmental_scores, marker='s', linewidth=2, label='Environmental', color='#82ca9d')
    plt.plot(dates, social_scores, marker='^', linewidth=2, label='Social', color='#ffc658')
    plt.plot(dates, governance_scores, marker='d', linewidth=2, label='Governance', color='#ff7300')
    
    plt.title('ESG Score Trend')
    plt.xlabel('Date')
    plt.ylabel('Score')
    plt.ylim(60, 100)
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # Save to file
    filename = os.path.join(output_dir, 'esg_score_chart_export.png')
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"ESG Score chart exported as '{filename}'")
    plt.close()
    
    # Plotly version (if available)
    if PLOTLY_AVAILABLE and KALEIDO_AVAILABLE:
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=dates, 
            y=esg_scores,
            mode='lines+markers',
            name='Overall ESG Score',
            line=dict(color='#8884d8', width=2),
            marker=dict(size=8)
        ))
        
        fig.add_trace(go.Scatter(
            x=dates, 
            y=environmental_scores,
            mode='lines+markers',
            name='Environmental',
            line=dict(color='#82ca9d', width=2),
            marker=dict(size=8)
        ))
        
        fig.add_trace(go.Scatter(
            x=dates, 
            y=social_scores,
            mode='lines+markers',
            name='Social',
            line=dict(color='#ffc658', width=2),
            marker=dict(size=8)
        ))
        
        fig.add_trace(go.Scatter(
            x=dates, 
            y=governance_scores,
            mode='lines+markers',
            name='Governance',
            line=dict(color='#ff7300', width=2),
            marker=dict(size=8)
        ))
        
        fig.update_layout(
            title='ESG Score Trend',
            xaxis_title='Date',
            yaxis_title='Score',
            yaxis=dict(range=[60, 100]),
            xaxis_tickangle=-45,
            template='plotly_white'
        )
        
        # Save to file
        filename = os.path.join(output_dir, 'esg_score_chart_export_plotly.png')
        try:
            fig.write_image(filename)
            print(f"ESG Score chart (Plotly) exported as '{filename}'")
        except Exception as e:
            print(f"Warning: Could not export Plotly chart: {e}")
    elif PLOTLY_AVAILABLE and not KALEIDO_AVAILABLE:
        print("Plotly available but Kaleido not installed. Skipping Plotly image export.")

def export_compliance_charts(output_dir: str = "demo_scripts") -> None:
    """
    Export supplier compliance charts as images
    """
    # Mock data
    suppliers = ['Supplier A', 'Supplier B', 'Supplier C', 'Supplier D', 'Supplier E']
    compliance_rates = [95, 87, 78, 92, 88]
    compliance_labels = ['Compliant (90-100%)', 'Mostly Compliant (75-89%)', 'Partially Compliant (60-74%)', 'Non-Compliant (<60%)']
    compliance_values = [45, 30, 15, 10]
    colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']
    
    # Bar chart
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Bar chart
    bars = ax1.bar(suppliers, compliance_rates, color='#8884d8')
    ax1.set_title('Supplier Compliance Rates')
    ax1.set_ylabel('Compliance Rate (%)')
    ax1.set_ylim(0, 100)
    ax1.tick_params(axis='x', rotation=45)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax1.annotate(f'{height}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom')
    
    # Pie chart
    ax2.pie(compliance_values, labels=compliance_labels, colors=colors, autopct='%1.1f%%', startangle=90)
    ax2.axis('equal')
    ax2.set_title('Compliance Distribution')
    
    plt.tight_layout()
    
    # Save to file
    filename = os.path.join(output_dir, 'compliance_charts_export.png')
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"Compliance charts exported as '{filename}'")
    plt.close()

def export_carbon_chart(output_dir: str = "demo_scripts") -> None:
    """
    Export real-time carbon footprint chart as image
    """
    # Generate mock real-time data
    times = [f"{i:02d}:{j:02d}" for i in range(10, 15) for j in range(0, 60, 10)][:10]
    carbon_values = np.random.randint(70, 100, len(times))
    
    plt.figure(figsize=(12, 6))
    plt.fill_between(times, carbon_values, alpha=0.3, color='#8884d8')
    plt.plot(times, carbon_values, marker='o', linewidth=2, color='#8884d8')
    
    plt.title('Real-time Carbon Footprint')
    plt.xlabel('Time')
    plt.ylabel('Carbon Footprint (kg CO2e)')
    plt.ylim(60, 110)
    plt.xticks(rotation=45)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # Save to file
    filename = os.path.join(output_dir, 'carbon_footprint_chart_export.png')
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"Carbon footprint chart exported as '{filename}'")
    plt.close()

def main():
    parser = argparse.ArgumentParser(description="Export ESG chart data as images")
    parser.add_argument("--chart-type", choices=["esg", "compliance", "carbon", "all"], 
                        default="all", help="Type of chart to export")
    parser.add_argument("--output-dir", default="demo_scripts", 
                        help="Directory to save exported images")
    
    args = parser.parse_args()
    
    # Create output directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)
    
    print("Exporting chart data...")
    
    # Export charts based on arguments
    if args.chart_type in ["esg", "all"]:
        print("Exporting ESG Score Trend chart...")
        export_esg_score_chart(args.output_dir)
    
    if args.chart_type in ["compliance", "all"]:
        print("Exporting Supplier Compliance charts...")
        export_compliance_charts(args.output_dir)
    
    if args.chart_type in ["carbon", "all"]:
        print("Exporting Real-time Carbon Footprint chart...")
        export_carbon_chart(args.output_dir)
    
    print("\nChart export complete!")

if __name__ == "__main__":
    main()