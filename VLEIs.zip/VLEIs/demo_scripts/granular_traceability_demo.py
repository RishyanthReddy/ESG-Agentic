"""
Granular Traceability Demo

This script demonstrates the enhanced visualization agent with granular traceability
capabilities that can trace a single data point from Tier-3 supplier to final report.
"""

import sys
import os
from datetime import datetime

# Add the project root to the Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from src.state.models import AppState
from src.agents.visualization import visualization_agent


def create_sample_data():
    """Create sample agent traces and blockchain logs for demonstration."""
    print("Creating sample agent traces and blockchain logs...")
    
    agent_traces = [
        {
            "agent_id": "supplier_data_collector",
            "agent_name": "Tier-3 Supplier Data Collector",
            "agent_role": "data_collection",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [],
            "output_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "supplier_info": {
                "id": "supplier_tier3_abc_corp",
                "name": "ABC Corporation",
                "location": "Shanghai, China",
                "certifications": ["ISO 14001", "ISO 45001"],
                "timestamp": datetime.now().isoformat()
            }
        },
        {
            "agent_id": "esg_data_processor",
            "agent_name": "ESG Data Processing Agent",
            "agent_role": "data_processing",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "processed_esg_data_q1_2024",
                    "name": "Processed ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 51200,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        },
        {
            "agent_id": "carbon_calculator",
            "agent_name": "Carbon Footprint Calculator",
            "agent_role": "carbon_calculation",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [
                {
                    "id": "processed_esg_data_q1_2024",
                    "name": "Processed ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 51200,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "carbon_footprint_q1_2024",
                    "name": "Carbon Footprint Q1 2024",
                    "type": "carbon_data",
                    "size": 2048,
                    "hash": "abcd1234ef567890",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
    ]
    
    blockchain_logs = [
        {
            "transaction_hash": "0x7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b",
            "data_hash": "abcd1234ef567890",
            "account": "0x9cEa8237BC8cc063768bD85883B01b8d66a1b61b",
            "block_number": 15783246,
            "gas_used": 21000,
            "timestamp": datetime.now().isoformat()
        }
    ]
    
    return agent_traces, blockchain_logs


def display_results(result):
    """Display the visualization results in a user-friendly format."""
    print("\n" + "="*50)
    print("VISUALIZATION RESULTS")
    print("="*50)
    
    if result["workflow_status"] != "visualization_generated":
        print("❌ Visualization failed!")
        if "errors" in result:
            for error in result["errors"]:
                print(f"   Error: {error}")
        return
    
    visualization_assets = result["visualization_assets"]
    provenance_info = visualization_assets["provenance_graph"]
    
    print(f"✅ Visualization successfully generated!")
    print(f"   Graph nodes: {provenance_info['node_count']}")
    print(f"   Graph edges: {provenance_info['edge_count']}")
    
    # Check if granular traceability data is available
    if "granular_traceability" in visualization_assets:
        granular_data = visualization_assets["granular_traceability"]
        print(f"\n🔍 Granular Traceability:")
        print(f"   Data Point ID: {granular_data['data_point_id']}")
        
        path_analysis = granular_data["path_analysis"]
        if path_analysis["success"]:
            print(f"   Path tracing: SUCCESS")
            print(f"   Source: {path_analysis['source']}")
            print(f"   Target: {path_analysis['target']}")
            print(f"   Path length: {path_analysis['path_length']}")
            print(f"   Nodes in path: {path_analysis['node_count']}")
            
            print(f"\n   Path sequence:")
            for i, node in enumerate(path_analysis['path']):
                prefix = "   " + ("└── " if i == len(path_analysis['path']) - 1 else "├── ")
                print(f"{prefix}{node}")
        else:
            print(f"   Path tracing: FAILED")
            if "error" in path_analysis:
                print(f"   Error: {path_analysis['error']}")
    else:
        print("\nℹ️  Regular visualization (no specific data point traced)")
    
    # Display general highlighted path
    highlighted_path = visualization_assets["highlighted_path"]
    if highlighted_path["success"]:
        print(f"\n📍 General Highlighted Path:")
        print(f"   Source: {highlighted_path['source']}")
        print(f"   Target: {highlighted_path['target']}")
        print(f"   Path length: {highlighted_path['path_length']}")
        print(f"   Nodes in path: {highlighted_path['node_count']}")
    else:
        print(f"\n📍 General Highlighted Path: Not available")


def main():
    """Main function to run the granular traceability demo."""
    print("🔍 Granular Traceability Demo")
    print("=" * 50)
    
    # Create sample data
    agent_traces, blockchain_logs = create_sample_data()
    
    # Demo 1: Regular visualization (no specific data point)
    print("\nDemo 1: Regular Visualization")
    print("-" * 30)
    
    state1 = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs
    )
    
    result1 = visualization_agent(state1)
    display_results(result1)
    
    # Demo 2: Granular traceability for a specific data point
    print("\n\nDemo 2: Granular Traceability")
    print("-" * 30)
    
    state2 = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="raw_esg_data_q1_2024"
    )
    
    result2 = visualization_agent(state2)
    display_results(result2)
    
    # Demo 3: Granular traceability for another data point
    print("\n\nDemo 3: Granular Traceability (Different Data Point)")
    print("-" * 45)
    
    state3 = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="carbon_footprint_q1_2024"
    )
    
    result3 = visualization_agent(state3)
    display_results(result3)
    
    print("\n" + "=" * 50)
    print("Demo completed!")


if __name__ == "__main__":
    main()