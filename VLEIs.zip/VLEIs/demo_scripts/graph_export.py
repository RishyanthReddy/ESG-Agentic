#!/usr/bin/env python3
"""
Graph Export Script for ESG Intelligence Platform
This script exports graph visualizations as static images.
"""

import json
import argparse
import os
from typing import Dict, Any
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

try:
    import graphviz
    GRAPHVIZ_AVAILABLE = True
except ImportError:
    GRAPHVIZ_AVAILABLE = False
    print("Warning: Graphviz not available. Some export features will be limited.")

def generate_mock_graph_data() -> Dict[str, Any]:
    """
    Generate mock graph data for export
    """
    return {
        "nodes": [
            {"id": "1", "name": "Supplier A", "type": "supplier", "group": "suppliers", "value": 10},
            {"id": "2", "name": "Manufacturer B", "type": "manufacturer", "group": "manufacturers", "value": 20},
            {"id": "3", "name": "Distributor C", "type": "distributor", "group": "distributors", "value": 15},
            {"id": "4", "name": "Retailer D", "type": "retailer", "group": "retailers", "value": 25},
            {"id": "5", "name": "Consumer E", "type": "consumer", "group": "consumers", "value": 5},
            {"id": "6", "name": "Supplier F", "type": "supplier", "group": "suppliers", "value": 12},
            {"id": "7", "name": "Manufacturer G", "type": "manufacturer", "group": "manufacturers", "value": 18},
            {"id": "8", "name": "Distributor H", "type": "distributor", "group": "distributors", "value": 14},
        ],
        "links": [
            {"source": "1", "target": "2", "value": 100},
            {"source": "2", "target": "3", "value": 90},
            {"source": "3", "target": "4", "value": 80},
            {"source": "4", "target": "5", "value": 70},
            {"source": "6", "target": "7", "value": 95},
            {"source": "7", "target": "8", "value": 85},
            {"source": "8", "target": "4", "value": 75},
        ]
    }

def create_networkx_graph(data: Dict[str, Any]) -> nx.Graph:
    """
    Create a NetworkX graph from the provided data
    """
    G = nx.Graph()
    
    # Add nodes
    for node in data["nodes"]:
        G.add_node(
            node["id"],
            name=node["name"],
            type=node["type"],
            group=node["group"],
            value=node["value"]
        )
    
    # Add edges
    for link in data["links"]:
        G.add_edge(
            link["source"],
            link["target"],
            weight=link["value"]
        )
    
    return G

def export_graph_matplotlib(G: nx.Graph, output_file: str) -> None:
    """
    Export graph using matplotlib
    """
    plt.figure(figsize=(15, 10))
    
    # Define node colors based on group
    group_colors = {
        "suppliers": "#FF6B6B",
        "manufacturers": "#4ECDC4",
        "distributors": "#45B7D1",
        "retailers": "#96CEB4",
        "consumers": "#FFEAA7"
    }
    
    # Get node positions using spring layout
    pos = nx.spring_layout(G, seed=42, k=3, iterations=50)
    
    # Draw nodes with colors based on group
    for group, color in group_colors.items():
        nodes_in_group = [n for n, attr in G.nodes(data=True) if attr.get("group") == group]
        if nodes_in_group:
            nx.draw_networkx_nodes(
                G, pos, 
                nodelist=nodes_in_group,
                node_color=color,
                node_size=1200,
                alpha=0.8,
                label=group.capitalize()
            )
    
    # Draw edges with varying thickness based on weight
    edges = G.edges()
    weights = [G[u][v]['weight']/20 for u, v in edges]
    nx.draw_networkx_edges(
        G, pos,
        width=weights,
        alpha=0.6,
        edge_color="gray"
    )
    
    # Draw labels
    labels = {n: attr["name"] for n, attr in G.nodes(data=True)}
    nx.draw_networkx_labels(
        G, pos,
        labels=labels,
        font_size=9,
        font_weight="bold"
    )
    
    # Add legend
    legend_patches = [mpatches.Patch(color=color, label=group.capitalize()) 
                      for group, color in group_colors.items()]
    plt.legend(handles=legend_patches, loc="upper right")
    
    plt.title("Supply Chain Provenance Graph", fontsize=18, fontweight="bold")
    plt.axis("off")
    plt.tight_layout()
    
    # Save to file
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"Graph exported as '{output_file}' using matplotlib")

def export_graph_graphviz(data: Dict[str, Any], output_file: str) -> None:
    """
    Export graph using Graphviz
    """
    if not GRAPHVIZ_AVAILABLE:
        print("Graphviz not available. Skipping Graphviz export.")
        return
        
    dot = graphviz.Graph(comment='Supply Chain Provenance Graph')
    dot.attr(rankdir='TB', size='10,10')
    
    # Define node colors based on group
    group_colors = {
        "suppliers": "red",
        "manufacturers": "blue",
        "distributors": "green",
        "retailers": "orange",
        "consumers": "yellow"
    }
    
    # Add nodes
    for node in data["nodes"]:
        color = group_colors.get(node["group"], "gray")
        dot.node(
            node["id"],
            node["name"],
            color=color,
            style="filled",
            shape="box"
        )
    
    # Add edges
    for link in data["links"]:
        dot.edge(
            link["source"],
            link["target"],
            label=str(link["value"])
        )
    
    # Render and save
    output_base = output_file.replace('.png', '').replace('.svg', '')
    format_ext = output_file.split('.')[-1] if '.' in output_file else 'png'
    dot.render(output_base, format=format_ext, cleanup=True)
    print(f"Graph exported as '{output_base}.{format_ext}' using Graphviz")

def export_graph_high_res(G: nx.Graph, output_file: str) -> None:
    """
    Export high-resolution graph
    """
    plt.figure(figsize=(20, 15))
    
    # Define node colors based on group
    group_colors = {
        "suppliers": "#FF6B6B",
        "manufacturers": "#4ECDC4",
        "distributors": "#45B7D1",
        "retailers": "#96CEB4",
        "consumers": "#FFEAA7"
    }
    
    # Get node positions using spring layout
    pos = nx.spring_layout(G, seed=42, k=3, iterations=100)
    
    # Draw nodes with colors based on group
    for group, color in group_colors.items():
        nodes_in_group = [n for n, attr in G.nodes(data=True) if attr.get("group") == group]
        if nodes_in_group:
            nx.draw_networkx_nodes(
                G, pos, 
                nodelist=nodes_in_group,
                node_color=color,
                node_size=1500,
                alpha=0.9,
                label=group.capitalize()
            )
    
    # Draw edges with varying thickness based on weight
    edges = G.edges()
    weights = [G[u][v]['weight']/15 for u, v in edges]
    nx.draw_networkx_edges(
        G, pos,
        width=weights,
        alpha=0.7,
        edge_color="gray",
        arrows=True,
        arrowsize=20
    )
    
    # Draw labels
    labels = {n: attr["name"] for n, attr in G.nodes(data=True)}
    nx.draw_networkx_labels(
        G, pos,
        labels=labels,
        font_size=10,
        font_weight="bold"
    )
    
    # Add legend
    legend_patches = [mpatches.Patch(color=color, label=group.capitalize()) 
                      for group, color in group_colors.items()]
    plt.legend(handles=legend_patches, loc="upper right", fontsize=12)
    
    plt.title("Supply Chain Provenance Graph - High Resolution", fontsize=20, fontweight="bold")
    plt.axis("off")
    plt.tight_layout()
    
    # Save to file with high DPI
    plt.savefig(output_file, dpi=600, bbox_inches='tight')
    print(f"High-resolution graph exported as '{output_file}'")

def main():
    parser = argparse.ArgumentParser(description="Export graph visualizations as static images")
    parser.add_argument("--format", choices=["matplotlib", "graphviz", "high-res"], 
                        default="matplotlib", help="Export format to use")
    parser.add_argument("--output-file", default="demo_scripts/graph_export.png", 
                        help="Output file name")
    parser.add_argument("--export-all", action="store_true", 
                        help="Export in all available formats")
    
    args = parser.parse_args()
    
    print("Generating mock graph data...")
    data = generate_mock_graph_data()
    
    # Create NetworkX graph
    G = create_networkx_graph(data)
    
    # Create output directory if it doesn't exist
    output_dir = os.path.dirname(args.output_file)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    # Export based on arguments
    if args.export_all:
        print("Exporting graph in all available formats...")
        export_graph_matplotlib(G, args.output_file.replace('.png', '_matplotlib.png'))
        export_graph_high_res(G, args.output_file.replace('.png', '_high_res.png'))
        if GRAPHVIZ_AVAILABLE:
            export_graph_graphviz(data, args.output_file.replace('.png', '_graphviz'))
        else:
            print("Graphviz not available. Skipping Graphviz export.")
    else:
        if args.format == "matplotlib":
            print("Exporting graph using matplotlib...")
            export_graph_matplotlib(G, args.output_file)
        elif args.format == "graphviz":
            print("Exporting graph using Graphviz...")
            export_graph_graphviz(data, args.output_file)
        elif args.format == "high-res":
            print("Exporting high-resolution graph...")
            export_graph_high_res(G, args.output_file)
    
    print("Graph export complete!")

if __name__ == "__main__":
    main()