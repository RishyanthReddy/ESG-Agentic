#!/usr/bin/env python3
"""
Polling Client Script for ESG Intelligence Platform

This script demonstrates polling-based communication as a fallback for WebSocket
communication with the ESG platform.
"""

import requests
import json
import argparse
import sys
import time
from typing import Dict, Any
from datetime import datetime

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


def poll_endpoint(base_url: str, endpoint: str, token: str, use_rich: bool = True) -> Dict[str, Any]:
    """
    Poll a REST endpoint for updates.
    
    Args:
        base_url: Base URL for API requests
        endpoint: REST endpoint to poll
        token: Authentication token
        use_rich: Whether to use rich formatting
        
    Returns:
        Response from polling endpoint
    """
    try:
        url = f"{base_url}{endpoint}"
        headers = {"Authorization": f"Bearer {token}"}
        
        if use_rich:
            rich_print(f"[blue]Polling {url}...[/blue]")
        else:
            print(f"Polling {url}...")
            
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            if use_rich:
                rich_print(f"[red]Polling request failed with status {response.status_code}[/red]")
            else:
                print(f"Polling request failed with status {response.status_code}")
            return {"status": "error", "message": f"HTTP {response.status_code}"}
    except Exception as e:
        if use_rich:
            rich_print(f"[red]Error in polling request: {e}[/red]")
        else:
            print(f"Error in polling request: {e}")
        return {"status": "error", "message": str(e)}


def continuous_polling(base_url: str, endpoint: str, token: str, interval: int, duration: int, use_rich: bool = True):
    """
    Continuously poll an endpoint for a specified duration.
    
    Args:
        base_url: Base URL for API requests
        endpoint: REST endpoint to poll
        token: Authentication token
        interval: Polling interval in seconds
        duration: Duration to poll in seconds
        use_rich: Whether to use rich formatting
    """
    start_time = time.time()
    
    if use_rich:
        rich_print(f"[blue]Starting continuous polling for {duration} seconds (interval: {interval}s)...[/blue]")
    else:
        print(f"Starting continuous polling for {duration} seconds (interval: {interval}s)...")
        
    poll_count = 0
    
    while time.time() - start_time < duration:
        poll_count += 1
        if use_rich:
            rich_print(f"[blue]Poll #{poll_count} at {datetime.now().strftime('%H:%M:%S')}[/blue]")
        else:
            print(f"Poll #{poll_count} at {datetime.now().strftime('%H:%M:%S')}")
            
        results = poll_endpoint(base_url, endpoint, token, use_rich)
        display_polling_results(results, use_rich)
        
        # Wait before next poll
        time.sleep(interval)
        
    if use_rich:
        rich_print(f"[green]Completed {poll_count} polls in {duration} seconds[/green]")
    else:
        print(f"Completed {poll_count} polls in {duration} seconds")


def display_polling_results(results: Dict[str, Any], use_rich: bool = True):
    """
    Display polling results in a formatted way.
    
    Args:
        results: Results from polling endpoint
        use_rich: Whether to use rich formatting
    """
    if not results:
        if use_rich:
            rich_print("[red]No polling results received[/red]")
        else:
            print("No polling results received")
        return
        
    if use_rich and RICH_AVAILABLE:
        console = Console()
        
        status = results.get("status", "unknown")
        if status == "success":
            console.print("[green]✓ Poll successful[/green]")
        else:
            console.print("[red]✗ Poll failed[/red]")
            message = results.get("message", "Unknown error")
            console.print(f"[red]Error: {message}[/red]")
            return
            
        data = results.get("data", [])
        timestamp = results.get("timestamp", "N/A")
        
        console.print(f"[blue]Timestamp: {timestamp}[/blue]")
        console.print(f"[blue]Updates received: {len(data)}[/blue]")
        
        if data:
            console.print("\n[bold]Recent Updates:[/bold]")
            for i, update in enumerate(data):
                if isinstance(update, dict):
                    update_type = update.get("type", "unknown")
                    console.print(f"  {i+1}. [cyan]{update_type}[/cyan]: {update}")
                else:
                    console.print(f"  {i+1}. [cyan]{update}[/cyan]")
    else:
        status = results.get("status", "unknown")
        if status == "success":
            print("✓ Poll successful")
        else:
            print("✗ Poll failed")
            message = results.get("message", "Unknown error")
            print(f"Error: {message}")
            return
            
        data = results.get("data", [])
        timestamp = results.get("timestamp", "N/A")
        
        print(f"Timestamp: {timestamp}")
        print(f"Updates received: {len(data)}")
        
        if data:
            print("\nRecent Updates:")
            for i, update in enumerate(data):
                if isinstance(update, dict):
                    update_type = update.get("type", "unknown")
                    print(f"  {i+1}. {update_type}: {update}")
                else:
                    print(f"  {i+1}. {update}")


def main():
    parser = argparse.ArgumentParser(description="Polling client for ESG Intelligence Platform")
    parser.add_argument("--url", type=str, default="http://localhost:8000", help="API server URL")
    parser.add_argument("--token", type=str, default="demo_token", help="Authentication token")
    parser.add_argument("--endpoint", type=str, default="/api/v1/poll/dashboard", help="Polling endpoint")
    parser.add_argument("--interval", type=int, default=5, help="Polling interval in seconds")
    parser.add_argument("--duration", type=int, default=30, help="Duration to poll in seconds")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Determine if we should use rich formatting
    use_rich = RICH_AVAILABLE and not args.simple
    
    # Perform continuous polling
    continuous_polling(
        base_url=args.url,
        endpoint=args.endpoint,
        token=args.token,
        interval=args.interval,
        duration=args.duration,
        use_rich=use_rich
    )


if __name__ == "__main__":
    main()