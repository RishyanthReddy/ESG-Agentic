#!/usr/bin/env python3
"""
Live Metrics Stream Script for ESG Intelligence Platform
This script demonstrates real-time metric updates in terminal.
"""

import json
import time
import argparse
from typing import Dict, Any
from datetime import datetime
import random
import sys
import threading
from collections import deque

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.chart import Chart
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")

class MetricsStreamer:
    def __init__(self, max_history: int = 20):
        self.metrics_history = {
            'api_response_time': deque(maxlen=max_history),
            'throughput': deque(maxlen=max_history),
            'error_rate': deque(maxlen=max_history),
            'active_connections': deque(maxlen=max_history),
            'cpu_usage': deque(maxlen=max_history),
            'memory_usage': deque(maxlen=max_history)
        }
        self.alerts = deque(maxlen=10)
        self.lock = threading.Lock()
        
    def generate_metrics(self) -> Dict[str, Any]:
        """Generate mock metrics data"""
        timestamp = datetime.now()
        
        # Generate realistic mock data
        metrics = {
            'timestamp': timestamp,
            'api_response_time': max(10, random.gauss(100, 30)),  # Mean 100ms
            'throughput': max(1, random.gauss(200, 50)),          # Mean 200 req/s
            'error_rate': max(0, random.gauss(0.3, 0.2)),         # Mean 0.3%
            'active_connections': random.randint(50, 500),
            'cpu_usage': min(100, max(0, random.gauss(40, 15))),  # Mean 40%
            'memory_usage': min(100, max(0, random.gauss(55, 10)))  # Mean 55%
        }
        
        # Round values for display
        metrics['api_response_time'] = round(metrics['api_response_time'], 2)
        metrics['throughput'] = round(metrics['throughput'], 1)
        metrics['error_rate'] = round(metrics['error_rate'], 2)
        metrics['cpu_usage'] = round(metrics['cpu_usage'], 1)
        metrics['memory_usage'] = round(metrics['memory_usage'], 1)
        
        # Check for alerts
        self.check_alerts(metrics)
        
        # Add to history
        with self.lock:
            for key, value in metrics.items():
                if key != 'timestamp':
                    self.metrics_history[key].append({
                        'timestamp': timestamp,
                        'value': value
                    })
        
        return metrics
    
    def check_alerts(self, metrics: Dict[str, Any]):
        """Check for alert conditions"""
        alerts = []
        
        # API Response Time Alert
        if metrics['api_response_time'] > 300:
            alerts.append(f"CRITICAL: API response time is {metrics['api_response_time']}ms (threshold: 300ms)")
        elif metrics['api_response_time'] > 200:
            alerts.append(f"WARNING: API response time is {metrics['api_response_time']}ms (threshold: 200ms)")
        
        # Error Rate Alert
        if metrics['error_rate'] > 2.0:
            alerts.append(f"CRITICAL: Error rate is {metrics['error_rate']}% (threshold: 2%)")
        elif metrics['error_rate'] > 1.0:
            alerts.append(f"WARNING: Error rate is {metrics['error_rate']}% (threshold: 1%)")
        
        # CPU Usage Alert
        if metrics['cpu_usage'] > 90:
            alerts.append(f"CRITICAL: CPU usage is {metrics['cpu_usage']}% (threshold: 90%)")
        elif metrics['cpu_usage'] > 75:
            alerts.append(f"WARNING: CPU usage is {metrics['cpu_usage']}% (threshold: 75%)")
        
        # Memory Usage Alert
        if metrics['memory_usage'] > 90:
            alerts.append(f"CRITICAL: Memory usage is {metrics['memory_usage']}% (threshold: 90%)")
        elif metrics['memory_usage'] > 80:
            alerts.append(f"WARNING: Memory usage is {metrics['memory_usage']}% (threshold: 80%)")
        
        # Add alerts to queue
        if alerts:
            with self.lock:
                for alert in alerts:
                    self.alerts.append({
                        'timestamp': metrics['timestamp'],
                        'message': alert,
                        'severity': 'CRITICAL' if 'CRITICAL' in alert else 'WARNING'
                    })

def create_metrics_table(metrics: Dict[str, Any]) -> Table:
    """Create a rich table with current metrics"""
    if not RICH_AVAILABLE:
        # Fallback to simple text output
        print("Live Metrics Stream")
        print("=" * 30)
        print(f"Time: {metrics['timestamp'].strftime('%H:%M:%S')}")
        print(f"API Response: {metrics['api_response_time']} ms")
        print(f"Throughput: {metrics['throughput']} req/s")
        print(f"Error Rate: {metrics['error_rate']} %")
        print(f"Connections: {metrics['active_connections']}")
        print(f"CPU Usage: {metrics['cpu_usage']} %")
        print(f"Memory Usage: {metrics['memory_usage']} %")
        return None
    
    table = Table(title="ESG Intelligence Platform - Live Metrics Stream")
    table.add_column("Metric", style="cyan", no_wrap=True)
    table.add_column("Value", style="green")
    table.add_column("Status", style="yellow")
    
    # API Response Time
    response_status = "✅ Normal" if metrics['api_response_time'] < 200 else "⚠️ Warning" if metrics['api_response_time'] < 300 else "❌ Critical"
    table.add_row("API Response Time", f"{metrics['api_response_time']} ms", response_status)
    
    # Throughput
    throughput_status = "✅ Good" if metrics['throughput'] > 150 else "⚠️ Low" if metrics['throughput'] > 50 else "❌ Critical"
    table.add_row("Throughput", f"{metrics['throughput']} req/s", throughput_status)
    
    # Error Rate
    error_status = "✅ Low" if metrics['error_rate'] < 1 else "⚠️ Moderate" if metrics['error_rate'] < 2 else "❌ High"
    table.add_row("Error Rate", f"{metrics['error_rate']} %", error_status)
    
    # Active Connections
    conn_status = "✅ Normal" if metrics['active_connections'] < 400 else "⚠️ High" if metrics['active_connections'] < 500 else "❌ Critical"
    table.add_row("Active Connections", str(metrics['active_connections']), conn_status)
    
    # CPU Usage
    cpu_status = "✅ Normal" if metrics['cpu_usage'] < 75 else "⚠️ High" if metrics['cpu_usage'] < 90 else "❌ Critical"
    table.add_row("CPU Usage", f"{metrics['cpu_usage']} %", cpu_status)
    
    # Memory Usage
    memory_status = "✅ Normal" if metrics['memory_usage'] < 80 else "⚠️ High" if metrics['memory_usage'] < 90 else "❌ Critical"
    table.add_row("Memory Usage", f"{metrics['memory_usage']} %", memory_status)
    
    return table

def create_alerts_panel(streamer: MetricsStreamer) -> Panel:
    """Create a panel with recent alerts"""
    if not RICH_AVAILABLE:
        return None
    
    with streamer.lock:
        if not streamer.alerts:
            return Panel("No recent alerts", title="Alerts")
        
        alert_text = ""
        for alert in list(streamer.alerts)[-5:]:  # Show last 5 alerts
            severity_style = "bold red" if alert['severity'] == 'CRITICAL' else "bold yellow"
            time_str = alert['timestamp'].strftime('%H:%M:%S')
            alert_text += f"[{severity_style}]{time_str} - {alert['message']}[/{severity_style}]\n"
        
        return Panel(alert_text.strip(), title="Recent Alerts")

def create_trend_charts(streamer: MetricsStreamer) -> Table:
    """Create simple ASCII charts for metric trends"""
    if not RICH_AVAILABLE:
        return None
    
    chart_table = Table(title="Metric Trends (Last 20 Points)")
    chart_table.add_column("Metric", style="cyan")
    chart_table.add_column("Trend", style="green")
    
    with streamer.lock:
        for metric_name, history in streamer.metrics_history.items():
            if len(history) > 1:
                # Create a simple ASCII representation
                values = [point['value'] for point in list(history)[-20:]]
                if values:
                    min_val, max_val = min(values), max(values)
                    range_val = max_val - min_val if max_val != min_val else 1
                    
                    # Create simple bar chart representation
                    bars = []
                    for val in values[-10:]:  # Last 10 points
                        height = int(((val - min_val) / range_val) * 5)  # Scale to 0-5
                        bars.append("█" * height if height > 0 else "▁")
                    
                    trend = "".join(bars)
                    chart_table.add_row(metric_name.replace('_', ' ').title(), trend)
    
    return chart_table

def metrics_update_worker(streamer: MetricsStreamer, interval: float, stop_event: threading.Event):
    """Worker thread to update metrics"""
    while not stop_event.is_set():
        streamer.generate_metrics()
        time.sleep(interval)

def main():
    parser = argparse.ArgumentParser(description="Stream ESG platform metrics in real-time")
    parser.add_argument("--interval", type=float, default=1.0, help="Update interval in seconds (default: 1.0)")
    parser.add_argument("--duration", type=int, default=0, help="Run duration in seconds (0 for infinite, default: 0)")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    streamer = MetricsStreamer()
    
    if not RICH_AVAILABLE or args.simple:
        # Simple text mode
        print("ESG Intelligence Platform - Live Metrics Stream")
        print("=" * 50)
        
        start_time = time.time()
        try:
            while True:
                metrics = streamer.generate_metrics()
                print(f"\n[{metrics['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}]")
                print("-" * 30)
                create_metrics_table(metrics)
                
                if args.duration > 0 and (time.time() - start_time) >= args.duration:
                    break
                    
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n\nLive metrics stream stopped.")
            return
    else:
        # Rich mode with live updates
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Live Metrics Stream[/bold blue]"))
        
        # Start metrics update thread
        stop_event = threading.Event()
        update_thread = threading.Thread(target=metrics_update_worker, args=(streamer, args.interval, stop_event))
        update_thread.start()
        
        start_time = time.time()
        try:
            with Live(console=console, refresh_per_second=2) as live:
                while True:
                    # Get current metrics
                    with streamer.lock:
                        # Get the latest metric values
                        current_metrics = {}
                        for metric_name, history in streamer.metrics_history.items():
                            if history:
                                current_metrics[metric_name] = history[-1]['value']
                        current_metrics['timestamp'] = datetime.now()
                    
                    # Create display components
                    metrics_table = create_metrics_table(current_metrics)
                    alerts_panel = create_alerts_panel(streamer)
                    trend_charts = create_trend_charts(streamer)
                    
                    # Create layout
                    if metrics_table and alerts_panel and trend_charts:
                        layout = Layout()
                        layout.split_column(
                            Layout(metrics_table, size=9),
                            Layout(alerts_panel, size=8),
                            Layout(trend_charts, size=8)
                        )
                        live.update(layout)
                    elif metrics_table:
                        live.update(metrics_table)
                    
                    if args.duration > 0 and (time.time() - start_time) >= args.duration:
                        break
                        
                    time.sleep(0.5)  # Update display more frequently than metrics generation
        except KeyboardInterrupt:
            console.print("\n[bold red]Live metrics stream stopped.[/bold red]")
        finally:
            # Stop the update thread
            stop_event.set()
            update_thread.join()

if __name__ == "__main__":
    main()