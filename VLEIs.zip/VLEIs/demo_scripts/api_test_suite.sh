#!/bin/bash

# API Test Suite for ESG Intelligence Platform
# This script tests all available API endpoints

echo "ESG Intelligence Platform - API Test Suite"
echo "=========================================="

# Check if jq is installed
if ! command -v jq &> /dev/null
then
    echo "jq is required but not installed. Please install jq to run this script."
    exit 1
fi

# Test counter
TOTAL_TESTS=0
PASSED_TESTS=0

# Function to run a test
run_test() {
    local test_name=$1
    local curl_cmd=$2
    local expected_status=$3
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    echo -n "Test $TOTAL_TESTS: $test_name... "
    
    # Execute the curl command and capture the HTTP status code
    local status_code=$(eval "$curl_cmd -o /dev/null -s -w \"%{http_code}\"")
    
    if [ "$status_code" -eq "$expected_status" ]; then
        echo "PASSED"
        PASSED_TESTS=$((PASSED_TESTS + 1))
    else
        echo "FAILED (HTTP $status_code)"
    fi
}

# Test 1: Root endpoint
run_test "Root endpoint accessibility" "curl -X GET http://localhost:8000/" 200

# Test 2: Health endpoint
run_test "Health endpoint accessibility" "curl -X GET http://localhost:8000/health" 200

# Test 3: JSON ingestion with valid data
run_test "JSON ingestion with valid data" "curl -X POST http://localhost:8000/ingest/json -H 'Content-Type: application/json' -d '{\"supplier_data\": {}}'" 200

# Test 4: JSON ingestion with invalid data
run_test "JSON ingestion with invalid data" "curl -X POST http://localhost:8000/ingest/json -H 'Content-Type: application/json' -d 'invalid json'" 422

# Test 5: File upload endpoint accessibility
run_test "File upload endpoint accessibility" "curl -X POST http://localhost:8000/ingest/file -F 'file=@/dev/null'" 200

# Test 6: Verification endpoint with non-existent report
run_test "Verification of non-existent report" "curl -X GET http://localhost:8000/verify/non-existent-id" 404

# Test 7: OPTIONS request for CORS
run_test "CORS preflight request" "curl -X OPTIONS http://localhost:8000/ -H 'Access-Control-Request-Method: GET'" 200

# Summary
echo ""
echo "Test Summary:"
echo "============="
echo "Total tests: $TOTAL_TESTS"
echo "Passed: $PASSED_TESTS"
echo "Failed: $((TOTAL_TESTS - PASSED_TESTS))"

if [ $PASSED_TESTS -eq $TOTAL_TESTS ]; then
    echo "All tests passed! ✅"
    exit 0
else
    echo "Some tests failed! ❌"
    exit 1
fi