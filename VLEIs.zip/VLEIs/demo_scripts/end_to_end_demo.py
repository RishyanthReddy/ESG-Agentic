#!/usr/bin/env python3
"""
End-to-End Demo Script for ESG Intelligence Platform
This script replicates the entire user journey via API calls.
"""

import json
import time
import argparse
import subprocess
import sys
import requests
from datetime import datetime
from typing import Dict, Any

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")

class EndToEndDemo:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.console = Console() if RICH_AVAILABLE else None
        
    def make_api_request(self, method: str, endpoint: str, data: Dict = None) -> Dict[str, Any]:
        """Make an API request and return the response"""
        url = f"{self.base_url}{endpoint}"
        try:
            if method.upper() == "GET":
                response = requests.get(url, timeout=30)
            elif method.upper() == "POST":
                response = requests.post(url, json=data, timeout=30)
            elif method.upper() == "PUT":
                response = requests.put(url, json=data, timeout=30)
            elif method.upper() == "DELETE":
                response = requests.delete(url, timeout=30)
            else:
                return {"success": False, "error": f"Unsupported method: {method}"}
            
            if response.status_code < 300:
                return {"success": True, "data": response.json() if response.content else None}
            else:
                return {"success": False, "error": f"HTTP {response.status_code}: {response.text}"}
        except requests.exceptions.RequestException as e:
            return {"success": False, "error": str(e)}
    
    def step_1_system_check(self):
        """Step 1: System health check"""
        if not RICH_AVAILABLE:
            print("Step 1: System Health Check")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 1: System Health Check[/bold]")
            self.console.print("-" * 30)
        
        # Check system health
        result = self.make_api_request("GET", "/health")
        if result["success"]:
            status = result["data"].get("status", "unknown")
            if not RICH_AVAILABLE:
                print(f"System Status: {status}")
                print("✅ System check passed")
            else:
                self.console.print(f"System Status: [green]{status}[/green]")
                self.console.print("[green]✅ System check passed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ System check failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ System check failed:[/red] {result['error']}")
        
        print()
    
    def step_2_data_ingestion(self):
        """Step 2: Data ingestion"""
        if not RICH_AVAILABLE:
            print("Step 2: Data Ingestion")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 2: Data Ingestion[/bold]")
            self.console.print("-" * 30)
        
        # Ingest supplier data
        if not RICH_AVAILABLE:
            print("Ingesting supplier data...")
        else:
            self.console.print("Ingesting supplier data...")
            
        result = self.make_api_request("POST", "/api/v1/suppliers/ingest", {
            "source": "supplier_api",
            "limit": 100
        })
        
        if result["success"]:
            if not RICH_AVAILABLE:
                print("✅ Supplier data ingestion completed")
            else:
                self.console.print("[green]✅ Supplier data ingestion completed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ Supplier data ingestion failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ Supplier data ingestion failed:[/red] {result['error']}")
        
        # Ingest compliance data
        if not RICH_AVAILABLE:
            print("Ingesting compliance data...")
        else:
            self.console.print("Ingesting compliance data...")
            
        result = self.make_api_request("POST", "/api/v1/compliance/ingest", {
            "source": "compliance_db",
            "limit": 100
        })
        
        if result["success"]:
            if not RICH_AVAILABLE:
                print("✅ Compliance data ingestion completed")
            else:
                self.console.print("[green]✅ Compliance data ingestion completed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ Compliance data ingestion failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ Compliance data ingestion failed:[/red] {result['error']}")
        
        # Ingest carbon data
        if not RICH_AVAILABLE:
            print("Ingesting carbon footprint data...")
        else:
            self.console.print("Ingesting carbon footprint data...")
            
        result = self.make_api_request("POST", "/api/v1/carbon/ingest", {
            "source": "emissions_api",
            "limit": 100
        })
        
        if result["success"]:
            if not RICH_AVAILABLE:
                print("✅ Carbon data ingestion completed")
            else:
                self.console.print("[green]✅ Carbon data ingestion completed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ Carbon data ingestion failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ Carbon data ingestion failed:[/red] {result['error']}")
        
        print()
    
    def step_3_data_processing(self):
        """Step 3: Data processing"""
        if not RICH_AVAILABLE:
            print("Step 3: Data Processing")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 3: Data Processing[/bold]")
            self.console.print("-" * 30)
        
        # Calculate ESG scores
        if not RICH_AVAILABLE:
            print("Calculating ESG scores...")
        else:
            self.console.print("Calculating ESG scores...")
            
        result = self.make_api_request("POST", "/api/v1/esg/calculate", {
            "batch_id": f"batch_{int(time.time())}"
        })
        
        if result["success"]:
            if not RICH_AVAILABLE:
                print("✅ ESG score calculation completed")
            else:
                self.console.print("[green]✅ ESG score calculation completed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ ESG score calculation failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ ESG score calculation failed:[/red] {result['error']}")
        
        # Generate reports
        if not RICH_AVAILABLE:
            print("Generating compliance reports...")
        else:
            self.console.print("Generating compliance reports...")
            
        result = self.make_api_request("POST", "/api/v1/reports/generate", {
            "report_type": "compliance",
            "format": "json"
        })
        
        if result["success"]:
            if not RICH_AVAILABLE:
                print("✅ Compliance report generation completed")
            else:
                self.console.print("[green]✅ Compliance report generation completed[/green]")
        else:
            if not RICH_AVAILABLE:
                print(f"❌ Compliance report generation failed: {result['error']}")
            else:
                self.console.print(f"[red]❌ Compliance report generation failed:[/red] {result['error']}")
        
        print()
    
    def step_4_data_validation(self):
        """Step 4: Data validation"""
        if not RICH_AVAILABLE:
            print("Step 4: Data Validation")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 4: Data Validation[/bold]")
            self.console.print("-" * 30)
        
        # Run integrity checker
        if not RICH_AVAILABLE:
            print("Running data integrity checks...")
        else:
            self.console.print("Running data integrity checks...")
            
        try:
            result = subprocess.run(
                ["bash", "demo_scripts/integrity_checker.sh"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                if not RICH_AVAILABLE:
                    print("✅ Data integrity validation passed")
                else:
                    self.console.print("[green]✅ Data integrity validation passed[/green]")
            else:
                if not RICH_AVAILABLE:
                    print("❌ Data integrity validation failed")
                    print(result.stdout)
                else:
                    self.console.print("[red]❌ Data integrity validation failed[/red]")
                    self.console.print(Panel(result.stdout, title="Validation Output"))
        except Exception as e:
            if not RICH_AVAILABLE:
                print(f"❌ Data integrity validation error: {e}")
            else:
                self.console.print(f"[red]❌ Data integrity validation error:[/red] {e}")
        
        print()
    
    def step_5_visualization(self):
        """Step 5: Visualization generation"""
        if not RICH_AVAILABLE:
            print("Step 5: Visualization Generation")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 5: Visualization Generation[/bold]")
            self.console.print("-" * 30)
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            # Generate metrics display
            task1 = progress.add_task("Generating metrics display...", total=None)
            try:
                result = subprocess.run(
                    ["python3", "demo_scripts/metrics_display.py"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    progress.update(task1, completed=True)
                    if not RICH_AVAILABLE:
                        print("✅ Metrics display generated")
                    else:
                        self.console.print("[green]✅ Metrics display generated[/green]")
                else:
                    progress.update(task1, completed=True)
                    if not RICH_AVAILABLE:
                        print("❌ Metrics display generation failed")
                    else:
                        self.console.print("[red]❌ Metrics display generation failed[/red]")
            except Exception as e:
                progress.update(task1, completed=True)
                if not RICH_AVAILABLE:
                    print(f"❌ Metrics display generation error: {e}")
                else:
                    self.console.print(f"[red]❌ Metrics display generation error:[/red] {e}")
            
            # Export charts
            task2 = progress.add_task("Exporting charts...", total=None)
            try:
                result = subprocess.run(
                    ["python3", "demo_scripts/chart_data_export.py", "--export-all"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    progress.update(task2, completed=True)
                    if not RICH_AVAILABLE:
                        print("✅ Charts exported")
                    else:
                        self.console.print("[green]✅ Charts exported[/green]")
                else:
                    progress.update(task2, completed=True)
                    if not RICH_AVAILABLE:
                        print("❌ Chart export failed")
                    else:
                        self.console.print("[red]❌ Chart export failed[/red]")
            except Exception as e:
                progress.update(task2, completed=True)
                if not RICH_AVAILABLE:
                    print(f"❌ Chart export error: {e}")
                else:
                    self.console.print(f"[red]❌ Chart export error:[/red] {e}")
            
            # Generate graph visualization
            task3 = progress.add_task("Generating graph visualization...", total=None)
            try:
                result = subprocess.run(
                    ["python3", "demo_scripts/graph_visualizer.py"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    progress.update(task3, completed=True)
                    if not RICH_AVAILABLE:
                        print("✅ Graph visualization generated")
                    else:
                        self.console.print("[green]✅ Graph visualization generated[/green]")
                else:
                    progress.update(task3, completed=True)
                    if not RICH_AVAILABLE:
                        print("❌ Graph visualization failed")
                    else:
                        self.console.print("[red]❌ Graph visualization failed[/red]")
            except Exception as e:
                progress.update(task3, completed=True)
                if not RICH_AVAILABLE:
                    print(f"❌ Graph visualization error: {e}")
                else:
                    self.console.print(f"[red]❌ Graph visualization error:[/red] {e}")
        
        print()
    
    def step_6_dashboard_update(self):
        """Step 6: Dashboard update"""
        if not RICH_AVAILABLE:
            print("Step 6: Dashboard Update")
            print("-" * 30)
        else:
            self.console.print("[bold]Step 6: Dashboard Update[/bold]")
            self.console.print("-" * 30)
        
        # In a real implementation, this would update the dashboard state
        if not RICH_AVAILABLE:
            print("Updating dashboard with new data...")
            print("✅ Dashboard updated with latest metrics and visualizations")
            print("✅ Real-time data streams activated")
        else:
            self.console.print("Updating dashboard with new data...")
            self.console.print("[green]✅ Dashboard updated with latest metrics and visualizations[/green]")
            self.console.print("[green]✅ Real-time data streams activated[/green]")
        
        print()
    
    def run_demo(self):
        """Run the complete end-to-end demo"""
        if not RICH_AVAILABLE:
            print("ESG Intelligence Platform - End-to-End Demo")
            print("=" * 50)
            print()
        else:
            self.console.print(Panel("[bold blue]ESG Intelligence Platform - End-to-End Demo[/bold blue]"))
        
        # Run all steps
        steps = [
            self.step_1_system_check,
            self.step_2_data_ingestion,
            self.step_3_data_processing,
            self.step_4_data_validation,
            self.step_5_visualization,
            self.step_6_dashboard_update
        ]
        
        for step in steps:
            step()
            time.sleep(1)  # Pause between steps
        
        # Summary
        if not RICH_AVAILABLE:
            print("End-to-End Demo Summary")
            print("-" * 30)
            print("✅ System check completed")
            print("✅ Data ingestion completed")
            print("✅ Data processing completed")
            print("✅ Data validation completed")
            print("✅ Visualizations generated")
            print("✅ Dashboard updated")
            print()
            print("🎉 End-to-end demo completed successfully!")
            print()
            print("You can now view the updated dashboard at: http://localhost:3000")
        else:
            self.console.print("[bold]End-to-End Demo Summary[/bold]")
            self.console.print("-" * 30)
            self.console.print("[green]✅ System check completed[/green]")
            self.console.print("[green]✅ Data ingestion completed[/green]")
            self.console.print("[green]✅ Data processing completed[/green]")
            self.console.print("[green]✅ Data validation completed[/green]")
            self.console.print("[green]✅ Visualizations generated[/green]")
            self.console.print("[green]✅ Dashboard updated[/green]")
            self.console.print("")
            self.console.print("[bold green]🎉 End-to-end demo completed successfully![/bold green]")
            self.console.print("")
            self.console.print("You can now view the updated dashboard at: [link]http://localhost:3000[/link]")

def main():
    parser = argparse.ArgumentParser(description="Run end-to-end demo of ESG Intelligence Platform")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    parser.add_argument("--base-url", default="http://localhost:8000", help="Base URL for API calls")
    
    args = parser.parse_args()
    
    # Force simple mode if rich is not available or explicitly requested
    use_rich = RICH_AVAILABLE and not args.simple
    
    demo = EndToEndDemo(args.base_url)
    
    try:
        demo.run_demo()
    except KeyboardInterrupt:
        print("\n\nEnd-to-end demo stopped.")
    except Exception as e:
        print(f"Error during demo: {e}")

if __name__ == "__main__":
    main()