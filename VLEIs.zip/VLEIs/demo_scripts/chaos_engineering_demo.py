 m #!/usr/bin/env python3
"""
Demo script for the Chaos Engineering Framework

This script demonstrates how to use the chaos engineering framework to test
system resilience against various failure scenarios.
"""

import sys
import os
import time
import random
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Load environment variables from .env file
load_dotenv()

from tests.chaos import (
    init_chaos_middleware, simulate_climatiq_api_failure,
    simulate_infura_api_failure, simulate_network_latency,
    simulate_bandwidth_limit, simulate_connection_failure,
    reset_chaos
)
from fastapi import FastAPI
from fastapi.testclient import TestClient


def demo_chaos_framework():
    """Demonstrate the chaos engineering framework capabilities"""
    print("Chaos Engineering Framework Demo")
    print("=" * 50)
    
    # Create a test FastAPI app
    app = FastAPI()
    
    @app.get("/api/health")
    async def health_check():
        """Simple health check endpoint"""
        return {"status": "healthy"}
    
    @app.post("/estimate")
    async def climatiq_estimate():
        """Mock Climatiq estimate endpoint"""
        return {
            "success": True,
            "co2e": 100.5,
            "co2e_unit": "kg"
        }
    
    @app.get("/v3/blockchain")
    async def infura_endpoint():
        """Mock Infura endpoint"""
        return {
            "result": "0x1234567890abcdef",
            "status": "success"
        }
    
    # Initialize chaos middleware
    chaos_middleware = init_chaos_middleware(app)
    app.add_middleware(lambda app: type('ChaosMiddlewareWrapper', (), {
        '__init__': lambda self, app: setattr(self, 'app', app),
        '__call__': lambda self, scope, receive, send: chaos_middleware.dispatch(
            type('Request', (), {'url': type('URL', (), {'path': scope.get('path', '/')})})(),
            lambda req: self.app(scope, receive, send)
        )
    })(app))
    
    # Create test client
    client = TestClient(app)
    
    print("\n1. Normal Operation (No Chaos)")
    print("-" * 30)
    
    # Test normal operation
    response = client.get("/api/health")
    print(f"Health check: {response.status_code} - {response.json()}")
    
    response = client.post("/estimate")
    print(f"Climatiq estimate: {response.status_code} - {response.json()}")
    
    response = client.get("/v3/blockchain")
    print(f"Infura endpoint: {response.status_code} - {response.json()}")
    
    print("\n2. Simulating Climatiq API 503 Errors (100% failure rate)")
    print("-" * 30)
    
    # Configure chaos: 100% probability of 503 errors for Climatiq API
    simulate_climatiq_api_failure(1.0, 503)
    
    response = client.post("/estimate")
    print(f"Climatiq estimate with chaos: {response.status_code} - {response.text}")
    
    # Reset chaos for next test
    reset_chaos()
    
    print("\n3. Simulating Infura API 500 Errors (100% failure rate)")
    print("-" * 30)
    
    # Configure chaos: 100% probability of 500 errors for Infura API
    simulate_infura_api_failure(1.0, 500)
    
    response = client.get("/v3/blockchain")
    print(f"Infura endpoint with chaos: {response.status_code} - {response.text}")
    
    # Reset chaos for next test
    reset_chaos()
    
    print("\n4. Partial Failure Scenarios (50% failure rate)")
    print("-" * 30)
    
    # Configure chaos: 50% probability of 503 errors for Climatiq API
    simulate_climatiq_api_failure(0.5, 503)
    
    # Make multiple requests to show partial failures
    print("Making 10 requests to Climatiq API:")
    failed_count = 0
    success_count = 0
    
    for i in range(10):
        response = client.post("/estimate")
        if response.status_code == 503:
            failed_count += 1
            print(f"  Request {i+1}: FAILED (503) - {response.text}")
        else:
            success_count += 1
            print(f"  Request {i+1}: SUCCESS ({response.status_code}) - {response.json()}")
    
    print(f"\nResults: {success_count} successful, {failed_count} failed")
    
    # Reset chaos for next test
    reset_chaos()
    
    print("\n5. Network Condition Simulation")
    print("-" * 30)
    
    # These don't actually affect the test client but demonstrate the API
    print("Simulating network conditions (demonstration only):")
    print("  - Adding 200ms latency with 20ms jitter")
    print("  - Limiting bandwidth to 512kbps")
    print("  - Simulating 30% connection failures")
    
    print("\n6. System Recovery")
    print("-" * 30)
    
    # Configure chaos
    simulate_climatiq_api_failure(1.0, 503)
    
    response = client.post("/estimate")
    print(f"With chaos: {response.status_code} - {response.text}")
    
    # Reset chaos
    reset_chaos()
    
    response = client.post("/estimate")
    print(f"After recovery: {response.status_code} - {response.json()}")
    
    print("\n" + "=" * 50)
    print("Demo completed successfully!")
    print("The chaos engineering framework is ready for resilience testing.")


if __name__ == "__main__":
    demo_chaos_framework()