#!/usr/bin/env python3
"""
Connection Manager Script for ESG Intelligence Platform

This script demonstrates connection management with automatic reconnection
and fallback mechanisms for both WebSocket and polling communication.
"""

import asyncio
import websockets
import requests
import json
import argparse
import sys
import time
from typing import Dict, Any, Callable
from datetime import datetime
import random

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


class ConnectionManager:
    """
    Manages connections with automatic reconnection and fallback mechanisms.
    """
    
    def __init__(self, base_url: str = "ws://localhost:8000", token: str = "demo_token"):
        """
        Initialize the connection manager.
        
        Args:
            base_url: Base URL for connections
            token: Authentication token
        """
        self.base_ws_url = base_url.rstrip('/')
        self.base_http_url = base_url.replace('ws://', 'http://').replace('wss://', 'https://')
        self.token = token
        self.websocket = None
        self.connected = False
        self.use_websocket = True
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        self.reconnect_delay = 1  # seconds
        
    def set_connection_mode(self, use_websocket: bool):
        """
        Set the connection mode (WebSocket or polling).
        
        Args:
            use_websocket: True to use WebSocket, False to use polling
        """
        self.use_websocket = use_websocket
        if RICH_AVAILABLE:
            mode = "WebSocket" if use_websocket else "Polling"
            rich_print(f"[blue]Connection mode set to: {mode}[/blue]")
        else:
            mode = "WebSocket" if use_websocket else "Polling"
            print(f"Connection mode set to: {mode}")
            
    async def connect_websocket(self, endpoint: str = "/api/v1/ws/dashboard") -> bool:
        """
        Connect to the WebSocket server.
        
        Args:
            endpoint: WebSocket endpoint to connect to
            
        Returns:
            True if connected successfully, False otherwise
        """
        try:
            url = f"{self.base_ws_url}{endpoint}"
            if "?" not in url and self.token:
                url += f"?token={self.token}"
            elif self.token:
                url += f"&token={self.token}"
                
            self.websocket = await websockets.connect(url, timeout=10)
            self.connected = True
            self.reconnect_attempts = 0  # Reset on successful connection
            
            if RICH_AVAILABLE:
                rich_print(f"[green]✓ Connected to WebSocket at {url}[/green]")
            else:
                print(f"✓ Connected to WebSocket at {url}")
                
            return True
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]✗ Failed to connect to WebSocket: {e}[/red]")
            else:
                print(f"✗ Failed to connect to WebSocket: {e}")
                
            self.connected = False
            return False
            
    def poll_endpoint(self, endpoint: str = "/api/v1/poll/dashboard") -> Dict[str, Any]:
        """
        Poll a REST endpoint.
        
        Args:
            endpoint: REST endpoint to poll
            
        Returns:
            Response from polling endpoint
        """
        try:
            url = f"{self.base_http_url}{endpoint}"
            headers = {"Authorization": f"Bearer {self.token}"}
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                if RICH_AVAILABLE:
                    rich_print(f"[red]Polling failed with status {response.status_code}[/red]")
                else:
                    print(f"Polling failed with status {response.status_code}")
                return {"status": "error", "message": f"HTTP {response.status_code}"}
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]Error in polling request: {e}[/red]")
            else:
                print(f"Error in polling request: {e}")
            return {"status": "error", "message": str(e)}
            
    async def disconnect(self):
        """
        Disconnect from the current connection.
        """
        if self.websocket and self.connected:
            await self.websocket.close()
            self.connected = False
            if RICH_AVAILABLE:
                rich_print("[yellow]Disconnected from WebSocket server[/yellow]")
            else:
                print("Disconnected from WebSocket server")
                
    async def send_message(self, message: str) -> bool:
        """
        Send a message through the current connection.
        
        Args:
            message: Message to send
            
        Returns:
            True if sent successfully, False otherwise
        """
        if self.use_websocket and self.connected:
            try:
                await self.websocket.send(message)
                return True
            except Exception as e:
                if RICH_AVAILABLE:
                    rich_print(f"[red]Error sending WebSocket message: {e}[/red]")
                else:
                    print(f"Error sending WebSocket message: {e}")
                return False
        else:
            # For polling, we can't send messages directly
            # In a real implementation, this would be an HTTP POST
            if RICH_AVAILABLE:
                rich_print("[yellow]Polling mode: Cannot send messages directly[/yellow]")
            else:
                print("Polling mode: Cannot send messages directly")
            return False
            
    async def receive_message(self) -> str:
        """
        Receive a message from the current connection.
        
        Returns:
            Received message
        """
        if self.use_websocket and self.connected:
            try:
                message = await self.websocket.recv()
                return message
            except Exception as e:
                if RICH_AVAILABLE:
                    rich_print(f"[red]Error receiving WebSocket message: {e}[/red]")
                else:
                    print(f"Error receiving WebSocket message: {e}")
                return ""
        else:
            # For polling, we return empty string as we use a different mechanism
            return ""
            
    async def reconnect(self) -> bool:
        """
        Attempt to reconnect to the server.
        
        Returns:
            True if reconnected successfully, False otherwise
        """
        if self.reconnect_attempts >= self.max_reconnect_attempts:
            if RICH_AVAILABLE:
                rich_print(f"[red]Maximum reconnection attempts ({self.max_reconnect_attempts}) reached[/red]")
            else:
                print(f"Maximum reconnection attempts ({self.max_reconnect_attempts}) reached")
            return False
            
        self.reconnect_attempts += 1
        delay = min(self.reconnect_delay * (2 ** (self.reconnect_attempts - 1)), 30)  # Exponential backoff, max 30s
        
        if RICH_AVAILABLE:
            rich_print(f"[yellow]Reconnection attempt {self.reconnect_attempts}/{self.max_reconnect_attempts} in {delay}s[/yellow]")
        else:
            print(f"Reconnection attempt {self.reconnect_attempts}/{self.max_reconnect_attempts} in {delay}s")
            
        await asyncio.sleep(delay)
        
        if self.use_websocket:
            return await self.connect_websocket()
        else:
            # For polling, we don't need to establish a persistent connection
            return True
            
    async def run_with_fallback(self, 
                               websocket_endpoint: str = "/api/v1/ws/dashboard",
                               polling_endpoint: str = "/api/v1/poll/dashboard",
                               message_handler: Callable[[str], None] = None,
                               polling_interval: int = 5):
        """
        Run the connection with automatic fallback and reconnection.
        
        Args:
            websocket_endpoint: WebSocket endpoint
            polling_endpoint: Polling endpoint
            message_handler: Function to handle received messages
            polling_interval: Interval for polling in seconds
        """
        if self.use_websocket:
            # Try to connect via WebSocket
            connected = await self.connect_websocket(websocket_endpoint)
            
            if not connected:
                if RICH_AVAILABLE:
                    rich_print("[yellow]Falling back to polling mode[/yellow]")
                else:
                    print("Falling back to polling mode")
                self.set_connection_mode(False)
            else:
                # WebSocket connection successful, listen for messages
                try:
                    while True:
                        try:
                            message = await self.receive_message()
                            if message and message_handler:
                                message_handler(message)
                        except websockets.exceptions.ConnectionClosed:
                            if RICH_AVAILABLE:
                                rich_print("[red]WebSocket connection closed[/red]")
                            else:
                                print("WebSocket connection closed")
                                
                            # Try to reconnect
                            reconnected = await self.reconnect()
                            if not reconnected:
                                if RICH_AVAILABLE:
                                    rich_print("[yellow]Falling back to polling mode[/yellow]")
                                else:
                                    print("Falling back to polling mode")
                                self.set_connection_mode(False)
                                break
                except Exception as e:
                    if RICH_AVAILABLE:
                        rich_print(f"[red]Error in WebSocket connection: {e}[/red]")
                    else:
                        print(f"Error in WebSocket connection: {e}")
                        
        # Polling mode
        if not self.use_websocket:
            if RICH_AVAILABLE:
                rich_print("[blue]Running in polling mode[/blue]")
            else:
                print("Running in polling mode")
                
            while True:
                try:
                    results = self.poll_endpoint(polling_endpoint)
                    if results.get("status") == "success" and message_handler:
                        # Convert polling results to message format
                        message = json.dumps(results)
                        message_handler(message)
                    elif results.get("status") != "success":
                        if RICH_AVAILABLE:
                            rich_print(f"[red]Polling error: {results.get('message', 'Unknown error')}[/red]")
                        else:
                            print(f"Polling error: {results.get('message', 'Unknown error')}")
                            
                    await asyncio.sleep(polling_interval)
                except Exception as e:
                    if RICH_AVAILABLE:
                        rich_print(f"[red]Error in polling: {e}[/red]")
                    else:
                        print(f"Error in polling: {e}")
                    await asyncio.sleep(polling_interval)


def default_message_handler(message: str):
    """
    Default message handler for displaying received messages.
    
    Args:
        message: Received message as JSON string
    """
    try:
        data = json.loads(message)
        if RICH_AVAILABLE:
            rich_print(f"[cyan]Received update: {data}[/cyan]")
        else:
            print(f"Received update: {data}")
    except json.JSONDecodeError:
        if RICH_AVAILABLE:
            rich_print(f"[cyan]Received message: {message}[/cyan]")
        else:
            print(f"Received message: {message}")


async def simulate_updates(manager: ConnectionManager, duration: int = 30):
    """
    Simulate sending updates through the connection.
    
    Args:
        manager: Connection manager instance
        duration: Duration to simulate updates (seconds)
    """
    start_time = time.time()
    
    # Sample update messages
    updates = [
        {"type": "esg_score_update", "supplier": "S001", "score": 85, "change": "+2"},
        {"type": "compliance_alert", "supplier": "S002", "issue": "Documentation missing", "priority": "high"},
        {"type": "carbon_emission", "value": 120.5, "unit": "kg CO2", "location": "Factory A"},
        {"type": "verification_complete", "supplier": "S003", "result": "passed", "certificate": "ISO 14001"},
        {"type": "new_supplier", "name": "Eco Materials Ltd", "location": "Germany", "esg_score": 92}
    ]
    
    update_index = 0
    
    if RICH_AVAILABLE:
        rich_print(f"[blue]Simulating updates for {duration} seconds...[/blue]")
    else:
        print(f"Simulating updates for {duration} seconds...")
        
    while time.time() - start_time < duration:
        update = updates[update_index % len(updates)].copy()
        update["timestamp"] = datetime.now().isoformat()
        update["id"] = random.randint(1000, 9999)
        
        success = await manager.send_message(json.dumps(update))
        if success:
            if RICH_AVAILABLE:
                rich_print(f"[green]Sent update #{update['id']}: {update['type']}[/green]")
            else:
                print(f"Sent update #{update['id']}: {update['type']}")
        else:
            if RICH_AVAILABLE:
                rich_print(f"[yellow]Could not send update #{update['id']} (connection mode: {'WebSocket' if manager.use_websocket else 'Polling'})[/yellow]")
            else:
                print(f"Could not send update #{update['id']} (connection mode: {'WebSocket' if manager.use_websocket else 'Polling'})")
                
        await asyncio.sleep(3)
        update_index += 1


async def main():
    parser = argparse.ArgumentParser(description="Connection manager for ESG Intelligence Platform")
    parser.add_argument("--url", type=str, default="ws://localhost:8000", help="Server URL")
    parser.add_argument("--token", type=str, default="demo_token", help="Authentication token")
    parser.add_argument("--mode", type=str, choices=["websocket", "polling", "auto"], default="auto",
                        help="Connection mode: websocket, polling, or auto (with fallback)")
    parser.add_argument("--duration", type=int, default=60, help="Duration to run (seconds)")
    parser.add_argument("--simulate", action="store_true", help="Simulate sending updates")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Determine if we should use rich formatting
    global RICH_AVAILABLE
    use_rich = RICH_AVAILABLE and not args.simple
    
    if not use_rich:
        RICH_AVAILABLE = False
    
    # Create connection manager
    manager = ConnectionManager(base_url=args.url, token=args.token)
    
    # Set connection mode
    if args.mode == "websocket":
        manager.set_connection_mode(True)
    elif args.mode == "polling":
        manager.set_connection_mode(False)
    # For "auto" mode, the manager will automatically choose and fallback
    
    try:
        if args.simulate:
            # Run simulation and connection manager concurrently
            await asyncio.gather(
                simulate_updates(manager, args.duration),
                manager.run_with_fallback(message_handler=default_message_handler)
            )
        else:
            # Run only the connection manager
            await manager.run_with_fallback(message_handler=default_message_handler)
    except KeyboardInterrupt:
        if use_rich:
            rich_print("[yellow]Interrupted by user[/yellow]")
        else:
            print("Interrupted by user")
    finally:
        await manager.disconnect()


if __name__ == "__main__":
    asyncio.run(main())