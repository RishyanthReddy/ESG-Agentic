#!/usr/bin/env python3
"""
State Simulation for ESG Intelligence Platform
This script maintains application state and demonstrates data flow using real API calls.
"""

import json
import requests
import time
import os
from typing import Dict, Any, Optional
import argparse

class ESGStateSimulator:
    """Simulates application state and data flow for the ESG Intelligence Platform"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.state = {
            "current_report_id": None,
            "reports_processed": [],
            "system_health": None,
            "last_api_call": None
        }
    
    def check_system_health(self) -> Dict[str, Any]:
        """Check the system health status"""
        try:
            response = requests.get(f"{self.base_url}/health")
            self.state["system_health"] = response.json()
            self.state["last_api_call"] = time.time()
            return self.state["system_health"]
        except Exception as e:
            print(f"Error checking system health: {e}")
            return {"status": "error", "message": str(e)}
    
    def process_json_data(self, supplier_data: Dict[str, Any]) -> Optional[str]:
        """Process JSON data through the ingestion endpoint"""
        try:
            response = requests.post(
                f"{self.base_url}/ingest/json",
                json={"supplier_data": supplier_data},
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                # Extract report ID from the response if available
                # For now, we'll just store the response
                report_entry = {
                    "timestamp": time.time(),
                    "data": supplier_data,
                    "response": result
                }
                self.state["reports_processed"].append(report_entry)
                self.state["last_api_call"] = time.time()
                print(f"Successfully processed JSON data")
                return "success"
            else:
                print(f"Error processing JSON data: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            print(f"Error processing JSON data: {e}")
            return None
    
    def process_file_data(self, file_path: str) -> Optional[str]:
        """Process file data through the file upload endpoint"""
        if not os.path.exists(file_path):
            print(f"File {file_path} does not exist")
            return None
            
        try:
            with open(file_path, 'rb') as f:
                files = {'file': f}
                response = requests.post(
                    f"{self.base_url}/ingest/file",
                    files=files
                )
            
            if response.status_code == 200:
                result = response.json()
                # Store the response
                report_entry = {
                    "timestamp": time.time(),
                    "file": file_path,
                    "response": result
                }
                self.state["reports_processed"].append(report_entry)
                self.state["last_api_call"] = time.time()
                print(f"Successfully processed file data")
                return "success"
            else:
                print(f"Error processing file data: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            print(f"Error processing file data: {e}")
            return None
    
    def verify_report(self, report_id: str) -> Optional[Dict[str, Any]]:
        """Verify a report using the verification endpoint"""
        try:
            response = requests.get(f"{self.base_url}/verify/{report_id}")
            
            if response.status_code == 200:
                result = response.json()
                self.state["current_report_id"] = report_id
                self.state["last_api_call"] = time.time()
                print(f"Successfully verified report {report_id}")
                return result
            elif response.status_code == 404:
                print(f"Report {report_id} not found")
                return None
            else:
                print(f"Error verifying report: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            print(f"Error verifying report: {e}")
            return None
    
    def get_current_state(self) -> Dict[str, Any]:
        """Return the current application state"""
        return self.state
    
    def save_state_to_file(self, filename: str = "demo_scripts/state_snapshot.json"):
        """Save the current state to a file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.state, f, indent=2)
            print(f"State saved to {filename}")
        except Exception as e:
            print(f"Error saving state to file: {e}")
    
    def load_state_from_file(self, filename: str = "demo_scripts/state_snapshot.json"):
        """Load state from a file"""
        try:
            with open(filename, 'r') as f:
                self.state = json.load(f)
            print(f"State loaded from {filename}")
        except Exception as e:
            print(f"Error loading state from file: {e}")

def demo_workflow():
    """Demonstrate a complete workflow using the ESGStateSimulator"""
    print("ESG Intelligence Platform - State Simulation Demo")
    print("=" * 50)
    
    simulator = ESGStateSimulator()
    
    # Step 1: Check system health
    print("\n1. Checking system health...")
    health = simulator.check_system_health()
    print(f"System health: {health['status']}")
    
    # Step 2: Process sample JSON data
    print("\n2. Processing sample JSON data...")
    sample_data = {
        "name": "Sample Supplier",
        "esg_score": 85,
        "location": "New York, USA",
        "industry": "Manufacturing"
    }
    result = simulator.process_json_data(sample_data)
    
    # Step 3: Save current state
    print("\n3. Saving current state...")
    simulator.save_state_to_file()
    
    # Step 4: Display current state
    print("\n4. Current application state:")
    state = simulator.get_current_state()
    print(json.dumps(state, indent=2))
    
    print("\nDemo workflow completed!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ESG State Simulator")
    parser.add_argument("--demo", action="store_true", help="Run demo workflow")
    parser.add_argument("--health", action="store_true", help="Check system health")
    parser.add_argument("--json-data", type=str, help="Process JSON data from file")
    parser.add_argument("--file-data", type=str, help="Process file data from path")
    parser.add_argument("--verify", type=str, help="Verify report by ID")
    parser.add_argument("--save-state", type=str, default="demo_scripts/state_snapshot.json", help="Save state to file")
    
    args = parser.parse_args()
    
    simulator = ESGStateSimulator()
    
    if args.demo:
        demo_workflow()
    elif args.health:
        health = simulator.check_system_health()
        print(json.dumps(health, indent=2))
    elif args.json_data:
        try:
            with open(args.json_data, 'r') as f:
                data = json.load(f)
            simulator.process_json_data(data)
        except Exception as e:
            print(f"Error processing JSON file: {e}")
    elif args.file_data:
        simulator.process_file_data(args.file_data)
    elif args.verify:
        result = simulator.verify_report(args.verify)
        if result:
            print(json.dumps(result, indent=2))
    else:
        # Default action - show help
        parser.print_help()