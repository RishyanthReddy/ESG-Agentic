#!/usr/bin/env python3
"""
Interactive Graph Demo Script for ESG Intelligence Platform
This script provides a CLI interface mimicking 3D graph interactions.
"""

import json
import argparse
from typing import Dict, Any, List
import networkx as nx
import cmd
import os

class GraphDemoCLI(cmd.Cmd):
    intro = """
===============================================
  ESG Intelligence Platform - Graph Demo CLI
===============================================
Welcome to the interactive graph visualization demo.
Type 'help' or '?' to list commands.
Type 'exit' to quit the demo.

Available commands:
  nodes              - List all nodes
  edges              - List all edges
  info <node_id>     - Show detailed info for a node
  neighbors <node_id> - Show neighbors of a node
  path <src> <dst>   - Find path between two nodes
  highlight <node_id> - Highlight a node and its connections
  export             - Export current view
  help               - Show this help
  exit               - Exit the demo
"""
    prompt = '(graph-demo) '
    
    def __init__(self):
        super().__init__()
        self.graph_data = self._load_mock_data()
        self.G = self._create_graph()
        self.highlighted_node = None
        
    def _load_mock_data(self) -> Dict[str, Any]:
        """Load mock graph data"""
        return {
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil", "esg_score": 78},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China", "esg_score": 65},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany", "esg_score": 92},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands", "esg_score": 88},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA", "esg_score": 81},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA", "esg_score": 100},
                {"id": "7", "name": "Recycling Center", "type": "recycler", "location": "Canada", "esg_score": 95},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5, "distance_km": 18500},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2, "distance_km": 8700},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7, "distance_km": 560},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3, "distance_km": 3500},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0, "distance_km": 15},
                {"source": "6", "target": "7", "type": "disposal", "date": "2025-03-15", "co2_emissions": 5.2, "distance_km": 800},
                {"source": "7", "target": "1", "type": "recycled_material", "date": "2025-04-01", "co2_emissions": -50.0, "distance_km": 9200},
            ],
            "product": {
                "id": "PRODUCT-001",
                "name": "Sustainable Wood Table",
                "esg_score": 85,
                "certifications": ["FSC", "CARB", "GREENGUARD"]
            }
        }
    
    def _create_graph(self) -> nx.DiGraph:
        """Create a NetworkX graph from the data"""
        G = nx.DiGraph()
        
        # Add nodes
        for node in self.graph_data["nodes"]:
            G.add_node(
                node["id"],
                name=node["name"],
                type=node["type"],
                location=node["location"],
                esg_score=node["esg_score"]
            )
        
        # Add edges
        for edge in self.graph_data["edges"]:
            G.add_edge(
                edge["source"],
                edge["target"],
                type=edge["type"],
                date=edge["date"],
                co2_emissions=edge["co2_emissions"],
                distance_km=edge["distance_km"]
            )
        
        return G
    
    def do_nodes(self, arg):
        """List all nodes in the graph"""
        print("\nNodes in the graph:")
        print("-" * 80)
        print(f"{'ID':<5} {'Name':<25} {'Type':<15} {'Location':<15} {'ESG Score':<10}")
        print("-" * 80)
        for node in self.graph_data["nodes"]:
            print(f"{node['id']:<5} {node['name']:<25} {node['type']:<15} {node['location']:<15} {node['esg_score']:<10}")
        print("-" * 80)
    
    def do_edges(self, arg):
        """List all edges in the graph"""
        print("\nEdges in the graph:")
        print("-" * 100)
        print(f"{'Source':<8} {'Target':<8} {'Type':<15} {'Date':<12} {'CO2 (kg)':<10} {'Distance (km)':<15}")
        print("-" * 100)
        for edge in self.graph_data["edges"]:
            print(f"{edge['source']:<8} {edge['target']:<8} {edge['type']:<15} {edge['date']:<12} {edge['co2_emissions']:<10} {edge['distance_km']:<15}")
        print("-" * 100)
    
    def do_info(self, node_id):
        """Show detailed information for a specific node"""
        node = next((n for n in self.graph_data["nodes"] if n["id"] == node_id), None)
        if not node:
            print(f"Node with ID '{node_id}' not found.")
            return
        
        print(f"\nNode Information:")
        print("-" * 30)
        print(f"ID: {node['id']}")
        print(f"Name: {node['name']}")
        print(f"Type: {node['type']}")
        print(f"Location: {node['location']}")
        print(f"ESG Score: {node['esg_score']}/100")
        
        # Show incoming and outgoing connections
        predecessors = list(self.G.predecessors(node_id))
        successors = list(self.G.successors(node_id))
        
        if predecessors:
            print(f"\nSuppliers/Inputs:")
            for pred in predecessors:
                pred_node = next(n for n in self.graph_data["nodes"] if n["id"] == pred)
                edge_data = self.G.get_edge_data(pred, node_id)
                print(f"  ← {pred_node['name']} ({edge_data['type']}) - {edge_data['date']}")
        
        if successors:
            print(f"\nCustomers/Outputs:")
            for succ in successors:
                succ_node = next(n for n in self.graph_data["nodes"] if n["id"] == succ)
                edge_data = self.G.get_edge_data(node_id, succ)
                print(f"  → {succ_node['name']} ({edge_data['type']}) - {edge_data['date']}")
    
    def do_neighbors(self, node_id):
        """Show neighbors of a specific node"""
        if not self.G.has_node(node_id):
            print(f"Node with ID '{node_id}' not found.")
            return
        
        predecessors = list(self.G.predecessors(node_id))
        successors = list(self.G.successors(node_id))
        
        node_name = next(n["name"] for n in self.graph_data["nodes"] if n["id"] == node_id)
        print(f"\nNeighbors of {node_name} (ID: {node_id}):")
        print("-" * 50)
        
        if predecessors:
            print("Suppliers/Inputs:")
            for pred in predecessors:
                pred_node = next(n for n in self.graph_data["nodes"] if n["id"] == pred)
                print(f"  ← {pred_node['name']} (ID: {pred})")
        
        if successors:
            print("Customers/Outputs:")
            for succ in successors:
                succ_node = next(n for n in self.graph_data["nodes"] if n["id"] == succ)
                print(f"  → {succ_node['name']} (ID: {succ})")
        
        if not predecessors and not successors:
            print("No neighbors found.")
    
    def do_path(self, args):
        """Find path between two nodes"""
        try:
            source, target = args.split()
        except ValueError:
            print("Usage: path <source_id> <target_id>")
            return
        
        if not self.G.has_node(source):
            print(f"Source node with ID '{source}' not found.")
            return
        
        if not self.G.has_node(target):
            print(f"Target node with ID '{target}' not found.")
            return
        
        try:
            paths = list(nx.all_simple_paths(self.G, source, target))
            
            if not paths:
                print(f"No path found from {source} to {target}.")
                return
            
            print(f"\nFound {len(paths)} path(s) from {source} to {target}:")
            print("=" * 60)
            
            for i, path in enumerate(paths, 1):
                print(f"\nPath {i}:")
                total_co2 = 0
                for j, node_id in enumerate(path):
                    node = next(n for n in self.graph_data["nodes"] if n["id"] == node_id)
                    print(f"  {j+1}. {node['name']} (ID: {node_id})")
                    
                    # Show edge info if not the last node
                    if j < len(path) - 1:
                        next_node_id = path[j+1]
                        edge_data = self.G.get_edge_data(node_id, next_node_id)
                        if edge_data:
                            print(f"     → {edge_data['type']} on {edge_data['date']}")
                            print(f"     → CO2: {edge_data['co2_emissions']} kg")
                            total_co2 += edge_data['co2_emissions']
                
                print(f"  Total CO2 Emissions: {total_co2:.2f} kg")
                print("-" * 40)
                
        except nx.NetworkXNoPath:
            print(f"No path found from {source} to {target}.")
    
    def do_highlight(self, node_id):
        """Highlight a node and its connections"""
        if not self.G.has_node(node_id):
            print(f"Node with ID '{node_id}' not found.")
            return
        
        self.highlighted_node = node_id
        node = next(n for n in self.graph_data["nodes"] if n["id"] == node_id)
        print(f"\nHighlighting node: {node['name']} (ID: {node_id})")
        
        # Show node details
        self.do_info(node_id)
        
        # Show neighbors
        self.do_neighbors(node_id)
    
    def do_export(self, arg):
        """Export current view information"""
        print("\nExporting current view information...")
        print("In a full implementation, this would export:")
        print("1. Current graph view as image")
        print("2. Highlighted node details")
        print("3. Selected path information")
        print("4. Current visualization parameters")
        print("\nExport completed to demo_scripts/graph_view_export.json")
    
    def do_exit(self, arg):
        """Exit the demo"""
        print("Thank you for using the ESG Intelligence Platform Graph Demo!")
        return True

def main():
    parser = argparse.ArgumentParser(description="Interactive graph demo CLI")
    parser.add_argument("--demo", action="store_true", help="Run in demo mode with sample commands")
    
    args = parser.parse_args()
    
    if args.demo:
        # Run in demo mode
        cli = GraphDemoCLI()
        print(cli.intro)
        
        # Demonstrate some commands
        print("(graph-demo) nodes")
        cli.do_nodes("")
        
        print("\n(graph-demo) info 3")
        cli.do_info("3")
        
        print("\n(graph-demo) path 1 6")
        cli.do_path("1 6")
        
        print("\n(graph-demo) highlight 4")
        cli.do_highlight("4")
        
        print("\nFor interactive mode, run without --demo flag")
    else:
        # Run interactive CLI
        cli = GraphDemoCLI()
        cli.cmdloop()

if __name__ == "__main__":
    main()