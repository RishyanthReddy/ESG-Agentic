# Frontend Fallback Documentation

This document provides curl equivalents for all frontend actions in the ESG Intelligence Platform. These commands can be used as fallback mechanisms when the frontend is not available.

## API Endpoints

### 1. Root Endpoint

**Frontend Action**: Visit homepage
**Curl Equivalent**:
```bash
curl -X GET http://localhost:8000/
```

### 2. Health Check

**Frontend Action**: Check system health status
**Curl Equivalent**:
```bash
curl -X GET http://localhost:8000/health
```

### 3. JSON Data Ingestion

**Frontend Action**: Submit supplier data via form
**Curl Equivalent**:
```bash
curl -X POST http://localhost:8000/ingest/json \
  -H "Content-Type: application/json" \
  -d '{
    "supplier_data": {
      "name": "Supplier Name",
      "esg_score": 85,
      "location": "New York, USA",
      "industry": "Manufacturing"
    },
    "config": {
      "verification_required": true
    }
  }'
```

### 4. File Upload Ingestion

**Frontend Action**: Upload CSV/Excel file with supplier data
**Curl Equivalent**:
```bash
curl -X POST http://localhost:8000/ingest/file \
  -F "file=@path/to/your/file.csv" \
  -F "config={\"verification_required\": true};type=application/json"
```

### 5. Report Verification

**Frontend Action**: Verify a report by its ID
**Curl Equivalent**:
```bash
curl -X GET http://localhost:8000/verify/{report_id}
```

## Example Workflows

### Complete Data Processing Workflow

1. Submit data for processing:
```bash
curl -X POST http://localhost:8000/ingest/json \
  -H "Content-Type: application/json" \
  -d '{"supplier_data": {"name": "ABC Corp", "esg_score": 78}}'
```

2. Extract the report_id from the response

3. Verify the report:
```bash
curl -X GET http://localhost:8000/verify/{report_id_from_step_1}
```

## Environment Variables

The following environment variables should be set for proper API functionality:

- `INFURA_API_KEY`: Required for blockchain connectivity
- `GLAMA_API_KEY`: Required for LLM functionality
- `CLIMATIQ_API_KEY`: Required for carbon footprint calculations
- `AZURE_CLIENT_ID`, `AZURE_CLIENT_SECRET`, `AZURE_TENANT_ID`: Required for Azure Verified ID integration

## Error Handling

All endpoints return appropriate HTTP status codes:
- 200: Success
- 400: Bad Request (invalid input)
- 404: Not Found (e.g., report not found)
- 500: Internal Server Error

Check the response body for detailed error messages in case of failures.