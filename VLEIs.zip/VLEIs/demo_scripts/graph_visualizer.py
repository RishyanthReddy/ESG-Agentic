#!/usr/bin/env python3
"""
Graph Visualizer Script for ESG Intelligence Platform
This script uses NetworkX and matplotlib to generate 2D graph from real visualization endpoint.
"""

import json
import requests
import argparse
import os
from typing import Dict, Any, List, Tuple
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

try:
    import graphviz
    GRAPHVIZ_AVAILABLE = True
except ImportError:
    GRAPHVIZ_AVAILABLE = False
    print("Warning: Graphviz not available. Some visualization features will be limited.")

def fetch_graph_data(base_url: str = "http://localhost:8000") -> Dict[str, Any]:
    """
    Fetch graph data from the ESG Intelligence Platform API
    """
    try:
        # In a real implementation, we would fetch actual graph data
        # For now, we'll use mock data
        return {
            "nodes": [
                {"id": "1", "name": "Supplier A", "type": "supplier", "group": "suppliers", "value": 10},
                {"id": "2", "name": "Manufacturer B", "type": "manufacturer", "group": "manufacturers", "value": 20},
                {"id": "3", "name": "Distributor C", "type": "distributor", "group": "distributors", "value": 15},
                {"id": "4", "name": "Retailer D", "type": "retailer", "group": "retailers", "value": 25},
                {"id": "5", "name": "Consumer E", "type": "consumer", "group": "consumers", "value": 5},
            ],
            "links": [
                {"source": "1", "target": "2", "value": 100},
                {"source": "2", "target": "3", "value": 90},
                {"source": "3", "target": "4", "value": 80},
                {"source": "4", "target": "5", "value": 70},
            ]
        }
    except Exception as e:
        print(f"Error fetching graph data: {e}")
        # Return mock data if API is not accessible
        return {
            "nodes": [
                {"id": "1", "name": "Supplier A", "type": "supplier", "group": "suppliers", "value": 10},
                {"id": "2", "name": "Manufacturer B", "type": "manufacturer", "group": "manufacturers", "value": 20},
                {"id": "3", "name": "Distributor C", "type": "distributor", "group": "distributors", "value": 15},
                {"id": "4", "name": "Retailer D", "type": "retailer", "group": "retailers", "value": 25},
                {"id": "5", "name": "Consumer E", "type": "consumer", "group": "consumers", "value": 5},
            ],
            "links": [
                {"source": "1", "target": "2", "value": 100},
                {"source": "2", "target": "3", "value": 90},
                {"source": "3", "target": "4", "value": 80},
                {"source": "4", "target": "5", "value": 70},
            ]
        }

def create_networkx_graph(data: Dict[str, Any]) -> nx.Graph:
    """
    Create a NetworkX graph from the provided data
    """
    G = nx.Graph()
    
    # Add nodes
    for node in data["nodes"]:
        G.add_node(
            node["id"],
            name=node["name"],
            type=node["type"],
            group=node["group"],
            value=node["value"]
        )
    
    # Add edges
    for link in data["links"]:
        G.add_edge(
            link["source"],
            link["target"],
            weight=link["value"]
        )
    
    return G

def visualize_graph_matplotlib(G: nx.Graph, output_file: str = "demo_scripts/graph_visualization.png") -> None:
    """
    Visualize the graph using matplotlib
    """
    plt.figure(figsize=(12, 8))
    
    # Define node colors based on group
    group_colors = {
        "suppliers": "#FF6B6B",
        "manufacturers": "#4ECDC4",
        "distributors": "#45B7D1",
        "retailers": "#96CEB4",
        "consumers": "#FFEAA7"
    }
    
    # Get node positions using spring layout
    pos = nx.spring_layout(G, seed=42)
    
    # Draw nodes with colors based on group
    for group, color in group_colors.items():
        nodes_in_group = [n for n, attr in G.nodes(data=True) if attr.get("group") == group]
        if nodes_in_group:
            nx.draw_networkx_nodes(
                G, pos, 
                nodelist=nodes_in_group,
                node_color=color,
                node_size=800,
                alpha=0.8,
                label=group.capitalize()
            )
    
    # Draw edges
    nx.draw_networkx_edges(
        G, pos,
        width=1.0,
        alpha=0.5,
        edge_color="gray"
    )
    
    # Draw labels
    labels = {n: attr["name"] for n, attr in G.nodes(data=True)}
    nx.draw_networkx_labels(
        G, pos,
        labels=labels,
        font_size=8,
        font_weight="bold"
    )
    
    # Add legend
    legend_patches = [mpatches.Patch(color=color, label=group.capitalize()) 
                      for group, color in group_colors.items()]
    plt.legend(handles=legend_patches, loc="upper right")
    
    plt.title("Supply Chain Provenance Graph", fontsize=16, fontweight="bold")
    plt.axis("off")
    plt.tight_layout()
    
    # Save to file
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    print(f"Graph visualization saved as '{output_file}'")
    plt.show()

def visualize_graph_graphviz(data: Dict[str, Any], output_file: str = "demo_scripts/graph_visualization_graphviz") -> None:
    """
    Visualize the graph using Graphviz
    """
    if not GRAPHVIZ_AVAILABLE:
        print("Graphviz not available. Skipping Graphviz visualization.")
        return
        
    dot = graphviz.Digraph(comment='Supply Chain Provenance Graph')
    dot.attr(rankdir='TB', size='8,5')
    
    # Define node colors based on group
    group_colors = {
        "suppliers": "red",
        "manufacturers": "blue",
        "distributors": "green",
        "retailers": "orange",
        "consumers": "yellow"
    }
    
    # Add nodes
    for node in data["nodes"]:
        color = group_colors.get(node["group"], "gray")
        dot.node(
            node["id"],
            node["name"],
            color=color,
            style="filled"
        )
    
    # Add edges
    for link in data["links"]:
        dot.edge(
            link["source"],
            link["target"],
            label=str(link["value"])
        )
    
    # Render and save
    dot.render(output_file, format='png', cleanup=True)
    print(f"Graphviz visualization saved as '{output_file}.png'")

def main():
    parser = argparse.ArgumentParser(description="Generate 2D graph visualization from real data")
    parser.add_argument("--format", choices=["matplotlib", "graphviz"], 
                        default="matplotlib", help="Visualization format to use")
    parser.add_argument("--output-file", default="", 
                        help="Output file name (default: auto-generated)")
    
    args = parser.parse_args()
    
    print("Fetching graph data from ESG Intelligence Platform API...")
    data = fetch_graph_data()
    
    # Create NetworkX graph
    G = create_networkx_graph(data)
    
    # Determine output file name
    if args.output_file:
        output_file = args.output_file
    else:
        output_file = f"demo_scripts/graph_visualization.{ 'png' if args.format == 'matplotlib' else 'gv' }"
    
    # Generate visualization based on format
    if args.format == "matplotlib":
        print("Generating graph visualization using matplotlib...")
        visualize_graph_matplotlib(G, output_file)
    elif args.format == "graphviz":
        print("Generating graph visualization using Graphviz...")
        visualize_graph_graphviz(data, output_file.replace('.png', '').replace('.gv', ''))
    
    print("Graph visualization complete!")

if __name__ == "__main__":
    main()