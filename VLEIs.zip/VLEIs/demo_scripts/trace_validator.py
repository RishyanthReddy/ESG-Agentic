#!/usr/bin/env python3
"""
Trace Validator Script for ESG Intelligence Platform
This script verifies path accuracy by calling verification endpoints.
"""

import json
import requests
import argparse
import sys
import time
from typing import Dict, Any, List
import hashlib

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


def fetch_path_data(base_url: str = "http://localhost:8000", path_id: str = "") -> Dict[str, Any]:
    """
    Fetch path data from the ESG Intelligence Platform API
    """
    try:
        # In a real implementation, this would call the actual API endpoint
        # For now, we'll use mock data
        return {
            "path_id": path_id or "path_12345",
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil", "hash": "a1b2c3d4"},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China", "hash": "e5f6g7h8"},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany", "hash": "i9j0k1l2"},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands", "hash": "m3n4o5p6"},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA", "hash": "q7r8s9t0"},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA", "hash": "u1v2w3x4"},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5, "hash": "z1y2x3w4"},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2, "hash": "v5u6t7s8"},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7, "hash": "r9q0p1o2"},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3, "hash": "n3m4l5k6"},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0, "hash": "j7i8h9g0"},
            ],
            "product": {
                "id": "PRODUCT-001",
                "name": "Sustainable Wood Table",
                "esg_score": 85,
                "certifications": ["FSC", "CARB", "GREENGUARD"]
            }
        }
    except Exception as e:
        print(f"Error fetching path data: {e}")
        return {}


def calculate_path_hash(path_data: Dict[str, Any]) -> str:
    """
    Calculate a hash for the path data to verify integrity
    """
    # Create a string representation of the path data
    path_str = json.dumps(path_data, sort_keys=True)
    # Calculate SHA256 hash
    return hashlib.sha256(path_str.encode()).hexdigest()


def verify_path_integrity(path_data: Dict[str, Any], expected_hash: str = "") -> Dict[str, Any]:
    """
    Verify the integrity of the path data
    """
    # Calculate the actual hash of the path data
    actual_hash = calculate_path_hash(path_data)
    
    # If expected hash is provided, compare with it
    if expected_hash:
        is_valid = actual_hash == expected_hash
    else:
        # In a real implementation, we would fetch the expected hash from a verification endpoint
        # For now, we'll just return the actual hash
        is_valid = True
    
    return {
        "is_valid": is_valid,
        "actual_hash": actual_hash,
        "expected_hash": expected_hash,
        "message": "Path integrity verified" if is_valid else "Path integrity verification failed"
    }


def validate_node_authenticity(node: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate the authenticity of a node
    """
    # In a real implementation, this would check the node against a verification database
    # For now, we'll just simulate validation
    return {
        "node_id": node.get("id"),
        "is_authentic": True,
        "verification_method": "Blockchain verification",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }


def validate_edge_authenticity(edge: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate the authenticity of an edge
    """
    # In a real implementation, this would check the edge against a verification database
    # For now, we'll just simulate validation
    return {
        "source": edge.get("source"),
        "target": edge.get("target"),
        "is_authentic": True,
        "verification_method": "Digital signature verification",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }


def display_validation_results(path_data: Dict[str, Any], validation_results: Dict[str, Any], use_rich: bool = True):
    """
    Display the validation results in terminal
    """
    if use_rich and RICH_AVAILABLE:
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Path Validation Results[/bold blue]"))
        
        # Display path integrity
        integrity = validation_results.get("integrity", {})
        if integrity.get("is_valid"):
            console.print("[green]✓[/green] [bold]Path Integrity:[/bold] Valid")
            console.print(f"  Hash: {integrity.get('actual_hash')[:16]}...")
        else:
            console.print("[red]✗[/red] [bold]Path Integrity:[/bold] Invalid")
            console.print(f"  Expected: {integrity.get('expected_hash')[:16]}...")
            console.print(f"  Actual: {integrity.get('actual_hash')[:16]}...")
        
        # Display node validations
        console.print("\n[bold]Node Authenticity:[/bold]")
        node_validations = validation_results.get("node_validations", [])
        for validation in node_validations:
            if validation.get("is_authentic"):
                console.print(f"  [green]✓[/green] Node {validation.get('node_id')}: Authentic")
            else:
                console.print(f"  [red]✗[/red] Node {validation.get('node_id')}: Not Authentic")
        
        # Display edge validations
        console.print("\n[bold]Edge Authenticity:[/bold]")
        edge_validations = validation_results.get("edge_validations", [])
        for validation in edge_validations:
            if validation.get("is_authentic"):
                console.print(f"  [green]✓[/green] {validation.get('source')} → {validation.get('target')}: Authentic")
            else:
                console.print(f"  [red]✗[/red] {validation.get('source')} → {validation.get('target')}: Not Authentic")
        
        # Display summary
        total_nodes = len(node_validations)
        valid_nodes = sum(1 for v in node_validations if v.get("is_authentic"))
        total_edges = len(edge_validations)
        valid_edges = sum(1 for v in edge_validations if v.get("is_authentic"))
        
        console.print(f"\n[bold]Validation Summary:[/bold]")
        console.print(f"  Nodes: {valid_nodes}/{total_nodes} valid")
        console.print(f"  Edges: {valid_edges}/{total_edges} valid")
        
        if valid_nodes == total_nodes and valid_edges == total_edges and integrity.get("is_valid"):
            console.print("\n[bold green]✅ All validations passed! Path is authentic.[/bold green]")
        else:
            console.print("\n[bold red]❌ Some validations failed! Path may not be authentic.[/bold red]")
    else:
        # Simple text output
        print("ESG Intelligence Platform - Path Validation Results")
        print("=" * 50)
        
        # Display path integrity
        integrity = validation_results.get("integrity", {})
        if integrity.get("is_valid"):
            print("✓ Path Integrity: Valid")
            print(f"  Hash: {integrity.get('actual_hash')[:16]}...")
        else:
            print("✗ Path Integrity: Invalid")
            print(f"  Expected: {integrity.get('expected_hash')[:16]}...")
            print(f"  Actual: {integrity.get('actual_hash')[:16]}...")
        
        # Display node validations
        print("\nNode Authenticity:")
        node_validations = validation_results.get("node_validations", [])
        for validation in node_validations:
            if validation.get("is_authentic"):
                print(f"  ✓ Node {validation.get('node_id')}: Authentic")
            else:
                print(f"  ✗ Node {validation.get('node_id')}: Not Authentic")
        
        # Display edge validations
        print("\nEdge Authenticity:")
        edge_validations = validation_results.get("edge_validations", [])
        for validation in edge_validations:
            if validation.get("is_authentic"):
                print(f"  ✓ {validation.get('source')} → {validation.get('target')}: Authentic")
            else:
                print(f"  ✗ {validation.get('source')} → {validation.get('target')}: Not Authentic")
        
        # Display summary
        total_nodes = len(node_validations)
        valid_nodes = sum(1 for v in node_validations if v.get("is_authentic"))
        total_edges = len(edge_validations)
        valid_edges = sum(1 for v in edge_validations if v.get("is_authentic"))
        
        print(f"\nValidation Summary:")
        print(f"  Nodes: {valid_nodes}/{total_nodes} valid")
        print(f"  Edges: {valid_edges}/{total_edges} valid")
        
        if valid_nodes == total_nodes and valid_edges == total_edges and integrity.get("is_valid"):
            print("\n✅ All validations passed! Path is authentic.")
        else:
            print("\n❌ Some validations failed! Path may not be authentic.")


def main():
    parser = argparse.ArgumentParser(description="Validate path accuracy in ESG supply chain")
    parser.add_argument("--path-id", type=str, default="", help="Path ID to validate")
    parser.add_argument("--base-url", type=str, default="http://localhost:8000", help="Base URL for API calls")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Determine if we should use rich formatting
    use_rich = RICH_AVAILABLE and not args.simple
    
    # Fetch path data
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Fetching path data...", total=None)
            path_data = fetch_path_data(args.base_url, args.path_id)
            progress.update(task, completed=True)
    else:
        print("Fetching path data...")
        path_data = fetch_path_data(args.base_url, args.path_id)
    
    if not path_data:
        if use_rich:
            rich_print("[red]Failed to fetch path data.[/red]")
        else:
            print("Failed to fetch path data.")
        return
    
    # Perform validations
    validation_results = {
        "integrity": {},
        "node_validations": [],
        "edge_validations": []
    }
    
    # Verify path integrity
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Verifying path integrity...", total=None)
            validation_results["integrity"] = verify_path_integrity(path_data)
            progress.update(task, completed=True)
    else:
        print("Verifying path integrity...")
        validation_results["integrity"] = verify_path_integrity(path_data)
    
    # Validate nodes
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Validating nodes...", total=len(path_data.get("nodes", [])))
            for node in path_data.get("nodes", []):
                validation = validate_node_authenticity(node)
                validation_results["node_validations"].append(validation)
                progress.update(task, advance=1)
    else:
        print("Validating nodes...")
        for node in path_data.get("nodes", []):
            validation = validate_node_authenticity(node)
            validation_results["node_validations"].append(validation)
    
    # Validate edges
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Validating edges...", total=len(path_data.get("edges", [])))
            for edge in path_data.get("edges", []):
                validation = validate_edge_authenticity(edge)
                validation_results["edge_validations"].append(validation)
                progress.update(task, advance=1)
    else:
        print("Validating edges...")
        for edge in path_data.get("edges", []):
            validation = validate_edge_authenticity(edge)
            validation_results["edge_validations"].append(validation)
    
    # Display results
    display_validation_results(path_data, validation_results, use_rich)


if __name__ == "__main__":
    main()