#!/usr/bin/env python3
"""
Master Demo Script for ESG Intelligence Platform

This script orchestrates all demo components for the hackathon presentation,
providing both web-based and CLI-based demonstration alternatives.
"""

import argparse
import subprocess
import sys
import time
import os
from typing import List, Dict, Any

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    from rich.table import Table
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


class DemoOrchestrator:
    """
    Orchestrates the complete demo presentation with fail-safe CLI alternatives.
    """
    
    def __init__(self):
        self.console = Console() if RICH_AVAILABLE else None
        self.demo_scripts = [
            {
                "name": "Dashboard Simulation",
                "description": "Complete dashboard simulation with all panels",
                "web_script": None,
                "cli_script": "demo_scripts/complete_dashboard_simulation.py",
                "duration": 30,
                "args": ["--simple"]
            },
            {
                "name": "Real-time Metrics",
                "description": "Live metrics streaming",
                "web_script": None,
                "cli_script": "demo_scripts/live_metrics_stream.py",
                "duration": 15,
                "args": ["--duration", "15", "--simple"]
            },
            {
                "name": "3D Visualization",
                "description": "Supply chain graph visualization",
                "web_script": None,
                "cli_script": "demo_scripts/graph_visualizer.py",
                "duration": 20,
                "args": ["--export-format", "json", "--simple"]
            },
            {
                "name": "Path Tracing",
                "description": "Provenance path tracing",
                "web_script": None,
                "cli_script": "demo_scripts/path_tracer.py",
                "duration": 15,
                "args": ["--simple"]
            },
            {
                "name": "File Upload",
                "description": "File upload and processing workflow",
                "web_script": None,
                "cli_script": "demo_scripts/file_upload_demo.sh",
                "duration": 20,
                "args": []
            },
            {
                "name": "WebSocket Communication",
                "description": "Real-time communication with fallback",
                "web_script": None,
                "cli_script": "demo_scripts/websocket_client.py",
                "duration": 20,
                "args": ["--mode", "simulate", "--duration", "20", "--simple"]
            },
            {
                "name": "Audit Verification",
                "description": "Audit process and verification",
                "web_script": None,
                "cli_script": "demo_scripts/audit_runner.py",
                "duration": 25,
                "args": ["--simple"]
            },
            {
                "name": "Metrics Display",
                "description": "ESG metrics and analytics",
                "web_script": None,
                "cli_script": "demo_scripts/metrics_display.py",
                "duration": 15,
                "args": ["--chart-type", "all", "--format", "matplotlib"]
            }
        ]
    
    def print_header(self, text: str):
        """Print a header with consistent formatting."""
        if self.console:
            self.console.print(Panel(f"[bold blue]{text}[/bold blue]"))
        else:
            print(f"\n{'='*50}")
            print(f"{text}")
            print(f"{'='*50}")
    
    def run_script(self, script_info: Dict[str, Any]) -> bool:
        """
        Run a demo script and handle any errors.
        
        Args:
            script_info: Dictionary containing script information
            
        Returns:
            True if script ran successfully, False otherwise
        """
        name = script_info["name"]
        description = script_info["description"]
        cli_script = script_info["cli_script"]
        args = script_info["args"]
        
        self.print_header(f"Demo: {name}")
        if self.console:
            self.console.print(f"[cyan]{description}[/cyan]")
        else:
            print(f"{description}")
        
        try:
            # Determine if it's a Python script or shell script
            if cli_script.endswith('.py'):
                cmd = [sys.executable, cli_script] + args
            else:
                # For shell scripts on Windows, we might need to use bash or cmd
                if os.name == 'nt':  # Windows
                    cmd = ['cmd', '/c', cli_script]
                else:
                    cmd = ['bash', cli_script]
            
            if self.console:
                self.console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")
            else:
                print(f"Running: {' '.join(cmd)}")
            
            # Run the script
            result = subprocess.run(cmd, capture_output=False, text=True)
            
            if result.returncode == 0:
                if self.console:
                    self.console.print("[green]✅ Script completed successfully[/green]")
                else:
                    print("✅ Script completed successfully")
                return True
            else:
                if self.console:
                    self.console.print(f"[red]❌ Script failed with return code {result.returncode}[/red]")
                else:
                    print(f"❌ Script failed with return code {result.returncode}")
                return False
                
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ Error running script: {e}[/red]")
            else:
                print(f"❌ Error running script: {e}")
            return False
    
    def run_full_demo(self, selected_demos: List[str] = None):
        """
        Run the complete demo presentation.
        
        Args:
            selected_demos: List of specific demos to run (None for all)
        """
        self.print_header("ESG Intelligence Platform - Hackathon Demo")
        
        if self.console:
            self.console.print("[bold]Starting complete demo presentation...[/bold]")
        else:
            print("Starting complete demo presentation...")
        
        # Filter demos if specific ones are selected
        if selected_demos:
            demos_to_run = [d for d in self.demo_scripts if d["name"] in selected_demos]
        else:
            demos_to_run = self.demo_scripts
        
        # Run each demo
        successful_demos = 0
        failed_demos = 0
        
        for i, demo in enumerate(demos_to_run, 1):
            if self.console:
                self.console.print(f"\n[bold yellow]Demo {i}/{len(demos_to_run)}[/bold yellow]")
            else:
                print(f"\nDemo {i}/{len(demos_to_run)}")
            
            success = self.run_script(demo)
            if success:
                successful_demos += 1
            else:
                failed_demos += 1
        
        # Print summary
        self.print_header("Demo Presentation Summary")
        if self.console:
            self.console.print(f"[green]Successful demos: {successful_demos}[/green]")
            self.console.print(f"[{'red' if failed_demos > 0 else 'green'}]Failed demos: {failed_demos}[/{'red' if failed_demos > 0 else 'green'}]")
        else:
            print(f"Successful demos: {successful_demos}")
            print(f"Failed demos: {failed_demos}")
        
        if failed_demos == 0:
            if self.console:
                self.console.print("[bold green]🎉 All demos completed successfully![/bold green]")
            else:
                print("🎉 All demos completed successfully!")
        else:
            if self.console:
                self.console.print("[bold yellow]⚠️  Some demos failed, but presentation can continue with working components[/bold yellow]")
            else:
                print("⚠️  Some demos failed, but presentation can continue with working components")
    
    def list_demos(self):
        """List all available demos."""
        self.print_header("Available Demo Components")
        
        if self.console:
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("Name", style="cyan", width=25)
            table.add_column("Description", width=40)
            table.add_column("Duration (sec)", justify="right")
            
            for demo in self.demo_scripts:
                table.add_row(
                    demo["name"],
                    demo["description"],
                    str(demo["duration"])
                )
            
            self.console.print(table)
        else:
            print(f"{'Name':<25} {'Description':<40} {'Duration (sec)':<15}")
            print("-" * 80)
            for demo in self.demo_scripts:
                print(f"{demo['name']:<25} {demo['description']:<40} {demo['duration']:<15}")
    
    def run_rehearsal(self):
        """Run a complete rehearsal of the demo presentation."""
        self.print_header("Demo Rehearsal Mode")
        
        if self.console:
            self.console.print("[bold]Running complete rehearsal...[/bold]")
            self.console.print("[dim]This will run all demo components in sequence[/dim]")
        else:
            print("Running complete rehearsal...")
            print("This will run all demo components in sequence")
        
        # Simulate timing
        total_time = sum(demo["duration"] for demo in self.demo_scripts)
        
        if self.console:
            self.console.print(f"[blue]Estimated total time: {total_time} seconds ({total_time/60:.1f} minutes)[/blue]")
        else:
            print(f"Estimated total time: {total_time} seconds ({total_time/60:.1f} minutes)")
        
        # Run the full demo
        self.run_full_demo()


def main():
    parser = argparse.ArgumentParser(description="Master demo script for ESG Intelligence Platform")
    parser.add_argument("--mode", choices=["full", "rehearse", "list"], default="list",
                        help="Demo mode: full (run all demos), rehearse (run rehearsal), list (list demos)")
    parser.add_argument("--demos", nargs="+", default=None,
                        help="Specific demos to run (use with --mode full)")
    parser.add_argument("--simple", action="store_true",
                        help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Disable rich formatting if requested
    global RICH_AVAILABLE
    if args.simple:
        RICH_AVAILABLE = False
    
    # Create orchestrator
    orchestrator = DemoOrchestrator()
    
    # Run based on mode
    if args.mode == "full":
        orchestrator.run_full_demo(args.demos)
    elif args.mode == "rehearse":
        orchestrator.run_rehearsal()
    elif args.mode == "list":
        orchestrator.list_demos()


if __name__ == "__main__":
    main()