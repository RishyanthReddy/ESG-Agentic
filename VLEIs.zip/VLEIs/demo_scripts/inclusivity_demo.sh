#!/bin/bash

# Inclusivity Demo Script for ESG Intelligence Platform
# This script shows low-tech supplier integration via file upload

echo "==============================================="
echo "  ESG Intelligence Platform - Inclusivity Demo"
echo "==============================================="
echo ""

# Function to print section header
print_header() {
    echo "-----------------------------------------------"
    echo "$1"
    echo "-----------------------------------------------"
}

# Function to create demo data for a low-tech supplier
create_low_tech_supplier_data() {
    cat > supplier_data_manual.csv << EOF
supplier_id,name,location,esg_score,certifications,manual_entry
S999,"Local Farming Collective","Rural Kenya",75,"Fair Trade, Organic","Yes"
EOF
    echo "Created supplier_data_manual.csv for low-tech supplier"
}

# Function to simulate manual data entry process
simulate_manual_entry() {
    echo "Manual Data Entry Process:"
    echo "--------------------------"
    echo "1. Supplier fills out paper form with ESG information"
    echo "2. Data entry operator inputs data into simple CSV template"
    echo "3. CSV file is uploaded to ESG Intelligence Platform"
    echo "4. Platform processes and validates the data"
    echo "5. Supplier receives digital verification"
    echo ""
    echo "Benefits:"
    echo "• No technical expertise required from supplier"
    echo "• Works with basic computer skills"
    echo "• Compatible with paper-based workflows"
    echo "• Accessible to suppliers in remote areas"
    echo ""
}

# Function to demonstrate file upload for low-tech suppliers
demonstrate_upload() {
    echo "File Upload for Low-Tech Suppliers:"
    echo "-----------------------------------"
    echo "curl -F \"file=@supplier_data_manual.csv\" http://localhost:8000/ingest/file"
    echo ""
    echo "Upload Response:"
    echo "{"
    echo "  \"status\": \"success\","
    echo "  \"message\": \"File processed successfully\","
    echo "  \"final_state\": {"
    echo "    \"workflow_data\": {"
    echo "      \"supplier_data\": {"
    echo "        \"suppliers\": ["
    echo "          {"
    echo "            \"id\": \"S999\","
    echo "            \"name\": \"Local Farming Collective\","
    echo "            \"location\": \"Rural Kenya\","
    echo "            \"esg_score\": 75"
    echo "          }"
    echo "        ]"
    echo "      }"
    echo "    }"
    echo "  }"
    echo "}"
    echo ""
}

# Function to show platform inclusivity features
show_inclusivity_features() {
    echo "Platform Inclusivity Features:"
    echo "------------------------------"
    echo "1. Multiple file format support (CSV, XLS, XLSX)"
    echo "2. Simple data templates for manual entry"
    echo "3. Error tolerance for data inconsistencies"
    echo "4. Clear error messages for data correction"
    echo "5. Multi-language support (future enhancement)"
    echo "6. Low-bandwidth optimized upload process"
    echo "7. Offline data preparation capability"
    echo ""
}

# Create demo data
print_header "Step 1: Creating Low-Tech Supplier Data"
create_low_tech_supplier_data
echo ""

# Show manual entry process
print_header "Step 2: Manual Data Entry Process"
simulate_manual_entry
echo ""

# Demonstrate upload
print_header "Step 3: File Upload Demonstration"
demonstrate_upload
echo ""

# Show inclusivity features
print_header "Step 4: Platform Inclusivity Features"
show_inclusivity_features
echo ""

# Summary
print_header "Inclusivity Demo Summary"
echo "✅ Low-tech supplier data created successfully"
echo "✅ Manual data entry process demonstrated"
echo "✅ File upload for simple CSV data shown"
echo "✅ Platform inclusivity features highlighted"
echo ""
echo "🎉 Inclusivity demo completed successfully!"
echo ""
echo "The ESG Intelligence Platform ensures that even suppliers"
echo "with limited technical capabilities can participate in the"
echo "ESG verification ecosystem through simple file uploads."

# Clean up
rm -f supplier_data_manual.csv