#!/usr/bin/env python3
"""
Demo script for the PyTorch-based Scope 3 Anomaly Detection Tool

This script demonstrates the functionality of the Scope3AnomalyPredictorTool
with sample ESG data.
"""

import sys
import os
from datetime import datetime, timedelta

# Add the src directory to the path so we can import modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

try:
    from src.tools.esg import Scope3AnomalyPredictorTool
    TORCH_AVAILABLE = True
    print("✅ PyTorch is available")
except ImportError as e:
    TORCH_AVAILABLE = False
    print(f"❌ PyTorch is not available: {e}")
    print("Please install PyTorch to use the anomaly detection tool")


def create_sample_data():
    """Create sample Scope 3 ESG data for demonstration."""
    base_time = datetime(2023, 1, 1)
    data_points = []
    
    # Create normal data points
    for i in range(20):
        timestamp = (base_time + timedelta(days=i)).isoformat() + "Z"
        # Normal values around 100 with some variation
        value = 100 + (i % 5) * 2 - 2  # Small variation
        
        data_points.append({
            "timestamp": timestamp,
            "value": value,
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.95
        })
    
    # Add some anomalies
    anomaly_indices = [5, 12, 18]
    for idx in anomaly_indices:
        data_points[idx]["value"] = data_points[idx]["value"] * 3  # Make it 3x larger
        data_points[idx]["confidence_score"] = 0.3  # Lower confidence
    
    return data_points


def main():
    """Main function to run the anomaly detection demo."""
    print("🔍 Scope 3 Anomaly Detection Demo")
    print("=" * 50)
    
    if not TORCH_AVAILABLE:
        print("PyTorch is required for this demo but is not available.")
        return
    
    try:
        # Create the anomaly detection tool
        print("Initializing Scope 3 Anomaly Predictor Tool...")
        tool = Scope3AnomalyPredictorTool()
        print(f"✅ Tool initialized successfully (using {tool.device})")
        
        # Create sample data
        print("\nCreating sample Scope 3 ESG data...")
        sample_data = create_sample_data()
        print(f"✅ Created {len(sample_data)} data points")
        
        # Show some sample data points
        print("\nSample data points:")
        for i in range(min(5, len(sample_data))):
            dp = sample_data[i]
            status = "🚨 ANOMALY" if i in [5, 12, 18] else "  normal"
            print(f"  {dp['timestamp']}: {dp['value']:.2f} ({status})")
        
        # Run anomaly detection
        print("\n🔍 Detecting anomalies...")
        result = tool.run(sample_data)
        
        if not result["success"]:
            print(f"❌ Anomaly detection failed: {result.get('error', 'Unknown error')}")
            return
        
        # Display results
        print(f"✅ Anomaly detection completed!")
        print(f"   Total data points: {result['total_points']}")
        print(f"   Anomalies detected: {result['anomaly_count']}")
        print(f"   Anomaly percentage: {result['anomaly_percentage']:.2f}%")
        print(f"   Device used: {result['device']}")
        
        # Show detailed results
        print("\nDetailed results:")
        anomalies = [r for r in result["results"] if r["is_anomaly"]]
        if anomalies:
            print("   Anomalous data points:")
            for anomaly in anomalies[:5]:  # Show first 5 anomalies
                print(f"     🚨 {anomaly['timestamp']}: Value={anomaly['value']:.2f}, "
                      f"Score={anomaly['anomaly_score']:.3f}, Confidence={anomaly['confidence']:.2f}")
        else:
            print("   No anomalies detected in this sample")
        
        # Show normal points
        normals = [r for r in result["results"] if not r["is_anomaly"]]
        print(f"\n   Normal data points: {len(normals)}")
        if normals:
            print("   Sample normal points:")
            for normal in normals[:3]:  # Show first 3 normal points
                print(f"     ✅ {normal['timestamp']}: Value={normal['value']:.2f}, "
                      f"Score={normal['anomaly_score']:.3f}")
        
    except Exception as e:
        print(f"❌ Demo failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()