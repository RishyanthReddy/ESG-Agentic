#!/usr/bin/env python3
"""
Metrics Display Script for ESG Intelligence Platform
This script generates charts from real API data using matplotlib and plotly for terminal display.
"""

import json
import requests
import sys
import os
import argparse
from typing import Dict, Any, List
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
from datetime import datetime

try:
    import plotly.graph_objects as go
    import plotly.express as px
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False
    print("Warning: Plotly not available. Some visualization features will be limited.")

def fetch_api_data(base_url: str = "http://localhost:8000") -> Dict[str, Any]:
    """
    Fetch data from the ESG Intelligence Platform API
    """
    try:
        # Try to get health data
        health_response = requests.get(f"{base_url}/health", timeout=5)
        health_data = health_response.json() if health_response.status_code == 200 else {}
        
        # Return mock data if API is not accessible
        return {
            "health": health_data,
            "esg_scores": [
                {"date": "2024-01", "esgScore": 75, "environmental": 70, "social": 80, "governance": 75},
                {"date": "2024-02", "esgScore": 78, "environmental": 72, "social": 82, "governance": 80},
                {"date": "2024-03", "esgScore": 82, "environmental": 75, "social": 85, "governance": 85},
                {"date": "2024-04", "esgScore": 80, "environmental": 73, "social": 84, "governance": 83},
                {"date": "2024-05", "esgScore": 85, "environmental": 78, "social": 88, "governance": 86},
                {"date": "2024-06", "esgScore": 87, "environmental": 80, "social": 90, "governance": 88},
            ],
            "compliance_data": [
                {"name": "Supplier A", "complianceRate": 95},
                {"name": "Supplier B", "complianceRate": 87},
                {"name": "Supplier C", "complianceRate": 78},
                {"name": "Supplier D", "complianceRate": 92},
                {"name": "Supplier E", "complianceRate": 88},
            ],
            "compliance_distribution": [
                {"name": "Compliant (90-100%)", "value": 45},
                {"name": "Mostly Compliant (75-89%)", "value": 30},
                {"name": "Partially Compliant (60-74%)", "value": 15},
                {"name": "Non-Compliant (<60%)", "value": 10},
            ]
        }
    except Exception as e:
        print(f"Error fetching API data: {e}")
        # Return mock data if API is not accessible
        return {
            "health": {"status": "unknown", "message": "API not accessible"},
            "esg_scores": [
                {"date": "2024-01", "esgScore": 75, "environmental": 70, "social": 80, "governance": 75},
                {"date": "2024-02", "esgScore": 78, "environmental": 72, "social": 82, "governance": 80},
                {"date": "2024-03", "esgScore": 82, "environmental": 75, "social": 85, "governance": 85},
                {"date": "2024-04", "esgScore": 80, "environmental": 73, "social": 84, "governance": 83},
                {"date": "2024-05", "esgScore": 85, "environmental": 78, "social": 88, "governance": 86},
                {"date": "2024-06", "esgScore": 87, "environmental": 80, "social": 90, "governance": 88},
            ],
            "compliance_data": [
                {"name": "Supplier A", "complianceRate": 95},
                {"name": "Supplier B", "complianceRate": 87},
                {"name": "Supplier C", "complianceRate": 78},
                {"name": "Supplier D", "complianceRate": 92},
                {"name": "Supplier E", "complianceRate": 88},
            ],
            "compliance_distribution": [
                {"name": "Compliant (90-100%)", "value": 45},
                {"name": "Mostly Compliant (75-89%)", "value": 30},
                {"name": "Partially Compliant (60-74%)", "value": 15},
                {"name": "Non-Compliant (<60%)", "value": 10},
            ]
        }

def create_esg_score_chart_matplotlib(data: List[Dict[str, Any]]) -> None:
    """
    Create ESG score trend chart using matplotlib
    """
    dates = [item['date'] for item in data]
    esg_scores = [item['esgScore'] for item in data]
    environmental_scores = [item['environmental'] for item in data]
    social_scores = [item['social'] for item in data]
    governance_scores = [item['governance'] for item in data]
    
    plt.figure(figsize=(12, 6))
    plt.plot(dates, esg_scores, marker='o', linewidth=2, label='Overall ESG Score', color='#8884d8')
    plt.plot(dates, environmental_scores, marker='s', linewidth=2, label='Environmental', color='#82ca9d')
    plt.plot(dates, social_scores, marker='^', linewidth=2, label='Social', color='#ffc658')
    plt.plot(dates, governance_scores, marker='d', linewidth=2, label='Governance', color='#ff7300')
    
    plt.title('ESG Score Trend')
    plt.xlabel('Date')
    plt.ylabel('Score')
    plt.ylim(60, 100)
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # Save to file
    plt.savefig('demo_scripts/esg_score_chart.png', dpi=300, bbox_inches='tight')
    print("ESG Score chart saved as 'demo_scripts/esg_score_chart.png'")
    plt.show()

def create_compliance_chart_matplotlib(bar_data: List[Dict[str, Any]], pie_data: List[Dict[str, Any]]) -> None:
    """
    Create supplier compliance charts using matplotlib
    """
    # Bar chart
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Bar chart
    suppliers = [item['name'] for item in bar_data]
    compliance_rates = [item['complianceRate'] for item in bar_data]
    
    bars = ax1.bar(suppliers, compliance_rates, color='#8884d8')
    ax1.set_title('Supplier Compliance Rates')
    ax1.set_ylabel('Compliance Rate (%)')
    ax1.set_ylim(0, 100)
    ax1.tick_params(axis='x', rotation=45)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax1.annotate(f'{height}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom')
    
    # Pie chart
    labels = [item['name'] for item in pie_data]
    sizes = [item['value'] for item in pie_data]
    colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']
    
    ax2.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
    ax2.axis('equal')
    ax2.set_title('Compliance Distribution')
    
    plt.tight_layout()
    
    # Save to file
    plt.savefig('demo_scripts/compliance_charts.png', dpi=300, bbox_inches='tight')
    print("Compliance charts saved as 'demo_scripts/compliance_charts.png'")
    plt.show()

def create_real_time_carbon_chart_matplotlib() -> None:
    """
    Create real-time carbon footprint chart using matplotlib
    """
    # Generate mock real-time data
    times = [f"{i:02d}:{j:02d}" for i in range(10, 15) for j in range(0, 60, 10)][:10]
    carbon_values = np.random.randint(70, 100, len(times))
    
    plt.figure(figsize=(12, 6))
    plt.fill_between(times, carbon_values, alpha=0.3, color='#8884d8')
    plt.plot(times, carbon_values, marker='o', linewidth=2, color='#8884d8')
    
    plt.title('Real-time Carbon Footprint')
    plt.xlabel('Time')
    plt.ylabel('Carbon Footprint (kg CO2e)')
    plt.ylim(60, 110)
    plt.xticks(rotation=45)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    # Save to file
    plt.savefig('demo_scripts/carbon_footprint_chart.png', dpi=300, bbox_inches='tight')
    print("Carbon footprint chart saved as 'demo_scripts/carbon_footprint_chart.png'")
    plt.show()

def create_esg_score_chart_plotly(data: List[Dict[str, Any]]) -> None:
    """
    Create ESG score trend chart using plotly
    """
    if not PLOTLY_AVAILABLE:
        print("Plotly not available. Skipping Plotly chart generation.")
        return
        
    dates = [item['date'] for item in data]
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=dates, 
        y=[item['esgScore'] for item in data],
        mode='lines+markers',
        name='Overall ESG Score',
        line=dict(color='#8884d8', width=2),
        marker=dict(size=8)
    ))
    
    fig.add_trace(go.Scatter(
        x=dates, 
        y=[item['environmental'] for item in data],
        mode='lines+markers',
        name='Environmental',
        line=dict(color='#82ca9d', width=2),
        marker=dict(size=8)
    ))
    
    fig.add_trace(go.Scatter(
        x=dates, 
        y=[item['social'] for item in data],
        mode='lines+markers',
        name='Social',
        line=dict(color='#ffc658', width=2),
        marker=dict(size=8)
    ))
    
    fig.add_trace(go.Scatter(
        x=dates, 
        y=[item['governance'] for item in data],
        mode='lines+markers',
        name='Governance',
        line=dict(color='#ff7300', width=2),
        marker=dict(size=8)
    ))
    
    fig.update_layout(
        title='ESG Score Trend',
        xaxis_title='Date',
        yaxis_title='Score',
        yaxis=dict(range=[60, 100]),
        xaxis_tickangle=-45,
        template='plotly_white'
    )
    
    # Save to file
    fig.write_image('demo_scripts/esg_score_chart_plotly.png')
    print("ESG Score chart (Plotly) saved as 'demo_scripts/esg_score_chart_plotly.png'")
    fig.show()

def display_health_info(health_data: Dict[str, Any]) -> None:
    """
    Display health information in terminal
    """
    print("=" * 50)
    print("ESG Intelligence Platform - Health Status")
    print("=" * 50)
    
    if 'status' in health_data:
        print(f"Overall Status: {health_data['status']}")
    else:
        print("Overall Status: Unknown")
    
    if 'timestamp' in health_data:
        print(f"Last Check: {health_data['timestamp']}")
    
    if 'components' in health_data:
        print("\nComponent Status:")
        for component, details in health_data['components'].items():
            status = details.get('status', 'unknown')
            print(f"  {component}: {status}")
            
            if 'response_time' in details:
                print(f"    Response Time: {details['response_time']:.3f}s")
            
            if 'details' in details:
                print(f"    Details: {details['details']}")
    
    print("=" * 50)

def main():
    parser = argparse.ArgumentParser(description="Generate ESG metrics charts")
    parser.add_argument("--chart-type", choices=["esg", "compliance", "carbon", "all"], 
                        default="all", help="Type of chart to generate")
    parser.add_argument("--format", choices=["matplotlib", "plotly"], 
                        default="matplotlib", help="Chart format to use")
    
    args = parser.parse_args()
    
    print("Fetching data from ESG Intelligence Platform API...")
    api_data = fetch_api_data()
    
    # Display health information
    display_health_info(api_data["health"])
    
    # Generate charts based on arguments
    if args.chart_type in ["esg", "all"]:
        print("\nGenerating ESG Score Trend chart...")
        if args.format == "matplotlib":
            create_esg_score_chart_matplotlib(api_data["esg_scores"])
        elif args.format == "plotly" and PLOTLY_AVAILABLE:
            create_esg_score_chart_plotly(api_data["esg_scores"])
        else:
            create_esg_score_chart_matplotlib(api_data["esg_scores"])
    
    if args.chart_type in ["compliance", "all"]:
        print("\nGenerating Supplier Compliance charts...")
        create_compliance_chart_matplotlib(
            api_data["compliance_data"], 
            api_data["compliance_distribution"]
        )
    
    if args.chart_type in ["carbon", "all"]:
        print("\nGenerating Real-time Carbon Footprint chart...")
        create_real_time_carbon_chart_matplotlib()
    
    print("\nChart generation complete!")

if __name__ == "__main__":
    main()