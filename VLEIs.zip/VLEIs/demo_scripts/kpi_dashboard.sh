#!/bin/bash

# KPI Dashboard Script for ESG Intelligence Platform
# This script fetches and displays key metrics in formatted terminal output

echo "=================================================="
echo "     ESG Intelligence Platform - KPI Dashboard    "
echo "=================================================="
echo ""

# Check if jq is installed
if ! command -v jq &> /dev/null
then
    echo "jq is required but not installed. Please install jq to run this script."
    exit 1
fi

# Check if curl is installed
if ! command -v curl &> /dev/null
then
    echo "curl is required but not installed. Please install curl to run this script."
    exit 1
fi

# Function to print a section header
print_header() {
    echo "--------------------------------------------------"
    echo "$1"
    echo "--------------------------------------------------"
}

# Function to print a metric with formatting
print_metric() {
    printf "%-30s %s\n" "$1" "$2"
}

# Fetch system health
print_header "System Health Status"
HEALTH_RESPONSE=$(curl -s -X GET http://localhost:8000/health)
HEALTH_STATUS=$(echo "$HEALTH_RESPONSE" | jq -r '.status')

if [ "$HEALTH_STATUS" = "healthy" ]; then
    echo "✓ System Status: $HEALTH_STATUS"
elif [ "$HEALTH_STATUS" = "degraded" ]; then
    echo "! System Status: $HEALTH_STATUS"
else
    echo "✗ System Status: $HEALTH_STATUS"
fi

echo ""

# Display component statuses
echo "Component Statuses:"
echo "$HEALTH_RESPONSE" | jq -r '.components | to_entries[] | "  \(.key): \(.value.status) \(.value.response_time // empty | "(\(.))s" // empty)"'

echo ""
echo ""

# Fetch recent reports (mock data for now)
print_header "Recent Reports Summary"
print_metric "Reports Processed (24h):" "24"
print_metric "Avg. Processing Time:" "2.3s"
print_metric "Success Rate:" "98.5%"

echo ""
echo ""

# Display ESG Metrics (mock data for now)
print_header "ESG Performance Metrics"
print_metric "Avg. ESG Score:" "82.4"
print_metric "Environmental Score:" "78.9"
print_metric "Social Score:" "85.2"
print_metric "Governance Score:" "83.1"

echo ""
echo ""

# Display Compliance Metrics (mock data for now)
print_header "Compliance Metrics"
print_metric "Overall Compliance Rate:" "91.7%"
print_metric "Suppliers Compliant:" "87/95"
print_metric "Pending Reviews:" "3"

echo ""
echo ""

# Display Carbon Metrics (mock data for now)
print_header "Carbon Footprint Metrics"
print_metric "Current Footprint:" "84.2 kg CO2e"
print_metric "Target Reduction:" "15% YoY"
print_metric "Offset Credits:" "1,240 tCO2e"

echo ""
echo "=================================================="
echo "              Dashboard Updated Successfully      "
echo "=================================================="