#!/bin/bash

# Full System Status Check for ESG Intelligence Platform
# This script checks all critical endpoints and displays system readiness

echo "ESG Intelligence Platform - Full System Status Check"
echo "==================================================="

# Check if jq is installed
if ! command -v jq &> /dev/null
then
    echo "jq is required but not installed. Please install jq to run this script."
    exit 1
fi

# Check if the API is running
echo "1. Checking API availability..."
if curl -s -f http://localhost:8000/ > /dev/null; then
    echo "   ✓ API is running"
else
    echo "   ✗ API is not accessible"
    exit 1
fi

# Check health endpoint
echo "2. Checking system health..."
HEALTH_RESPONSE=$(curl -s -X GET http://localhost:8000/health)
HEALTH_STATUS=$(echo "$HEALTH_RESPONSE" | jq -r '.status')

if [ "$HEALTH_STATUS" = "healthy" ]; then
    echo "   ✓ System health: $HEALTH_STATUS"
else
    echo "   ⚠ System health: $HEALTH_STATUS"
fi

# Display component statuses
echo "3. Component status details:"
echo "$HEALTH_RESPONSE" | jq -r '.components | to_entries[] | "   \(.key): \(.value.status) \(.value.response_time // empty | "(\(.))s" // empty)"'

# Test data ingestion endpoint
echo "4. Checking data ingestion endpoint..."
if curl -s -f -X POST http://localhost:8000/ingest/json -H "Content-Type: application/json" -d '{"supplier_data": {}}' > /dev/null; then
    echo "   ✓ JSON ingestion endpoint accessible"
else
    echo "   ⚠ JSON ingestion endpoint not responding as expected"
fi

# Test file upload endpoint
echo "5. Checking file upload endpoint..."
if curl -s -f -X POST http://localhost:8000/ingest/file -F "file=@/dev/null" > /dev/null; then
    echo "   ✓ File upload endpoint accessible"
else
    echo "   ⚠ File upload endpoint not responding as expected"
fi

# Test verification endpoint (with a dummy ID)
echo "6. Checking verification endpoint..."
if curl -s -f http://localhost:8000/verify/dummy_id > /dev/null; then
    echo "   ✓ Verification endpoint accessible"
else
    echo "   ⚠ Verification endpoint not responding as expected"
fi

echo ""
echo "Full system status check completed."