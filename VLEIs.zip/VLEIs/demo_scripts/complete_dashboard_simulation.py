#!/usr/bin/env python3
"""
Complete Dashboard Simulation Script for ESG Intelligence Platform
This script orchestrates all demo scripts to simulate full dashboard experience.
"""

import json
import time
import argparse
import subprocess
import sys
import threading
from datetime import datetime
from typing import Dict, Any

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")

class DashboardSimulator:
    def __init__(self):
        self.console = Console() if RICH_AVAILABLE else None
        self.data = {}
        self.running = False
        
    def run_script(self, script_name: str, args: list = None) -> Dict[str, Any]:
        """Run a demo script and capture its output"""
        try:
            script_path = f"demo_scripts/{script_name}"
            cmd = [sys.executable, script_path] + (args or [])
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                return {
                    "success": True,
                    "output": result.stdout,
                    "error": None
                }
            else:
                return {
                    "success": False,
                    "output": result.stdout,
                    "error": result.stderr
                }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "output": "",
                "error": f"Script {script_name} timed out"
            }
        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e)
            }
    
    def simulate_overview_tab(self):
        """Simulate the overview dashboard tab"""
        if not RICH_AVAILABLE:
            print("=== ESG Intelligence Platform - Overview ===")
            print()
            
            # Run metrics display
            result = self.run_script("metrics_display.py", ["--format", "text"])
            if result["success"]:
                print("Metrics Display:")
                print(result["output"])
            else:
                print(f"Error running metrics display: {result['error']}")
            
            # Run metrics summary
            result = self.run_script("metrics_summary.py", ["--format", "text"])
            if result["success"]:
                print("Metrics Summary:")
                print(result["output"])
            else:
                print(f"Error running metrics summary: {result['error']}")
                
            return
        
        # Rich version
        self.console.print(Panel("[bold blue]ESG Intelligence Platform - Dashboard Overview[/bold blue]"))
        
        # Create layout
        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main", ratio=1),
            Layout(name="footer", size=3)
        )
        
        layout["main"].split_row(
            Layout(name="left"),
            Layout(name="right")
        )
        
        # Header
        layout["header"].update(Panel("Dashboard Overview", style="bold white on blue"))
        
        # Left panel - System metrics
        metrics_result = self.run_script("metrics_summary.py", ["--format", "json"])
        if metrics_result["success"]:
            try:
                metrics_data = json.loads(metrics_result["output"])
                metrics_table = Table(title="System Metrics")
                metrics_table.add_column("Metric", style="cyan")
                metrics_table.add_column("Value", style="green")
                
                for key, value in metrics_data.get("system_health", {}).items():
                    metrics_table.add_row(key.replace("_", " ").title(), str(value))
                    
                layout["left"].update(metrics_table)
            except json.JSONDecodeError:
                layout["left"].update(Panel("Error parsing metrics data", style="red"))
        else:
            layout["left"].update(Panel(f"Error: {metrics_result['error']}", style="red"))
        
        # Right panel - KPIs
        kpi_result = self.run_script("kpi_dashboard.sh")
        if kpi_result["success"]:
            layout["right"].update(Panel(kpi_result["output"], title="Key Performance Indicators"))
        else:
            layout["right"].update(Panel(f"Error: {kpi_result['error']}", style="red"))
        
        # Footer
        layout["footer"].update(Panel("Use arrow keys to navigate, 'q' to quit", style="italic"))
        
        self.console.print(layout)
    
    def simulate_metrics_tab(self):
        """Simulate the real-time metrics tab"""
        if not RICH_AVAILABLE:
            print("=== ESG Intelligence Platform - Real-time Metrics ===")
            print()
            
            # Run live metrics stream for a short duration
            result = self.run_script("live_metrics_stream.py", ["--duration", "10", "--simple"])
            if result["success"]:
                print("Live Metrics Stream:")
                print(result["output"])
            else:
                print(f"Error running live metrics stream: {result['error']}")
                
            return
        
        # Rich version
        self.console.print(Panel("[bold blue]ESG Intelligence Platform - Real-time Metrics[/bold blue]"))
        print("Starting live metrics stream for 10 seconds...")
        
        # Run the live metrics stream script
        result = self.run_script("live_metrics_stream.py", ["--duration", "10"])
        if result["success"]:
            print(result["output"])
        else:
            print(f"Error: {result['error']}")
    
    def simulate_visualizations_tab(self):
        """Simulate the visualizations tab"""
        if not RICH_AVAILABLE:
            print("=== ESG Intelligence Platform - Visualizations ===")
            print()
            
            # Run graph visualization
            result = self.run_script("graph_visualizer.py")
            if result["success"]:
                print("Graph Visualization:")
                print("Graph visualization saved to demo_scripts/graph_visualization.png")
            else:
                print(f"Error running graph visualizer: {result['error']}")
            
            # Run chart data export
            result = self.run_script("chart_data_export.py")
            if result["success"]:
                print("Chart Exports:")
                print("Charts exported to demo_scripts/ directory")
            else:
                print(f"Error running chart data export: {result['error']}")
                
            return
        
        # Rich version
        self.console.print(Panel("[bold blue]ESG Intelligence Platform - Visualizations[/bold blue]"))
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            # Graph visualization task
            task1 = progress.add_task("Generating graph visualization...", total=None)
            graph_result = self.run_script("graph_visualizer.py")
            progress.update(task1, completed=True)
            
            # Chart export task
            task2 = progress.add_task("Exporting charts...", total=None)
            chart_result = self.run_script("chart_data_export.py")
            progress.update(task2, completed=True)
        
        if graph_result["success"]:
            self.console.print("[green]✓[/green] Graph visualization saved to demo_scripts/graph_visualization.png")
        else:
            self.console.print(f"[red]✗[/red] Error generating graph: {graph_result['error']}")
            
        if chart_result["success"]:
            self.console.print("[green]✓[/green] Charts exported to demo_scripts/ directory")
        else:
            self.console.print(f"[red]✗[/red] Error exporting charts: {chart_result['error']}")
    
    def simulate_provenance_tab(self):
        """Simulate the provenance graph tab"""
        if not RICH_AVAILABLE:
            print("=== ESG Intelligence Platform - Provenance Graph ===")
            print()
            
            # Run provenance trace
            result = self.run_script("provenance_trace.py", ["--source", "1", "--target", "6"])
            if result["success"]:
                print("Provenance Trace:")
                print(result["output"])
            else:
                print(f"Error running provenance trace: {result['error']}")
                
            return
        
        # Rich version
        self.console.print(Panel("[bold blue]ESG Intelligence Platform - Provenance Graph[/bold blue]"))
        
        # Run provenance trace
        result = self.run_script("provenance_trace.py", ["--source", "1", "--target", "6"])
        if result["success"]:
            self.console.print(Panel(result["output"], title="Supply Chain Provenance Trace"))
        else:
            self.console.print(f"[red]Error: {result['error']}[/red]")
    
    def run_full_simulation(self):
        """Run a complete simulation of the dashboard experience"""
        if not RICH_AVAILABLE:
            print("ESG Intelligence Platform - Complete Dashboard Simulation")
            print("=" * 60)
            print()
            
            print("1. Overview Tab")
            print("-" * 20)
            self.simulate_overview_tab()
            print()
            
            print("2. Metrics Tab")
            print("-" * 20)
            self.simulate_metrics_tab()
            print()
            
            print("3. Visualizations Tab")
            print("-" * 20)
            self.simulate_visualizations_tab()
            print()
            
            print("4. Provenance Tab")
            print("-" * 20)
            self.simulate_provenance_tab()
            print()
            
            print("Dashboard simulation complete!")
            return
        
        # Rich version
        self.console.print(Panel("[bold blue]ESG Intelligence Platform - Complete Dashboard Simulation[/bold blue]"))
        
        tabs = [
            ("Overview", self.simulate_overview_tab),
            ("Metrics", self.simulate_metrics_tab),
            ("Visualizations", self.simulate_visualizations_tab),
            ("Provenance", self.simulate_provenance_tab)
        ]
        
        for tab_name, tab_function in tabs:
            self.console.print(f"\n[bold underline]{tab_name} Tab[/bold underline]")
            tab_function()
            time.sleep(2)  # Pause between tabs
        
        self.console.print("\n[green]Dashboard simulation complete![/green]")

def main():
    parser = argparse.ArgumentParser(description="Simulate the complete ESG dashboard experience in terminal")
    parser.add_argument("--tab", choices=["overview", "metrics", "visualizations", "provenance"], 
                        help="Run simulation for a specific tab only")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    simulator = DashboardSimulator()
    
    if args.simple or not RICH_AVAILABLE:
        # Force simple mode if rich is not available
        RICH_AVAILABLE = False if args.simple else RICH_AVAILABLE
    
    try:
        if args.tab:
            # Run specific tab simulation
            if args.tab == "overview":
                simulator.simulate_overview_tab()
            elif args.tab == "metrics":
                simulator.simulate_metrics_tab()
            elif args.tab == "visualizations":
                simulator.simulate_visualizations_tab()
            elif args.tab == "provenance":
                simulator.simulate_provenance_tab()
        else:
            # Run full simulation
            simulator.run_full_simulation()
    except KeyboardInterrupt:
        print("\n\nDashboard simulation stopped.")
    except Exception as e:
        print(f"Error during simulation: {e}")

if __name__ == "__main__":
    main()