#!/usr/bin/env python3
"""
Provenance Trace Script for ESG Intelligence Platform
This script demonstrates path highlighting using terminal output and real API calls.
"""

import json
import requests
import argparse
from typing import Dict, Any, List
import networkx as nx
from collections import deque
import sys

# Handle encoding issues on Windows
if sys.platform.startswith('win'):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def fetch_provenance_data(base_url: str = "http://localhost:8000") -> Dict[str, Any]:
    """
    Fetch provenance data from the ESG Intelligence Platform API
    """
    try:
        # In a real implementation, we would fetch actual provenance data
        # For now, we'll use mock data
        return {
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil"},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China"},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany"},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands"},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA"},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA"},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0},
            ],
            "product": {
                "id": "PRODUCT-001",
                "name": "Sustainable Wood Table",
                "esg_score": 85,
                "certifications": ["FSC", "CARB", "GREENGUARD"]
            }
        }
    except Exception as e:
        print(f"Error fetching provenance data: {e}")
        # Return mock data if API is not accessible
        return {
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil"},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China"},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany"},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands"},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA"},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA"},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0},
            ],
            "product": {
                "id": "PRODUCT-001",
                "name": "Sustainable Wood Table",
                "esg_score": 85,
                "certifications": ["FSC", "CARB", "GREENGUARD"]
            }
        }

def create_graph(data: Dict[str, Any]) -> nx.DiGraph:
    """
    Create a directed graph from the provenance data
    """
    G = nx.DiGraph()
    
    # Add nodes
    for node in data["nodes"]:
        G.add_node(
            node["id"],
            name=node["name"],
            type=node["type"],
            location=node["location"]
        )
    
    # Add edges
    for edge in data["edges"]:
        G.add_edge(
            edge["source"],
            edge["target"],
            type=edge["type"],
            date=edge["date"],
            co2_emissions=edge["co2_emissions"]
        )
    
    return G

def find_paths(G: nx.DiGraph, source: str, target: str) -> List[List[str]]:
    """
    Find all paths between source and target nodes
    """
    try:
        # Find all simple paths
        paths = list(nx.all_simple_paths(G, source, target))
        return paths
    except nx.NetworkXNoPath:
        return []

def highlight_path_terminal(G: nx.DiGraph, path: List[str], data: Dict[str, Any]) -> None:
    """
    Highlight a path in the terminal output
    """
    print("=" * 60)
    print("ESG INTELLIGENCE PLATFORM - PROVENANCE TRACE")
    print("=" * 60)
    
    # Display product information
    product = data["product"]
    print(f"Product: {product['name']} ({product['id']})")
    print(f"ESG Score: {product['esg_score']}/100")
    print(f"Certifications: {', '.join(product['certifications'])}")
    print()
    
    print("Supply Chain Path:")
    print("-" * 30)
    
    total_co2 = 0
    for i, node_id in enumerate(path):
        node = G.nodes[node_id]
        print(f"{i+1}. {node['name']}")
        print(f"   Type: {node['type'].capitalize()}")
        print(f"   Location: {node['location']}")
        
        # Show edge information if not the last node
        if i < len(path) - 1:
            next_node_id = path[i+1]
            edge_data = G.get_edge_data(node_id, next_node_id)
            if edge_data:
                print(f"   -> Shipment Date: {edge_data['date']}")
                print(f"   -> CO2 Emissions: {edge_data['co2_emissions']} kg")
                total_co2 += edge_data['co2_emissions']
                print(f"   -> Transport Type: {edge_data['type'].capitalize()}")
        
        print()
    
    print("-" * 30)
    print(f"Total Supply Chain CO2 Emissions: {total_co2:.2f} kg")
    print("=" * 60)

def display_graph_overview(G: nx.DiGraph, data: Dict[str, Any]) -> None:
    """
    Display an overview of the graph
    """
    print("\n" + "=" * 60)
    print("GRAPH OVERVIEW")
    print("=" * 60)
    print(f"Total Nodes: {G.number_of_nodes()}")
    print(f"Total Edges: {G.number_of_edges()}")
    print()
    
    print("Node Types:")
    node_types = {}
    for node, attrs in G.nodes(data=True):
        node_type = attrs.get("type", "unknown")
        node_types[node_type] = node_types.get(node_type, 0) + 1
    
    for node_type, count in node_types.items():
        print(f"  {node_type.capitalize()}: {count}")
    
    print()
    print("Edge Types:")
    edge_types = {}
    for source, target, attrs in G.edges(data=True):
        edge_type = attrs.get("type", "unknown")
        edge_types[edge_type] = edge_types.get(edge_type, 0) + 1
    
    for edge_type, count in edge_types.items():
        print(f"  {edge_type.capitalize()}: {count}")

def main():
    parser = argparse.ArgumentParser(description="Trace product provenance using terminal output")
    parser.add_argument("--source", default="1", help="Source node ID (default: 1)")
    parser.add_argument("--target", default="6", help="Target node ID (default: 6)")
    parser.add_argument("--overview", action="store_true", help="Display graph overview")
    
    args = parser.parse_args()
    
    print("Fetching provenance data from ESG Intelligence Platform API...")
    data = fetch_provenance_data()
    
    # Create graph
    G = create_graph(data)
    
    # Display overview if requested
    if args.overview:
        display_graph_overview(G, data)
    
    # Find paths
    paths = find_paths(G, args.source, args.target)
    
    if not paths:
        print(f"No path found from node {args.source} to node {args.target}")
        return
    
    print(f"Found {len(paths)} path(s) from node {args.source} to node {args.target}")
    
    # Highlight the first path
    highlight_path_terminal(G, paths[0], data)
    
    # If there are multiple paths, list them
    if len(paths) > 1:
        print(f"\nAlternative paths:")
        for i, path in enumerate(paths[1:], 2):
            node_names = [G.nodes[node_id]["name"] for node_id in path]
            print(f"  {i}. {' -> '.join(node_names)}")

if __name__ == "__main__":
    main()