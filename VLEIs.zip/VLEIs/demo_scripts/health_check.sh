#!/bin/bash

# Health Check Script for ESG Intelligence Platform
# This script checks the health status of the API and formats the output with jq

echo "Checking ESG Intelligence Platform Health Status..."
echo "=================================================="

# Make API call to health endpoint and format with jq
curl -s -X GET http://localhost:8000/health | jq '{
  status: .status,
  timestamp: .timestamp,
  components: .components | with_entries({
    key: .key,
    value: {
      status: .value.status,
      response_time: .value.response_time,
      details: .value.details
    }
  })
}'

echo ""
echo "Health check completed."