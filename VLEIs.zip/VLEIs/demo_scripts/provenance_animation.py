#!/usr/bin/env python3
"""
Provenance Animation Script for ESG Intelligence Platform
This script simulates path animation using time-delayed API calls.
"""

import json
import requests
import argparse
import sys
import time
from typing import Dict, Any, List
import networkx as nx
from collections import deque

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich.live import Live
    from rich.layout import Layout
    from rich.text import Text
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


def fetch_graph_data(base_url: str = "http://localhost:8000") -> Dict[str, Any]:
    """
    Fetch graph data from the ESG Intelligence Platform API
    """
    try:
        # In a real implementation, this would call the actual API endpoint
        # For now, we'll use mock data
        return {
            "nodes": [
                {"id": "1", "name": "Raw Material Supplier", "type": "supplier", "location": "Brazil"},
                {"id": "2", "name": "Processing Plant", "type": "manufacturer", "location": "China"},
                {"id": "3", "name": "Quality Control Center", "type": "qc", "location": "Germany"},
                {"id": "4", "name": "Distribution Hub", "type": "distributor", "location": "Netherlands"},
                {"id": "5", "name": "Retail Store", "type": "retailer", "location": "USA"},
                {"id": "6", "name": "End Consumer", "type": "consumer", "location": "USA"},
            ],
            "edges": [
                {"source": "1", "target": "2", "type": "shipment", "date": "2024-01-15", "co2_emissions": 120.5},
                {"source": "2", "target": "3", "type": "shipment", "date": "2024-02-03", "co2_emissions": 85.2},
                {"source": "3", "target": "4", "type": "shipment", "date": "2024-02-20", "co2_emissions": 45.7},
                {"source": "4", "target": "5", "type": "shipment", "date": "2024-03-05", "co2_emissions": 12.3},
                {"source": "5", "target": "6", "type": "purchase", "date": "2024-03-15", "co2_emissions": 0.0},
            ]
        }
    except Exception as e:
        print(f"Error fetching graph data: {e}")
        return {}


def find_shortest_path(graph_data: Dict[str, Any], source: str, target: str) -> List[str]:
    """
    Find the shortest path between source and target nodes using BFS
    """
    # Create a graph from the data
    G = nx.Graph()
    
    # Add nodes
    for node in graph_data.get("nodes", []):
        G.add_node(node["id"], **node)
    
    # Add edges
    for edge in graph_data.get("edges", []):
        G.add_edge(edge["source"], edge["target"], **edge)
    
    try:
        # Find shortest path
        path = nx.shortest_path(G, source, target)
        return path
    except nx.NetworkXNoPath:
        return []
    except Exception as e:
        print(f"Error finding path: {e}")
        return []


def animate_path_traversal(graph_data: Dict[str, Any], path: List[str], delay: float = 1.0):
    """
    Animate the path traversal in terminal
    """
    if not path:
        print("No path to animate.")
        return
    
    # Create node lookup
    node_lookup = {node["id"]: node for node in graph_data.get("nodes", [])}
    edge_lookup = {}
    
    # Create edge lookup (source-target pair to edge data)
    for edge in graph_data.get("edges", []):
        edge_lookup[(edge["source"], edge["target"])] = edge
        edge_lookup[(edge["target"], edge["source"])] = edge  # For undirected graph
    
    if RICH_AVAILABLE:
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Path Animation[/bold blue]"))
        
        # Display the full path first
        console.print("[bold]Full Path:[/bold]")
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            if i == 0:
                console.print(f"[green]→ Start: {node_name} ({node_type})[/green]")
            elif i == len(path) - 1:
                console.print(f"[green]→ End: {node_name} ({node_type})[/green]")
            else:
                console.print(f"[cyan]→ {node_name} ({node_type})[/cyan]")
        
        console.print("\n[bold]Animating Path Traversal:[/bold]")
        
        # Animate traversal
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            # Highlight current node
            if i == 0:
                console.print(f"[bold green]→ Currently at Start: {node_name} ({node_type})[/bold green]")
            elif i == len(path) - 1:
                console.print(f"[bold green]→ Currently at End: {node_name} ({node_type})[/bold green]")
            else:
                console.print(f"[bold green]→ Currently at: {node_name} ({node_type})[/bold green]")
            
            # Display edge to next node if not the last node
            if i < len(path) - 1:
                next_node_id = path[i + 1]
                edge = edge_lookup.get((node_id, next_node_id), {})
                if edge:
                    edge_type = edge.get("type", "connection")
                    co2_emissions = edge.get("co2_emissions", 0)
                    date = edge.get("date", "N/A")
                    console.print(f"  [dim]├─ Moving via {edge_type} (Date: {date}, CO2: {co2_emissions} kg)[/dim]")
                
                # Wait before moving to next node
                time.sleep(delay)
                
                # Clear the current highlight for next iteration
                console.print(f"[green]→ Passed: {node_name} ({node_type})[/green]")
        
        console.print("\n[bold green]✅ Path traversal animation complete![/bold green]")
    else:
        # Simple text animation
        print("ESG Intelligence Platform - Path Animation")
        print("=" * 45)
        
        # Display the full path first
        print("Full Path:")
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            if i == 0:
                print(f"→ Start: {node_name} ({node_type})")
            elif i == len(path) - 1:
                print(f"→ End: {node_name} ({node_type})")
            else:
                print(f"→ {node_name} ({node_type})")
        
        print("\nAnimating Path Traversal:")
        
        # Animate traversal
        for i, node_id in enumerate(path):
            node = node_lookup.get(node_id, {})
            node_name = node.get("name", f"Node {node_id}")
            node_type = node.get("type", "unknown")
            
            # Highlight current node
            if i == 0:
                print(f"→ Currently at Start: {node_name} ({node_type})")
            elif i == len(path) - 1:
                print(f"→ Currently at End: {node_name} ({node_type})")
            else:
                print(f"→ Currently at: {node_name} ({node_type})")
            
            # Display edge to next node if not the last node
            if i < len(path) - 1:
                next_node_id = path[i + 1]
                edge = edge_lookup.get((node_id, next_node_id), {})
                if edge:
                    edge_type = edge.get("type", "connection")
                    co2_emissions = edge.get("co2_emissions", 0)
                    date = edge.get("date", "N/A")
                    print(f"  ├─ Moving via {edge_type} (Date: {date}, CO2: {co2_emissions} kg)")
                
                # Wait before moving to next node
                time.sleep(delay)
                
                # Clear the current highlight for next iteration
                print(f"→ Passed: {node_name} ({node_type})")
        
        print("\n✅ Path traversal animation complete!")


def main():
    parser = argparse.ArgumentParser(description="Animate path traversal in ESG supply chain")
    parser.add_argument("--source", type=str, default="1", help="Source node ID")
    parser.add_argument("--target", type=str, default="6", help="Target node ID")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between steps in seconds")
    parser.add_argument("--base-url", type=str, default="http://localhost:8000", help="Base URL for API calls")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Force simple mode if rich is not available
    use_rich = RICH_AVAILABLE and not args.simple
    
    # Fetch graph data
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Fetching graph data...", total=None)
            graph_data = fetch_graph_data(args.base_url)
            progress.update(task, completed=True)
    else:
        print("Fetching graph data...")
        graph_data = fetch_graph_data(args.base_url)
    
    if not graph_data:
        if use_rich:
            from rich import print as rich_print
            rich_print("[red]Failed to fetch graph data.[/red]")
        else:
            print("Failed to fetch graph data.")
        return
    
    # Find shortest path
    if use_rich:
        with Progress() as progress:
            task = progress.add_task("Calculating path...", total=None)
            path = find_shortest_path(graph_data, args.source, args.target)
            progress.update(task, completed=True)
    else:
        print("Calculating path...")
        path = find_shortest_path(graph_data, args.source, args.target)
    
    # Animate path traversal
    animate_path_traversal(graph_data, path, args.delay)


if __name__ == "__main__":
    main()