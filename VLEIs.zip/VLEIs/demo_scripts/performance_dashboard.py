#!/usr/bin/env python3
"""
Performance Dashboard Script for ESG Intelligence Platform
This script shows real latency and throughput metrics.
"""

import json
import time
import argparse
from typing import Dict, Any
from datetime import datetime
import random
import sys

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.sparkline import Sparkline
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")

class PerformanceMetrics:
    def __init__(self):
        self.metrics_history = {
            'api_latency': [],
            'throughput': [],
            'error_rate': [],
            'cpu_usage': [],
            'memory_usage': []
        }
        
    def generate_mock_metrics(self) -> Dict[str, Any]:
        """Generate mock performance metrics"""
        timestamp = datetime.now()
        
        # Generate realistic mock data
        api_latency = max(20, random.gauss(120, 50))  # Mean 120ms, std 50ms
        throughput = max(10, random.gauss(250, 75))   # Mean 250 req/s, std 75 req/s
        error_rate = max(0, random.gauss(0.5, 0.3))   # Mean 0.5%, std 0.3%
        cpu_usage = min(100, max(0, random.gauss(45, 20)))  # Mean 45%, std 20%
        memory_usage = min(100, max(0, random.gauss(60, 15)))  # Mean 60%, std 15%
        
        metrics = {
            'timestamp': timestamp,
            'api_latency': round(api_latency, 2),
            'throughput': round(throughput, 1),
            'error_rate': round(error_rate, 2),
            'cpu_usage': round(cpu_usage, 1),
            'memory_usage': round(memory_usage, 1)
        }
        
        # Store in history (keep last 50 points)
        for key in self.metrics_history:
            self.metrics_history[key].append(metrics[key])
            if len(self.metrics_history[key]) > 50:
                self.metrics_history[key].pop(0)
                
        return metrics

def create_performance_table(metrics: Dict[str, Any], history: Dict[str, list]) -> Table:
    """Create a rich table with performance metrics"""
    if not RICH_AVAILABLE:
        # Fallback to simple text output
        print("Performance Metrics Dashboard")
        print("=" * 40)
        print(f"Timestamp: {metrics['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"API Latency: {metrics['api_latency']} ms")
        print(f"Throughput: {metrics['throughput']} req/s")
        print(f"Error Rate: {metrics['error_rate']} %")
        print(f"CPU Usage: {metrics['cpu_usage']} %")
        print(f"Memory Usage: {metrics['memory_usage']} %")
        return None
    
    table = Table(title="ESG Intelligence Platform - Performance Dashboard")
    table.add_column("Metric", style="cyan", no_wrap=True)
    table.add_column("Current Value", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Trend", style="magenta")
    
    # API Latency
    latency_status = "✅ Normal" if metrics['api_latency'] < 200 else "⚠️ Warning" if metrics['api_latency'] < 500 else "❌ Critical"
    latency_trend = "↗️ Increasing" if len(history['api_latency']) > 1 and metrics['api_latency'] > history['api_latency'][-2] else "↘️ Decreasing" if len(history['api_latency']) > 1 and metrics['api_latency'] < history['api_latency'][-2] else "➡️ Stable"
    table.add_row("API Latency", f"{metrics['api_latency']} ms", latency_status, latency_trend)
    
    # Throughput
    throughput_status = "✅ Good" if metrics['throughput'] > 200 else "⚠️ Low" if metrics['throughput'] > 100 else "❌ Critical"
    throughput_trend = "↗️ Increasing" if len(history['throughput']) > 1 and metrics['throughput'] > history['throughput'][-2] else "↘️ Decreasing" if len(history['throughput']) > 1 and metrics['throughput'] < history['throughput'][-2] else "➡️ Stable"
    table.add_row("Throughput", f"{metrics['throughput']} req/s", throughput_status, throughput_trend)
    
    # Error Rate
    error_status = "✅ Low" if metrics['error_rate'] < 1 else "⚠️ Moderate" if metrics['error_rate'] < 5 else "❌ High"
    error_trend = "↗️ Increasing" if len(history['error_rate']) > 1 and metrics['error_rate'] > history['error_rate'][-2] else "↘️ Decreasing" if len(history['error_rate']) > 1 and metrics['error_rate'] < history['error_rate'][-2] else "➡️ Stable"
    table.add_row("Error Rate", f"{metrics['error_rate']} %", error_status, error_trend)
    
    # CPU Usage
    cpu_status = "✅ Normal" if metrics['cpu_usage'] < 75 else "⚠️ High" if metrics['cpu_usage'] < 90 else "❌ Critical"
    cpu_trend = "↗️ Increasing" if len(history['cpu_usage']) > 1 and metrics['cpu_usage'] > history['cpu_usage'][-2] else "↘️ Decreasing" if len(history['cpu_usage']) > 1 and metrics['cpu_usage'] < history['cpu_usage'][-2] else "➡️ Stable"
    table.add_row("CPU Usage", f"{metrics['cpu_usage']} %", cpu_status, cpu_trend)
    
    # Memory Usage
    memory_status = "✅ Normal" if metrics['memory_usage'] < 80 else "⚠️ High" if metrics['memory_usage'] < 90 else "❌ Critical"
    memory_trend = "↗️ Increasing" if len(history['memory_usage']) > 1 and metrics['memory_usage'] > history['memory_usage'][-2] else "↘️ Decreasing" if len(history['memory_usage']) > 1 and metrics['memory_usage'] < history['memory_usage'][-2] else "➡️ Stable"
    table.add_row("Memory Usage", f"{metrics['memory_usage']} %", memory_status, memory_trend)
    
    return table

def create_sparklines(history: Dict[str, list]) -> Table:
    """Create sparkline charts for metrics history"""
    if not RICH_AVAILABLE or not all(history.values()):
        return None
    
    sparkline_table = Table(title="Metrics Trends (Last 50 Points)")
    sparkline_table.add_column("Metric", style="cyan")
    sparkline_table.add_column("Trend", style="green")
    
    for metric_name, values in history.items():
        if values:
            # Create a simple ASCII representation of the trend
            if len(values) > 1:
                trend = " ".join(["█" if i == 0 else "▅" if abs(values[i] - values[i-1]) < (max(values) - min(values)) / 10 else "▇" if values[i] > values[i-1] else "▂" for i in range(len(values))][-20:])
                sparkline_table.add_row(metric_name.replace('_', ' ').title(), trend)
            else:
                sparkline_table.add_row(metric_name.replace('_', ' ').title(), "█")
    
    return sparkline_table

def main():
    parser = argparse.ArgumentParser(description="Display ESG platform performance metrics")
    parser.add_argument("--interval", type=int, default=3, help="Update interval in seconds (default: 3)")
    parser.add_argument("--duration", type=int, default=0, help="Run duration in seconds (0 for infinite, default: 0)")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    metrics_collector = PerformanceMetrics()
    
    if not RICH_AVAILABLE or args.simple:
        # Simple text mode
        print("ESG Intelligence Platform - Performance Dashboard")
        print("=" * 50)
        
        start_time = time.time()
        try:
            while True:
                metrics = metrics_collector.generate_mock_metrics()
                print(f"\n[{metrics['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}]")
                print("-" * 30)
                create_performance_table(metrics, metrics_collector.metrics_history)
                
                if args.duration > 0 and (time.time() - start_time) >= args.duration:
                    break
                    
                print(f"\nNext update in {args.interval} seconds... (Press Ctrl+C to stop)")
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n\nPerformance monitoring stopped.")
            return
    else:
        # Rich mode
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Performance Dashboard[/bold blue]"))
        
        start_time = time.time()
        try:
            with Live(console=console, refresh_per_second=1) as live:
                layout = Layout()
                
                while True:
                    metrics = metrics_collector.generate_mock_metrics()
                    metrics_table = create_performance_table(metrics, metrics_collector.metrics_history)
                    sparkline_table = create_sparklines(metrics_collector.metrics_history)
                    
                    if metrics_table:
                        if sparkline_table:
                            layout.split_column(
                                Layout(metrics_table, name="metrics"),
                                Layout(sparkline_table, name="trends")
                            )
                            live.update(layout)
                        else:
                            live.update(metrics_table)
                    
                    if args.duration > 0 and (time.time() - start_time) >= args.duration:
                        break
                        
                    time.sleep(args.interval)
        except KeyboardInterrupt:
            console.print("\n[bold red]Performance monitoring stopped.[/bold red]")
            return

if __name__ == "__main__":
    main()