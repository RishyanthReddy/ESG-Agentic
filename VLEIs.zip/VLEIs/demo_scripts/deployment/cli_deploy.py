#!/usr/bin/env python3
"""
CLI Deployment Script for ESG Intelligence Platform

This script provides command-line access to deploy and manage the ESG Intelligence Platform
in different environments with fallback capabilities.
"""

import sys
import os
import argparse
import time
import json
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from deploy.deployment_manager import DeploymentManager
from deploy.deployment_config import DeploymentConfig


def main():
    parser = argparse.ArgumentParser(description="ESG Intelligence Platform Deployment CLI")
    parser.add_argument(
        "--mode",
        choices=["deploy", "health", "status", "fallback", "stop"],
        default="health",
        help="Deployment mode"
    )
    parser.add_argument(
        "--environment",
        choices=["local", "cloud"],
        default="local",
        help="Deployment environment"
    )
    parser.add_argument(
        "--wait",
        action="store_true",
        help="Wait for deployment to be ready"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=60,
        help="Timeout in seconds for deployment operations"
    )
    
    args = parser.parse_args()
    
    dm = DeploymentManager()
    config = DeploymentConfig()
    
    print(f"ESG Intelligence Platform Deployment CLI")
    print(f"Mode: {args.mode}")
    print(f"Environment: {args.environment}")
    print("-" * 50)
    
    if args.mode == "deploy":
        if args.environment == "local":
            success = dm.deploy_local()
            if success and args.wait:
                print("Waiting for local deployment to be ready...")
                # Wait a bit for services to start
                time.sleep(10)
                # Check health
                health = dm.check_health("local")
                if health["status"] == "healthy":
                    print("✅ Local deployment is ready!")
                else:
                    print("⚠️  Local deployment completed but health check failed")
                    print(f"   Health check result: {health}")
            print(f"Local deployment {'successful' if success else 'failed'}")
        else:
            success = dm.deploy_cloud()
            print(f"Cloud deployment {'successful' if success else 'failed'}")
            
    elif args.mode == "health":
        health = dm.check_health(args.environment)
        print(f"Health check result:")
        print(json.dumps(health, indent=2))
        
        if health["status"] == "healthy":
            print("✅ System is healthy")
        else:
            print("❌ System is not healthy")
            
    elif args.mode == "status":
        status = dm.get_deployment_status(args.environment)
        print(f"Deployment status:")
        print(json.dumps(status, indent=2))
        
    elif args.mode == "fallback":
        print("Initiating fallback to local deployment...")
        success = dm.fallback_to_local()
        if success and args.wait:
            print("Waiting for fallback deployment to be ready...")
            time.sleep(10)
            health = dm.check_health("local")
            if health["status"] == "healthy":
                print("✅ Fallback to local deployment successful!")
            else:
                print("⚠️  Fallback completed but health check failed")
                print(f"   Health check result: {health}")
        print(f"Fallback deployment {'successful' if success else 'failed'}")
        
    elif args.mode == "stop":
        if args.environment == "local":
            success = dm.stop_local_deployment()
            print(f"Local deployment stop {'successful' if success else 'failed'}")
        else:
            print("Stop operation only supported for local environment")


if __name__ == "__main__":
    main()