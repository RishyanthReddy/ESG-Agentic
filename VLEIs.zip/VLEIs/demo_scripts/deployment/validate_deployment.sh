#!/bin/bash

# Deployment Validation Script for ESG Intelligence Platform
# This script validates that the deployment is working correctly

echo "========================================="
echo "ESG Intelligence Platform Deployment Validator"
echo "========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print success message
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Function to print warning message
print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Function to print error message
print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check if required tools are installed
echo "Checking required tools..."

# Check Docker
if command -v docker &> /dev/null; then
    print_success "Docker is installed"
    docker_version=$(docker --version)
    echo "  Version: $docker_version"
else
    print_warning "Docker is not installed"
fi

# Check Docker Compose
if command -v docker-compose &> /dev/null; then
    print_success "Docker Compose is installed"
    docker_compose_version=$(docker-compose --version)
    echo "  Version: $docker_compose_version"
else
    print_warning "Docker Compose is not installed"
fi

# Check Modal CLI
if command -v modal &> /dev/null; then
    print_success "Modal CLI is installed"
    modal_version=$(modal --version)
    echo "  Version: $modal_version"
else
    print_warning "Modal CLI is not installed"
fi

# Check Python
if command -v python3 &> /dev/null; then
    print_success "Python is installed"
    python_version=$(python3 --version)
    echo "  Version: $python_version"
else
    print_error "Python is not installed"
    exit 1
fi

# Check project files
echo
echo "Checking project files..."

REQUIRED_FILES=(
    "docker-compose.yml"
    "modal_entrypoint.py"
    "deploy/deployment_config.py"
    "deploy/deployment_manager.py"
    "demo_scripts/deployment/cli_deploy.py"
)

MISSING_FILES=()

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        print_success "$file found"
    else
        print_error "$file not found"
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -ne 0 ]; then
    echo
    print_error "Missing required files. Deployment cannot proceed."
    exit 1
fi

# Check Python dependencies
echo
echo "Checking Python dependencies..."

REQUIRED_PACKAGES=(
    "fastapi"
    "uvicorn"
    "modal"
    "docker"
    "requests"
)

echo "Checking Python packages..."
for package in "${REQUIRED_PACKAGES[@]}"; do
    if python3 -c "import $package" &> /dev/null; then
        print_success "$package is available"
    else
        print_warning "$package is not installed"
    fi
done

# Test deployment configuration
echo
echo "Testing deployment configuration..."

if python3 -c "from deploy.deployment_config import DeploymentConfig; config = DeploymentConfig(); print('Deployment config loaded successfully')" &> /dev/null; then
    print_success "Deployment configuration loaded successfully"
else
    print_error "Failed to load deployment configuration"
fi

# Test deployment manager
echo
echo "Testing deployment manager..."

if python3 -c "from deploy.deployment_manager import DeploymentManager; dm = DeploymentManager(); print('Deployment manager loaded successfully')" &> /dev/null; then
    print_success "Deployment manager loaded successfully"
else
    print_error "Failed to load deployment manager"
fi

# Summary
echo
echo "========================================="
echo "Deployment Validation Summary"
echo "========================================="

echo "Required tools check: Completed"
echo "Project files check: Completed"
echo "Python dependencies check: Completed"
echo "Configuration test: Completed"
echo "Deployment manager test: Completed"

echo
print_success "Deployment validation completed!"
echo "You can now proceed with deployment using the CLI tool:"
echo "  python demo_scripts/deployment/cli_deploy.py --help"