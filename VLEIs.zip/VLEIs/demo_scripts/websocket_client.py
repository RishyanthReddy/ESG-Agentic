#!/usr/bin/env python3
"""
WebSocket Client Script for ESG Intelligence Platform

This script demonstrates real-time WebSocket communication with the ESG platform,
including automatic fallback to polling when WebSocket is not available.
"""

import asyncio
import websockets
import json
import argparse
import sys
import time
from typing import Dict, Any
import requests
from datetime import datetime

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress
    from rich import print as rich_print
    from rich.live import Live
    from rich.layout import Layout
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    print("Warning: Rich library not available. Some features will be limited.")


class WebSocketClient:
    """
    WebSocket client for connecting to the ESG Intelligence Platform.
    """
    
    def __init__(self, base_url: str = "ws://localhost:8000", token: str = "demo_token"):
        """
        Initialize the WebSocket client.
        
        Args:
            base_url: Base URL for WebSocket connections
            token: Authentication token
        """
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.websocket = None
        self.connected = False
        self.fallback_to_polling = False
        
    async def connect(self, endpoint: str = "/api/v1/ws/dashboard") -> bool:
        """
        Connect to the WebSocket server.
        
        Args:
            endpoint: WebSocket endpoint to connect to
            
        Returns:
            True if connected successfully, False otherwise
        """
        try:
            url = f"{self.base_url}{endpoint}"
            if "?" not in url and self.token:
                url += f"?token={self.token}"
            elif self.token:
                url += f"&token={self.token}"
                
            self.websocket = await websockets.connect(url)
            self.connected = True
            
            # Receive initial connection message
            initial_message = await self.websocket.recv()
            if RICH_AVAILABLE:
                rich_print(f"[green]✓ Connected to {url}[/green]")
                rich_print(f"[blue]Server response: {initial_message}[/blue]")
            else:
                print(f"✓ Connected to {url}")
                print(f"Server response: {initial_message}")
                
            return True
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]✗ Failed to connect to WebSocket: {e}[/red]")
            else:
                print(f"✗ Failed to connect to WebSocket: {e}")
                
            self.connected = False
            return False
            
    async def disconnect(self):
        """
        Disconnect from the WebSocket server.
        """
        if self.websocket and self.connected:
            await self.websocket.close()
            self.connected = False
            if RICH_AVAILABLE:
                rich_print("[yellow]Disconnected from WebSocket server[/yellow]")
            else:
                print("Disconnected from WebSocket server")
                
    async def send_message(self, message: str) -> bool:
        """
        Send a message to the WebSocket server.
        
        Args:
            message: Message to send
            
        Returns:
            True if sent successfully, False otherwise
        """
        if not self.connected:
            return False
            
        try:
            await self.websocket.send(message)
            return True
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]Error sending message: {e}[/red]")
            else:
                print(f"Error sending message: {e}")
            return False
            
    async def receive_message(self) -> str:
        """
        Receive a message from the WebSocket server.
        
        Returns:
            Received message
        """
        if not self.connected:
            return ""
            
        try:
            message = await self.websocket.recv()
            return message
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]Error receiving message: {e}[/red]")
            else:
                print(f"Error receiving message: {e}")
            return ""
            
    def fallback_to_polling_request(self, endpoint: str = "/api/v1/poll/dashboard") -> Dict[str, Any]:
        """
        Fallback to polling REST endpoint.
        
        Args:
            endpoint: REST endpoint for polling
            
        Returns:
            Response from polling endpoint
        """
        try:
            url = f"{self.base_url.replace('ws://', 'http://').replace('wss://', 'https://')}{endpoint}"
            headers = {"Authorization": f"Bearer {self.token}"}
            
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                return response.json()
            else:
                if RICH_AVAILABLE:
                    rich_print(f"[red]Polling request failed with status {response.status_code}[/red]")
                else:
                    print(f"Polling request failed with status {response.status_code}")
                return {}
        except Exception as e:
            if RICH_AVAILABLE:
                rich_print(f"[red]Error in polling request: {e}[/red]")
            else:
                print(f"Error in polling request: {e}")
            return {}


async def simulate_real_time_updates(client: WebSocketClient, duration: int = 30):
    """
    Simulate real-time updates by sending periodic messages.
    
    Args:
        client: WebSocket client instance
        duration: Duration to run simulation (seconds)
    """
    start_time = time.time()
    
    if RICH_AVAILABLE:
        rich_print(f"[blue]Starting real-time updates simulation for {duration} seconds...[/blue]")
    else:
        print(f"Starting real-time updates simulation for {duration} seconds...")
        
    # Sample update messages
    updates = [
        {"type": "esg_score_update", "supplier": "S001", "score": 85, "change": "+2"},
        {"type": "compliance_alert", "supplier": "S002", "issue": "Documentation missing", "priority": "high"},
        {"type": "carbon_emission", "value": 120.5, "unit": "kg CO2", "location": "Factory A"},
        {"type": "verification_complete", "supplier": "S003", "result": "passed", "certificate": "ISO 14001"},
        {"type": "new_supplier", "name": "Eco Materials Ltd", "location": "Germany", "esg_score": 92}
    ]
    
    update_index = 0
    
    while time.time() - start_time < duration:
        if client.connected:
            # Send an update message
            update = updates[update_index % len(updates)]
            update["timestamp"] = datetime.now().isoformat()
            
            success = await client.send_message(json.dumps(update))
            if success:
                if RICH_AVAILABLE:
                    rich_print(f"[green]Sent update: {update['type']}[/green]")
                else:
                    print(f"Sent update: {update['type']}")
            else:
                if RICH_AVAILABLE:
                    rich_print("[red]Failed to send update[/red]")
                else:
                    print("Failed to send update")
                    
        # Wait before sending next update
        await asyncio.sleep(3)
        update_index += 1


async def listen_for_messages(client: WebSocketClient):
    """
    Listen for messages from the WebSocket server.
    
    Args:
        client: WebSocket client instance
    """
    if RICH_AVAILABLE:
        rich_print("[blue]Listening for messages... (Press Ctrl+C to stop)[/blue]")
    else:
        print("Listening for messages... (Press Ctrl+C to stop)")
        
    try:
        while client.connected:
            message = await client.receive_message()
            if message:
                try:
                    data = json.loads(message)
                    if RICH_AVAILABLE:
                        rich_print(f"[cyan]Received: {data}[/cyan]")
                    else:
                        print(f"Received: {data}")
                except json.JSONDecodeError:
                    if RICH_AVAILABLE:
                        rich_print(f"[cyan]Received: {message}[/cyan]")
                    else:
                        print(f"Received: {message}")
    except KeyboardInterrupt:
        if RICH_AVAILABLE:
            rich_print("[yellow]Stopping message listener...[/yellow]")
        else:
            print("Stopping message listener...")
    except Exception as e:
        if RICH_AVAILABLE:
            rich_print(f"[red]Error in message listener: {e}[/red]")
        else:
            print(f"Error in message listener: {e}")


def display_polling_results(results: Dict[str, Any], use_rich: bool = True):
    """
    Display polling results in a formatted way.
    
    Args:
        results: Results from polling endpoint
        use_rich: Whether to use rich formatting
    """
    if not results:
        if use_rich:
            rich_print("[red]No polling results received[/red]")
        else:
            print("No polling results received")
        return
        
    if use_rich and RICH_AVAILABLE:
        console = Console()
        console.print(Panel("[bold blue]ESG Intelligence Platform - Polling Results[/bold blue]"))
        
        status = results.get("status", "unknown")
        if status == "success":
            console.print("[green]✓ Polling successful[/green]")
        else:
            console.print("[red]✗ Polling failed[/red]")
            
        data = results.get("data", [])
        timestamp = results.get("timestamp", "N/A")
        
        console.print(f"[blue]Timestamp: {timestamp}[/blue]")
        console.print(f"[blue]Updates received: {len(data)}[/blue]")
        
        if data:
            console.print("\n[bold]Recent Updates:[/bold]")
            for i, update in enumerate(data):
                console.print(f"  {i+1}. [cyan]{update}[/cyan]")
    else:
        print("ESG Intelligence Platform - Polling Results")
        print("=" * 50)
        
        status = results.get("status", "unknown")
        if status == "success":
            print("✓ Polling successful")
        else:
            print("✗ Polling failed")
            
        data = results.get("data", [])
        timestamp = results.get("timestamp", "N/A")
        
        print(f"Timestamp: {timestamp}")
        print(f"Updates received: {len(data)}")
        
        if data:
            print("\nRecent Updates:")
            for i, update in enumerate(data):
                print(f"  {i+1}. {update}")


async def main():
    parser = argparse.ArgumentParser(description="WebSocket client for ESG Intelligence Platform")
    parser.add_argument("--url", type=str, default="ws://localhost:8000", help="WebSocket server URL")
    parser.add_argument("--token", type=str, default="demo_token", help="Authentication token")
    parser.add_argument("--endpoint", type=str, default="/api/v1/ws/dashboard", help="WebSocket endpoint")
    parser.add_argument("--poll-endpoint", type=str, default="/api/v1/poll/dashboard", help="Polling endpoint")
    parser.add_argument("--duration", type=int, default=30, help="Duration to run simulation (seconds)")
    parser.add_argument("--mode", type=str, choices=["connect", "simulate", "poll"], default="connect", 
                        help="Operation mode: connect, simulate, or poll")
    parser.add_argument("--simple", action="store_true", help="Use simple text output instead of rich formatting")
    
    args = parser.parse_args()
    
    # Determine if we should use rich formatting
    use_rich = RICH_AVAILABLE and not args.simple
    
    # Create WebSocket client
    client = WebSocketClient(base_url=args.url, token=args.token)
    
    if args.mode == "poll":
        # Use polling fallback
        if use_rich:
            rich_print("[blue]Using polling fallback...[/blue]")
        else:
            print("Using polling fallback...")
            
        results = client.fallback_to_polling_request(args.poll_endpoint)
        display_polling_results(results, use_rich)
        return
    
    # Try to connect to WebSocket
    connected = await client.connect(args.endpoint)
    
    if not connected:
        # Fallback to polling
        if use_rich:
            rich_print("[yellow]Falling back to polling...[/yellow]")
        else:
            print("Falling back to polling...")
            
        results = client.fallback_to_polling_request(args.poll_endpoint)
        display_polling_results(results, use_rich)
        return
    
    try:
        if args.mode == "simulate":
            # Run simulation
            await simulate_real_time_updates(client, args.duration)
        elif args.mode == "connect":
            # Listen for messages
            await listen_for_messages(client)
    except KeyboardInterrupt:
        if use_rich:
            rich_print("[yellow]Interrupted by user[/yellow]")
        else:
            print("Interrupted by user")
    finally:
        # Disconnect
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())