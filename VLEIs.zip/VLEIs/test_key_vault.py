import os
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient

# Your actual credentials
AZURE_TENANT_ID = "108c04f2-4c5e-4b19-85ee-b9d18a4c8c5f"
AZURE_CLIENT_ID = "1e75a210-8941-447d-8b44-c0834f6114ad"
AZURE_CLIENT_SECRET = "5Pm8Q~fht_4qntRP1JLJhW111NyibYmTAPRQ0cze"
AZURE_KEY_VAULT_URL = "https://esg-verified-id-vault.vault.azure.net/"

def test_key_vault():
    print("🔍 Testing Azure Key Vault Access...")
    print("=" * 50)
    
    try:
        # Create credential
        credential = ClientSecretCredential(
            tenant_id=AZURE_TENANT_ID,
            client_id=AZURE_CLIENT_ID,
            client_secret=AZURE_CLIENT_SECRET
        )
        
        # Create a secret client
        client = SecretClient(vault_url=AZURE_KEY_VAULT_URL, credential=credential)
        
        # Try to get properties of the vault (this will authenticate)
        print("1. Testing Key Vault authentication...")
        vault_properties = client.vault_url
        print(f"   ✅ Successfully connected to vault: {vault_properties}")
        
        # List secrets (if any)
        print("\n2. Listing secrets in the vault...")
        try:
            secrets = client.list_properties_of_secrets()
            secret_count = 0
            for secret in secrets:
                secret_count += 1
                print(f"   🔑 Secret: {secret.name}")
            
            if secret_count == 0:
                print("   ℹ️  No secrets found in the vault")
            else:
                print(f"   ✅ Found {secret_count} secrets in the vault")
                
        except Exception as e:
            print(f"   ℹ️  Could not list secrets: {str(e)}")
            print("      This might be due to permissions or no secrets existing yet")
        
        print("\n" + "=" * 50)
        print("🎉 Key Vault test completed successfully!")
        return True
        
    except Exception as e:
        print(f"   ❌ Key Vault test failed: {str(e)}")
        print("\n💡 Troubleshooting tips:")
        print("   • Check if the Key Vault URL is correct")
        print("   • Verify the app has permissions to access the vault")
        print("   • Ensure the client secret hasn't expired")
        return False

if __name__ == "__main__":
    test_key_vault()