"""
Demo Script Validation Tests

This module validates that demo scripts function correctly and produce expected outputs.
"""

import os
import sys
import pytest
import subprocess
import json
import tempfile
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

# Test configuration
TEST_TIMEOUT = 30  # seconds
DEMO_SCRIPTS_DIR = "demo_scripts"


def test_health_check_script():
    """Test the health check script produces valid output"""
    script_path = os.path.join(DEMO_SCRIPTS_DIR, "health_check.sh")
    
    if not os.path.exists(script_path):
        pytest.skip("Health check script not found")
    
    try:
        if os.name == 'nt':  # Windows
            result = subprocess.run(['cmd', '/c', script_path], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=TEST_TIMEOUT)
        else:  # Unix-like systems
            result = subprocess.run(['bash', script_path], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=TEST_TIMEOUT)
        
        # Should succeed or at least provide meaningful output
        # Check that output contains expected elements
        output = result.stdout + result.stderr
        # Just check that we get some output
        assert len(output.strip()) > 0 or result.returncode in [0, 1], \
            f"Health check script failed with return code {result.returncode}"
            
    except subprocess.TimeoutExpired:
        pytest.fail(f"Health check script timed out after {TEST_TIMEOUT} seconds")


def test_file_upload_demo():
    """Test the file upload demo script"""
    script_path = os.path.join(DEMO_SCRIPTS_DIR, "file_upload_demo.sh")
    
    if not os.path.exists(script_path):
        pytest.skip("File upload demo script not found")
    
    try:
        if os.name == 'nt':  # Windows
            result = subprocess.run(['cmd', '/c', script_path], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=TEST_TIMEOUT)
        else:  # Unix-like systems
            result = subprocess.run(['bash', script_path], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=TEST_TIMEOUT)
        
        # Should succeed or provide help
        output = result.stdout + result.stderr
        assert result.returncode in [0, 1, 2], \
            f"File upload demo script failed with return code {result.returncode}"
            
    except subprocess.TimeoutExpired:
        pytest.fail(f"File upload demo script timed out after {TEST_TIMEOUT} seconds")


def test_audit_runner():
    """Test the audit runner script"""
    script_path = os.path.join(DEMO_SCRIPTS_DIR, "audit_runner.py")
    
    if not os.path.exists(script_path):
        pytest.skip("Audit runner script not found")
    
    try:
        # Test with help flag first
        result = subprocess.run([sys.executable, script_path, '--help'], 
                              capture_output=True, 
                              text=True, 
                              timeout=TEST_TIMEOUT)
        
        # Should succeed or provide help
        assert result.returncode == 0 or '--help' in result.stdout.lower(), \
            f"Audit runner script failed with return code {result.returncode}"
            
        # Test with simple mode if available
        result = subprocess.run([sys.executable, script_path, '--simple'], 
                              capture_output=True, 
                              text=True, 
                              timeout=TEST_TIMEOUT)
        
        # Should succeed or provide meaningful output
        output = result.stdout + result.stderr
        assert result.returncode in [0, 1], \
            f"Audit runner script failed with return code {result.returncode}"
            
    except subprocess.TimeoutExpired:
        pytest.fail(f"Audit runner script timed out after {TEST_TIMEOUT} seconds")


def test_metrics_display():
    """Test the metrics display script"""
    script_path = os.path.join(DEMO_SCRIPTS_DIR, "metrics_display.py")
    
    if not os.path.exists(script_path):
        pytest.skip("Metrics display script not found")
    
    try:
        # Test with help flag first
        result = subprocess.run([sys.executable, script_path, '--help'], 
                              capture_output=True, 
                              text=True, 
                              timeout=TEST_TIMEOUT)
        
        # Should succeed or provide help
        assert result.returncode == 0 or '--help' in result.stdout.lower(), \
            f"Metrics display script failed with return code {result.returncode}"
            
        # Don't run the actual chart generation as it takes too long for a test
        # Just validate that the script can be imported without errors
        import importlib.util
        spec = importlib.util.spec_from_file_location("metrics_display", script_path)
        module = importlib.util.module_from_spec(spec)
        # This will raise an exception if there are import errors
        spec.loader.exec_module(module)
            
    except subprocess.TimeoutExpired:
        pytest.fail(f"Metrics display script timed out after {TEST_TIMEOUT} seconds")


def test_demo_data_files():
    """Test that demo data files are valid"""
    demo_data_files = [
        "esg_metrics_report_20250828_220341.json",
        "esg_metrics_report_20250828_220430.json",
        "esg_metrics_report_20250828_220454.json",
        "esg_metrics_report_20250828_234359.json",
        "esg_metrics_report_20250828_235306.json",
        "state_snapshot.json"
    ]
    
    for data_file in demo_data_files:
        file_path = os.path.join(DEMO_SCRIPTS_DIR, data_file)
        
        if not os.path.exists(file_path):
            pytest.skip(f"Demo data file {data_file} not found")
        
        # Check that file is not empty
        assert os.path.getsize(file_path) > 0, \
            f"Demo data file {data_file} is empty"
        
        # For JSON files, validate structure
        if data_file.endswith('.json'):
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                assert isinstance(data, (dict, list)), \
                    f"Demo data file {data_file} does not contain valid JSON"
            except json.JSONDecodeError as e:
                pytest.fail(f"Invalid JSON in {data_file}: {e}")


def test_master_demo_script():
    """Test the master demo script functionality"""
    script_path = os.path.join(DEMO_SCRIPTS_DIR, "master_demo.py")
    
    if not os.path.exists(script_path):
        pytest.skip("Master demo script not found")
    
    try:
        # Test with help flag
        result = subprocess.run([sys.executable, script_path, '--help'], 
                              capture_output=True, 
                              text=True, 
                              timeout=TEST_TIMEOUT)
        
        # Should succeed or provide help
        assert result.returncode == 0 or '--help' in result.stdout.lower(), \
            f"Master demo script failed with return code {result.returncode}"
        
        # Test listing mode
        result = subprocess.run([sys.executable, script_path, '--mode', 'list'], 
                              capture_output=True, 
                              text=True, 
                              timeout=TEST_TIMEOUT)
        
        # Should succeed and provide output
        output = result.stdout + result.stderr
        assert result.returncode == 0, \
            f"Master demo script list mode failed with return code {result.returncode}"
        assert len(output.strip()) > 0, \
            "Master demo script list mode produced no output"
            
    except subprocess.TimeoutExpired:
        pytest.fail(f"Master demo script timed out after {TEST_TIMEOUT} seconds")


def test_demo_script_consistency():
    """Test that demo scripts are consistent with project documentation"""
    # Check that documented scripts actually exist
    documented_scripts = [
        "master_demo.py",
        "health_check.sh",
        "file_upload_demo.sh",
        "integrity_verification.sh",
        "traceability_demo.sh",
        "audit_runner.py",
        "metrics_display.py",
        "complete_dashboard_simulation.py",
        "end_to_end_demo.py"
    ]
    
    missing_scripts = []
    for script_name in documented_scripts:
        script_path = os.path.join(DEMO_SCRIPTS_DIR, script_name)
        if not os.path.exists(script_path):
            missing_scripts.append(script_name)
    
    assert len(missing_scripts) == 0, \
        f"Documented demo scripts are missing: {missing_scripts}"


if __name__ == "__main__":
    pytest.main([__file__])