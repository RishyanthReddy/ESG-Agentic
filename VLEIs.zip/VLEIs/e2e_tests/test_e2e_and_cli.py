"""
End-to-End Testing with CLI Validation

This module tests:
1. Browser testing with Playwright
2. CLI script validation
3. Visual regression testing
4. Performance monitoring
5. Script testing
"""

import os
import sys
import pytest
import subprocess
import time
import json
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Test configuration
TEST_TIMEOUT = 60  # seconds
DEMO_SCRIPTS_DIR = "demo_scripts"


def test_browser_testing():
    """Test individual UI components with Playwright"""
    # This test will be expanded with actual Playwright tests
    assert True  # Placeholder for now


def test_script_testing():
    """Test individual demo scripts"""
    # List of critical demo scripts to test
    critical_scripts = [
        "health_check.sh",
        "file_upload_demo.sh",
        "integrity_verification.sh",
        "traceability_demo.sh",
        "audit_runner.py",
        "metrics_display.py",
        "graph_visualizer.py",
        "path_tracer.py"
    ]
    
    for script_name in critical_scripts:
        script_path = os.path.join(DEMO_SCRIPTS_DIR, script_name)
        if os.path.exists(script_path):
            # Test that the script runs without errors
            try:
                if script_name.endswith('.sh'):
                    if os.name == 'nt':  # Windows
                        result = subprocess.run(['cmd', '/c', script_path], 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=TEST_TIMEOUT)
                    else:  # Unix-like systems
                        result = subprocess.run(['bash', script_path], 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=TEST_TIMEOUT)
                else:  # Python scripts
                    result = subprocess.run([sys.executable, script_path, '--help'], 
                                          capture_output=True, 
                                          text=True, 
                                          timeout=TEST_TIMEOUT)
                
                # Script should either succeed or provide help without error
                assert result.returncode == 0 or '--help' in result.stdout.lower() or '--help' in result.stderr.lower(), \
                    f"Script {script_name} failed with return code {result.returncode}\nstdout: {result.stdout}\nstderr: {result.stderr}"
            except subprocess.TimeoutExpired:
                pytest.fail(f"Script {script_name} timed out after {TEST_TIMEOUT} seconds")
            except Exception as e:
                pytest.fail(f"Script {script_name} failed with exception: {e}")
        else:
            pytest.skip(f"Script {script_name} not found, skipping test")


def test_visual_testing():
    """Test screenshot and rendering validation"""
    # Check if required image files exist
    required_images = [
        "graph_export_high_res.png",
        "graph_visualization.png",
        "esg_score_chart.png",
        "compliance_charts.png"
    ]
    
    missing_images = []
    for image_name in required_images:
        image_path = os.path.join(DEMO_SCRIPTS_DIR, image_name)
        if not os.path.exists(image_path):
            missing_images.append(image_name)
    
    assert len(missing_images) == 0, \
        f"Missing required visualization files: {missing_images}"
    
    # Test that images are not empty
    for image_name in required_images:
        image_path = os.path.join(DEMO_SCRIPTS_DIR, image_name)
        if os.path.exists(image_path):
            # Check that file is not empty
            assert os.path.getsize(image_path) > 0, \
                f"Visualization file {image_name} is empty"


def test_performance_testing():
    """Test load time and responsiveness"""
    # Test that demo scripts complete within reasonable time
    performance_scripts = [
        ("health_check.sh", 10),
        ("integrity_checker.sh", 15),
        ("kpi_dashboard.sh", 15)
    ]
    
    for script_name, max_duration in performance_scripts:
        script_path = os.path.join(DEMO_SCRIPTS_DIR, script_name)
        if os.path.exists(script_path):
            start_time = time.time()
            try:
                if script_name.endswith('.sh'):
                    if os.name == 'nt':  # Windows
                        result = subprocess.run(['cmd', '/c', script_path], 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=max_duration)
                    else:  # Unix-like systems
                        result = subprocess.run(['bash', script_path], 
                                              capture_output=True, 
                                              text=True, 
                                              timeout=max_duration)
                else:  # Python scripts
                    result = subprocess.run([sys.executable, script_path], 
                                          capture_output=True, 
                                          text=True, 
                                          timeout=max_duration)
                
                end_time = time.time()
                execution_time = end_time - start_time
                
                assert result.returncode == 0, \
                    f"Script {script_name} failed with return code {result.returncode}"
                assert execution_time < max_duration, \
                    f"Script {script_name} took {execution_time:.2f}s, exceeding max {max_duration}s"
            except subprocess.TimeoutExpired:
                pytest.fail(f"Script {script_name} timed out after {max_duration} seconds")
            except Exception as e:
                pytest.fail(f"Script {script_name} failed with exception: {e}")


def test_complete_user_journey():
    """Test full browser-based user experience"""
    # This test will be expanded with actual Playwright tests for user journey
    # For now, we'll test that required frontend files exist
    required_frontend_files = [
        "dashboard/src",
        "dashboard/package.json",
        "dashboard/README.md"
    ]
    
    missing_files = []
    for file_path in required_frontend_files:
        full_path = os.path.join(os.path.dirname(__file__), '..', file_path)
        if not os.path.exists(full_path):
            missing_files.append(file_path)
    
    assert len(missing_files) == 0, \
        f"Missing required frontend files: {missing_files}"
    
    assert True  # Placeholder for actual Playwright tests


def test_complete_cli_journey():
    """Test full CLI-based demonstration experience"""
    # Test the master demo script
    master_demo_script = os.path.join(DEMO_SCRIPTS_DIR, "master_demo.py")
    
    if os.path.exists(master_demo_script):
        try:
            # Test listing demos
            result = subprocess.run([sys.executable, master_demo_script, "--mode", "list"], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=TEST_TIMEOUT)
            assert result.returncode == 0, \
                f"Master demo script failed with return code {result.returncode}\nstdout: {result.stdout}\nstderr: {result.stderr}"
            
            # Check that output contains expected content
            assert "Available Demo Components" in result.stdout or \
                   "Demo" in result.stdout or \
                   len(result.stdout) > 0, \
                   "Master demo script output does not contain expected content"
                   
            # Test running in rehearsal mode with simple output to avoid encoding issues
            # We'll just check that it starts correctly, not that it completes
            result = subprocess.run([sys.executable, master_demo_script, "--mode", "rehearse", "--simple"], 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=10)  # Short timeout to avoid running the full demo
            # Check that it at least started (we expect it to timeout, which is fine for this test)
            assert result.returncode == 0 or "Demo Rehearsal Mode" in result.stdout or result.returncode == -15, \
                f"Master demo script rehearsal failed with return code {result.returncode}\nstdout: {result.stdout}\nstderr: {result.stderr}"
        except subprocess.TimeoutExpired:
            # This is expected since the rehearsal would take a long time
            pass
        except Exception as e:
            pytest.fail(f"Master demo script failed with exception: {e}")
    else:
        pytest.skip("Master demo script not found, skipping test")


def test_cross_platform_testing():
    """Test multiple browsers and operating systems"""
    # This test will be expanded with actual cross-platform testing
    # For now, we check that we can identify the platform
    import platform
    current_platform = platform.system()
    assert current_platform in ['Windows', 'Linux', 'Darwin'], \
        f"Unsupported platform: {current_platform}"
    
    # Check that shell scripts can be executed on Unix-like systems
    if current_platform in ['Linux', 'Darwin']:
        script_path = os.path.join(DEMO_SCRIPTS_DIR, "health_check.sh")
        if os.path.exists(script_path):
            assert os.access(script_path, os.X_OK), \
                f"Shell script {script_path} is not executable on {current_platform}"
    
    assert True  # Placeholder for actual cross-platform testing with Playwright


def test_performance_validation():
    """Test systems under load"""
    # Test concurrent execution of lightweight scripts
    lightweight_scripts = [
        "health_check.sh",
        "integrity_checker.sh",
        "kpi_dashboard.sh"
    ]
    
    processes = []
    start_time = time.time()
    
    try:
        # Start all scripts concurrently
        for script_name in lightweight_scripts:
            script_path = os.path.join(DEMO_SCRIPTS_DIR, script_name)
            if os.path.exists(script_path):
                if script_name.endswith('.sh'):
                    if os.name == 'nt':  # Windows
                        proc = subprocess.Popen(['cmd', '/c', script_path], 
                                              stdout=subprocess.PIPE, 
                                              stderr=subprocess.PIPE)
                    else:  # Unix-like systems
                        proc = subprocess.Popen(['bash', script_path], 
                                              stdout=subprocess.PIPE, 
                                              stderr=subprocess.PIPE)
                else:  # Python scripts
                    proc = subprocess.Popen([sys.executable, script_path], 
                                          stdout=subprocess.PIPE, 
                                          stderr=subprocess.PIPE)
                processes.append((script_name, proc))
        
        # Wait for all processes to complete with a reasonable timeout
        for script_name, proc in processes:
            try:
                stdout, stderr = proc.communicate(timeout=30)
                assert proc.returncode == 0, \
                    f"Script {script_name} failed with return code {proc.returncode}\nstdout: {stdout}\nstderr: {stderr}"
            except subprocess.TimeoutExpired:
                proc.kill()
                pytest.fail(f"Script {script_name} timed out during concurrent execution")
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # All scripts should complete within a reasonable time when run concurrently
        assert total_time < 45, \
            f"Concurrent execution took {total_time:.2f}s, exceeding max 45s"
            
    except Exception as e:
        # Clean up any remaining processes
        for _, proc in processes:
            if proc.poll() is None:  # Process is still running
                proc.kill()
        raise e


def test_demonstration_readiness():
    """Test complete hackathon demo validation"""
    # Test that all required demo scripts exist
    required_scripts = [
        "master_demo.py",
        "health_check.sh",
        "file_upload_demo.sh",
        "integrity_verification.sh",
        "traceability_demo.sh",
        "audit_runner.py",
        "metrics_display.py",
        "complete_dashboard_simulation.py",
        "end_to_end_demo.py"
    ]
    
    missing_scripts = []
    for script_name in required_scripts:
        script_path = os.path.join(DEMO_SCRIPTS_DIR, script_name)
        if not os.path.exists(script_path):
            missing_scripts.append(script_name)
    
    assert len(missing_scripts) == 0, \
        f"Missing required demo scripts: {missing_scripts}"
    
    # Test that documentation exists
    required_docs = [
        ("docs", "demo_script.md"),
        (".", "Project Plan.md"),
        ("demo_scripts", "frontend_fallback.md")
    ]
    
    missing_docs = []
    for dir_path, doc_name in required_docs:
        doc_path = os.path.join(dir_path, doc_name)
        full_path = os.path.join(os.path.dirname(__file__), '..', doc_path)
        if not os.path.exists(full_path):
            missing_docs.append(doc_path)
    
    assert len(missing_docs) == 0, \
        f"Missing required documentation files: {missing_docs}"
    
    # Test that demo data files exist
    required_data_files = [
        "esg_metrics_report_20250828_220341.json",
        "state_snapshot.json"
    ]
    
    missing_data = []
    for data_file in required_data_files:
        file_path = os.path.join(DEMO_SCRIPTS_DIR, data_file)
        if not os.path.exists(file_path):
            missing_data.append(data_file)
    
    assert len(missing_data) == 0, \
        f"Missing required demo data files: {missing_data}"
    
    # Validate JSON data files
    for data_file in required_data_files:
        if data_file.endswith('.json'):
            file_path = os.path.join(DEMO_SCRIPTS_DIR, data_file)
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        json.load(f)
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {data_file}: {e}")


if __name__ == "__main__":
    pytest.main([__file__])