"""
Locust Stress Testing Framework for ESG Intelligence Platform

This module defines Locust user classes for stress testing the ESG platform,
specifically targeting the /ingest/stream endpoint for performance measurement.
"""

import json
import random
from locust import HttpUser, task, between, events
from datetime import datetime, timedelta


class ESGIngestionUser(HttpUser):
    """
    Locust user class for simulating ESG data ingestion requests.
    
    This user class sends POST requests to the /ingest/stream endpoint
    with realistic ESG supplier data to measure system performance under load.
    """
    
    # Host attribute - required by Locust
    host = "http://localhost:8000"
    
    # Wait time between tasks (1-3 seconds)
    wait_time = between(1, 3)
    
    def on_start(self):
        """
        Initialize user with sample data on start.
        """
        # Generate sample supplier data
        self.sample_data = self._generate_sample_supplier_data()
    
    def _generate_sample_supplier_data(self):
        """
        Generate realistic sample supplier ESG data.
        
        Returns:
            dict: Sample supplier data for ingestion
        """
        # Generate a list of data points over a period
        data_points = []
        base_date = datetime.now() - timedelta(days=30)
        
        for i in range(30):  # 30 days of data
            timestamp = (base_date + timedelta(days=i)).isoformat() + "Z"
            # Generate realistic ESG values with some variation
            co2_emissions = 100 + random.uniform(-20, 20)  # Base 100 with variation
            energy_usage = 500 + random.uniform(-100, 100)  # Base 500 with variation
            water_usage = 200 + random.uniform(-50, 50)    # Base 200 with variation
            
            data_points.append({
                "timestamp": timestamp,
                "co2_emissions": round(co2_emissions, 2),
                "energy_usage": round(energy_usage, 2),
                "water_usage": round(water_usage, 2),
                "supplier_id": f"supplier_{random.randint(1, 100)}",
                "location": random.choice(["US", "EU", "APAC"]),
                "confidence_score": round(random.uniform(0.8, 1.0), 3)
            })
        
        return {
            "supplier_id": f"supplier_{random.randint(1, 1000)}",
            "company_name": f"Company {random.randint(1, 1000)}",
            "reporting_period": "2023-Q1",
            "data_points": data_points,
            "metadata": {
                "source": "api",
                "version": "1.0",
                "generated_at": datetime.now().isoformat() + "Z"
            }
        }
    
    @task(3)
    def ingest_stream_normal(self):
        """
        Normal ingestion task - sends standard ESG data.
        Weight: 3 (most common task)
        """
        # Send POST request to /ingest/stream endpoint
        with self.client.post(
            "/ingest/stream",
            json={"supplier_data": self.sample_data},
            name="Ingest Stream - Normal",
            catch_response=True
        ) as response:
            try:
                # Check if response is valid JSON
                json_response = response.json()
                
                # Check if the response indicates success
                if response.status_code == 200 and json_response.get("status") == "success":
                    response.success()
                else:
                    response.failure(f"Request failed with status {response.status_code}: {json_response}")
            except json.JSONDecodeError:
                response.failure("Response is not valid JSON")
            except Exception as e:
                response.failure(f"Unexpected error: {str(e)}")
    
    @task(1)
    def ingest_stream_large(self):
        """
        Large ingestion task - sends ESG data with many data points.
        Weight: 1 (less common task)
        """
        # Generate larger dataset
        large_data = self._generate_sample_supplier_data()
        # Add more data points
        additional_points = []
        base_date = datetime.now() - timedelta(days=90)
        
        for i in range(90):  # 90 days of data (3x normal)
            timestamp = (base_date + timedelta(days=i)).isoformat() + "Z"
            co2_emissions = 100 + random.uniform(-30, 30)
            energy_usage = 500 + random.uniform(-150, 150)
            water_usage = 200 + random.uniform(-75, 75)
            
            additional_points.append({
                "timestamp": timestamp,
                "co2_emissions": round(co2_emissions, 2),
                "energy_usage": round(energy_usage, 2),
                "water_usage": round(water_usage, 2),
                "supplier_id": f"supplier_{random.randint(1, 100)}",
                "location": random.choice(["US", "EU", "APAC", "LATAM", "MEA"]),
                "confidence_score": round(random.uniform(0.7, 1.0), 3)
            })
        
        large_data["data_points"] = additional_points
        
        # Send POST request to /ingest/stream endpoint
        with self.client.post(
            "/ingest/stream",
            json={"supplier_data": large_data},
            name="Ingest Stream - Large",
            catch_response=True
        ) as response:
            try:
                json_response = response.json()
                
                if response.status_code == 200 and json_response.get("status") == "success":
                    response.success()
                else:
                    response.failure(f"Request failed with status {response.status_code}: {json_response}")
            except json.JSONDecodeError:
                response.failure("Response is not valid JSON")
            except Exception as e:
                response.failure(f"Unexpected error: {str(e)}")
    
    @task(1)
    def health_check(self):
        """
        Health check task - verifies system health.
        Weight: 1 (less common task)
        """
        with self.client.get("/health", name="Health Check", catch_response=True) as response:
            try:
                json_response = response.json()
                
                if response.status_code == 200 and json_response.get("status") in ["healthy", "degraded"]:
                    response.success()
                else:
                    response.failure(f"Health check failed with status {response.status_code}: {json_response}")
            except json.JSONDecodeError:
                response.failure("Health check response is not valid JSON")
            except Exception as e:
                response.failure(f"Unexpected error in health check: {str(e)}")


# Custom metrics collection
@events.request.add_listener
def on_request_success(request_type, name, response_time, response_length, **kwargs):
    """
    Event listener for successful requests.
    Can be used to collect custom metrics.
    """
    # This is where you could add custom ESG-specific KPI tracking
    pass


@events.request.add_listener
def on_request_failure(request_type, name, response_time, response_length, exception, **kwargs):
    """
    Event listener for failed requests.
    Can be used to track failure patterns.
    """
    # This is where you could add custom failure tracking
    pass


# Example of how to run this test:
# locust -f benchmarks/stress_test.py --host http://localhost:8000