"""
Unit tests for the Chaos Engineering Framework
"""

import pytest
import asyncio
import random
from unittest.mock import Mock, patch
from fastapi import FastAPI
import httpx
from tests.chaos import (
    ToxiproxyChaosProxy, ChaosMiddleware, ChaosError,
    simulate_network_failure, set_network_failure_probability,
    set_timeout_failure, init_chaos_middleware,
    simulate_climatiq_api_failure, simulate_infura_api_failure,
    simulate_network_latency, simulate_bandwidth_limit,
    simulate_connection_failure, reset_chaos
)


def test_toxiproxy_chaos_proxy_initialization():
    """Test ToxiproxyChaosProxy initialization"""
    with patch('tests.chaos.Toxiproxy') as mock_client:
        proxy = ToxiproxyChaosProxy()
        assert proxy.toxiproxy_host == "localhost"
        assert proxy.toxiproxy_port == 8474
        assert proxy.proxies == {}
        mock_client.assert_called_once_with("http://localhost:8474")


def test_toxiproxy_create_proxy():
    """Test creating a proxy with ToxiproxyChaosProxy"""
    with patch('tests.chaos.Toxiproxy') as mock_client:
        mock_proxy = Mock()
        mock_client.return_value.create_proxy.return_value = mock_proxy
        
        proxy = ToxiproxyChaosProxy()
        result = proxy.create_proxy("test_service", 8080, "upstream.host", 80)
        
        assert result == mock_proxy
        assert "test_service" in proxy.proxies
        assert proxy.proxies["test_service"] == mock_proxy
        mock_client.return_value.create_proxy.assert_called_once_with(
            "test_service", "localhost:8080", "upstream.host:80"
        )


def test_toxiproxy_add_latency():
    """Test adding latency to a proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.add_latency("test_service", 100, 10)
        
        mock_proxy.add_toxic.assert_called_once_with(
            "latency", "latency", attributes={"latency": 100, "jitter": 10}
        )


def test_toxiproxy_add_bandwidth_limit():
    """Test adding bandwidth limitation to a proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.add_bandwidth_limit("test_service", 1024)
        
        mock_proxy.add_toxic.assert_called_once_with(
            "bandwidth", "bandwidth", attributes={"rate": 1024}
        )


def test_toxiproxy_add_connection_failure():
    """Test adding connection failures to a proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.add_connection_failure("test_service", 50.0)
        
        mock_proxy.add_toxic.assert_called_once_with(
            "connection_failure", "timeout", attributes={"timeout": 0}
        )


def test_toxiproxy_add_http_error():
    """Test adding HTTP error simulation to a proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.add_http_error("test_service", 503)
        
        mock_proxy.add_toxic.assert_called_once_with(
            "http_error", "timeout", attributes={"timeout": 1}
        )


def test_toxiproxy_remove_toxic():
    """Test removing a toxic from a proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.remove_toxic("test_service", "latency_downstream")
        
        mock_proxy.remove_toxic.assert_called_once_with("latency_downstream")


def test_toxiproxy_reset_specific_proxy():
    """Test resetting a specific proxy"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        proxy.reset("test_service")
        
        mock_proxy.destroy.assert_called_once()


def test_toxiproxy_reset_all_proxies():
    """Test resetting all proxies"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy1 = Mock()
        mock_proxy2 = Mock()
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service1"] = mock_proxy1
        proxy.proxies["test_service2"] = mock_proxy2
        
        proxy.reset()
        
        assert mock_proxy1.destroy.call_count == 1
        assert mock_proxy2.destroy.call_count == 1
        assert proxy.proxies == {}


def test_toxiproxy_error_handling_create_proxy():
    """Test error handling when creating a proxy"""
    with patch('tests.chaos.Toxiproxy') as mock_client:
        mock_client.return_value.create_proxy.side_effect = Exception("Connection failed")
        
        proxy = ToxiproxyChaosProxy()
        with pytest.raises(ChaosError, match="Failed to create proxy 'test_service'"):
            proxy.create_proxy("test_service", 8080, "upstream.host", 80)


def test_toxiproxy_error_handling_add_latency():
    """Test error handling when adding latency"""
    with patch('tests.chaos.Toxiproxy'):
        mock_proxy = Mock()
        mock_proxy.add_toxic.side_effect = Exception("API error")
        proxy = ToxiproxyChaosProxy()
        proxy.proxies["test_service"] = mock_proxy
        
        with pytest.raises(ChaosError, match="Failed to add latency to proxy 'test_service'"):
            proxy.add_latency("test_service", 100)


def test_toxiproxy_error_handling_proxy_not_found():
    """Test error handling when proxy is not found"""
    with patch('tests.chaos.Toxiproxy'):
        proxy = ToxiproxyChaosProxy()
        
        with pytest.raises(ChaosError, match="Proxy 'nonexistent' not found"):
            proxy.add_latency("nonexistent", 100)


def test_chaos_middleware():
    """Test chaos middleware functionality"""
    app = FastAPI()
    
    # Test with 100% failure probability
    middleware = ChaosMiddleware(app, failure_probability=1.0)
    
    # Mock the call_next function
    async def mock_call_next(request):
        return httpx.Response(200, content="OK")
    
    # Create a mock request
    mock_request = Mock()
    
    # Execute the middleware
    # Note: In a real test, we would use TestClient or a proper ASGI test setup
    # For now, we'll just check that it doesn't crash


def test_network_failure_simulation():
    """Test network failure simulation"""
    # Set probability to 0 to ensure no failure
    set_network_failure_probability(0.0)
    simulate_network_failure()  # Should not raise exception
    
    # Set probability to 1 to ensure failure
    set_network_failure_probability(1.0)
    with pytest.raises(ChaosError):
        simulate_network_failure()


def test_network_latency_simulation():
    """Test network latency simulation"""
    # This is a simple test - in practice, you'd measure the actual time
    simulate_network_latency(10, 50)  # Should not raise exception


def test_reset_chaos():
    """Test resetting chaos configurations"""
    set_network_failure_probability(0.5)
    set_timeout_failure(30)
    
    reset_chaos()
    
    # These are internal variables, so we can't directly test them
    # But we can test that the function executes without error


def test_climatiq_api_failure_simulation():
    """Test Climatiq API failure simulation"""
    # This function just logs, so we're testing it executes without error
    simulate_climatiq_api_failure()


def test_infura_api_failure_simulation():
    """Test Infura API failure simulation"""
    # This function just logs, so we're testing it executes without error
    simulate_infura_api_failure()


def test_connection_failure_simulation():
    """Test connection failure simulation"""
    # This function just logs, so we're testing it executes without error
    simulate_connection_failure("test_service")


def test_bandwidth_limit_simulation():
    """Test bandwidth limit simulation"""
    # This function just logs, so we're testing it executes without error
    simulate_bandwidth_limit(1024)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])