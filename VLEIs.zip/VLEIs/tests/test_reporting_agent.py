"""
Unit tests for the Regulatory Reporting Agent
"""

import pytest
from datetime import datetime
from src.agents.reporting import regulatory_reporting_agent, RegulatoryReportingError
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport


def test_mapping_logic_with_current_credential():
    """Test data mapping to regulatory formats with current credential"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state with a credential
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    assert "regulatory_report" in result
    assert result["regulatory_report"]["company_name"] == "Test Company"
    
    # Verify GRI and SASB frameworks are included
    assert "gri" in result["regulatory_report"]["frameworks"]
    assert "sasb" in result["regulatory_report"]["frameworks"]
    
    # Verify processing results
    assert "processing_results" in result
    assert "regulatory_mapping_result" in result["processing_results"]


def test_mapping_logic_with_credentials_list():
    """Test data mapping to regulatory formats with credentials list"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company From List"
            }
        }
    )
    
    # Create initial state with credentials list
    state = AppState(
        credentials=[credential]
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    assert result["regulatory_report"]["company_name"] == "Test Company From List"


def test_mapping_logic_with_gri_reports():
    """Test data mapping to regulatory formats with GRI reports"""
    # Create a test GRI report
    gri_report = GRIReport(
        company_name="Test Company From GRI",
        report_year=2023
    )
    
    # Create initial state with GRI reports
    state = AppState(
        gri_reports=[gri_report]
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    assert result["regulatory_report"]["company_name"] == "Test Company From GRI"
    assert result["regulatory_report"]["report_year"] == 2023


def test_mapping_logic_with_sasb_reports():
    """Test data mapping to regulatory formats with SASB reports"""
    # Create a test SASB report
    sasb_report = SASBReport(
        company_name="Test Company From SASB",
        report_year=2023
    )
    
    # Create initial state with SASB reports
    state = AppState(
        sasb_reports=[sasb_report]
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    assert result["regulatory_report"]["company_name"] == "Test Company From SASB"
    assert result["regulatory_report"]["report_year"] == 2023


def test_mapping_logic_with_no_data():
    """Test data mapping when no data is available"""
    # Create initial state with no data
    state = AppState()
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution even with no data
    assert result["workflow_status"] == "regulatory_report_generated"
    assert "regulatory_report" in result
    assert result["regulatory_report"]["company_name"] == "Unknown Company"


def test_report_generation():
    """Test regulatory report creation"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify report structure
    report = result["regulatory_report"]
    assert "id" in report
    assert "company_name" in report
    assert "report_year" in report
    assert "generated_date" in report
    assert "frameworks" in report
    assert "summary" in report
    
    # Verify frameworks structure
    frameworks = report["frameworks"]
    assert "gri" in frameworks
    assert "sasb" in frameworks
    
    # Verify GRI framework
    gri = frameworks["gri"]
    assert "report_id" in gri
    assert "standards" in gri
    assert "mapped_data" in gri
    
    # Verify SASB framework
    sasb = frameworks["sasb"]
    assert "report_id" in sasb
    assert "standards" in sasb
    assert "mapped_data" in sasb


def test_model_validation():
    """Test Pydantic model compliance"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject"
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify that the generated reports conform to the models
    report = result["regulatory_report"]
    
    # Check that we can create GRIReport and SASBReport instances from the mapped data
    gri_data = report["frameworks"]["gri"]["mapped_data"]
    sasb_data = report["frameworks"]["sasb"]["mapped_data"]
    
    # These should not raise validation errors
    gri_report = GRIReport(
        company_name=report["company_name"],
        report_year=report["report_year"],
        data=gri_data
    )
    
    sasb_report = SASBReport(
        company_name=report["company_name"],
        report_year=report["report_year"],
        data=sasb_data
    )
    
    assert gri_report is not None
    assert sasb_report is not None


def test_error_handling():
    """Test handling of incomplete data"""
    # Create a state with problematic data that might cause issues
    state = AppState()
    
    # Mock a potential issue by patching datetime to raise an exception
    with pytest.MonkeyPatch().context() as mp:
        # This is a bit of a contrived example, but demonstrates error handling
        result = regulatory_reporting_agent(state)
        
        # Should still work with default error handling
        assert result["workflow_status"] in ["regulatory_report_generated", "regulatory_reporting_failed"]
        
        # If it failed, check error handling
        if result["workflow_status"] == "regulatory_reporting_failed":
            assert "errors" in result
            assert len(result["errors"]) > 0
            assert "agent_trace" in result


def test_agent_trace_logging():
    """Test that agent actions are properly logged in agent_trace"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject"
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify agent trace
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    
    # Check the last trace entry
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "regulatory_reporting_agent"
    assert "action" in last_trace
    assert "timestamp" in last_trace