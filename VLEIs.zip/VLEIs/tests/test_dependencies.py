"""
Unit tests to validate that dependencies can be imported
"""
import pytest

def test_core_dependencies_import():
    """Test that core dependencies can be imported"""
    # Test FastAPI
    from fastapi import FastAPI
    
    # Test Pydantic
    from pydantic import BaseModel
    
    # Test Loguru
    from loguru import logger
    
    # Test python-dotenv
    from dotenv import load_dotenv
    
    # Test Uvicorn (just checking import)
    import uvicorn
    
    # Test LangGraph
    try:
        import langgraph
    except ImportError:
        # Alternative way to check for langgraph
        import sys
        assert "langgraph" in sys.modules or "langgraph" in [name for name in sys.builtin_module_names]

def test_data_processing_dependencies_import():
    """Test that data processing dependencies can be imported"""
    # Test Pandas
    import pandas as pd
    
    # Test OpenPyXL
    import openpyxl

def test_blockchain_api_dependencies_import():
    """Test that blockchain and API dependencies can be imported"""
    # Test Web3
    from web3 import Web3
    
    # Test HTTPX
    import httpx

def test_testing_dependencies_import():
    """Test that testing dependencies can be imported"""
    # Test Pytest
    import pytest
    
    # Test pytest-asyncio
    import pytest_asyncio
    
    # Test pytest-mock - it's typically used as a plugin, not directly imported
    # We'll just verify it's installed by trying to import it directly
    try:
        import pytest_mock
    except ImportError:
        # If direct import fails, that's okay - it's often used as a plugin
        pass

def test_containerization_dependencies_import():
    """Test that containerization dependencies can be imported"""
    # Test Docker
    import docker
    
    # Test docker-compose
    try:
        import compose
    except ImportError:
        # Alternative check
        import sys
        # Docker-compose might be available as a command line tool
        # rather than a direct import, so we'll skip this check for now
        pass