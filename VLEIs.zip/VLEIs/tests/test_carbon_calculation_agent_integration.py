"""
Integration tests for the Carbon Calculation Agent
"""

import pytest
import os
from src.agents.esg import carbon_calculation_agent, CarbonCalculationError
from src.state.models import AppState
from config import settings


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_end_to_end_calculation():
    """Test full carbon footprint calculation workflow"""
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": [
                    {
                        "activity_id": "electricity-supply_grid-source_residual_mix",
                        "amount": 100,
                        "unit": "kwh",
                        "region": "AU",
                        "data_version": "^3"
                    }
                ]
            }
        }
    )
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_completed"
    assert "esg_metrics" in result
    assert "carbon_footprints" in result["esg_metrics"]
    assert len(result["esg_metrics"]["carbon_footprints"]) == 1
    
    # Verify carbon footprint data
    carbon_footprint = result["esg_metrics"]["carbon_footprints"][0]
    assert "co2e" in carbon_footprint
    assert "co2e_unit" in carbon_footprint
    assert carbon_footprint["co2e"] > 0
    assert carbon_footprint["co2e_unit"] == "kg"
    assert carbon_footprint["activity_id"] == "electricity-supply_grid-source_residual_mix"
    assert carbon_footprint["amount"] == 100
    assert carbon_footprint["unit"] == "kwh"
    assert carbon_footprint["region"] == "AU"
    
    # Verify total carbon footprint
    assert "total_carbon_footprint" in result["esg_metrics"]
    assert result["esg_metrics"]["total_carbon_footprint"]["co2e"] == carbon_footprint["co2e"]
    assert result["esg_metrics"]["total_carbon_footprint"]["co2e_unit"] == "kg"


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_data_accuracy():
    """Test calculation results against known values"""
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": {
                    "activity_id": "electricity-supply_grid-source_residual_mix",
                    "amount": 1000,  # 1000 kWh
                    "unit": "kwh",
                    "region": "AU",
                    "data_version": "^3"
                }
            }
        }
    )
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_completed"
    assert "esg_metrics" in result
    assert "carbon_footprints" in result["esg_metrics"]
    
    # Verify carbon footprint data
    carbon_footprint = result["esg_metrics"]["carbon_footprints"][0]
    assert carbon_footprint["co2e"] > 0  # Should be a positive value
    assert carbon_footprint["activity_id"] == "electricity-supply_grid-source_residual_mix"
    assert carbon_footprint["amount"] == 1000
    assert carbon_footprint["unit"] == "kwh"


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_performance_analysis():
    """Test calculation time and resource usage"""
    import time
    
    # Create state with multiple activities
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": [
                    {
                        "activity_id": "electricity-supply_grid-source_residual_mix",
                        "amount": 100,
                        "unit": "kwh",
                        "region": "AU",
                        "data_version": "^3"
                    }
                ]
            }
        }
    )
    
    # Measure execution time
    start_time = time.time()
    result = carbon_calculation_agent(state)
    end_time = time.time()
    
    execution_time = end_time - start_time
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_completed"
    assert execution_time < 10.0  # Should complete within 10 seconds
    assert "esg_metrics" in result
    assert "carbon_footprints" in result["esg_metrics"]
    assert len(result["esg_metrics"]["carbon_footprints"]) == 1


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_error_handling_with_incomplete_data():
    """Test behavior with incomplete activity data"""
    # Create state with incomplete activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": {
                    "activity_id": "invalid_activity_id",  # Invalid activity ID
                    "amount": 100,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        }
    )
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify that the workflow status indicates failure
    assert result["workflow_status"] == "carbon_calculation_failed"
    assert "errors" in result
    assert len(result["errors"]) > 0


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_workflow_integration():
    """Test integration with overall ESG workflow"""
    # Create state with ESG metrics data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "esg_metrics": {
                    "energy_consumption_kwh": 1000,
                    "vehicle_distance_km": 500
                }
            }
        },
        esg_metrics={
            "existing_metric": "value"
        }
    )
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_completed"
    assert "esg_metrics" in result
    
    # Check that existing metrics are preserved
    assert "existing_metric" in result["esg_metrics"]
    assert result["esg_metrics"]["existing_metric"] == "value"
    
    # Check that new carbon footprint metrics are added
    assert "carbon_footprints" in result["esg_metrics"]
    assert len(result["esg_metrics"]["carbon_footprints"]) >= 1  # At least one activity inferred
    
    # Check total carbon footprint
    assert "total_carbon_footprint" in result["esg_metrics"]
    assert result["esg_metrics"]["total_carbon_footprint"]["co2e"] > 0


if __name__ == "__main__":
    pytest.main([__file__])