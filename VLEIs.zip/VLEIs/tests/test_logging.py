"""
Unit tests for structured logging with loguru
"""

import pytest
import sys
import os
import json
import re
from io import StringIO
from loguru import logger
from datetime import datetime


def test_log_configuration():
    """Test loguru configuration"""
    # Add a test handler first
    test_id = logger.add(sys.stdout, format="{time} | {level} | {message}", level="INFO")
    
    # Check that we have the expected handlers
    logger_handlers = logger._core.handlers
    assert len(logger_handlers) >= 1  # Should have at least one handler
    
    # Clean up
    logger.remove(test_id)


def test_log_format():
    """Verify structured log format with request_id"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate a log message with request_id
    request_id = "test_request_123"
    logger.info(f"Request {request_id}: Testing log format")
    
    # Get the log output
    log_output = log_stream.getvalue()
    assert f"Request {request_id}:" in log_output
    
    # Check that it has the expected format (timestamp | level | message)
    lines = log_output.strip().split('\n')
    assert len(lines) >= 1
    # Updated pattern to match the actual timestamp format
    pattern = r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+[+-]\d{4} \| INFO \| Request test_request_123: Testing log format'
    assert re.search(pattern, lines[-1]) is not None
    
    # Clean up
    logger.remove(test_id)


def test_log_levels():
    """Test all log levels work correctly"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="TRACE")
    
    # Test each log level
    request_id = "level_test_request"
    
    logger.trace(f"Request {request_id}: Trace message")
    logger.debug(f"Request {request_id}: Debug message")
    logger.info(f"Request {request_id}: Info message")
    logger.warning(f"Request {request_id}: Warning message")
    logger.error(f"Request {request_id}: Error message")
    logger.critical(f"Request {request_id}: Critical message")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Check that we have the expected number of lines (TRACE might not be shown depending on config)
    assert len(lines) >= 5
    
    # Check that each level is represented
    log_levels_found = []
    for line in lines:
        if f"Request {request_id}:" in line:
            match = re.search(r' \| (\w+) \| ', line)
            if match:
                log_levels_found.append(match.group(1))
    
    expected_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
    for level in expected_levels:
        assert level in log_levels_found
    
    # Clean up
    logger.remove(test_id)


def test_context_injection():
    """Test request_id context in logs"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Test with different request IDs
    request_ids = ["req_001", "req_002", "req_003"]
    
    for req_id in request_ids:
        logger.info(f"Request {req_id}: Processing task")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Check that each request ID is in the logs
    for req_id in request_ids:
        found = False
        for line in lines:
            if f"Request {req_id}:" in line:
                found = True
                break
        assert found, f"Request ID {req_id} not found in logs"
    
    # Clean up
    logger.remove(test_id)


def test_log_timestamp_format():
    """Test that log timestamps are properly formatted"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate a log message
    request_id = "timestamp_test"
    logger.info(f"Request {request_id}: Timestamp test")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Check the timestamp format
    timestamp_line = None
    for line in lines:
        if f"Request {request_id}:" in line:
            timestamp_line = line
            break
    
    assert timestamp_line is not None
    
    # Extract timestamp (updated pattern for ISO format with timezone)
    match = re.search(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+[+-]\d{4}) \| INFO \|', timestamp_line)
    assert match is not None
    
    # Verify it's a valid timestamp
    timestamp_str = match.group(1)
    try:
        # Parse ISO format with timezone
        datetime.fromisoformat(timestamp_str)
    except ValueError:
        pytest.fail(f"Invalid timestamp format: {timestamp_str}")
    
    # Clean up
    logger.remove(test_id)


def test_unique_request_ids():
    """Test that request IDs are unique"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate multiple log messages
    for i in range(10):
        logger.info(f"Request test_{i}: Unique ID test")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Extract request IDs
    request_ids = []
    for line in lines:
        match = re.search(r'Request (test_\d+):', line)
        if match:
            request_ids.append(match.group(1))
    
    # Check that all request IDs are unique
    assert len(request_ids) == 10
    assert len(set(request_ids)) == 10
    
    # Clean up
    logger.remove(test_id)


def test_log_message_structure():
    """Test that log messages have the correct structure"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate a structured log message
    request_id = "structure_test"
    message_content = "Executing data processing task"
    logger.info(f"Request {request_id}: {message_content}")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Find our test line
    test_line = None
    for line in lines:
        if f"Request {request_id}:" in line:
            test_line = line
            break
    
    assert test_line is not None
    
    # Check structure: timestamp | level | message
    parts = test_line.split(' | ')
    assert len(parts) == 3
    
    # Check timestamp format (updated for ISO format)
    try:
        datetime.fromisoformat(parts[0])
    except ValueError:
        pytest.fail(f"Invalid timestamp format: {parts[0]}")
    
    # Check level
    assert parts[1] == "INFO"
    
    # Check message
    assert f"Request {request_id}: {message_content}" in parts[2]
    
    # Clean up
    logger.remove(test_id)


def test_error_logging():
    """Test error logging with context"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate an error log
    request_id = "error_test"
    error_message = "Failed to process data"
    logger.error(f"Request {request_id}: {error_message}")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Find our test line
    test_line = None
    for line in lines:
        if f"Request {request_id}:" in line:
            test_line = line
            break
    
    assert test_line is not None
    
    # Check that it's an error level log
    assert "ERROR" in test_line
    assert error_message in test_line
    
    # Clean up
    logger.remove(test_id)


def test_warning_logging():
    """Test warning logging with context"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate a warning log
    request_id = "warning_test"
    warning_message = "Data validation took longer than expected"
    logger.warning(f"Request {request_id}: {warning_message}")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Find our test line
    test_line = None
    for line in lines:
        if f"Request {request_id}:" in line:
            test_line = line
            break
    
    assert test_line is not None
    
    # Check that it's a warning level log
    assert "WARNING" in test_line
    assert warning_message in test_line
    
    # Clean up
    logger.remove(test_id)


def test_info_logging():
    """Test info logging with context"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    # Generate an info log
    request_id = "info_test"
    info_message = "Processing completed successfully"
    logger.info(f"Request {request_id}: {info_message}")
    
    # Get the log output
    log_output = log_stream.getvalue()
    lines = log_output.strip().split('\n')
    
    # Find our test line
    test_line = None
    for line in lines:
        if f"Request {request_id}:" in line:
            test_line = line
            break
    
    assert test_line is not None
    
    # Check that it's an info level log
    assert "INFO" in test_line
    assert info_message in test_line
    
    # Clean up
    logger.remove(test_id)