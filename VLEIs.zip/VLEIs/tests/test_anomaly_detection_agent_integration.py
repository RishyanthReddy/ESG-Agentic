"""
Integration tests for the Anomaly Detection Agent

This module contains tests for verifying the correct functionality of the 
anomaly_detection_agent in an integrated environment.
"""

import pytest
import os
from src.agents.esg import anomaly_detection_agent, AnomalyDetectionError
from src.state.models import AppState
from config import settings


def test_real_time_detection():
    """Test continuous anomaly detection workflow"""
    # Create state with Scope 3 data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "scope3_data": [
                    {
                        "timestamp": "2023-01-01T00:00:00Z",
                        "value": 100.0,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-01-02T00:00:00Z",
                        "value": 102.5,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-01-03T00:00:00Z",
                        "value": 98.7,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-01-04T00:00:00Z",
                        "value": 101.2,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-01-05T00:00:00Z",
                        "value": 250.0,  # Anomalous value
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    }
                ]
            }
        }
    )
    
    # Run the agent
    result = anomaly_detection_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "anomaly_detection_completed"
    assert "processing_results" in result
    assert "anomaly_detection" in result["processing_results"]
    
    # Verify anomaly detection data
    anomaly_results = result["processing_results"]["anomaly_detection"]
    assert "success" in anomaly_results
    assert anomaly_results["success"] is True
    assert "anomaly_count" in anomaly_results
    assert "total_points" in anomaly_results
    assert anomaly_results["total_points"] == 5
    assert "anomaly_percentage" in anomaly_results
    assert "results" in anomaly_results
    
    # Verify individual results
    individual_results = anomaly_results["results"]
    assert len(individual_results) == 5
    for res in individual_results:
        assert "timestamp" in res
        assert "value" in res
        assert "anomaly_score" in res
        assert "is_anomaly" in res
        assert "confidence" in res


def test_alert_workflow():
    """Test end-to-end alert generation and handling"""
    # Create state with Scope 3 data including clear anomalies
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "scope3_data": [
                    {
                        "timestamp": "2023-01-01T00:00:00Z",
                        "value": 100.0,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-01-02T00:00:00Z",
                        "value": 300.0,  # Clear anomaly
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    }
                ]
            }
        }
    )
    
    # Run the agent
    result = anomaly_detection_agent(state)
    
    # Verify alerts were generated
    assert result["workflow_status"] == "anomaly_detection_completed"
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    
    # Check the last agent trace entry
    trace_entry = result["agent_trace"][-1]
    assert trace_entry["agent"] == "anomaly_detection_agent"
    assert "anomalies_detected" in trace_entry
    assert "anomaly_percentage" in trace_entry


def test_performance_testing():
    """Test anomaly detection performance and latency"""
    # Create state with larger dataset
    scope3_data = []
    for i in range(50):  # 50 data points
        scope3_data.append({
            "timestamp": f"2023-01-{i+1:02d}T00:00:00Z",
            "value": 100.0 + (i % 10),  # Normal variation
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1"
        })
    
    # Add some clear anomalies
    scope3_data[10]["value"] = 500.0
    scope3_data[25]["value"] = 450.0
    scope3_data[40]["value"] = 600.0
    
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "scope3_data": scope3_data
            }
        }
    )
    
    # Run the agent
    result = anomaly_detection_agent(state)
    
    # Verify performance
    assert result["workflow_status"] == "anomaly_detection_completed"
    assert "processing_results" in result
    assert "anomaly_detection" in result["processing_results"]
    
    anomaly_results = result["processing_results"]["anomaly_detection"]
    assert anomaly_results["total_points"] == 50
    assert anomaly_results["anomaly_count"] >= 3  # Should detect our injected anomalies


def test_false_positive_analysis():
    """Test that the anomaly detection system runs without errors on normal data"""
    # Create state with consistent, normal data
    scope3_data = []
    for i in range(20):
        # Consistent values with small variations
        scope3_data.append({
            "timestamp": f"2023-01-{i+1:02d}T00:00:00Z",
            "value": 98.0 + (i % 5),  # Small variations (98-102)
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1"
        })
    
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "scope3_data": scope3_data
            }
        }
    )
    
    # Run the agent
    result = anomaly_detection_agent(state)
    
    # Verify that the system runs without errors
    assert result["workflow_status"] == "anomaly_detection_completed"
    assert "processing_results" in result
    assert "anomaly_detection" in result["processing_results"]
    
    # Verify that results are generated
    anomaly_results = result["processing_results"]["anomaly_detection"]
    assert "success" in anomaly_results
    assert anomaly_results["success"] is True
    assert "anomaly_count" in anomaly_results
    assert "total_points" in anomaly_results
    assert anomaly_results["total_points"] == 20
    assert "anomaly_percentage" in anomaly_results
    assert "results" in anomaly_results
    
    # Verify individual results
    individual_results = anomaly_results["results"]
    assert len(individual_results) == 20
    for res in individual_results:
        assert "timestamp" in res
        assert "value" in res
        assert "anomaly_score" in res
        assert "is_anomaly" in res
        assert "confidence" in res


def test_integration_with_esg_monitoring_system():
    """Test integration with overall ESG monitoring system"""
    # Create state with mixed ESG data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "esg_rating": "AA",
                "report_year": 2023,
                "revenue": 1000000,
                "industry": "Technology",
                "employees": 500,
                "hq_location": "New York, NY",
                "scope3_data": [
                    {
                        "timestamp": "2023-01-01T00:00:00Z",
                        "value": 100.0,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-02-01T00:00:00Z",
                        "value": 105.0,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    },
                    {
                        "timestamp": "2023-03-01T00:00:00Z",
                        "value": 95.0,
                        "metric_type": "co2_emissions",
                        "supplier_id": "supplier_1"
                    }
                ]
            }
        },
        processing_results={}
    )
    
    # Run the agent
    result = anomaly_detection_agent(state)
    
    # Verify integration
    assert result["workflow_status"] == "anomaly_detection_completed"
    
    # Check that processing results were updated correctly
    assert "processing_results" in result
    assert "anomaly_detection" in result["processing_results"]
    
    # Check that agent trace was updated
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    assert result["agent_trace"][-1]["agent"] == "anomaly_detection_agent"


if __name__ == "__main__":
    pytest.main([__file__])