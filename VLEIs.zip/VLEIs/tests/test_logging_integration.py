"""
Integration tests for structured logging with loguru through complete workflows
"""

import pytest
import sys
import os
import json
import re
from io import StringIO
from loguru import logger
from datetime import datetime
import tempfile
import shutil
from unittest.mock import patch, MagicMock

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))


def test_log_message_structure():
    """Test that log messages have the correct structure with request_id"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Generate a structured log message
        request_id = "structure_test"
        message_content = "Executing data processing task"
        logger.info(f"Request {request_id}: {message_content}")
        
        # Get the log output
        log_output = log_stream.getvalue()
        lines = log_output.strip().split('\n')
        
        # Find our test line
        test_line = None
        for line in lines:
            if f"Request {request_id}:" in line:
                test_line = line
                break
        
        assert test_line is not None
        
        # Check structure: timestamp | level | message
        parts = test_line.split(' | ')
        assert len(parts) == 3
        
        # Check timestamp format (updated for ISO format)
        try:
            datetime.fromisoformat(parts[0])
        except ValueError:
            pytest.fail(f"Invalid timestamp format: {parts[0]}")
        
        # Check level
        assert parts[1] == "INFO"
        
        # Check message
        assert f"Request {request_id}: {message_content}" in parts[2]
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_traceability():
    """Test request tracing through logs"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Simulate a complete workflow with a single request ID
        request_id = "trace_test_12345"
        
        # Log workflow steps
        workflow_steps = [
            "workflow_started",
            "data_ingested",
            "credentials_verified",
            "reports_generated",
            "blockchain_logged",
            "workflow_completed"
        ]
        
        for step in workflow_steps:
            logger.info(f"Request {request_id}: Workflow step {step}")
        
        # Read log output
        log_output = log_stream.getvalue()
        
        # Verify traceability
        for step in workflow_steps:
            assert f"Request {request_id}: Workflow step {step}" in log_output
        
        # Count occurrences of the request ID
        request_id_count = log_output.count(f"Request {request_id}:")
        assert request_id_count >= len(workflow_steps)
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_error_traceability():
    """Test error tracing through logs"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Simulate an error scenario
        request_id = "error_trace_test"
        
        # Log normal operations
        logger.info(f"Request {request_id}: Starting data processing")
        logger.info(f"Request {request_id}: Validating input data")
        
        # Log an error
        logger.error(f"Request {request_id}: Failed to process data: Connection timeout")
        
        # Log recovery attempt
        logger.warning(f"Request {request_id}: Retrying data processing")
        logger.info(f"Request {request_id}: Data processing completed successfully")
        
        # Read log output
        log_output = log_stream.getvalue()
        
        # Verify error traceability
        assert "Request error_trace_test:" in log_output
        assert "Starting data processing" in log_output
        assert "Failed to process data: Connection timeout" in log_output
        assert "Retrying data processing" in log_output
        assert "Data processing completed successfully" in log_output
        
        # Check that error is logged
        error_logged = "ERROR" in log_output and "Failed to process data" in log_output
        assert error_logged
        
        # Check that warning is logged
        warning_logged = "WARNING" in log_output and "Retrying" in log_output
        assert warning_logged
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_concurrent_request_logging():
    """Test logging with concurrent requests pattern"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Simulate concurrent requests pattern
        import threading
        import time
        
        logged_requests = []
        
        def simulate_request(request_id):
            logger.info(f"Request {request_id}: Processing request")
            logged_requests.append(request_id)
            time.sleep(0.001)  # Small delay
            logger.info(f"Request {request_id}: Request completed")
        
        # Simulate requests without actual threading to avoid file access issues
        request_ids = [f"concurrent_{i:03d}" for i in range(5)]
        for req_id in request_ids:
            simulate_request(req_id)
        
        # Read log output
        log_output = log_stream.getvalue()
        
        # Verify concurrent logging pattern
        for req_id in request_ids:
            assert f"Request {req_id}: Processing request" in log_output
            assert f"Request {req_id}: Request completed" in log_output
        
        # Check for unique request IDs
        request_id_count = 0
        for req_id in request_ids:
            request_id_count += log_output.count(f"Request {req_id}:")
        
        # Should have 2 log entries per request (start and complete)
        assert request_id_count >= 10
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_agent_logging_pattern():
    """Test the logging pattern used in agents"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Test the pattern used in agents
        request_id = "agent_test_001"
        
        # Simulate agent logging pattern
        logger.info(f"[{request_id}] Agent processing task")
        logger.info(f"[{request_id}] Task completed successfully")
        logger.warning(f"[{request_id}] Task taking longer than expected")
        logger.error(f"[{request_id}] Task failed due to network error")
        
        # Read log output
        log_output = log_stream.getvalue()
        
        # Verify agent logging pattern
        assert f"[{request_id}] Agent processing task" in log_output
        assert f"[{request_id}] Task completed successfully" in log_output
        assert f"[{request_id}] Task taking longer than expected" in log_output
        assert f"[{request_id}] Task failed due to network error" in log_output
        
        # Check log levels
        assert "INFO" in log_output
        assert "WARNING" in log_output
        assert "ERROR" in log_output
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_performance_logging():
    """Measure logging performance"""
    import time
    
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Measure time to generate logs
        start_time = time.perf_counter()
        
        # Generate a number of log messages
        for i in range(100):
            logger.info(f"Request perf_test_{i:03d}: Performance test message")
        
        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        
        # Check that it completed in a reasonable time (should be < 1 second)
        assert elapsed_time < 1.0, f"Logging took too long: {elapsed_time:.4f} seconds"
        
        # Verify logs were captured
        log_output = log_stream.getvalue()
        assert "Request perf_test_" in log_output
        assert log_output.count("Performance test message") >= 100
        
    finally:
        # Clean up
        logger.remove(test_id)


def test_log_analysis_parsing():
    """Validate logs can be parsed and analyzed"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Generate structured log messages
        test_data = [
            {"request_id": "analysis_001", "agent": "ingestion_agent", "action": "data_processed"},
            {"request_id": "analysis_002", "agent": "credential_agent", "action": "credential_verified"},
            {"request_id": "analysis_003", "agent": "reporting_agent", "action": "report_generated"},
            {"request_id": "analysis_004", "agent": "master_orchestrator", "action": "task_routed"},
        ]
        
        for data in test_data:
            logger.info(f"Request {data['request_id']}: Agent {data['agent']} executed {data['action']}")
        
        # Read and parse log output
        log_output = log_stream.getvalue()
        log_lines = log_output.split('\n')
        
        # Parse log entries
        parsed_logs = []
        for line in log_lines:
            if "Request" in line and "Agent" in line and "executed" in line:
                # Extract structured data
                level_match = re.search(r' \| (\w+) \| ', line)
                request_match = re.search(r'Request (\w+):', line)
                agent_match = re.search(r'Agent (\w+)', line)
                action_match = re.search(r'executed (\w+)', line)
                
                if all([level_match, request_match, agent_match, action_match]):
                    parsed_logs.append({
                        "level": level_match.group(1),
                        "request_id": request_match.group(1),
                        "agent": agent_match.group(1),
                        "action": action_match.group(1)
                    })
        
        # Verify parsed data
        assert len(parsed_logs) >= 4
        
        # Check that we can find specific entries
        ingestion_logs = [log for log in parsed_logs if log["agent"] == "ingestion_agent"]
        assert len(ingestion_logs) >= 1
        
        # Verify data integrity
        for log in parsed_logs:
            assert "level" in log
            assert "request_id" in log
            assert "agent" in log
            assert "action" in log
            
    finally:
        # Clean up
        logger.remove(test_id)


def test_context_enrichment():
    """Test context enrichment in logs"""
    # Capture log output
    log_stream = StringIO()
    test_id = logger.add(log_stream, format="{time} | {level} | {message}", level="INFO")
    
    try:
        # Test context enrichment
        request_id = "context_test_001"
        agent_name = "test_agent"
        action = "processing_data"
        
        # Log with enriched context
        logger.info(f"Request {request_id}: Agent {agent_name} executing {action}")
        logger.info(f"Request {request_id}: Completed {action} with status success")
        
        # Read log output
        log_output = log_stream.getvalue()
        
        # Verify context enrichment
        assert f"Request {request_id}:" in log_output
        assert f"Agent {agent_name}" in log_output
        assert action in log_output
        assert "success" in log_output
        
    finally:
        # Clean up
        logger.remove(test_id)
