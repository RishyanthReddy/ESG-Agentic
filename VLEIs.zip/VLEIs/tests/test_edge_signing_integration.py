"""
Integration tests for the Edge Signing Tool implementation.
"""

import os
import tempfile
import json
import subprocess
import sys
from pathlib import Path
from scripts.sign_data import EdgeSigningTool


class TestEdgeSigningToolIntegration:
    """Integration tests for the EdgeSigningTool."""
    
    def setup_method(self):
        """Set up test resources."""
        # Create temporary directory for test files
        self.test_dir = tempfile.TemporaryDirectory()
        self.test_dir_path = Path(self.test_dir.name)
        
        # Create a test data file
        self.test_file = self.test_dir_path / "test_data.csv"
        self.test_file.write_text("company_name,emissions,energy_usage\n"
                                  "Test Company,100,500\n"
                                  "Another Company,200,750")
        
        # Key file paths
        self.private_key_file = self.test_dir_path / "private.key"
        self.public_key_file = self.test_dir_path / "public.pub"
    
    def teardown_method(self):
        """Clean up test resources."""
        self.test_dir.cleanup()
    
    def test_end_to_end_signing_and_verification_workflow(self):
        """Test the complete file signing and verification workflow."""
        # Step 1: Generate keys
        result = subprocess.run([
            sys.executable, "scripts/sign_data.py", "generate-keys",
            str(self.private_key_file),
            str(self.public_key_file)
        ], capture_output=True, text=True)
        
        assert result.returncode == 0
        assert self.private_key_file.exists()
        assert self.public_key_file.exists()
        
        # Step 2: Sign file
        result = subprocess.run([
            sys.executable, "scripts/sign_data.py", "sign",
            str(self.test_file),
            str(self.private_key_file)
        ], capture_output=True, text=True)
        
        assert result.returncode == 0
        
        # Check that signature file was created
        sig_file = self.test_file.with_suffix(self.test_file.suffix + ".sig")
        assert sig_file.exists()
        
        # Step 3: Verify signature
        result = subprocess.run([
            sys.executable, "scripts/sign_data.py", "verify",
            str(self.test_file),
            str(sig_file),
            str(self.public_key_file)
        ], capture_output=True, text=True)
        
        assert result.returncode == 0
        assert "Signature is VALID" in result.stdout
    
    def test_security_validation_with_tampered_file(self):
        """Test that tampering with a file causes signature verification to fail."""
        # Generate keys
        tool = EdgeSigningTool()
        tool.generate_keys()
        tool.save_keys(str(self.private_key_file), str(self.public_key_file))
        
        # Sign file
        metadata = tool.sign_file(str(self.test_file), str(self.private_key_file))
        sig_file = self.test_file.with_suffix(self.test_file.suffix + ".sig")
        
        with open(sig_file, 'w') as f:
            json.dump(metadata, f)
        
        # Tamper with the file
        with open(self.test_file, 'a') as f:
            f.write("\nTampered Data,999,999")
        
        # Verify signature - should fail
        result = subprocess.run([
            sys.executable, "scripts/sign_data.py", "verify",
            str(self.test_file),
            str(sig_file),
            str(self.public_key_file)
        ], capture_output=True, text=True)
        
        assert result.returncode == 0  # Script runs successfully
        assert "Signature is INVALID" in result.stdout
    
    def test_file_format_support(self):
        """Test support for different file formats."""
        # Test with CSV
        csv_file = self.test_dir_path / "data.csv"
        csv_file.write_text("test,data\n1,2")
        
        # Test with Excel (create a simple CSV for this test)
        # In a real scenario, we would create actual Excel files
        
        tool = EdgeSigningTool()
        tool.generate_keys()
        tool.save_keys(str(self.private_key_file), str(self.public_key_file))
        
        # Sign CSV file
        metadata = tool.sign_file(str(csv_file), str(self.private_key_file))
        
        # Verify signature
        is_valid = tool.verify_signature(str(csv_file), metadata, str(self.public_key_file))
        assert is_valid is True
    
    def test_attack_resistance_signature_tampering(self):
        """Test resistance against signature tampering attempts."""
        tool = EdgeSigningTool()
        tool.generate_keys()
        tool.save_keys(str(self.private_key_file), str(self.public_key_file))
        
        # Sign file
        metadata = tool.sign_file(str(self.test_file), str(self.private_key_file))
        
        # Tamper with signature
        metadata["signature"] = "invalid_signature_data"
        
        # Verification should fail
        is_valid = tool.verify_signature(str(self.test_file), metadata, str(self.public_key_file))
        assert is_valid is False


if __name__ == "__main__":
    pytest.main([__file__])