"""
Integration tests for the Centralized Error Handling Framework
"""

import pytest
from unittest.mock import patch
from src.utils.error_handling import (
    BaseVLEIError, APIFailureError, DataValidationError, 
    ConfigurationError, WorkflowError, handle_error, log_error, safe_execute
)
from src.state.models import AppState


class TestWorkflowErrorRecovery:
    """Test error handling in full workflows"""
    
    def test_workflow_continues_after_api_error(self):
        """Test that workflow continues operating after API error"""
        # Simulate a workflow step that fails with API error
        def api_call_step():
            raise APIFailureError(
                "API service unavailable",
                status_code=503,
                url="https://api.example.com/data"
            )
        
        # Simulate a workflow step that succeeds
        def successful_step():
            return {"status": "success", "data": "processed"}
        
        # Execute the failing step
        result1, error1 = safe_execute(api_call_step)
        assert result1 is None
        assert isinstance(error1, APIFailureError)
        
        # Execute the successful step
        result2, error2 = safe_execute(successful_step)
        assert result2 == {"status": "success", "data": "processed"}
        assert error2 is None
    
    def test_workflow_continues_after_validation_error(self):
        """Test that workflow continues operating after validation error"""
        # Simulate a data validation that fails
        def validation_step(data):
            if not isinstance(data, dict):
                raise DataValidationError(
                    "Invalid data format",
                    field="input_data",
                    value=type(data).__name__
                )
            return {"validated": True, "data": data}
        
        # Test with invalid data
        result1, error1 = safe_execute(validation_step, "invalid_string")
        assert result1 is None
        assert isinstance(error1, DataValidationError)
        
        # Test with valid data
        result2, error2 = safe_execute(validation_step, {"key": "value"})
        assert result2 == {"validated": True, "data": {"key": "value"}}
        assert error2 is None


class TestAgentErrorPropagation:
    """Test that errors properly bubble up from agents"""
    
    def test_error_propagation_from_credential_agent(self):
        """Test error propagation from credential agent"""
        def credential_processing():
            # Simulate a configuration error in credential processing
            raise ConfigurationError(
                "Missing credential verification service configuration",
                config_key="CREDENTIAL_SERVICE_URL"
            )
        
        result, error = safe_execute(credential_processing)
        
        assert result is None
        assert isinstance(error, ConfigurationError)
        assert error.config_key == "CREDENTIAL_SERVICE_URL"
    
    def test_error_propagation_from_reporting_agent(self):
        """Test error propagation from reporting agent"""
        def report_generation():
            # Simulate a workflow error in report generation
            raise WorkflowError(
                "Failed to generate ESG report",
                workflow_step="report_compilation"
            )
        
        result, error = safe_execute(report_generation)
        
        assert result is None
        assert isinstance(error, WorkflowError)
        assert "report_compilation" in error.workflow_step


class TestSystemStability:
    """Test system stability under various error conditions"""
    
    def test_system_stability_with_multiple_errors(self):
        """Test system continues operating after multiple errors"""
        def error_function(error_type):
            if isinstance(error_type, ValueError):
                raise ValueError("Test value error")
            elif isinstance(error_type, KeyError):
                raise KeyError("missing_key")
            elif isinstance(error_type, TypeError):
                raise TypeError("Test type error")
            return "success"
        
        errors = [ValueError(), KeyError(), TypeError()]
        results = []
        
        for error in errors:
            result, handled_error = safe_execute(error_function, error)
            results.append((result, handled_error))
        
        # Verify all errors were handled properly
        for i, (result, error) in enumerate(results):
            # All should be errors, so result should be None
            assert result is None
            # All should be converted to our custom errors
            assert isinstance(error, BaseVLEIError)
    
    def test_system_stability_with_nested_errors(self):
        """Test system handles nested errors correctly"""
        def nested_function():
            def inner_function():
                raise ValueError("Inner function error")
            try:
                inner_function()
            except ValueError as e:
                raise APIFailureError("Outer API error due to inner failure")
        
        result, error = safe_execute(nested_function)
        
        assert result is None
        assert isinstance(error, APIFailureError)


class TestErrorReporting:
    """Test that error information reaches appropriate handlers"""
    
    @patch('src.utils.error_handling.logger')
    def test_error_logging_format(self, mock_logger):
        """Test error logging with proper formatting"""
        error = DataValidationError(
            "Invalid email format",
            field="email",
            value="invalid-email@test"
        )
        
        log_error(error)
        
        # Verify error was logged
        assert mock_logger.error.called
        assert mock_logger.debug.called
    
    def test_error_information_preservation(self):
        """Test that error information is preserved through handling"""
        original_error = APIFailureError(
            "Service timeout",
            status_code=504,
            url="https://api.example.com/timeout",
            response_body="Gateway Timeout"
        )
        
        handled_error = handle_error(original_error)
        
        # Verify all information is preserved
        assert handled_error.message == "Service timeout"
        assert handled_error.status_code == 504
        assert handled_error.url == "https://api.example.com/timeout"
        assert handled_error.response_body == "Gateway Timeout"
        assert handled_error.details["status_code"] == 504
        assert handled_error.details["url"] == "https://api.example.com/timeout"


class TestPerformanceImpact:
    """Test the performance impact of error handling framework"""
    
    def test_error_handling_overhead(self):
        """Test overhead of error handling framework"""
        import time
        
        def simple_function():
            return "success"
        
        def error_function():
            raise ValueError("Test error")
        
        # Measure normal function execution time
        start_time = time.time()
        for _ in range(100):
            result = simple_function()
        normal_execution_time = time.time() - start_time
        
        # Measure function execution time with error handling
        start_time = time.time()
        for _ in range(100):
            result, error = safe_execute(simple_function)
        safe_execution_time = time.time() - start_time
        
        # Measure error handling time
        start_time = time.time()
        for _ in range(100):
            result, error = safe_execute(error_function)
        error_handling_time = time.time() - start_time
        
        # Verify overhead is reasonable (less than 100x normal execution)
        # Note: This is a rough check, actual performance may vary
        assert safe_execution_time < normal_execution_time * 100
        assert error_handling_time < 10.0  # Should complete in under 10 seconds


if __name__ == "__main__":
    pytest.main([__file__])