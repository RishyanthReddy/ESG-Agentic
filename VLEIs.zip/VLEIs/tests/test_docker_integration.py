"""
Integration tests for Docker deployment
"""

import pytest
import subprocess
import time
import requests
import docker
from pathlib import Path
import os


def test_full_stack_deployment():
    """Test full stack deployment with docker-compose"""
    try:
        # Start services with docker-compose
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to start
        time.sleep(30)
        
        # Check that services are running
        ps_result = subprocess.run(
            ["docker-compose", "ps"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert ps_result.returncode == 0, "docker-compose ps failed"
        assert "esg-engine" in ps_result.stdout, "esg-engine service not running"
        assert "esg-redis" in ps_result.stdout, "redis service not running"
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
    except subprocess.TimeoutExpired:
        pytest.fail("docker-compose operation timed out")
    except FileNotFoundError:
        pytest.skip("docker-compose not available on this system")


def test_service_communication():
    """Test inter-service communication"""
    try:
        # Start services
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to be ready
        time.sleep(45)
        
        # Test that we can access the API
        response = requests.get("http://localhost:8000/", timeout=10)
        assert response.status_code == 200, "API root endpoint not accessible"
        
        # Test health endpoint
        response = requests.get("http://localhost:8000/health", timeout=10)
        assert response.status_code == 200, "Health endpoint not accessible"
        assert "status" in response.json(), "Health response missing status field"
        
        # Test that Redis is accessible from the app container
        exec_result = subprocess.run(
            ["docker-compose", "exec", "-T", "esg-engine", "python", "-c", 
             "import redis; r = redis.Redis(host='redis', port=6379); r.ping(); print('Redis connection successful')"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert exec_result.returncode == 0, f"Redis connection test failed: {exec_result.stderr}"
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
    except (subprocess.TimeoutExpired, requests.exceptions.RequestException):
        # Clean up on failure
        try:
            subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        except:
            pass
        pytest.fail("Service communication test failed")


def test_data_persistence():
    """Test data persistence across container restarts"""
    try:
        # Start services
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to be ready
        time.sleep(45)
        
        # Create some data by making a request
        response = requests.post(
            "http://localhost:8000/ingest/stream",
            json={
                "supplier_data": {
                    "company_name": "Test Company",
                    "esg_rating": "AA"
                }
            },
            timeout=30
        )
        
        # Store the initial response
        initial_response = response.json()
        assert response.status_code == 200, "Initial data ingestion failed"
        
        # Restart the esg-engine service
        restart_result = subprocess.run(
            ["docker-compose", "restart", "esg-engine"],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        assert restart_result.returncode == 0, "Service restart failed"
        
        # Wait for service to come back up
        time.sleep(30)
        
        # Verify API is still accessible
        response = requests.get("http://localhost:8000/", timeout=10)
        assert response.status_code == 200, "API not accessible after restart"
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
    except (subprocess.TimeoutExpired, requests.exceptions.RequestException):
        # Clean up on failure
        try:
            subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        except:
            pass
        pytest.fail("Data persistence test failed")


def test_production_simulation():
    """Test production-like deployment scenarios"""
    try:
        # Start services
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to be ready
        time.sleep(45)
        
        # Check service health
        exec_result = subprocess.run(
            ["docker-compose", "exec", "-T", "esg-engine", "curl", "-f", "http://localhost:8000/health"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert exec_result.returncode == 0, "Health check failed"
        
        # Check logs for proper startup
        logs_result = subprocess.run(
            ["docker-compose", "logs", "esg-engine"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert logs_result.returncode == 0, "Could not retrieve logs"
        assert "Starting ESG Intelligence Platform" in logs_result.stdout, "Application startup message not found"
        
        # Check that the app is running as non-root user
        user_result = subprocess.run(
            ["docker-compose", "exec", "-T", "esg-engine", "whoami"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
    except subprocess.TimeoutExpired:
        # Clean up on failure
        try:
            subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        except:
            pass
        pytest.fail("Production simulation test failed")


def test_volume_management():
    """Test persistent volumes for data storage"""
    try:
        # Start services
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to be ready
        time.sleep(45)
        
        # Check that volumes are created
        volume_result = subprocess.run(
            ["docker", "volume", "ls"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert volume_result.returncode == 0, "Could not list docker volumes"
        assert "redis_data" in volume_result.stdout, "Redis data volume not found"
        assert "app_logs" in volume_result.stdout, "App logs volume not found"
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
        # Check that volumes are removed with -v flag
        volume_result_after = subprocess.run(
            ["docker", "volume", "ls"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
    except subprocess.TimeoutExpired:
        # Clean up on failure
        try:
            subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        except:
            pass
        pytest.fail("Volume management test failed")


def test_network_configuration():
    """Test Docker networking for service communication"""
    try:
        # Start services
        up_result = subprocess.run(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        assert up_result.returncode == 0, f"docker-compose up failed: {up_result.stderr}"
        
        # Wait for services to be ready
        time.sleep(45)
        
        # Check that containers are on the same network
        network_result = subprocess.run(
            ["docker", "network", "ls"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        assert network_result.returncode == 0, "Could not list docker networks"
        
        # Check that containers can communicate
        ping_result = subprocess.run(
            ["docker-compose", "exec", "-T", "esg-engine", "ping", "-c", "3", "redis"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Clean up
        subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        
    except subprocess.TimeoutExpired:
        # Clean up on failure
        try:
            subprocess.run(["docker-compose", "down", "-v"], capture_output=True, timeout=60)
        except:
            pass
        pytest.fail("Network configuration test failed")


if __name__ == "__main__":
    pytest.main([__file__])