"""
Tests for enhanced ingestion functionality including multi-format data handling.
"""

import pytest
import pandas as pd
from io import BytesIO
import json

from src.tools.ingestion import FileUploadTool, FileUploadError
from src.agents.ingestion import ingestion_agent, IngestionError
from src.state.models import AppState


class TestEnhancedIngestion:
    """Test suite for enhanced ingestion functionality."""

    def test_csv_format_detection(self):
        """Test automatic format detection for CSV files."""
        tool = FileUploadTool()
        
        # Create a sample CSV with ESG data
        csv_data = """company_name,esg_score,carbon_emissions,renewable_energy
        GreenCorp,85,1200,45
        EcoTech,92,800,65"""
        
        # Convert to bytes
        file_content = csv_data.encode('utf-8')
        result = tool.run(file_content, "test_data.csv")
        
        assert result["company_name"] == "GreenCorp"
        assert result["data_type"] == "esg_data"
        assert "esg_score" in result
        assert result["esg_score"] in [85, "85"]  # Could be int or str

    def test_excel_format_detection(self):
        """Test automatic format detection for Excel files."""
        tool = FileUploadTool()
        
        # Create a sample Excel file with GRI data in memory
        df = pd.DataFrame({
            'company_name': ['SustainCo'],
            'gri_standard': ['GRI 302'],
            'report_year': [2023],
            'energy_consumption': [5000]
        })
        
        excel_buffer = BytesIO()
        df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        
        result = tool.run(excel_buffer.getvalue(), "test_data.xlsx")
        
        assert result["company_name"] == "SustainCo"
        assert result["data_type"] == "gri_report"
        assert "report_year" in result

    def test_data_mapping_various_formats(self):
        """Test mapping from various formats to canonical format."""
        tool = FileUploadTool()
        
        # Test with custom format mapping
        csv_data = """CompanyName,ESG_Rating,CO2_Emissions
        BlueIndustries,A+,1500"""
        
        file_content = csv_data.encode('utf-8')
        format_mapping = {
            "CompanyName": "company_name",
            "ESG_Rating": "esg_rating",
            "CO2_Emissions": "carbon_emissions"
        }
        
        result = tool.run(
            file_content, 
            "custom_format.csv",
            format_mapping=format_mapping
        )
        
        assert result["company_name"] == "BlueIndustries"
        assert "esg_rating" in result
        assert "carbon_emissions" in result

    def test_malformed_file_handling(self):
        """Test handling of malformed files."""
        tool = FileUploadTool()
        
        # Test with empty CSV
        empty_csv = ""
        with pytest.raises(FileUploadError, match="empty"):
            tool.run(empty_csv.encode('utf-8'), "empty.csv")
        
        # Test with invalid file extension
        with pytest.raises(FileUploadError, match="Unsupported file format"):
            tool.run(b"some data", "test_data.txt")

    def test_data_quality_validation(self):
        """Test data quality validation."""
        tool = FileUploadTool()
        
        # Test with valid data
        csv_data = """company_name,data_type,revenue
        ValidCompany,esg_data,1000000"""
        
        result = tool.run(csv_data.encode('utf-8'), "valid_data.csv")
        
        assert result["company_name"] == "ValidCompany"
        assert result["data_type"] == "esg_data"
        assert "revenue" in result

    def test_ingestion_agent_with_file_data(self):
        """Test ingestion agent with file upload data."""
        # Create a mock state with file upload data
        state = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": b"company_name,data_type,revenue\nTestCorp,esg_data,500000",
                    "name": "test_upload.csv"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Process with ingestion agent
        result = ingestion_agent(state)
        
        # Check that the result contains expected data
        assert result["workflow_status"] == "data_ingested"
        assert len(result["task_queue"]) > 0
        assert "processed_supplier_data" in result["workflow_data"]
        
        processed_data = result["workflow_data"]["processed_supplier_data"]
        assert processed_data["company_name"] == "TestCorp"
        assert processed_data["data_type"] == "esg_data"

    def test_ingestion_agent_with_direct_data(self):
        """Test ingestion agent with direct supplier data."""
        # Create a mock state with direct supplier data
        state = AppState(
            workflow_data={
                "supplier_data": {
                    "company_name": "DirectCorp",
                    "data_type": "gri_report",
                    "report_year": 2023
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Process with ingestion agent
        result = ingestion_agent(state)
        
        # Check that the result contains expected data
        assert result["workflow_status"] == "data_ingested"
        assert len(result["task_queue"]) > 0
        assert "processed_supplier_data" in result["workflow_data"]
        
        processed_data = result["workflow_data"]["processed_supplier_data"]
        assert processed_data["company_name"] == "DirectCorp"
        assert processed_data["data_type"] == "gri_report"

    def test_error_handling_in_ingestion_agent(self):
        """Test error handling in ingestion agent."""
        # Create a mock state with invalid data
        state = AppState(
            workflow_data={
                "supplier_data": {
                    # Missing required fields
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Should raise IngestionError
        with pytest.raises(IngestionError):
            ingestion_agent(state)

    def test_excel_with_multiple_sheets(self):
        """Test processing Excel files with multiple sheets (first sheet should be used)."""
        tool = FileUploadTool()
        
        # Create Excel with multiple sheets
        with pd.ExcelWriter('test_multi_sheet.xlsx') as writer:
            pd.DataFrame({'company_name': ['Sheet1Corp'], 'data_type': ['esg_data']}).to_excel(writer, sheet_name='Sheet1', index=False)
            pd.DataFrame({'company_name': ['Sheet2Corp'], 'data_type': ['gri_report']}).to_excel(writer, sheet_name='Sheet2', index=False)
        
        # Read the file and test
        with open('test_multi_sheet.xlsx', 'rb') as f:
            file_content = f.read()
            
        result = tool.run(file_content, "multi_sheet.xlsx")
        
        # Should process the first sheet
        assert result["company_name"] == "Sheet1Corp"
        assert result["data_type"] == "esg_data"

    def test_data_type_hint_functionality(self):
        """Test data type hint functionality."""
        tool = FileUploadTool()
        
        # CSV without clear indicators
        csv_data = """company_name,value1,value2
        HintTestCorp,100,200"""
        
        # Without hint
        result1 = tool.run(csv_data.encode('utf-8'), "no_hint.csv")
        # With hint
        result2 = tool.run(
            csv_data.encode('utf-8'), 
            "with_hint.csv",
            data_type_hint="gri_report"
        )
        
        # Without hint it might default to esg_data
        # With hint it should use the provided type
        assert result2["data_type"] == "gri_report"


if __name__ == "__main__":
    pytest.main([__file__])