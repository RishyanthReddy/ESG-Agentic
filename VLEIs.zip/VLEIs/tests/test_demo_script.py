"""
Test suite for demo script and narrative creation.
This module tests:
1. Demo script accuracy and completeness
2. Presentation timing validation
3. Fallback testing for CLI demonstration
4. Documentation quality and clarity
"""

import os
import sys
import pytest
import json
import time
import subprocess
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from demo_scripts.master_demo import DemoOrchestrator


def test_script_validation():
    """Test demo script accuracy and completeness"""
    # Create orchestrator instance
    orchestrator = DemoOrchestrator()
    
    # Check that we have demo scripts
    assert len(orchestrator.demo_scripts) > 0, "No demo scripts found"
    
    # Check that each demo script has required fields
    for demo in orchestrator.demo_scripts:
        assert "name" in demo, "Demo script missing 'name' field"
        assert "description" in demo, "Demo script missing 'description' field"
        assert "cli_script" in demo, "Demo script missing 'cli_script' field"
        assert "duration" in demo, "Demo script missing 'duration' field"
        assert "args" in demo, "Demo script missing 'args' field"
        
        # Check that CLI script exists
        cli_script_path = demo["cli_script"]
        assert os.path.exists(cli_script_path), f"CLI script not found: {cli_script_path}"


def test_timing_validation():
    """Test presentation fits time constraints"""
    # Create orchestrator instance
    orchestrator = DemoOrchestrator()
    
    # Calculate total estimated time
    total_time = sum(demo["duration"] for demo in orchestrator.demo_scripts)
    
    # Check that total time is within hackathon constraints (typically 10-15 minutes)
    assert total_time <= 900, f"Total demo time ({total_time}s) exceeds 15-minute constraint"
    
    # Check that we have a reasonable number of demos
    assert len(orchestrator.demo_scripts) >= 5, "Insufficient number of demo components"
    assert len(orchestrator.demo_scripts) <= 15, "Too many demo components"


def test_fallback_testing():
    """Test CLI demonstration completeness"""
    # Create orchestrator instance
    orchestrator = DemoOrchestrator()
    
    # Check that all demos have CLI alternatives
    for demo in orchestrator.demo_scripts:
        cli_script = demo["cli_script"]
        assert cli_script is not None, f"Demo '{demo['name']}' missing CLI alternative"
        assert isinstance(cli_script, str), f"Demo '{demo['name']}' CLI script is not a string"
        assert len(cli_script) > 0, f"Demo '{demo['name']}' CLI script is empty"


def test_documentation_quality():
    """Test clarity and usability of documentation"""
    # Check that demo script documentation exists
    doc_path = os.path.join(os.path.dirname(__file__), '..', 'docs', 'demo_script.md')
    assert os.path.exists(doc_path), "Demo script documentation not found"
    
    # Read the documentation
    with open(doc_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for key sections
    assert "# ESG Intelligence Platform - Hackathon Demo Script" in content, "Missing title"
    assert "Executive Summary" in content, "Missing executive summary"
    assert "Presentation Narrative" in content, "Missing presentation narrative"
    assert "Fallback Plans" in content, "Missing fallback plans"
    assert "Timing Breakdown" in content, "Missing timing breakdown"
    
    # Check for CLI alternatives in documentation
    assert "CLI Alternative" in content, "Missing CLI alternatives in documentation"


def test_cli_script_execution():
    """Test that CLI scripts execute without errors"""
    # Test master demo script
    result = subprocess.run(
        [sys.executable, "demo_scripts/master_demo.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"master_demo.py failed with return code {result.returncode}"
    
    # Test listing demos
    result = subprocess.run(
        [sys.executable, "demo_scripts/master_demo.py", "--mode", "list"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"master_demo.py --mode list failed with return code {result.returncode}"


def test_demo_orchestrator_functionality():
    """Test demo orchestrator functionality"""
    # Create orchestrator instance
    orchestrator = DemoOrchestrator()
    
    # Test listing demos
    orchestrator.list_demos()
    
    # Test running a single demo script (using a simple one)
    simple_demo = {
        "name": "Test Demo",
        "description": "Test demo description",
        "cli_script": "demo_scripts/health_check.sh",
        "duration": 5,
        "args": []
    }
    
    # This should not raise an exception
    result = orchestrator.run_script(simple_demo)
    # Note: Result may be False if bash is not available, but it shouldn't raise an exception


def test_rehearsal_mode():
    """Test rehearsal mode functionality"""
    # Create orchestrator instance
    orchestrator = DemoOrchestrator()
    
    # Test rehearsal mode (this should not raise exceptions)
    orchestrator.run_rehearsal()


if __name__ == "__main__":
    pytest.main([__file__])