"""
Unit tests to validate the project structure
"""
import os
import pytest
from pathlib import Path

def test_project_root_files():
    """Test that required files exist in project root"""
    required_files = [
        "main.py",
        "config.py",
        "requirements.txt",
        "Dockerfile",
        "docker-compose.yml",
        ".env"
    ]
    
    for file_name in required_files:
        assert Path(file_name).exists(), f"Required file {file_name} not found in project root"

def test_src_directory_structure():
    """Test that src directory has required subdirectories"""
    src_path = Path("src")
    assert src_path.exists(), "src directory not found"
    
    required_dirs = [
        "agents",
        "tools", 
        "state",
        "graph"
    ]
    
    for dir_name in required_dirs:
        dir_path = src_path / dir_name
        assert dir_path.exists(), f"Required directory {dir_name} not found in src"
        assert (dir_path / "__init__.py").exists(), f"__init__.py not found in {dir_name}"

def test_tests_directory_exists():
    """Test that tests directory exists"""
    tests_path = Path("tests")
    assert tests_path.exists(), "tests directory not found"
    assert (tests_path / "__init__.py").exists(), "__init__.py not found in tests"

def test_requirements_txt_content():
    """Test that requirements.txt contains required dependencies"""
    with open("requirements.txt", "r") as f:
        content = f.read()
        
    # Check for core dependencies
    assert "langgraph==0.2.14" in content
    assert "fastapi==0.104.1" in content
    assert "uvicorn[standard]==0.24.0" in content
    assert "pydantic>=" in content
    assert "loguru==0.7.2" in content
    assert "python-dotenv==1.0.0" in content
    
    # Check for data processing dependencies
    assert "pandas" in content
    assert "openpyxl==3.1.2" in content
    
    # Check for blockchain and API dependencies
    assert "web3==6.12.0" in content
    assert "httpx==0.25.2" in content
    
    # Check for testing dependencies
    assert "pytest==7.4.3" in content
    assert "pytest-asyncio==0.21.1" in content
    assert "pytest-mock==3.12.0" in content
    
    # Check for containerization dependencies
    assert "docker==6.1.3" in content