"""
Integration tests for the health endpoint
"""
import pytest
import asyncio
import time
import threading
import uvicorn
from fastapi.testclient import TestClient
from unittest.mock import patch
from main import app

# Create test client with proper server setup
class TestHealthEndpoint:
    @pytest.fixture(scope="class")
    def test_client(self):
        """Create a test client with running server"""
        # Start the server in a separate thread
        def run_server():
            uvicorn.run(app, host="0.0.0.0", port=8000)
        
        server_thread = threading.Thread(target=run_server)
        server_thread.daemon = True
        server_thread.start()
        
        # Wait for server to start
        time.sleep(2)
        
        # Return a test client
        yield TestClient(app)
        
        # Clean up
        server_thread.join(timeout=1)

    def test_live_llm_connectivity(self, test_client):
        """Test against actual LLM service if API key is available"""
        import os
        if not os.getenv("GLAMA_API_KEY"):
            pytest.skip("GLAMA_API_KEY not set, skipping live LLM test")
        
        response = test_client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert "checks" in data
        assert "llm" in data["checks"]
        
        # LLM check should be either healthy or unhealthy, but should exist
        llm_check = data["checks"]["llm"]
        assert "status" in llm_check
        assert llm_check["status"] in ["healthy", "unhealthy"]

    def test_live_blockchain_connectivity(self, test_client):
        """Test against actual blockchain service if INFURA_API_KEY is available"""
        import os
        if not os.getenv("INFURA_API_KEY"):
            pytest.skip("INFURA_API_KEY not set, skipping live blockchain test")
        
        response = test_client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert "checks" in data
        assert "blockchain" in data["checks"]
        
        # Blockchain check should be either healthy or unhealthy, but should exist
        blockchain_check = data["checks"]["blockchain"]
        assert "status" in blockchain_check
        assert blockchain_check["status"] in ["healthy", "unhealthy", "unknown"]

    def test_endpoint_performance(self, test_client):
        """Measure health check response times"""
        start_time = time.time()
        response = test_client.get("/health")
        end_time = time.time()
        
        assert response.status_code == 200
        assert end_time - start_time < 5.0  # Should complete within 5 seconds
        
        data = response.json()
        assert "response_time" in data
        assert data["response_time"] < 5.0

    def test_service_failure_simulation(self, test_client):
        """Test with various service failures simulated via mocking"""
        # Test with LLM failure
        with patch('src.llm.client.GeminiClient.generate_content') as mock_generate:
            mock_generate.side_effect = Exception("Simulated LLM failure")
            
            response = test_client.get("/health")
            assert response.status_code == 200
            
            data = response.json()
            assert data["status"] in ["unhealthy", "degraded"]
            assert data["checks"]["llm"]["status"] == "unhealthy"

    def test_health_endpoint_format(self, test_client):
        """Validate that health responses can be parsed by monitoring systems"""
        response = test_client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        
        # Check required fields for monitoring systems
        required_fields = ["status", "timestamp", "checks", "response_time"]
        for field in required_fields:
            assert field in data, f"Missing required field: {field}"
        
        # Check checks structure
        assert isinstance(data["checks"], dict)
        
        # Check that each check has a status
        for check_name, check_data in data["checks"].items():
            assert "status" in check_data, f"Missing status in check: {check_name}"

    def test_concurrent_requests(self, test_client):
        """Test health endpoint under concurrent requests"""
        import concurrent.futures
        
        def make_request():
            response = test_client.get("/health")
            return response.status_code == 200
        
        # Make multiple concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(make_request) for _ in range(10)]
            results = [future.result() for future in futures]
        
        # All requests should succeed
        assert all(results), "Not all concurrent requests succeeded"