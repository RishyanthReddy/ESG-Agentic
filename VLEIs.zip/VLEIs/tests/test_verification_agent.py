"""
Unit tests for the verification agent
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.verification import verification_agent, VerificationError
from src.state.models import AppState, vLEICredential, VerificationStatus
from src.tools.verification import GleifVerifierTool
from src.tools.registry import ToolRegistry


class TestVerificationAgent:
    """Test cases for verification agent logic"""
    
    def test_agent_logic_with_current_credential(self):
        """Test verification workflow logic with current_credential"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "value"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification result
        mock_result = {
            "verified": True,
            "credential_id": str(credential.id),
            "reason": "Credential is valid"
        }
        
        # Patch the GleifVerifierTool.run method
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_result):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify the result
            assert result["workflow_status"] == "credential_verified"
            assert "processing_results" in result
            assert "verification_result" in result["processing_results"]
            assert result["processing_results"]["verification_result"]["verified"] is True
            
            # Verify credential status was updated
            assert len(result["credentials"]) == 1
            assert result["credentials"][0].verification_status == VerificationStatus.VERIFIED
            
            # Verify agent trace was updated
            assert len(result["agent_trace"]) == 1
            assert result["agent_trace"][0]["agent"] == "verification_agent"
    
    def test_agent_logic_with_pending_credential(self):
        """Test verification workflow logic with pending credential in list"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "value"},
            verification_status=VerificationStatus.PENDING
        )
        
        # Create initial state without current_credential but with pending credential
        state = AppState(
            credentials=[credential]
        )
        
        # Mock verification result
        mock_result = {
            "verified": False,
            "credential_id": str(credential.id),
            "reason": "Credential has been revoked"
        }
        
        # Patch the GleifVerifierTool.run method
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_result):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify the result
            assert result["workflow_status"] == "credential_verified"
            assert result["processing_results"]["verification_result"]["verified"] is False
            
            # Verify credential status was updated
            assert len(result["credentials"]) == 1
            assert result["credentials"][0].verification_status == VerificationStatus.FAILED
    
    def test_agent_logic_with_no_credential(self):
        """Test verification workflow logic with no credential to verify"""
        # Create initial state without any credentials
        state = AppState()
        
        # Run the verification agent
        result = verification_agent(state)
        
        # Verify error handling
        assert result["workflow_status"] == "verification_failed"
        assert len(result["errors"]) > 0
        assert "No credential found for verification" in result["errors"][0]
    
    def test_tool_integration_with_registry(self):
        """Test GleifVerifierTool usage when registered in ToolRegistry"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject"
        )
        
        # Create initial state
        state = AppState(
            current_credential=credential
        )
        
        # Mock verification result
        mock_result = {
            "verified": True,
            "credential_id": str(credential.id)
        }
        
        # Mock the tool registry to return our tool
        mock_tool = Mock(spec=GleifVerifierTool)
        mock_tool.run.return_value = mock_result
        
        with patch('src.tools.registry.ToolRegistry.get_tool', return_value=mock_tool):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify the tool was used
            mock_tool.run.assert_called_once()
            assert result["workflow_status"] == "credential_verified"
    
    def test_tool_integration_without_registry(self):
        """Test GleifVerifierTool usage when not registered in ToolRegistry"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject"
        )
        
        # Create initial state
        state = AppState(
            current_credential=credential
        )
        
        # Mock verification result
        mock_result = {
            "verified": True,
            "credential_id": str(credential.id)
        }
        
        # Mock the tool registry to return None (tool not registered)
        with patch('src.tools.registry.ToolRegistry.get_tool', return_value=None):
            with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Verify the result
                assert result["workflow_status"] == "credential_verified"
    
    def test_state_updates_with_current_credential(self):
        """Verify correct state modifications when current_credential is verified"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject"
        )
        
        # Create initial state
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification result
        mock_result = {
            "verified": True,
            "credential_id": str(credential.id)
        }
        
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_result):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify state updates
            assert "current_credential" in result
            assert result["current_credential"].verification_status == VerificationStatus.VERIFIED
            assert len(result["credentials"]) == 1
            assert result["credentials"][0].verification_status == VerificationStatus.VERIFIED
    
    def test_state_updates_without_current_credential(self):
        """Verify correct state modifications when only credentials list is updated"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            verification_status=VerificationStatus.PENDING
        )
        
        # Create initial state
        state = AppState(
            credentials=[credential]
        )
        
        # Mock verification result
        mock_result = {
            "verified": False,
            "credential_id": str(credential.id)
        }
        
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_result):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify state updates
            assert "current_credential" not in result
            assert len(result["credentials"]) == 1
            assert result["credentials"][0].verification_status == VerificationStatus.FAILED
    
    def test_error_scenarios_with_tool_exception(self):
        """Test handling of verification failures when tool raises exception"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject"
        )
        
        # Create initial state
        state = AppState(
            current_credential=credential
        )
        
        # Mock the tool to raise an exception
        with patch('src.tools.verification.GleifVerifierTool.run', side_effect=Exception("API Error")):
            # Run the verification agent
            result = verification_agent(state)
            
            # Verify error handling
            assert result["workflow_status"] == "verification_failed"
            assert len(result["errors"]) > 0
            assert "API Error" in result["errors"][0]
    
    def test_error_scenarios_with_invalid_result(self):
        """Test handling of verification failures with invalid tool result"""
        # Create a credential to verify
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject"
        )
        
        # Create initial state
        state = AppState(
            current_credential=credential
        )
        
        # Mock the tool to return an invalid result
        with patch('src.tools.verification.GleifVerifierTool.run', return_value={"invalid": "result"}):
            # Run the verification agent
            result = verification_agent(state)
            
            # The agent should handle this gracefully
            assert result["workflow_status"] in ["credential_verified", "verification_failed"]


if __name__ == "__main__":
    pytest.main([__file__])