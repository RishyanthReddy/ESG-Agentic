"""
Unit tests for the Infura Blockchain Tool
"""

import pytest
from unittest.mock import Mock, patch
from web3 import Web3
from src.tools.provenance import InfuraBlockchainTool, BlockchainError
from src.tools.registry import BaseTool


class TestInfuraBlockchainTool:
    """Test cases for Infura Blockchain Tool logic"""
    
    def test_transaction_building_and_signing(self):
        """Test transaction construction and signing"""
        # Mock web3 and account
        with patch('src.tools.provenance.Web3') as mock_web3:
            # Configure mock
            mock_instance = Mock()
            mock_web3.return_value = mock_instance
            mock_instance.is_connected.return_value = True
            mock_instance.eth.chain_id = 11155111
            
            # Mock account methods
            mock_account = Mock()
            mock_account.address = "0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6"
            mock_instance.eth.account.from_key.return_value = mock_account
            
            # Mock transaction methods
            mock_instance.eth.get_transaction_count.return_value = 5
            mock_instance.eth.estimate_gas.return_value = 21000
            mock_instance.eth.gas_price = 20000000000  # 20 Gwei
            mock_instance.to_bytes.return_value = b"test_data"
            
            # Mock signing
            mock_signed_txn = Mock()
            mock_signed_txn.rawTransaction = b"signed_transaction_data"
            mock_instance.eth.account.sign_transaction.return_value = mock_signed_txn
            
            # Mock sending transaction
            mock_tx_hash = b'\x12\x34\x56\x78\x90\xab\xcd\xef'
            mock_instance.eth.send_raw_transaction.return_value = mock_tx_hash
            
            # Mock transaction receipt
            mock_receipt = Mock()
            mock_receipt.status = 1
            mock_instance.eth.wait_for_transaction_receipt.return_value = mock_receipt
            
            # Mock hex conversion
            mock_instance.to_hex.return_value = "0x1234567890abcdef"
            
            # Initialize tool
            tool = InfuraBlockchainTool()
            
            # Test transaction preparation
            transaction = tool._prepare_transaction("test_data_hash", "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef")
            
            # Verify transaction structure
            assert "nonce" in transaction
            assert "to" in transaction
            assert "value" in transaction
            assert "gas" in transaction
            assert "gasPrice" in transaction
            assert "data" in transaction
            assert transaction["value"] == 0
            assert transaction["nonce"] == 5
            
            # Test signing and sending
            tx_hash = tool._sign_and_send_transaction(transaction, "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef")
            
            # Verify the transaction hash
            assert tx_hash == "0x1234567890abcdef"
    
    def test_gas_estimation(self):
        """Validate gas calculation algorithms"""
        with patch('src.tools.provenance.Web3') as mock_web3:
            # Configure mock
            mock_instance = Mock()
            mock_web3.return_value = mock_instance
            mock_instance.is_connected.return_value = True
            mock_instance.eth.chain_id = 11155111
            
            # Mock account methods
            mock_account = Mock()
            mock_account.address = "0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6"
            mock_instance.eth.account.from_key.return_value = mock_account
            
            # Mock gas estimation
            mock_instance.eth.get_transaction_count.return_value = 0
            mock_instance.eth.estimate_gas.return_value = 25000  # Custom gas estimate
            mock_instance.eth.gas_price = 30000000000  # 30 Gwei
            mock_instance.to_bytes.return_value = b"test_data"
            
            # Initialize tool
            tool = InfuraBlockchainTool()
            
            # Test transaction preparation
            transaction = tool._prepare_transaction("test_data_hash", "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef")
            
            # Verify gas estimation
            assert transaction["gas"] == 30000  # 25000 * 1.2 (20% buffer)
            assert transaction["gasPrice"] == 33000000000  # 30 Gwei * 1.1 (10% premium)
    
    def test_error_scenarios_network_failures(self):
        """Test network failures"""
        with patch('src.tools.provenance.Web3') as mock_web3:
            # Configure mock to simulate network failure
            mock_instance = Mock()
            mock_web3.return_value = mock_instance
            mock_instance.is_connected.return_value = False
            
            # Should raise BlockchainError on connection failure
            with pytest.raises(BlockchainError, match="Failed to connect to Infura Sepolia endpoint"):
                InfuraBlockchainTool()
    
    def test_error_scenarios_insufficient_funds(self):
        """Test insufficient funds scenario"""
        with patch('src.tools.provenance.Web3') as mock_web3:
            # Configure mock
            mock_instance = Mock()
            mock_web3.return_value = mock_instance
            mock_instance.is_connected.return_value = True
            mock_instance.eth.chain_id = 11155111
            
            # Mock account methods
            mock_account = Mock()
            mock_account.address = "0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6"
            mock_instance.eth.account.from_key.return_value = mock_account
            
            # Mock transaction methods
            mock_instance.eth.get_transaction_count.return_value = 5
            mock_instance.eth.estimate_gas.return_value = 21000
            mock_instance.eth.gas_price = 20000000000
            mock_instance.to_bytes.return_value = b"test_data"
            
            # Mock signing to raise exception
            mock_instance.eth.account.sign_transaction.side_effect = Exception("Insufficient funds")
            
            # Initialize tool
            tool = InfuraBlockchainTool()
            
            # Test transaction preparation
            transaction = tool._prepare_transaction("test_data_hash", "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef")
            
            # Test signing and sending should raise BlockchainError
            with pytest.raises(BlockchainError, match="Insufficient funds"):
                tool._sign_and_send_transaction(transaction, "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef")
    
    def test_tool_interface_compliance(self):
        """Test BaseTool compliance and method signatures"""
        with patch('src.tools.provenance.Web3') as mock_web3:
            # Configure mock
            mock_instance = Mock()
            mock_web3.return_value = mock_instance
            mock_instance.is_connected.return_value = True
            mock_instance.eth.chain_id = 11155111
            
            # Create the tool instance
            tool = InfuraBlockchainTool()
            
            # Verify it's a BaseTool instance
            assert isinstance(tool, BaseTool)
            
            # Verify attributes
            assert tool.name == "infura_blockchain"
            assert tool.description == "Logs data provenance to Ethereum blockchain via Infura's Sepolia testnet"
            
            # Verify methods exist
            assert hasattr(tool, 'run')
            assert callable(tool.run)
            assert hasattr(tool, 'get_connection_info')
            assert callable(tool.get_connection_info)
            assert hasattr(tool, '_prepare_transaction')
            assert callable(tool._prepare_transaction)
            assert hasattr(tool, '_sign_and_send_transaction')
            assert callable(tool._sign_and_send_transaction)


if __name__ == "__main__":
    pytest.main([__file__])