"""
Unit tests for the Azure Verified ID Tool
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from src.tools.verification import AzureVerifiedIDTool
from src.state.models import vLEICredential
from datetime import datetime
import uuid


@pytest.fixture
def azure_tool():
    """Create an AzureVerifiedIDTool instance for testing"""
    return AzureVerifiedIDTool()


@pytest.fixture
def mock_credential_data():
    """Sample credential data for testing"""
    return {
        "company_name": "Test Company",
        "esg_rating": "AA",
        "report_year": 2023,
        "verified_date": datetime.utcnow().isoformat()
    }


@pytest.fixture
def mock_presentation_request():
    """Sample presentation request for testing"""
    return {
        "purpose": "ESG compliance verification",
        "issuer": "did:web:example.com"
    }


def test_azure_tool_initialization(azure_tool):
    """Test Azure Verified ID Tool initialization"""
    assert azure_tool.name == "azure_verified_id"
    assert azure_tool.description == "Issues and verifies credentials using Microsoft's Azure Verified ID API"
    assert hasattr(azure_tool, 'api_base_url')
    assert hasattr(azure_tool, 'tenant_id')
    assert hasattr(azure_tool, 'client_id')
    assert hasattr(azure_tool, 'client_secret')


@patch('src.tools.verification.ClientSecretCredential')
def test_get_access_token_success(mock_credential_class, azure_tool):
    """Test successful access token retrieval"""
    # Mock the credential and token
    mock_credential = Mock()
    mock_token = Mock()
    mock_token.token = "fake_access_token"
    mock_credential.get_token.return_value = mock_token
    mock_credential_class.return_value = mock_credential
    
    # Reinitialize tool with mocked credential
    tool = AzureVerifiedIDTool()
    
    # Test token retrieval
    token = tool._get_access_token()
    assert token == "fake_access_token"
    mock_credential.get_token.assert_called_once()


@patch('src.tools.verification.ClientSecretCredential')
def test_get_access_token_failure(mock_credential_class, azure_tool):
    """Test failed access token retrieval"""
    # Mock credential to raise an exception
    mock_credential_class.side_effect = Exception("Authentication failed")
    
    # Reinitialize tool with mocked credential
    tool = AzureVerifiedIDTool()
    
    # Test token retrieval
    token = tool._get_access_token()
    assert token is None


@patch('src.tools.verification.httpx.Client')
def test_make_azure_api_call_success(mock_http_client, azure_tool):
    """Test successful Azure API call"""
    # Mock HTTP client and response
    mock_client_instance = Mock()
    mock_response = Mock()
    mock_response.json.return_value = {"status": "success", "data": "test"}
    mock_response.raise_for_status.return_value = None
    mock_client_instance.post.return_value = mock_response
    mock_http_client.return_value = mock_client_instance
    
    # Mock access token
    with patch.object(azure_tool, '_get_access_token', return_value="fake_token"):
        result = azure_tool._make_azure_api_call("POST", "test/endpoint", {"test": "data"})
        
    assert result == {"status": "success", "data": "test"}
    mock_client_instance.post.assert_called_once()


@patch('src.tools.verification.httpx.Client')
def test_make_azure_api_call_failure(mock_http_client, azure_tool):
    """Test failed Azure API call"""
    # Mock HTTP client to raise an exception
    mock_client_instance = Mock()
    mock_client_instance.post.side_effect = Exception("Network error")
    mock_http_client.return_value = mock_client_instance
    
    # Mock access token
    with patch.object(azure_tool, '_get_access_token', return_value="fake_token"):
        with pytest.raises(Exception):
            azure_tool._make_azure_api_call("POST", "test/endpoint", {"test": "data"})


def test_issue_credential_success(azure_tool, mock_credential_data):
    """Test successful credential issuance"""
    # Mock the _make_azure_api_call method
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.return_value = {
            "requestId": "test_request_id",
            "url": "https://example.com",
            "expiry": "2023-12-31T23:59:59Z"
        }
        
        result = azure_tool.issue_credential(mock_credential_data)
        
        assert result["issued"] == True
        assert result["request_id"] == "test_request_id"
        assert "credential_data" in result
        mock_api_call.assert_called_once()


def test_issue_credential_failure(azure_tool, mock_credential_data):
    """Test failed credential issuance"""
    # Mock the _make_azure_api_call method to raise an exception
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.side_effect = Exception("API error")
        
        result = azure_tool.issue_credential(mock_credential_data)
        
        assert result["issued"] == False
        assert "error" in result
        assert "credential_data" in result


def test_verify_credential_success(azure_tool, mock_presentation_request):
    """Test successful credential verification"""
    # Mock the _make_azure_api_call method
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.return_value = {
            "requestId": "test_request_id",
            "url": "https://example.com",
            "expiry": "2023-12-31T23:59:59Z"
        }
        
        result = azure_tool.verify_credential(mock_presentation_request)
        
        assert result["verification_requested"] == True
        assert result["request_id"] == "test_request_id"
        mock_api_call.assert_called_once()


def test_verify_credential_failure(azure_tool, mock_presentation_request):
    """Test failed credential verification"""
    # Mock the _make_azure_api_call method to raise an exception
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.side_effect = Exception("API error")
        
        result = azure_tool.verify_credential(mock_presentation_request)
        
        assert result["verification_requested"] == False
        assert "error" in result


def test_check_request_status_success(azure_tool):
    """Test successful request status check"""
    # Mock the _make_azure_api_call method
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.return_value = {
            "status": "completed",
            "requestId": "test_request_id"
        }
        
        result = azure_tool.check_request_status("test_request_id")
        
        assert result["status"] == "completed"
        assert result["request_id"] == "test_request_id"
        mock_api_call.assert_called_once_with("GET", "request/test_request_id")


def test_check_request_status_failure(azure_tool):
    """Test failed request status check"""
    # Mock the _make_azure_api_call method to raise an exception
    with patch.object(azure_tool, '_make_azure_api_call') as mock_api_call:
        mock_api_call.side_effect = Exception("API error")
        
        result = azure_tool.check_request_status("test_request_id")
        
        assert result["status"] == "error"
        assert "error" in result
        assert result["request_id"] == "test_request_id"


def test_run_issue_action(azure_tool, mock_credential_data):
    """Test run method with issue action"""
    # Mock the issue_credential method
    with patch.object(azure_tool, 'issue_credential') as mock_issue:
        mock_issue.return_value = {"issued": True, "request_id": "test"}
        
        result = azure_tool.run("issue", credential_data=mock_credential_data)
        
        assert result["issued"] == True
        mock_issue.assert_called_once_with(mock_credential_data)


def test_run_verify_action(azure_tool, mock_presentation_request):
    """Test run method with verify action"""
    # Mock the verify_credential method
    with patch.object(azure_tool, 'verify_credential') as mock_verify:
        mock_verify.return_value = {"verification_requested": True, "request_id": "test"}
        
        result = azure_tool.run("verify", presentation_request=mock_presentation_request)
        
        assert result["verification_requested"] == True
        mock_verify.assert_called_once_with(mock_presentation_request)


def test_run_check_status_action(azure_tool):
    """Test run method with check_status action"""
    # Mock the check_request_status method
    with patch.object(azure_tool, 'check_request_status') as mock_check:
        mock_check.return_value = {"status": "completed", "request_id": "test"}
        
        result = azure_tool.run("check_status", request_id="test")
        
        assert result["status"] == "completed"
        mock_check.assert_called_once_with("test")


def test_run_invalid_action(azure_tool):
    """Test run method with invalid action"""
    result = azure_tool.run("invalid_action")
    
    assert result["status"] == "error"
    assert "Unsupported action" in result["error"]


def test_run_check_status_without_request_id(azure_tool):
    """Test run method with check_status action but missing request_id"""
    result = azure_tool.run("check_status")
    
    assert result["status"] == "error"
    assert "request_id is required" in result["error"]


if __name__ == "__main__":
    pytest.main([__file__])