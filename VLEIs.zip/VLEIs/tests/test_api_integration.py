"""
Integration tests for the Workflow Orchestration API
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
import json
import time
import io

from main import app


# Create test client
client = TestClient(app)


def test_end_to_end_api_workflow():
    """Test complete API workflow with JSON data"""
    # Prepare test data
    test_data = {
        "supplier_data": {
            "company_name": "Test Company",
            "esg_rating": "AA",
            "report_year": 2023,
            "revenue": 1000000
        },
        "config": {
            "processing_timeout": 30
        }
    }
    
    # Measure execution time
    start_time = time.time()
    
    # Call the API endpoint
    response = client.post("/ingest/stream", json=test_data)
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    # Check response
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "final_state" in data
    
    # Check that the final state contains expected fields
    final_state = data["final_state"]
    assert "workflow_status" in final_state
    assert "task_queue" in final_state
    assert "processing_results" in final_state
    
    # Verify execution time is reasonable
    assert execution_time < 5.0  # Should complete within 5 seconds


def test_file_upload_endpoint():
    """Test the file upload endpoint"""
    # Create mock CSV data
    csv_content = """company_name,esg_rating,report_year,revenue
Test Company,AA,2023,1000000
Another Company,BB,2023,2000000"""
    
    # Convert to bytes
    file_bytes = csv_content.encode('utf-8')
    
    # Measure execution time
    start_time = time.time()
    
    # Call the API endpoint
    response = client.post(
        "/ingest/upload",
        files={"file": ("test_data.csv", file_bytes, "text/csv")}
    )
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    # Check response
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "final_state" in data
    
    # Check that the final state contains expected fields
    final_state = data["final_state"]
    assert "workflow_status" in final_state
    assert "task_queue" in final_state
    assert "processing_results" in final_state
    
    # Verify execution time is reasonable
    assert execution_time < 5.0  # Should complete within 5 seconds


def test_file_upload_with_config():
    """Test the file upload endpoint with configuration"""
    # Create mock CSV data
    csv_content = """company_name,esg_rating,report_year,revenue
Test Company,AA,2023,1000000"""
    
    # Convert to bytes
    file_bytes = csv_content.encode('utf-8')
    
    # Configuration as JSON string
    config_json = json.dumps({
        "processing_timeout": 30,
        "max_retries": 3
    })
    
    # Call the API endpoint
    response = client.post(
        "/ingest/upload",
        files={"file": ("test_data.csv", file_bytes, "text/csv")},
        data={"config": config_json}
    )
    
    # Check response
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "final_state" in data


def test_api_performance_under_load():
    """Test API performance with multiple concurrent requests"""
    # Prepare test data
    test_data = {
        "supplier_data": {
            "company_name": "Test Company",
            "esg_rating": "AA",
            "report_year": 2023
        }
    }
    
    # Measure time for multiple requests
    start_time = time.time()
    
    # Make multiple requests
    responses = []
    for i in range(5):
        response = client.post("/ingest/stream", json=test_data)
        responses.append(response)
    
    end_time = time.time()
    total_time = end_time - start_time
    avg_time = total_time / 5
    
    # Check all responses
    for response in responses:
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "success"
    
    # Average time should be reasonable
    assert avg_time < 2.0  # Average should be less than 2 seconds


def test_frontend_integration_compatibility():
    """Test API compatibility with frontend integration"""
    # Test with CORS headers
    test_data = {
        "supplier_data": {
            "company_name": "Test Company"
        }
    }
    
    response = client.post(
        "/ingest/stream",
        json=test_data,
        headers={"Origin": "http://localhost:3000"}
    )
    
    assert response.status_code == 200
    
    # Check CORS headers
    assert "access-control-allow-origin" in response.headers


def test_error_recovery_scenarios():
    """Test API behavior under various failure scenarios"""
    # Test with empty supplier data
    empty_data = {
        "supplier_data": {}
    }
    
    response = client.post("/ingest/stream", json=empty_data)
    # Should still succeed even with empty data
    assert response.status_code == 200
    
    # Test with malformed config
    malformed_data = {
        "supplier_data": {"key": "value"},
        "config": "not_a_dict"  # This should be handled gracefully
    }
    
    response = client.post("/ingest/stream", json=malformed_data)
    # Should handle gracefully or return appropriate error
    assert response.status_code in [200, 422]


def test_file_upload_error_handling():
    """Test file upload error handling"""
    # Test with unsupported file type
    response = client.post(
        "/ingest/upload",
        files={"file": ("test_data.txt", b"some text", "text/plain")}
    )
    
    # Should return error for unsupported file type
    assert response.status_code == 500  # Internal server error due to file processing failure


def test_response_format_consistency():
    """Test that API responses have consistent format"""
    test_data = {
        "supplier_data": {
            "company_name": "Test Company"
        }
    }
    
    response = client.post("/ingest/stream", json=test_data)
    assert response.status_code == 200
    
    data = response.json()
    
    # Check required fields
    required_fields = ["status", "message", "final_state"]
    for field in required_fields:
        assert field in data
    
    # Check field types
    assert isinstance(data["status"], str)
    assert isinstance(data["message"], str)
    assert isinstance(data["final_state"], dict)


def test_api_documentation():
    """Test that API documentation is working"""
    # Test OpenAPI JSON
    response = client.get("/openapi.json")
    assert response.status_code == 200
    assert "openapi" in response.json()
    
    # Test Swagger UI
    response = client.get("/docs")
    assert response.status_code == 200
    assert "<!DOCTYPE html>" in response.text
    
    # Test ReDoc
    response = client.get("/redoc")
    assert response.status_code == 200
    assert "<!DOCTYPE html>" in response.text


if __name__ == "__main__":
    pytest.main([__file__])