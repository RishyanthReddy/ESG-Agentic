"""
Unit tests for the Stakeholder Dashboard
"""

import pytest
import pandas as pd
import json
from datetime import datetime
from unittest.mock import patch, MagicMock, Mock
import sys
import os

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestStakeholderDashboard:
    """Test cases for the Stakeholder Dashboard components"""
    
    @pytest.fixture
    def mock_streamlit(self):
        """Create a mock Streamlit module"""
        mock_st = Mock()
        mock_st.columns.return_value = [Mock(), Mock(), Mock(), Mock()]
        mock_st.tabs.return_value = [Mock(), Mock()]
        return mock_st
    
    @pytest.fixture
    def sample_state(self):
        """Create a sample AppState for testing"""
        # Mock the AppState creation
        with patch('src.state.models.AppState') as mock_appstate:
            mock_state = Mock()
            mock_state.workflow_status = "reporting_completed"
            mock_state.workflow_step = 5
            mock_state.processing_results = {
                "carbon_metrics": {
                    "total_carbon_footprint": {
                        "co2e": 1250.5,
                        "co2e_unit": "kg"
                    },
                    "carbon_footprints": []
                },
                "esg_scores": {
                    "environmental_score": 85.5,
                    "social_score": 78.2,
                    "governance_score": 92.1,
                    "overall_score": 85.3
                },
                "verification_results": {
                    "credentials_verified": 12,
                    "credentials_pending": 3,
                    "credentials_failed": 1
                }
            }
            mock_state.visualization_assets = {
                "provenance_graph": {
                    "node_count": 15,
                    "edge_count": 22,
                    "created_at": datetime.utcnow().isoformat()
                },
                "serialized_graph": {
                    "json_data": json.dumps({
                        "nodes": [
                            {"id": "supplier:abc_corp", "name": "ABC Corporation", "type": "supplier"},
                            {"id": "agent:ingestion", "name": "Ingestion Agent", "type": "agent"}
                        ],
                        "links": [
                            {"source": "supplier:abc_corp", "target": "agent:ingestion"}
                        ]
                    }),
                    "format": "threejs",
                    "size": 512,
                    "compressed": True,
                    "optimized": True,
                    "created_at": datetime.utcnow().isoformat()
                },
                "highlighted_path": {
                    "success": True,
                    "path": ["supplier:abc_corp", "agent:ingestion"],
                    "path_length": 1,
                    "source": "supplier:abc_corp",
                    "target": "agent:ingestion",
                    "node_count": 2,
                    "edge_count": 1
                }
            }
            mock_state.agent_trace = [
                {
                    "agent": "ingestion_agent",
                    "action": "data_ingested",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
            mock_state.blockchain_log = [
                {
                    "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                    "data_hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
            mock_appstate.return_value = mock_state
            yield mock_state
    
    def test_key_metrics_display(self, mock_streamlit, sample_state):
        """Test key metrics display component"""
        # Mock the display_key_metrics function
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_key_metrics
            
            # Call the function
            display_key_metrics(sample_state)
            
            # Verify that markdown was called (indicating metrics were displayed)
            assert mock_streamlit.markdown.called
            
            # Verify that columns were called with the right number of columns
            mock_streamlit.columns.assert_called_with(4)
    
    def test_provenance_graph_display(self, mock_streamlit, sample_state):
        """Test provenance graph display component"""
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_provenance_graph
            
            # Mock additional Streamlit functions
            mock_streamlit.header = Mock()
            mock_streamlit.info = Mock()
            mock_streamlit.tabs = Mock(return_value=[Mock(), Mock()])
            mock_streamlit.subheader = Mock()
            mock_streamlit.metric = Mock()
            mock_streamlit.dataframe = Mock()
            mock_streamlit.plotly_chart = Mock()
            mock_streamlit.success = Mock()
            mock_streamlit.write = Mock()
            mock_streamlit.error = Mock()
            
            # Test with valid visualization assets
            display_provenance_graph(sample_state)
            
            # Verify tabs were created
            mock_streamlit.tabs.assert_called_with(["Graph Visualization", "Path Highlighting"])
    
    def test_carbonsutra_visualizations_display(self, mock_streamlit, sample_state):
        """Test CarbonSutra visualizations display component"""
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_carbonsutra_visualizations
            
            # Mock Streamlit functions
            mock_streamlit.header = Mock()
            mock_streamlit.tabs = Mock(return_value=[Mock(), Mock(), Mock()])
            mock_streamlit.subheader = Mock()
            mock_streamlit.metric = Mock()
            mock_streamlit.plotly_chart = Mock()
            mock_streamlit.dataframe = Mock()
            
            # Mock pandas DataFrame
            with patch('pandas.DataFrame') as mock_dataframe:
                mock_dataframe.return_value = pd.DataFrame({
                    "Year": [2023, 2024],
                    "Current": [1200, 1150],
                    "Projected": [1100, 1050],
                    "Target": [900, 850]
                })
                
                # Mock melt function
                mock_melted_df = pd.DataFrame({
                    "Year": [2023, 2023, 2023, 2024, 2024, 2024],
                    "Scenario": ["Current", "Projected", "Target"] * 2,
                    "Emissions": [1200, 1100, 900, 1150, 1050, 850]
                })
                
                with patch.object(pd.DataFrame, 'melt', return_value=mock_melted_df):
                    # Call the function
                    display_carbonsutra_visualizations(sample_state)
                    
                    # Verify tabs were created
                    mock_streamlit.tabs.assert_called_with(["Emissions Trend", "Scenario Comparison", "Key Metrics"])
    
    def test_agent_activity_display(self, mock_streamlit, sample_state):
        """Test agent activity display component"""
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_agent_activity
            
            # Mock Streamlit functions
            mock_streamlit.header = Mock()
            mock_streamlit.tabs = Mock(return_value=[Mock(), Mock()])
            mock_streamlit.subheader = Mock()
            mock_streamlit.info = Mock()
            mock_streamlit.dataframe = Mock()
            mock_streamlit.plotly_chart = Mock()
            
            # Call the function
            display_agent_activity(sample_state)
            
            # Verify tabs were created
            mock_streamlit.tabs.assert_called_with(["Agent Activity", "Blockchain Transactions"])
    
    def test_data_structure_validation(self, mock_streamlit, sample_state):
        """Test that dashboard components handle various data structures correctly"""
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_key_metrics
            
            # Mock columns to return fake column objects
            mock_streamlit.markdown = Mock()
            mock_streamlit.columns = Mock(return_value=[Mock(), Mock(), Mock(), Mock()])
            
            # Should not raise an exception
            display_key_metrics(sample_state)
        
    def test_visualization_assets_parsing(self, mock_streamlit, sample_state):
        """Test parsing of visualization assets JSON data"""
        with patch('src.dashboard.main_dashboard.st', mock_streamlit):
            from src.dashboard.main_dashboard import display_provenance_graph
            
            # Mock Streamlit functions
            mock_streamlit.header = Mock()
            mock_streamlit.tabs = Mock(return_value=[Mock(), Mock()])
            mock_streamlit.subheader = Mock()
            mock_streamlit.metric = Mock()
            mock_streamlit.dataframe = Mock()
            mock_streamlit.plotly_chart = Mock()
            mock_streamlit.success = Mock()
            mock_streamlit.write = Mock()
            mock_streamlit.error = Mock()
            
            # Should not raise an exception
            display_provenance_graph(sample_state)
            
            # Test with invalid JSON data
            invalid_state = Mock()
            invalid_state.visualization_assets = {
                "serialized_graph": {
                    "json_data": "invalid json"
                }
            }
            
            display_provenance_graph(invalid_state)
            # Should show error message for invalid JSON
            mock_streamlit.error.assert_called_with("Error parsing graph data.")


if __name__ == "__main__":
    pytest.main([__file__])