"""
Unit tests for the Path Highlighting functionality in Visualization Agent

This module contains tests for verifying the correct integration of the ShortestPathTool
with the VisualizationAgent and the proper enhancement of JSON output with path data.

Test suite for path highlighting functionality.
This module tests:
1. Path calculation accuracy
2. 3D animation effects
3. CLI visualization clarity
4. Real-time update performance
"""

import os
import sys
import pytest
import json
import time
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from demo_scripts.path_tracer import find_shortest_path, trace_path_in_terminal
from demo_scripts.provenance_animation import find_shortest_path as animation_find_path


def test_path_calculation_accuracy():
    """Test shortest path algorithm accuracy"""
    # Mock graph data
    graph_data = {
        "nodes": [
            {"id": "1", "name": "Node 1"},
            {"id": "2", "name": "Node 2"},
            {"id": "3", "name": "Node 3"},
            {"id": "4", "name": "Node 4"},
        ],
        "edges": [
            {"source": "1", "target": "2"},
            {"source": "2", "target": "3"},
            {"source": "3", "target": "4"},
            {"source": "1", "target": "4"},  # Direct connection
        ]
    }
    
    # Test shortest path calculation
    path = find_shortest_path(graph_data, "1", "4")
    assert path == ["1", "4"], f"Expected direct path ['1', '4'], got {path}"
    
    # Test path with intermediate nodes
    path = find_shortest_path(graph_data, "1", "3")
    assert path == ["1", "4", "3"] or path == ["1", "2", "3"], f"Expected path with 2 nodes, got {path}"


def test_3d_animation_effects():
    """Test Three.js path highlighting effects"""
    # This test would normally require a browser environment
    # For now, we'll test that the component file exists and can be imported
    component_path = os.path.join(
        os.path.dirname(__file__), 
        '..', 
        'dashboard', 
        'src', 
        'components', 
        'threejs', 
        'PathHighlightingGraph3D.tsx'
    )
    assert os.path.exists(component_path), "PathHighlightingGraph3D.tsx component not found"


def test_cli_visualization_clarity():
    """Test terminal path display clarity"""
    # Mock graph data
    graph_data = {
        "nodes": [
            {"id": "1", "name": "Start Node", "type": "supplier"},
            {"id": "2", "name": "Middle Node", "type": "manufacturer"},
            {"id": "3", "name": "End Node", "type": "consumer"},
        ],
        "edges": [
            {"source": "1", "target": "2", "type": "shipment", "co2_emissions": 100.0, "date": "2024-01-01"},
            {"source": "2", "target": "3", "type": "delivery", "co2_emissions": 50.0, "date": "2024-01-02"},
        ]
    }
    
    # Test path tracing function
    path = ["1", "2", "3"]
    
    # Capture output
    import io
    from contextlib import redirect_stdout
    
    captured_output = io.StringIO()
    with redirect_stdout(captured_output):
        trace_path_in_terminal(graph_data, path, use_rich=False)
    
    output = captured_output.getvalue()
    assert "Start Node" in output, "Start node not found in output"
    assert "Middle Node" in output, "Middle node not found in output"
    assert "End Node" in output, "End node not found in output"
    assert "shipment" in output, "Edge type not found in output"
    assert "100.0" in output, "CO2 emissions not found in output"


def test_real_time_updates_performance():
    """Test live path calculation performance"""
    # Mock graph data with more nodes
    graph_data = {
        "nodes": [{"id": str(i), "name": f"Node {i}"} for i in range(100)],
        "edges": [{"source": str(i), "target": str(i+1)} for i in range(99)]
    }
    
    # Measure path calculation time
    start_time = time.time()
    path = find_shortest_path(graph_data, "0", "99")
    end_time = time.time()
    
    # Check that path is correct
    assert len(path) == 100, f"Expected path with 100 nodes, got {len(path)}"
    assert path[0] == "0", f"Expected start node '0', got '{path[0]}'"
    assert path[-1] == "99", f"Expected end node '99', got '{path[-1]}'"
    
    # Check that calculation is reasonably fast (less than 1 second)
    calculation_time = end_time - start_time
    assert calculation_time < 1.0, f"Path calculation took {calculation_time:.2f}s, expected < 1.0s"


def test_cli_script_execution():
    """Test that CLI scripts execute without errors"""
    import subprocess
    import sys
    
    # Test path_tracer.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/path_tracer.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"path_tracer.py failed with return code {result.returncode}"
    
    # Test provenance_animation.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/provenance_animation.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"provenance_animation.py failed with return code {result.returncode}"
    
    # Test trace_validator.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/trace_validator.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"trace_validator.py failed with return code {result.returncode}"


def test_path_consistency_across_scripts():
    """Test that all scripts use the same path calculation algorithm"""
    # Mock graph data
    graph_data = {
        "nodes": [
            {"id": "A", "name": "Node A"},
            {"id": "B", "name": "Node B"},
            {"id": "C", "name": "Node C"},
        ],
        "edges": [
            {"source": "A", "target": "B"},
            {"source": "B", "target": "C"},
        ]
    }
    
    # Calculate path using both scripts' functions
    path1 = find_shortest_path(graph_data, "A", "C")
    path2 = animation_find_path(graph_data, "A", "C")
    
    # Both paths should be the same
    assert path1 == path2, f"Paths differ: {path1}, {path2}"


def test_error_handling():
    """Test error handling in path calculation"""
    # Test with empty graph
    empty_graph = {"nodes": [], "edges": []}
    path = find_shortest_path(empty_graph, "1", "2")
    assert path == [], f"Expected empty path for empty graph, got {path}"
    
    # Test with disconnected nodes
    disconnected_graph = {
        "nodes": [
            {"id": "1", "name": "Node 1"},
            {"id": "2", "name": "Node 2"},
        ],
        "edges": []
    }
    path = find_shortest_path(disconnected_graph, "1", "2")
    assert path == [], f"Expected empty path for disconnected nodes, got {path}"


if __name__ == "__main__":
    pytest.main([__file__])