"""
Unit tests for the CarbonSutra API Tool
"""

import pytest
from unittest.mock import Mock, patch
import json
from src.tools.esg import CarbonSutraTool, CarbonSutraError, Scope3DataPoint


class TestCarbonSutraTool:
    """Test cases for CarbonSutra API Tool"""
    
    def test_initialization(self):
        """Test CarbonSutraTool initialization with valid credentials"""
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            tool = CarbonSutraTool()
            assert tool.name == "carbonsutra_api"
            assert tool.description == "Integrates with CarbonSutra API for decarbonization insights and pathway scenarios"
            assert tool.api_key == "test_api_key"
            assert tool.auth_token == "Bearer test_token"
    
    def test_initialization_missing_api_key(self):
        """Test CarbonSutraTool initialization with missing API key"""
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = None
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            with pytest.raises(CarbonSutraError, match="CARBONSUTRA_API_KEY not found in environment variables"):
                CarbonSutraTool()
    
    def test_initialization_missing_auth_token(self):
        """Test CarbonSutraTool initialization with missing auth token"""
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = None
            
            with pytest.raises(CarbonSutraError, match="CARBONSUTRA_AUTH_TOKEN not found in environment variables"):
                CarbonSutraTool()
    
    def test_scope3_data_point_model(self):
        """Test Scope3DataPoint model validation"""
        # Test valid data point
        valid_data = {
            "timestamp": "2023-01-01T00:00:00Z",
            "value": 100.5,
            "metric_type": "co2e",
            "supplier_id": "supplier_123",
            "confidence_score": 0.95
        }
        
        data_point = Scope3DataPoint(**valid_data)
        assert data_point.timestamp == valid_data["timestamp"]
        assert data_point.value == valid_data["value"]
        assert data_point.metric_type == valid_data["metric_type"]
        assert data_point.supplier_id == valid_data["supplier_id"]
        assert data_point.confidence_score == valid_data["confidence_score"]
    
    @patch('src.tools.esg.redis.Redis')
    def test_cache_key_generation(self, mock_redis):
        """Test cache key generation for Scope 3 data"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            tool = CarbonSutraTool()
            
            scope3_data = [
                {
                    "timestamp": "2023-01-01T00:00:00Z",
                    "value": 100.0,
                    "metric_type": "co2e",
                    "supplier_id": "supplier_1"
                },
                {
                    "timestamp": "2023-01-02T00:00:00Z",
                    "value": 150.0,
                    "metric_type": "co2e",
                    "supplier_id": "supplier_1"
                }
            ]
            
            cache_key = tool._get_cache_key(scope3_data)
            assert cache_key.startswith("carbonsutra:")
            assert len(cache_key) > 15  # Should be a proper hash
    
    @patch('src.tools.esg.redis.Redis')
    def test_cached_result_handling(self, mock_redis):
        """Test cached result handling"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        mock_redis_instance.get.return_value = json.dumps({
            "success": True,
            "analysis": {"reduction_potential": 25.0}
        })
        
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            tool = CarbonSutraTool()
            
            scope3_data = [{
                "timestamp": "2023-01-01T00:00:00Z",
                "value": 100.0,
                "metric_type": "co2e"
            }]
            
            result = tool._get_cached_result(scope3_data)
            assert result is not None
            assert result["success"] is True
            assert result["analysis"]["reduction_potential"] == 25.0
    
    def test_pathway_analysis(self):
        """Test decarbonization pathway analysis"""
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            tool = CarbonSutraTool()
            
            # Mock pathway data
            pathways_data = {
                "scenarios": ["scenario_1", "scenario_2", "scenario_3"],
                "best_pathway": "scenario_2",
                "reduction_potential": 30.5,
                "timeline_analysis": {"2030": 25.0, "2040": 50.0, "2050": 100.0},
                "confidence_score": 0.87
            }
            
            analyzed_data = tool._analyze_pathways(pathways_data)
            
            assert analyzed_data["total_scenarios"] == 3
            assert analyzed_data["best_pathway"] == "scenario_2"
            assert analyzed_data["reduction_potential"] == 30.5
            assert analyzed_data["confidence_score"] == 0.87
            assert "timeline_analysis" in analyzed_data
            assert "processed_at" in analyzed_data
    
    def test_visualization_generation(self):
        """Test visualization data generation"""
        with patch('src.tools.esg.settings') as mock_settings:
            mock_settings.CARBONSUTRA_API_KEY = "test_api_key"
            mock_settings.CARBONSUTRA_AUTH_TOKEN = "Bearer test_token"
            
            tool = CarbonSutraTool()
            
            # Mock analysis data
            analysis_data = {
                "current_emissions": [100, 95, 90],
                "projected_emissions": [90, 80, 70],
                "target_emissions": [80, 70, 60],
                "scenario_comparison": ["scen1", "scen2"],
                "key_metrics": {"reduction": 25.0}
            }
            
            visualization_data = tool._generate_visualizations(analysis_data)
            
            assert "chart_data" in visualization_data
            assert "scenario_comparison" in visualization_data
            assert "key_metrics" in visualization_data
            assert "generated_at" in visualization_data
            
            chart_data = visualization_data["chart_data"]
            assert chart_data["current_emissions"] == [100, 95, 90]
            assert chart_data["projected_emissions"] == [90, 80, 70]
            assert chart_data["target_emissions"] == [80, 70, 60]