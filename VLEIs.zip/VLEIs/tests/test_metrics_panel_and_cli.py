"""
Test suite for metrics panel and CLI equivalents.
This module tests:
1. KPI calculation logic consistency
2. Metrics shown identically in both systems
3. Update frequency and accuracy
4. Alert threshold and notification systems
"""

import os
import sys
import subprocess
import pytest
import json
import time
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def test_panel_components_exist():
    """Test that the panel components exist"""
    components_dir = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'components', 'panels')
    
    assert os.path.exists(components_dir), "Panels components directory not found"
    
    required_files = [
        'MetricsPanel.tsx',
        'RealTimeMetricsPanel.tsx',
        'index.ts'
    ]
    
    for file_name in required_files:
        file_path = os.path.join(components_dir, file_name)
        assert os.path.exists(file_path), f"Required panel component {file_name} not found"

def test_accuracy_monitor_script_exists():
    """Test that the accuracy_monitor.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'accuracy_monitor.py')
    assert os.path.exists(script_path), "accuracy_monitor.py script not found"

def test_integrity_checker_script_exists():
    """Test that the integrity_checker.sh script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'integrity_checker.sh')
    assert os.path.exists(script_path), "integrity_checker.sh script not found"

def test_performance_dashboard_script_exists():
    """Test that the performance_dashboard.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'performance_dashboard.py')
    assert os.path.exists(script_path), "performance_dashboard.py script not found"

def test_live_metrics_stream_script_exists():
    """Test that the live_metrics_stream.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'live_metrics_stream.py')
    assert os.path.exists(script_path), "live_metrics_stream.py script not found"

def test_accuracy_monitor_script_execution():
    """Test that the accuracy_monitor.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'accuracy_monitor.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "accuracy_monitor.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"accuracy_monitor.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("accuracy_monitor.py script timed out")
    except Exception as e:
        pytest.fail(f"accuracy_monitor.py script failed with error: {e}")

def test_performance_dashboard_script_execution():
    """Test that the performance_dashboard.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'performance_dashboard.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "performance_dashboard.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"performance_dashboard.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("performance_dashboard.py script timed out")
    except Exception as e:
        pytest.fail(f"performance_dashboard.py script failed with error: {e}")

def test_live_metrics_stream_script_execution():
    """Test that the live_metrics_stream.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'live_metrics_stream.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "live_metrics_stream.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"live_metrics_stream.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("live_metrics_stream.py script timed out")
    except Exception as e:
        pytest.fail(f"live_metrics_stream.py script failed with error: {e}")

def test_metrics_consistency():
    """Test that metrics are calculated consistently across frontend and CLI"""
    # This test would verify that the same metrics are calculated in both systems
    # For now, we'll just check that both systems can generate metrics
    
    # Test React component can render (this is a shallow test)
    panel_files = [
        'MetricsPanel.tsx',
        'RealTimeMetricsPanel.tsx'
    ]
    
    for file_name in panel_files:
        file_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'components', 'panels', file_name)
        assert os.path.exists(file_path), f"Panel component {file_name} not found"
        
        # Check that the file contains key elements
        with open(file_path, 'r') as f:
            content = f.read()
            
        # Check for essential React component elements
        assert 'React' in content, f"{file_name} should import React"
        assert 'useState' in content or 'useEffect' in content, f"{file_name} should use React hooks"
        assert 'export default' in content, f"{file_name} should have a default export"

def test_real_time_updates():
    """Test real-time update frequency and accuracy"""
    # Test that the live metrics stream can run for a short duration
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'live_metrics_stream.py')
    
    try:
        # Run the script for a short duration
        result = subprocess.run(
            ['python', script_path, '--duration', '3', '--simple'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"live_metrics_stream.py failed with return code {result.returncode}"
        
        # Check that output contains expected information
        output = result.stdout.lower()
        assert 'metrics' in output or 'time' in output or 'api' in output
        
    except subprocess.TimeoutExpired:
        pytest.fail("live_metrics_stream.py script timed out")
    except Exception as e:
        pytest.fail(f"live_metrics_stream.py script failed with error: {e}")

def test_alert_system():
    """Test alert threshold and notification systems"""
    # Test that the accuracy monitor can detect and report alerts
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'accuracy_monitor.py')
    
    try:
        # Run the script for a short duration
        result = subprocess.run(
            ['python', script_path, '--duration', '3', '--interval', '1', '--simple'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"accuracy_monitor.py failed with return code {result.returncode}"
        
        # Check that output contains expected information
        output = result.stdout.lower()
        assert 'metrics' in output or 'time' in output or 'api' in output or 'accuracy' in output
        
    except subprocess.TimeoutExpired:
        pytest.fail("accuracy_monitor.py script timed out")
    except Exception as e:
        pytest.fail(f"accuracy_monitor.py script failed with error: {e}")

if __name__ == "__main__":
    pytest.main([__file__])