"""
Integration tests for the GLEIF vLEI Verification Tool

These tests are designed to work with both sandbox and production environments.
When running against real APIs, ensure you have:
1. Internet connectivity
2. Appropriate rate-limiting configuration
3. Valid test credentials
"""

import pytest
import asyncio
import time
from src.tools.verification import GleifVerifierTool, VerificationError
from src.state.models import vLEICredential, CredentialStatus, VerificationStatus
from src.tools.registry import ToolRegistry


def test_tool_registry_integration():
    """Test integration with the tool registry"""
    # Create registry and clear it
    registry = ToolRegistry()
    registry.clear()
    
    # Create and register the tool
    tool = GleifVerifierTool()
    registry.register_tool(tool)
    
    # Retrieve the tool
    retrieved_tool = registry.get_tool("gleif_verifier")
    
    # Verify it's the same tool
    assert retrieved_tool is tool
    assert retrieved_tool.name == "gleif_verifier"
    
    # Verify it's in the list
    tools = registry.list_tools()
    assert "gleif_verifier" in tools
    assert tools["gleif_verifier"] == "Verifies vLEI credentials against the GLEIF vLEI Verifier API"


@pytest.mark.asyncio
async def test_live_gleif_api_verification():
    """Test against actual GLEIF API with a known valid LEI"""
    # Skip if not running in an environment with internet access
    # This would typically be run in a controlled environment
    
    tool = GleifVerifierTool()
    
    # Create a credential with a known valid LEI (Apple Inc.)
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:HXB0UMUMDLF1QQF6UY42",
        claims={"lei": "HXB0UMUMDLF1QQF6UY42"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should get a result (either verified or not)
    assert "verified" in result
    assert "reason" in result
    assert result["lei"] == "HXB0UMUMDLF1QQF6UY42"
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


def test_end_to_end_verification_workflow():
    """Test full credential verification workflow"""
    # Create a tool instance
    tool = GleifVerifierTool()
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:web:example-verifier.com",
        subject="did:lei:549300A6XUSR882F7N34:entity",
        claims={
            "lei": "549300A6XUSR882F7N34",
            "entity_name": "Test Organization",
            "registration_date": "2023-01-01"
        },
        proof={
            "type": "Ed25519Signature2018",
            "created": "2023-01-01T10:00:00Z",
            "proofValue": "test_signature"
        }
    )
    
    # Run the tool (will fail but tests the workflow)
    result = tool.run(credential)
    # Check that we get a result with the expected structure
    assert "verified" in result
    assert "credential_id" in result
    assert "timestamp" in result


def test_performance_testing():
    """Test API response times under load (simulated)"""
    tool = GleifVerifierTool()
    
    # Create multiple test credentials
    credentials = []
    for i in range(3):  # Reduced from 5 to 3 for faster testing
        credential = vLEICredential(
            issuer=f"did:web:issuer{i}.com",
            subject=f"did:lei:549300A6XUSR882F7N3{i}:entity",
            claims={
                "lei": f"549300A6XUSR882F7N3{i}",
                "entity_name": f"Test Organization {i}",
            },
            proof={
                "type": "Ed25519Signature2018",
                "created": "2023-01-01T10:00:00Z",
                "proofValue": f"test_signature_{i}"
            }
        )
        credentials.append(credential)
    
    # Time the verification process
    start_time = time.time()
    
    # Run verifications (will fail but tests the workflow)
    results = []
    for credential in credentials:
        try:
            result = tool.run(credential, dry_run=True)
            results.append(result)
        except Exception as e:
            # We shouldn't get here since we're using dry_run
            pytest.fail(f"Unexpected exception: {str(e)}")
    
    end_time = time.time()
    total_time = end_time - start_time
    
    # Verify we got results for all credentials
    assert len(results) == len(credentials)
    
    # Check that each result has the expected structure
    for result in results:
        assert "verified" in result
        assert "credential_id" in result
        assert "timestamp" in result
    
    # Should complete within a reasonable time (even with failures)
    # Increased time limit to 30 seconds to account for network delays
    assert total_time < 30.0


def test_error_recovery_with_api_outages():
    """Test resilience to API outages"""
    tool = GleifVerifierTool()
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:web:example.com",
        subject="did:lei:549300A6XUSR882F7N34:entity",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Test that the tool handles API outages gracefully
    # Since we don't have a real API, we'll test that the retry mechanism is in place
    assert hasattr(tool, '_make_api_call_with_retry')
    assert tool.max_retries == 3


@pytest.mark.asyncio
async def test_live_gleif_api_verification_invalid_lei():
    """Test against actual GLEIF API with an invalid LEI"""
    
    tool = GleifVerifierTool()
    
    # Create a credential with an invalid LEI
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "INVALIDLEI123456789"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should fail verification
    assert result["verified"] is False
    assert "lei" in result
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_trust_chain_validation():
    """Test end-to-end trust chain verification"""
    
    tool = GleifVerifierTool()
    
    # Test with a valid LEI
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:549300A6XUSR882F7N34",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should have proper structure
    assert "verified" in result
    assert "reason" in result
    assert "timestamp" in result
    assert result["lei"] == "549300A6XUSR882F7N34"
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_performance_metrics():
    """Test API response times and caching effectiveness"""
    
    tool = GleifVerifierTool()
    
    # Test with a valid LEI
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:549300A6XUSR882F7N34",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Measure first call (no cache)
    start_time = time.time()
    result1 = tool.run(credential)
    first_call_time = time.time() - start_time
    
    # Measure second call (should be cached)
    start_time = time.time()
    result2 = tool.run(credential)
    second_call_time = time.time() - start_time
    
    # Both should have the same result
    assert result1["verified"] == result2["verified"]
    assert result1["lei"] == result2["lei"]
    
    # Second call should be faster (from cache)
    # Note: This might not always be true in all environments
    assert "from_cache" in result2
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_error_scenarios():
    """Test various error scenarios"""
    
    tool = GleifVerifierTool()
    
    # Test with credential missing LEI
    credential_no_lei = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"other": "data"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    result = tool.run(credential_no_lei)
    assert result["verified"] is False
    assert "Could not extract LEI" in result["reason"]
    
    # Test with invalid LEI format
    credential_invalid_lei = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "INVALID"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    result = tool.run(credential_invalid_lei)
    assert result["verified"] is False
    assert "Invalid LEI format" in result["reason"]
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


if __name__ == "__main__":
    pytest.main([__file__])