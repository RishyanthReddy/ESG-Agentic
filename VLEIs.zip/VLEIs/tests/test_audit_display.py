"""
Test suite for audit display functionality.
This module tests:
1. Audit endpoint integration
2. Status display rendering and CLI output
3. Audit status state updates
4. Error handling in audit failure scenarios
"""

import os
import sys
import pytest
import json
import time
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from demo_scripts.audit_runner import fetch_audit_data, run_audit_simulation, display_audit_results
from demo_scripts.audit_proof import generate_audit_proof, verify_audit_proof


def test_audit_integration():
    """Test audit endpoint integration"""
    # Test that we can fetch audit data
    audit_data = fetch_audit_data("http://localhost:8000", "audit_12345")
    
    # Check that we get the expected structure
    assert isinstance(audit_data, dict)
    assert "audit_id" in audit_data
    assert "status" in audit_data
    assert "timestamp" in audit_data
    assert "details" in audit_data


def test_status_display():
    """Test status badge rendering and CLI output"""
    # Test audit runner with simple output
    audit_data = {
        "audit_id": "test_audit",
        "status": "verified",
        "timestamp": "2025-08-28T12:00:00Z",
        "details": "Test audit details",
        "evidence_hash": "test_hash",
        "verifier": "Test Verifier"
    }
    
    # Capture output
    import io
    from contextlib import redirect_stdout
    
    captured_output = io.StringIO()
    with redirect_stdout(captured_output):
        display_audit_results(audit_data, use_rich=False)
    
    output = captured_output.getvalue()
    assert "Audit Results" in output
    assert "test_audit" in output
    assert "VERIFIED" in output
    assert "Test audit details" in output


def test_state_management():
    """Test audit status state updates"""
    # Test running audit simulation
    audit_data = run_audit_simulation("test_audit", "http://localhost:8000", use_rich=False)
    
    # Check that we get audit data back
    assert isinstance(audit_data, dict)
    assert "audit_id" in audit_data
    assert "status" in audit_data
    assert audit_data["audit_id"] == "test_audit"


def test_error_handling():
    """Test audit failure scenarios"""
    # Test with empty audit data
    import io
    from contextlib import redirect_stdout
    
    captured_output = io.StringIO()
    with redirect_stdout(captured_output):
        display_audit_results({}, use_rich=False)
    
    output = captured_output.getvalue()
    assert "No audit data to display" in output


def test_audit_proof_generation():
    """Test audit proof generation and verification"""
    # Test generating audit proof
    proof_data = generate_audit_proof("test_audit", use_rich=False)
    
    # Check that we get proof data back
    assert isinstance(proof_data, dict)
    assert "audit_id" in proof_data
    assert "evidence_hash" in proof_data
    assert "signature" in proof_data
    assert "blockchain_transaction" in proof_data
    
    # Test verifying audit proof
    verification_data = verify_audit_proof(proof_data, use_rich=False)
    
    # Check that we get verification data back
    assert isinstance(verification_data, dict)
    assert "verification_status" in verification_data
    assert "verification_timestamp" in verification_data
    assert verification_data["verification_status"] == "passed"


def test_cli_script_execution():
    """Test that CLI scripts execute without errors"""
    import subprocess
    import sys
    
    # Test audit_runner.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/audit_runner.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"audit_runner.py failed with return code {result.returncode}"
    
    # Test audit_proof.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/audit_proof.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"audit_proof.py failed with return code {result.returncode}"
    
    # Test trust_demonstration.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/trust_demonstration.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"trust_demonstration.py failed with return code {result.returncode}"


if __name__ == "__main__":
    pytest.main([__file__])