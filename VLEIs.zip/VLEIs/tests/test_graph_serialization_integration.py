"""
Integration tests for the GraphSerializationTool implementation.
"""

import pytest
import networkx as nx
from datetime import datetime
from src.tools.visualization import GraphSerializationTool, NetworkXProvenanceTool


class TestGraphSerializationToolIntegration:
    """Integration tests for the GraphSerializationTool."""
    
    def setup_method(self):
        """Set up test resources."""
        self.serialization_tool = GraphSerializationTool()
        self.provenance_tool = NetworkXProvenanceTool()
    
    def test_threejs_compatibility(self):
        """Validate JSON works with Three.js."""
        # Create a realistic supply chain graph using the provenance tool
        agent_traces = [
            {
                "agent_id": "credential_agent",
                "agent_name": "Credential Verification Agent",
                "agent_role": "verification",
                "status": "completed",
                "timestamp": datetime.utcnow().isoformat(),
                "input_artifacts": [
                    {
                        "id": "credential_1",
                        "name": "vLEI Credential",
                        "type": "credential",
                        "size": 2048,
                        "hash": "abc123",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ],
                "output_artifacts": [
                    {
                        "id": "report_1",
                        "name": "Verification Report",
                        "type": "report",
                        "size": 4096,
                        "hash": "def456",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ]
            }
        ]
        
        blockchain_logs = [
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "abc123",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
        
        # Create the provenance graph
        provenance_result = self.provenance_tool.run(agent_traces, blockchain_logs)
        assert provenance_result['success'] is True
        
        graph = provenance_result['graph']
        
        # Serialize for Three.js
        result = self.serialization_tool.run(graph, format="threejs")
        assert result['success'] is True
        assert result['format'] == 'threejs'
        
        # Verify Three.js compatibility
        import json
        data = json.loads(result['serialized_graph'])
        
        # Check required Three.js fields
        assert 'nodes' in data
        assert 'links' in data
        assert 'metadata' in data
        
        # Check metadata
        assert 'format' in data['metadata']
        assert 'version' in data['metadata']
        assert 'node_count' in data['metadata']
        assert 'link_count' in data['metadata']
        
        # Check that all nodes have required visualization fields
        for node in data['nodes']:
            assert 'id' in node
            assert 'x' in node
            assert 'y' in node
            assert 'z' in node
            assert 'size' in node
            assert 'opacity' in node
            assert 'color' in node
            assert 'label' in node
        
        # Check that all links have required visualization fields
        for link in data['links']:
            assert 'source' in link
            assert 'target' in link
            assert 'width' in link
            assert 'opacity' in link
            assert 'color' in link
    
    def test_large_graph_handling(self):
        """Performance with complex supply chain graphs."""
        import time
        
        # Create a larger, more complex graph
        agent_traces = []
        blockchain_logs = []
        
        # Generate 20 agent traces with artifacts
        for i in range(20):
            trace = {
                "agent_id": f"agent_{i}",
                "agent_name": f"Agent {i}",
                "agent_role": f"role_{i % 5}",
                "status": "completed",
                "timestamp": datetime.utcnow().isoformat(),
                "input_artifacts": [
                    {
                        "id": f"input_{i}_1",
                        "name": f"Input {i} 1",
                        "type": "input",
                        "size": 100 + i,
                        "hash": f"hash_input_{i}_1",
                        "timestamp": datetime.utcnow().isoformat()
                    },
                    {
                        "id": f"input_{i}_2",
                        "name": f"Input {i} 2",
                        "type": "input",
                        "size": 200 + i,
                        "hash": f"hash_input_{i}_2",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ],
                "output_artifacts": [
                    {
                        "id": f"output_{i}",
                        "name": f"Output {i}",
                        "type": "output",
                        "size": 300 + i,
                        "hash": f"hash_output_{i}",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ]
            }
            
            if i % 5 == 0:  # Add supplier info to every 5th agent
                trace["supplier_info"] = {
                    "id": f"supplier_{i}",
                    "name": f"Supplier {i}",
                    "location": f"Location {i}",
                    "certifications": [f"ISO {i}"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            agent_traces.append(trace)
            
            # Add blockchain logs for some artifacts
            if i % 3 == 0:  # Every 3rd artifact
                log = {
                    "transaction_hash": f"0x{i:064x}",
                    "data_hash": f"hash_output_{i}",
                    "account": "0xAccount123",
                    "block_number": 1000000 + i,
                    "gas_used": 21000 + i,
                    "timestamp": datetime.utcnow().isoformat()
                }
                blockchain_logs.append(log)
        
        # Create the provenance graph
        start_time = time.time()
        provenance_result = self.provenance_tool.run(agent_traces, blockchain_logs)
        provenance_time = time.time() - start_time
        
        assert provenance_result['success'] is True
        graph = provenance_result['graph']
        
        # Serialize for Three.js
        start_time = time.time()
        result = self.serialization_tool.run(graph, format="threejs")
        serialization_time = time.time() - start_time
        
        assert result['success'] is True
        assert result['size'] > 0
        
        # Performance should be reasonable
        assert provenance_time < 5.0  # Provenance creation under 5 seconds
        assert serialization_time < 1.0  # Serialization under 1 second
        
        print(f"Provenance graph with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges")
        print(f"Provenance creation time: {provenance_time:.4f} seconds")
        print(f"Serialization time: {serialization_time:.4f} seconds")
        print(f"Serialized JSON size: {result['size']} characters")
    
    def test_data_transfer(self):
        """Test JSON size and transfer efficiency."""
        # Create a medium-sized graph
        graph = nx.DiGraph()
        
        # Add nodes
        for i in range(50):
            graph.add_node(f"agent_{i}", type="agent", name=f"Agent {i}", role="processor")
            graph.add_node(f"artifact_{i}", type="artifact", name=f"Artifact {i}", size=1024+i)
        
        # Add edges
        for i in range(49):
            graph.add_edge(f"agent_{i}", f"artifact_{i}", relationship="produced")
            graph.add_edge(f"artifact_{i}", f"agent_{i+1}", relationship="consumed_by")
        
        # Test standard JSON serialization
        result_json = self.serialization_tool.run(graph, format="json", compress=False)
        assert result_json['success'] is True
        
        # Test compressed JSON serialization
        result_compressed = self.serialization_tool.run(graph, format="json", compress=True)
        assert result_compressed['success'] is True
        
        # Compressed version should be smaller
        assert result_compressed['size'] <= result_json['size']
        
        print(f"Standard JSON size: {result_json['size']} characters")
        print(f"Compressed JSON size: {result_compressed['size']} characters")
        print(f"Size reduction: {result_json['size'] - result_compressed['size']} characters "
              f"({((result_json['size'] - result_compressed['size']) / result_json['size']) * 100:.1f}%)")
    
    def test_visualization_quality(self):
        """Validate visualization data completeness."""
        # Create a graph with all node types
        agent_traces = [
            {
                "agent_id": "verification_agent",
                "agent_name": "Verification Agent",
                "agent_role": "verification",
                "status": "completed",
                "timestamp": datetime.utcnow().isoformat(),
                "input_artifacts": [
                    {
                        "id": "credential_1",
                        "name": "vLEI Credential",
                        "type": "credential",
                        "size": 2048,
                        "hash": "hash1",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ],
                "output_artifacts": [
                    {
                        "id": "verification_report",
                        "name": "Verification Report",
                        "type": "report",
                        "size": 4096,
                        "hash": "hash2",
                        "timestamp": datetime.utcnow().isoformat()
                    }
                ],
                "supplier_info": {
                    "id": "supplier_corp",
                    "name": "Supplier Corporation",
                    "location": "New York",
                    "certifications": ["ISO 14001"],
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
        ]
        
        blockchain_logs = [
            {
                "transaction_hash": "0xabcdef1234567890",
                "data_hash": "hash1",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
        
        # Create the provenance graph
        provenance_result = self.provenance_tool.run(agent_traces, blockchain_logs)
        assert provenance_result['success'] is True
        
        graph = provenance_result['graph']
        
        # Serialize for Three.js with optimization
        result = self.serialization_tool.run(graph, format="threejs", optimize=True)
        assert result['success'] is True
        
        # Parse the JSON
        import json
        data = json.loads(result['serialized_graph'])
        
        # Check that all expected node types are present with correct colors
        node_types_found = set()
        for node in data['nodes']:
            node_types_found.add(node.get('type', 'unknown'))
            
            # Check that visualization properties are present
            assert 'x' in node
            assert 'y' in node
            assert 'z' in node
            assert 'size' in node
            assert 'opacity' in node
            assert 'color' in node
            assert 'label' in node
            
            # Check color mapping
            node_type = node.get('type', 'unknown')
            color = node.get('color', '')
            
            color_map = {
                'agent': '#ff7f0e',      # Orange
                'artifact': '#1f77b4',   # Blue
                'supplier': '#2ca02c',   # Green
                'blockchain': '#d62728'  # Red
            }
            
            if node_type in color_map:
                assert color == color_map[node_type]
        
        # Check that all expected relationship types are present with correct colors
        relationship_types_found = set()
        for link in data['links']:
            relationship_types_found.add(link.get('relationship', 'unknown'))
            
            # Check that visualization properties are present
            assert 'width' in link
            assert 'opacity' in link
            assert 'color' in link
            
            # Check color mapping
            relationship = link.get('relationship', 'unknown')
            color = link.get('color', '')
            
            color_map = {
                'produced': '#1f77b4',          # Blue
                'consumed_by': '#ff7f0e',       # Orange
                'provides_service_to': '#2ca02c', # Green
                'recorded_on_chain': '#d62728'   # Red
            }
            
            if relationship in color_map:
                assert color == color_map[relationship]
        
        # Ensure we have all expected node types
        expected_node_types = {'agent', 'artifact', 'supplier', 'blockchain'}
        assert expected_node_types.issubset(node_types_found)
        
        # Ensure we have all expected relationship types
        expected_relationship_types = {'produced', 'consumed_by', 'provides_service_to', 'recorded_on_chain'}
        assert expected_relationship_types.issubset(relationship_types_found)
    
    def test_format_evolution(self):
        """Test format versioning and backwards compatibility."""
        # Create a simple graph
        graph = nx.DiGraph()
        graph.add_node("A", type="agent", name="Agent A")
        graph.add_node("B", type="artifact", name="Artifact B")
        graph.add_edge("A", "B", relationship="produced")
        
        # Test different format versions
        formats_to_test = ['threejs', 'json']
        
        for format_name in formats_to_test:
            result = self.serialization_tool.run(graph, format=format_name)
            assert result['success'] is True
            assert result['format'] == format_name
            
            # Verify it's valid JSON
            import json
            data = json.loads(result['serialized_graph'])
            assert 'nodes' in data
            assert len(data['nodes']) > 0
            
            # Check that basic structure is maintained
            assert isinstance(data['nodes'], list)
            
            if format_name == 'threejs':
                assert 'metadata' in data
                assert data['metadata']['format'] == 'threejs-compatible'
            elif format_name == 'json':
                # Standard JSON format should still have nodes and links
                assert 'links' in data


if __name__ == "__main__":
    pytest.main([__file__])