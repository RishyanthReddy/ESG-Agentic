"""
Unit tests for the GLEIF vLEI Verification Tool
"""

import pytest
from unittest.mock import AsyncMock, Mock, patch
import httpx
from src.tools.verification import GleifVerifierTool, VerificationError
from src.state.models import vLEICredential, CredentialStatus, VerificationStatus
from src.tools.registry import BaseTool
import json
from uuid import UUID
from datetime import datetime
import asyncio


def test_tool_interface():
    """Test BaseTool compliance and method signatures"""
    # Create the tool instance
    tool = GleifVerifierTool()
    
    # Verify it's a BaseTool instance
    assert isinstance(tool, BaseTool)
    
    # Verify attributes
    assert tool.name == "gleif_verifier"
    assert tool.description == "Verifies vLEI credentials against the GLEIF vLEI Verifier API"
    
    # Verify methods exist
    assert hasattr(tool, 'run')
    assert callable(tool.run)


def test_credential_validation_with_valid_lei():
    """Test input credential validation with valid LEI"""
    tool = GleifVerifierTool()
    
    # Create a credential with valid LEI in claims
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Test LEI extraction
    lei = tool._extract_lei_from_credential(credential)
    assert lei == "549300A6XUSR882F7N34"


def test_credential_validation_with_did_format_lei():
    """Test input credential validation with DID format LEI"""
    tool = GleifVerifierTool()
    
    # Create a credential with LEI in subject DID
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:549300A6XUSR882F7N34:subject",
        claims={},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Test LEI extraction
    lei = tool._extract_lei_from_credential(credential)
    assert lei == "549300A6XUSR882F7N34"


def test_credential_validation_with_invalid_lei():
    """Test input credential validation with invalid LEI format"""
    tool = GleifVerifierTool()
    
    # Create a credential with invalid LEI
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "INVALID_LEI"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should fail validation
    assert result["verified"] is False
    assert "Invalid LEI format" in result["reason"]


def test_credential_validation_with_missing_lei():
    """Test input credential validation with missing LEI"""
    tool = GleifVerifierTool()
    
    # Create a credential without LEI
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"other": "data"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should fail to extract LEI
    assert result["verified"] is False
    assert "Could not extract LEI from credential" in result["reason"]


def test_mock_api_responses_success():
    """Test with mocked GLEIF API responses for successful verification"""
    tool = GleifVerifierTool()
    
    # Mock successful API response
    mock_response_data = {
        "verified": True,
        "reason": "Credential is valid",
        "chain_of_trust": ["root", "qvi", "issuer"],
        "valid_from": "2023-01-01T00:00:00Z",
        "valid_until": "2024-01-01T00:00:00Z"
    }
    
    with patch.object(tool, '_make_api_call_with_retry', return_value=mock_response_data):
        # Create a credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"lei": "549300A6XUSR882F7N34"},
            proof={"type": "Ed25519Signature2018"}
        )
        
        # Run the tool
        result = tool.run(credential)
        
        # Verify the result
        assert result["verified"] is True
        assert result["reason"] == "Credential is valid"
        assert result["lei"] == "549300A6XUSR882F7N34"
        assert "api_response" in result


def test_mock_api_responses_failure():
    """Test with mocked GLEIF API responses for failed verification"""
    tool = GleifVerifierTool()
    
    # Mock failed API response
    mock_response_data = {
        "verified": False,
        "reason": "Credential has been revoked",
        "revocation_date": "2023-06-15T10:00:00Z"
    }
    
    with patch.object(tool, '_make_api_call_with_retry', return_value=mock_response_data):
        # Create a credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"lei": "549300A6XUSR882F7N34"},
            proof={"type": "Ed25519Signature2018"}
        )
        
        # Run the tool
        result = tool.run(credential)
        
        # Verify the result
        assert result["verified"] is False
        assert "revoked" in result["reason"].lower()
        assert result["lei"] == "549300A6XUSR882F7N34"


@patch('src.tools.verification.httpx.Client')
def test_api_error_handling_http_status_error(mock_http_client):
    """Test API error handling with HTTP status errors"""
    tool = GleifVerifierTool()
    
    # Mock the HTTP client to raise an HTTPStatusError
    mock_client_instance = Mock()
    mock_http_client.return_value = mock_client_instance
    
    mock_client_instance.post.side_effect = httpx.HTTPStatusError(
        "Not Found", 
        request=Mock(), 
        response=Mock(status_code=404)
    )
    
    # Create a credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should handle the error gracefully
    assert result["verified"] is False
    assert "API verification failed" in result["reason"]


@patch('src.tools.verification.httpx.Client')
def test_api_error_handling_network_error(mock_http_client):
    """Test API error handling with network errors"""
    tool = GleifVerifierTool()
    
    # Mock the HTTP client to raise a RequestError
    mock_client_instance = Mock()
    mock_http_client.return_value = mock_client_instance
    
    mock_client_instance.post.side_effect = httpx.RequestError("Connection timeout")
    
    # Create a credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "549300A6XUSR882F7N34"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    # Run the tool
    result = tool.run(credential)
    
    # Should handle the error gracefully
    assert result["verified"] is False
    assert "API verification failed" in result["reason"]


def test_data_validation_valid_credential():
    """Test data validation with a valid credential"""
    tool = GleifVerifierTool()
    
    # Create a valid credential
    credential = vLEICredential(
        issuer="did:web:example.com",
        subject="did:lei:549300A6XUSR882F7N34:entity",
        claims={
            "lei": "549300A6XUSR882F7N34",
            "entity_name": "Example Corp",
            "registration_date": "2023-01-01"
        },
        proof={
            "type": "Ed25519Signature2018",
            "created": "2023-01-01T10:00:00Z",
            "proofValue": "example_signature"
        }
    )
    
    # Mock the API response
    mock_response_data = {
        "verified": True,
        "reason": "Valid credential",
        "chain_of_trust": ["GLEIF", "QVI", "Issuer"],
        "valid_until": "2024-01-01T00:00:00Z"
    }
    
    with patch.object(tool, '_make_api_call_with_retry', return_value=mock_response_data):
        # Run the tool
        result = tool.run(credential)
        
        # Verify the result
        assert result["verified"] is True
        assert result["lei"] == "549300A6XUSR882F7N34"
        assert "api_response" in result


if __name__ == "__main__":
    pytest.main([__file__])