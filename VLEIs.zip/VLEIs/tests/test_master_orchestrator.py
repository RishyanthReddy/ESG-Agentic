"""
Unit tests for the master orchestrator
"""

import pytest
from pydantic import ValidationError
from src.agents.core import master_orchestrator, RoutingError
from src.state.models import AppState


def test_empty_queue():
    """Test orchestrator with empty task queue"""
    state = AppState()
    result = master_orchestrator(state)
    assert result == "__end__"


def test_single_task():
    """Test orchestrator with a single task in queue"""
    state = AppState(task_queue=["credential_agent"])
    result = master_orchestrator(state)
    assert result == "credential_agent"
    assert len(state.task_queue) == 0  # Task should be popped


def test_multiple_tasks():
    """Test orchestrator with multiple tasks in queue"""
    state = AppState(task_queue=["agent1", "agent2", "agent3"])
    
    # First call should return first agent
    result = master_orchestrator(state)
    assert result == "agent1"
    assert state.task_queue == ["agent2", "agent3"]
    
    # Second call should return second agent
    result = master_orchestrator(state)
    assert result == "agent2"
    assert state.task_queue == ["agent3"]
    
    # Third call should return third agent
    result = master_orchestrator(state)
    assert result == "agent3"
    assert len(state.task_queue) == 0
    
    # Fourth call should return __end__
    result = master_orchestrator(state)
    assert result == "__end__"


def test_invalid_task_names():
    """Test orchestrator with invalid task names - Pydantic validation prevents non-strings"""
    # Test that Pydantic prevents non-string task names
    with pytest.raises(ValidationError):
        AppState(task_queue=[123])  # type: ignore
    
    # Test with empty string task name
    state = AppState(task_queue=[""])
    with pytest.raises(RoutingError):
        master_orchestrator(state)
    
    # Test with whitespace-only task name
    state = AppState(task_queue=["   "])
    with pytest.raises(RoutingError):
        master_orchestrator(state)


def test_malformed_tasks():
    """Test orchestrator with malformed tasks - Pydantic validation prevents None values"""
    # Test that Pydantic prevents None values
    with pytest.raises(ValidationError):
        AppState(task_queue=[None])  # type: ignore
    
    # Test with empty string (which passes Pydantic but fails our validation)
    state = AppState(task_queue=[""])
    with pytest.raises(RoutingError):
        master_orchestrator(state)


def test_state_persistence():
    """Test that state modifications persist correctly"""
    state = AppState(
        task_queue=["agent1", "agent2"],
        workflow_status="routing",
        workflow_data={"test": "data"}
    )
    
    # Initial state check
    assert state.workflow_status == "routing"
    assert state.workflow_data == {"test": "data"}
    assert len(state.task_queue) == 2
    
    # Run orchestrator
    result = master_orchestrator(state)
    
    # Check that state was modified correctly
    assert result == "agent1"
    assert len(state.task_queue) == 1
    assert state.task_queue == ["agent2"]
    # Other state fields should remain unchanged
    assert state.workflow_status == "routing"
    assert state.workflow_data == {"test": "data"}


def test_routing_error_inheritance():
    """Test that RoutingError is a proper Exception subclass"""
    assert issubclass(RoutingError, Exception)


if __name__ == "__main__":
    pytest.main([__file__])