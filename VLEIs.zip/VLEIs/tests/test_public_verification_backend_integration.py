"""
Integration tests for the Public Verification Backend

This module contains tests for verifying the end-to-end functionality of the 
public verification endpoint including public access testing, load testing,
security validation, interoperability, and documentation testing.
"""

import pytest
import os
import json
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
from src.state.models import AppState, GRIReport, SASBReport
from src.state.storage import ReportStorage
from main import app


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_public_access_testing():
    """Test external access and verification testing"""
    # This test requires a running instance and external access
    # We'll skip this in the local environment
    pytest.skip("External access testing requires deployed instance")


def test_load_testing():
    """Test public endpoint performance under load"""
    # Create a test client
    client = TestClient(app)
    
    # Create a mock report and proofs
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return test data
        mock_storage.get_report.return_value = {
            "id": "load-test-report-id",
            "company_name": "Load Test Company",
            "report_year": 2023
        }
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "load_test_vc_jwt_token",
            "blockchain_hashes": ["0xloadtest123456789abcdef"],
            "report_type": "GRI"
        }
        
        # Make 5 requests (should be allowed with 5/minute rate limit)
        responses = []
        for i in range(5):
            response = client.get("/verify/load-test-report-id")
            responses.append(response)
        
        # All should be successful
        for response in responses:
            assert response.status_code == 200
            
        # The 6th request should be rate limited (429)
        response = client.get("/verify/load-test-report-id")
        assert response.status_code == 429
            
        # Verify response data for one of the successful requests
        data = responses[0].json()
        assert data["report_id"] == "load-test-report-id"
        assert data["vc_jwt"] == "load_test_vc_jwt_token"
        assert data["blockchain_hashes"] == ["0xloadtest123456789abcdef"]
        assert data["verification_status"] == "success"


def test_security_validation():
    """Test security testing against common attacks"""
    # Create a test client
    client = TestClient(app)
    
    # Test with potentially malicious input
    malicious_inputs = [
        "../../../etc/passwd",
        "'; DROP TABLE users; --",
        "<script>alert('xss')</script>",
        "%00",
        "UNION SELECT * FROM users"
    ]
    
    for malicious_input in malicious_inputs:
        response = client.get(f"/verify/{malicious_input}")
        # Should either return 404 (not found) or 422 (validation error)
        assert response.status_code in [404, 422]


def test_interoperability():
    """Test with external verification systems"""
    # Create a test client
    client = TestClient(app)
    
    # Create a mock report and proofs
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return test data
        mock_storage.get_report.return_value = {
            "id": "interop-test-report-id",
            "company_name": "Interop Test Company",
            "report_year": 2024
        }
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "interop_test_vc_jwt_token",
            "blockchain_hashes": ["0xinterop123456789abcdef", "0xinterop987654321fedcba"],
            "report_type": "SASB"
        }
        
        # Test the endpoint
        response = client.get("/verify/interop-test-report-id")
        assert response.status_code == 200
        
        # Parse the response
        data = response.json()
        assert data["report_id"] == "interop-test-report-id"
        assert data["vc_jwt"] == "interop_test_vc_jwt_token"
        assert len(data["blockchain_hashes"]) == 2
        assert data["verification_status"] == "success"


def test_documentation_testing():
    """Test API documentation accuracy and completeness"""
    # Create a test client
    client = TestClient(app)
    
    # Test the OpenAPI documentation endpoint
    response = client.get("/openapi.json")
    assert response.status_code == 200
    
    # Parse the OpenAPI spec
    openapi_spec = response.json()
    
    # Verify that our endpoint is documented
    assert "/verify/{report_id}" in openapi_spec["paths"]
    assert "get" in openapi_spec["paths"]["/verify/{report_id}"]
    
    # Verify the response model is documented
    verify_endpoint = openapi_spec["paths"]["/verify/{report_id}"]["get"]
    assert "responses" in verify_endpoint
    assert "200" in verify_endpoint["responses"]
    
    # Verify rate limiting is mentioned in the description
    assert "rate" in verify_endpoint["description"].lower()
    assert "limit" in verify_endpoint["description"].lower()


if __name__ == "__main__":
    pytest.main([__file__])