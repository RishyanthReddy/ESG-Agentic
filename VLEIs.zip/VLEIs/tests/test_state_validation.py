"""
Unit tests for state validation
"""

import pytest
from datetime import datetime
from uuid import UUID
from pydantic import ValidationError
from src.state.models import vLEICredential, GRIReport, SASBReport, AppState, CredentialStatus, VerificationStatus


class TestModelValidation:
    """Test cases for model validation"""
    
    def test_vlei_credential_required_fields(self):
        """Test that vLEICredential requires issuer and subject"""
        # Should fail without required fields
        with pytest.raises(ValidationError):
            vLEICredential()
            
        # Should succeed with required fields
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com"
        )
        assert credential.issuer == "did:web:example.com"
        assert credential.subject == "did:web:company.com"
        
    def test_vlei_credential_invalid_dates(self):
        """Test validation of date fields"""
        # This should work fine
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com"
        )
        
        # Test with valid expiration date
        future_date = datetime(2030, 1, 1)
        credential_with_expiration = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            expiration_date=future_date
        )
        assert credential_with_expiration.expiration_date == future_date
        
    def test_enum_validation(self):
        """Test validation of enum fields"""
        # Valid enum values
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            credential_status=CredentialStatus.REVOKED,
            verification_status=VerificationStatus.VERIFIED
        )
        assert credential.credential_status == CredentialStatus.REVOKED
        assert credential.verification_status == VerificationStatus.VERIFIED
        
        # Invalid enum values should raise ValidationError
        with pytest.raises(ValidationError):
            vLEICredential(
                issuer="did:web:example.com",
                subject="did:web:company.com",
                credential_status="invalid_status"  # type: ignore
            )


class TestSerialization:
    """Test cases for model serialization/deserialization"""
    
    def test_vlei_credential_serialization(self):
        """Test serialization of vLEICredential to dict"""
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            claims={"name": "Test Company"}
        )
        
        # Test model_dump with mode="json" (Pydantic v2 method)
        data = credential.model_dump(mode="json")
        assert isinstance(data['id'], str)  # UUID should be serialized as string
        assert isinstance(data['issuance_date'], str)  # datetime should be serialized as string
        assert data['issuer'] == "did:web:example.com"
        assert data['subject'] == "did:web:company.com"
        assert data['claims'] == {"name": "Test Company"}
        
    def test_vlei_credential_json_serialization(self):
        """Test JSON serialization of vLEICredential"""
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com"
        )
        
        # Test model_dump_json (Pydantic v2 method)
        json_data = credential.model_dump_json()
        assert isinstance(json_data, str)
        assert "did:web:example.com" in json_data
        assert "did:web:company.com" in json_data
        
    def test_app_state_serialization(self):
        """Test serialization of AppState"""
        state = AppState(
            workflow_status="testing",
            workflow_step=2
        )
        
        # Test model_dump with mode="json"
        data = state.model_dump(mode="json")
        assert isinstance(data['id'], str)
        assert isinstance(data['created_at'], str)
        assert isinstance(data['updated_at'], str)
        assert data['workflow_status'] == "testing"
        assert data['workflow_step'] == 2
        
    def test_deserialization(self):
        """Test deserialization from dict"""
        # Create a credential and serialize it
        original = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            claims={"test": "value"}
        )
        
        # Serialize to dict with mode="json"
        data = original.model_dump(mode="json")
        
        # Deserialize back to model
        deserialized = vLEICredential.model_validate(data)
        assert deserialized.issuer == original.issuer
        assert deserialized.subject == original.subject
        assert deserialized.claims == original.claims
        # Note: id will be different because of default_factory=uuid4