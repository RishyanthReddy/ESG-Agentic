"""
Integration tests for the Regulatory Reporting Agent
"""

import pytest
from datetime import datetime
from src.agents.reporting import regulatory_reporting_agent
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport


def test_end_to_end_reporting():
    """Test full regulatory reporting workflow"""
    # Create a realistic test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Global Manufacturing Corp",
                "lei": "LEI01234567890123456789"
            },
            "verification": {
                "method": "DocumentaryEvidence",
                "evidence": ["CertificateOfIncorporation", "AnnualReport"]
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    
    # Verify report content
    report = result["regulatory_report"]
    assert report["company_name"] == "Global Manufacturing Corp"
    assert isinstance(report["report_year"], int)
    assert "generated_date" in report
    
    # Verify frameworks
    frameworks = report["frameworks"]
    assert "gri" in frameworks
    assert "sasb" in frameworks
    
    # Verify GRI data structure
    gri = frameworks["gri"]
    assert "standards" in gri
    assert "mapped_data" in gri
    assert isinstance(gri["standards"], list)
    assert len(gri["standards"]) > 0
    assert gri["mapped_data"] is not None
    
    # Verify SASB data structure
    sasb = frameworks["sasb"]
    assert "standards" in sasb
    assert "mapped_data" in sasb
    assert isinstance(sasb["standards"], list)
    assert len(sasb["standards"]) > 0
    assert sasb["mapped_data"] is not None


def test_multi_framework_support():
    """Test multiple regulatory frameworks support"""
    # Create test reports
    gri_report = GRIReport(
        company_name="Sustainability First Ltd",
        report_year=2023,
        data={
            "environmental": {
                "en15": {
                    "description": "GHG emissions intensity",
                    "value": 0.18,
                    "unit": "tonnes CO2e / USD million revenue"
                }
            }
        }
    )
    
    sasb_report = SASBReport(
        company_name="Sustainability First Ltd",
        report_year=2023,
        data={
            "environment": {
                "air_quality": {
                    "description": "Impacts from stationary combustion",
                    "metrics": ["Total GHG emissions: 8000 tonnes CO2e"]
                }
            }
        }
    )
    
    # Create initial state with both report types
    state = AppState(
        gri_reports=[gri_report],
        sasb_reports=[sasb_report]
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    
    # Verify both frameworks are included
    frameworks = result["regulatory_report"]["frameworks"]
    assert "gri" in frameworks
    assert "sasb" in frameworks
    
    # Verify data from both sources is included
    assert frameworks["gri"]["mapped_data"] is not None
    assert frameworks["sasb"]["mapped_data"] is not None


def test_data_quality():
    """Validate report data quality and completeness"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Quality Data Corp",
                "sector": "Technology"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify data quality metrics
    report = result["regulatory_report"]
    summary = report["summary"]
    
    # Check that quality metrics are included
    assert "compliance_status" in summary
    assert "mapped_indicators" in summary
    assert "data_quality_score" in summary
    
    # Verify reasonable values
    assert summary["mapped_indicators"] > 0
    assert 0 <= summary["data_quality_score"] <= 1


def test_compliance_validation():
    """Validate reports meet regulatory requirements"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Compliant Corp",
                "sector": "Energy"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify compliance information
    report = result["regulatory_report"]
    summary = report["summary"]
    
    # Check compliance status
    assert "compliance_status" in summary
    # Should be "pending_review" since this is a mock implementation
    assert summary["compliance_status"] in ["pending_review", "compliant", "non_compliant"]


def test_performance_under_load():
    """Test report generation performance with multiple data sources"""
    # Create multiple test credentials and reports
    credentials = []
    gri_reports = []
    sasb_reports = []
    
    for i in range(5):
        credential = vLEICredential(
            issuer=f"did:example:issuer{i}",
            subject=f"did:example:subject{i}",
            claims={
                "organization": {
                    "name": f"Test Company {i}"
                }
            }
        )
        credentials.append(credential)
        
        gri_report = GRIReport(
            company_name=f"Test Company {i}",
            report_year=2023,
            data={"test": f"GRI data {i}"}
        )
        gri_reports.append(gri_report)
        
        sasb_report = SASBReport(
            company_name=f"Test Company {i}",
            report_year=2023,
            data={"test": f"SASB data {i}"}
        )
        sasb_reports.append(sasb_report)
    
    # Create initial state with multiple data sources
    state = AppState(
        credentials=credentials,
        gri_reports=gri_reports,
        sasb_reports=sasb_reports
    )
    
    import time
    start_time = time.time()
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    
    # Performance check - should complete within a reasonable time
    # (This is a basic check, real performance testing would be more comprehensive)
    assert execution_time < 5.0  # Should complete within 5 seconds
    
    # Verify report contains data from all sources
    report = result["regulatory_report"]
    assert report["company_name"] in [f"Test Company {i}" for i in range(5)]