"""
Unit tests for the ShortestPathTool.

This module contains tests for verifying the correct functionality of the ShortestPathTool
which uses NetworkX's Dijkstra algorithm to find shortest paths in supply chain graphs.
"""

import pytest
import networkx as nx
from src.tools.visualization import ShortestPathTool


class TestShortestPathTool:
    """Test cases for the ShortestPathTool class."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.tool = ShortestPathTool()
    
    def test_initialization(self):
        """Test that the tool initializes correctly."""
        assert self.tool.name == "shortest_path"
        assert self.tool.description is not None
        assert len(self.tool.description) > 0
    
    def test_shortest_path_basic(self):
        """Test finding shortest path in a simple graph."""
        # Create a simple graph
        graph = nx.Graph()
        graph.add_edge("A", "B", weight=1)
        graph.add_edge("B", "C", weight=2)
        graph.add_edge("A", "C", weight=4)
        
        # Find shortest path
        result = self.tool.run(graph, "A", "C", "weight")
        
        assert result["success"] is True
        assert result["path"] == ["A", "B", "C"]
        assert result["path_length"] == 3
        assert result["source"] == "A"
        assert result["target"] == "C"
        assert len(result["path_edges"]) == 2
    
    def test_shortest_path_no_weight(self):
        """Test finding shortest path without weight attribute."""
        # Create a simple graph
        graph = nx.Graph()
        graph.add_edge("A", "B")
        graph.add_edge("B", "C")
        graph.add_edge("A", "C")
        
        # Find shortest path
        result = self.tool.run(graph, "A", "C")
        
        assert result["success"] is True
        assert len(result["path"]) == 2  # Direct connection
        assert result["source"] == "A"
        assert result["target"] == "C"
    
    def test_shortest_path_no_path(self):
        """Test behavior when no path exists between nodes."""
        # Create a disconnected graph
        graph = nx.Graph()
        graph.add_edge("A", "B")
        graph.add_edge("C", "D")
        
        # Try to find path between disconnected components
        result = self.tool.run(graph, "A", "C")
        
        assert result["success"] is False
        assert "No path found" in result["error"]
        assert result["source"] == "A"
        assert result["target"] == "C"
    
    def test_shortest_path_invalid_source(self):
        """Test behavior when source node doesn't exist."""
        graph = nx.Graph()
        graph.add_edge("A", "B")
        
        result = self.tool.run(graph, "X", "B")
        
        assert result["success"] is False
        assert "not found in graph" in result["error"]
    
    def test_shortest_path_invalid_target(self):
        """Test behavior when target node doesn't exist."""
        graph = nx.Graph()
        graph.add_edge("A", "B")
        
        result = self.tool.run(graph, "A", "X")
        
        assert result["success"] is False
        assert "not found in graph" in result["error"]
    
    def test_shortest_path_directed_graph(self):
        """Test finding shortest path in a directed graph."""
        # Create a directed graph
        graph = nx.DiGraph()
        graph.add_edge("A", "B", weight=1)
        graph.add_edge("B", "C", weight=2)
        graph.add_edge("A", "C", weight=5)
        
        # Find shortest path
        result = self.tool.run(graph, "A", "C", "weight")
        
        assert result["success"] is True
        assert result["path"] == ["A", "B", "C"]
        assert result["path_length"] == 3
    
    def test_shortest_path_complex_graph(self):
        """Test finding shortest path in a more complex graph."""
        # Create a more complex graph
        graph = nx.Graph()
        graph.add_edge("A", "B", weight=4)
        graph.add_edge("A", "C", weight=2)
        graph.add_edge("B", "C", weight=1)
        graph.add_edge("B", "D", weight=5)
        graph.add_edge("C", "D", weight=8)
        graph.add_edge("C", "E", weight=10)
        graph.add_edge("D", "E", weight=2)
        
        # Find shortest path
        result = self.tool.run(graph, "A", "E", "weight")
        
        assert result["success"] is True
        # Should go A -> C -> B -> D -> E or similar optimal path
        assert result["source"] == "A"
        assert result["target"] == "E"
        assert result["node_count"] >= 2  # At least source and target