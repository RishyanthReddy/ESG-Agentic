"""
Test Utility for Anomaly Injection

This module provides utilities for injecting anomalies into supplier data
for testing the anomaly detection system.
"""

import random
import copy
from typing import Dict, Any, Optional, List, Union
from loguru import logger


def inject_anomaly(supplier_data: Dict[str, Any], 
                   anomaly_type: str = "spike",
                   anomaly_factor: float = 2.0,
                   anomaly_position: Optional[int] = None,
                   target_field: str = "value") -> Dict[str, Any]:
    """
    Inject anomalies into supplier data for testing detection capabilities.
    
    Args:
        supplier_data: The supplier data dictionary to inject anomalies into
        anomaly_type: Type of anomaly to inject ("spike", "offset", "noise", "missing")
        anomaly_factor: Factor to apply for spike/offset/noise anomalies
        anomaly_position: Position to inject anomaly (random if None)
        target_field: Field name to apply anomaly to
        
    Returns:
        Dict[str, Any]: Modified supplier data with injected anomaly
    """
    # Create a deep copy to avoid modifying the original data
    modified_data = copy.deepcopy(supplier_data)
    
    try:
        # Check if we have time series data to work with
        if "data_points" in modified_data and isinstance(modified_data["data_points"], list):
            data_points = modified_data["data_points"]
            
            if not data_points:
                logger.warning("No data points found to inject anomaly into")
                return modified_data
            
            # Determine position for anomaly injection
            if anomaly_position is None:
                anomaly_position = random.randint(0, len(data_points) - 1)
            elif anomaly_position >= len(data_points):
                logger.warning(f"Anomaly position {anomaly_position} out of range, using last position")
                anomaly_position = len(data_points) - 1
            
            # Get the target data point
            target_point = data_points[anomaly_position]
            
            # Apply the specified anomaly type
            if anomaly_type == "spike":
                if target_field in target_point and isinstance(target_point[target_field], (int, float)):
                    original_value = target_point[target_field]
                    target_point[target_field] = original_value * anomaly_factor
                    logger.info(f"Injected spike anomaly at position {anomaly_position}: {original_value} -> {target_point[target_field]}")
            
            elif anomaly_type == "offset":
                if target_field in target_point and isinstance(target_point[target_field], (int, float)):
                    original_value = target_point[target_field]
                    target_point[target_field] = original_value + anomaly_factor
                    logger.info(f"Injected offset anomaly at position {anomaly_position}: {original_value} -> {target_point[target_field]}")
            
            elif anomaly_type == "noise":
                if target_field in target_point and isinstance(target_point[target_field], (int, float)):
                    original_value = target_point[target_field]
                    noise = random.uniform(-anomaly_factor, anomaly_factor)
                    target_point[target_field] = original_value + noise
                    logger.info(f"Injected noise anomaly at position {anomaly_position}: {original_value} -> {target_point[target_field]}")
            
            elif anomaly_type == "missing":
                if target_field in target_point:
                    original_value = target_point[target_field]
                    del target_point[target_field]
                    logger.info(f"Injected missing data anomaly at position {anomaly_position}: removed {target_field}={original_value}")
            
            else:
                logger.warning(f"Unknown anomaly type: {anomaly_type}")
        
        else:
            logger.warning("No data_points field found in supplier data or it's not a list")
            
    except Exception as e:
        logger.error(f"Error injecting anomaly: {str(e)}")
        # Return original data in case of error
        return supplier_data
    
    return modified_data


def inject_multiple_anomalies(supplier_data: Dict[str, Any],
                              anomaly_configs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Inject multiple anomalies into supplier data based on configuration.
    
    Args:
        supplier_data: The supplier data dictionary to inject anomalies into
        anomaly_configs: List of anomaly configurations, each with:
            - type: anomaly type
            - factor: anomaly factor
            - position: anomaly position (optional)
            - field: target field (optional)
            
    Returns:
        Dict[str, Any]: Modified supplier data with injected anomalies
    """
    modified_data = copy.deepcopy(supplier_data)
    
    for config in anomaly_configs:
        anomaly_type = config.get("type", "spike")
        anomaly_factor = config.get("factor", 2.0)
        anomaly_position = config.get("position")
        target_field = config.get("field", "value")
        
        modified_data = inject_anomaly(
            modified_data,
            anomaly_type=anomaly_type,
            anomaly_factor=anomaly_factor,
            anomaly_position=anomaly_position,
            target_field=target_field
        )
    
    return modified_data