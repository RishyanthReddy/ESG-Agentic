"""
Unit tests for Docker build validation
"""

import pytest
import subprocess
import os
import docker
from pathlib import Path


def test_dockerfile_exists():
    """Test that Dockerfile exists in project root"""
    dockerfile_path = Path("Dockerfile")
    assert dockerfile_path.exists(), "Dockerfile not found in project root"


def test_dockerfile_structure():
    """Test Dockerfile has required components"""
    with open("Dockerfile", "r") as f:
        content = f.read()
    
    # Check for multi-stage build
    assert "FROM python:3.11-slim as builder" in content, "Multi-stage build not found"
    assert "FROM python:3.11-slim" in content, "Production stage not found"
    
    # Check for proper copying of dependencies
    assert "COPY --from=builder" in content, "Dependencies not copied from builder stage"
    
    # Check for non-root user
    assert "USER appuser" in content, "Non-root user not set"
    
    # Check for health check
    assert "HEALTHCHECK" in content, "Health check not configured"
    
    # Check for proper CMD
    assert 'CMD ["uvicorn", "main:app"' in content, "Uvicorn command not found"


def test_docker_compose_exists():
    """Test that docker-compose.yml exists in project root"""
    compose_path = Path("docker-compose.yml")
    assert compose_path.exists(), "docker-compose.yml not found in project root"


def test_docker_compose_structure():
    """Test docker-compose.yml has required services"""
    with open("docker-compose.yml", "r") as f:
        content = f.read()
    
    # Check for required services
    assert "redis:" in content, "Redis service not found"
    assert "esg-engine:" in content, "ESG engine service not found"
    
    # Check for volume definitions
    assert "volumes:" in content, "Volumes not defined"
    
    # Check for environment variables
    assert "NODE_ENV=production" in content, "Production environment not set"
    
    # Check for health checks
    assert "healthcheck:" in content, "Health checks not configured"


def test_docker_build():
    """Test that Docker image builds successfully"""
    try:
        # Run docker build command
        result = subprocess.run(
            ["docker", "build", "-t", "esg-engine:test", "."],
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )
        
        assert result.returncode == 0, f"Docker build failed: {result.stderr}"
        
        # Clean up test image
        subprocess.run(["docker", "rmi", "esg-engine:test"], capture_output=True)
        
    except subprocess.TimeoutExpired:
        pytest.fail("Docker build timed out")
    except FileNotFoundError:
        pytest.skip("Docker not available on this system")


def test_requirements_txt_exists():
    """Test that requirements.txt exists and has required dependencies"""
    req_path = Path("requirements.txt")
    assert req_path.exists(), "requirements.txt not found"
    
    with open(req_path, "r") as f:
        content = f.read()
    
    # Check for core dependencies
    assert "langgraph==" in content, "langgraph not found in requirements"
    assert "fastapi==" in content, "fastapi not found in requirements"
    assert "uvicorn[standard]==" in content, "uvicorn not found in requirements"
    assert "pydantic>=" in content, "pydantic not found in requirements"
    assert "loguru==" in content, "loguru not found in requirements"
    assert "web3==" in content, "web3 not found in requirements"


def test_env_file_exists():
    """Test that .env file exists with required variables"""
    env_path = Path(".env")
    assert env_path.exists(), ".env file not found"
    
    with open(env_path, "r") as f:
        content = f.read()
    
    # Check for essential environment variables
    assert "INFURA_API_KEY=" in content, "INFURA_API_KEY not found in .env"
    assert "NODE_ENV=" in content, "NODE_ENV not found in .env"


def test_docker_image_optimization():
    """Test that Docker image uses multi-stage build for optimization"""
    try:
        # Build the image
        result = subprocess.run(
            ["docker", "build", "-t", "esg-engine:optimization-test", "."],
            capture_output=True,
            text=True,
            timeout=300
        )
        
        assert result.returncode == 0, f"Docker build failed: {result.stderr}"
        
        # Check image size (should be reasonable for a Python app)
        client = docker.from_env()
        image = client.images.get("esg-engine:optimization-test")
        
        # Get image size in MB
        image_size = image.attrs['Size'] / (1024 * 1024)
        
        # Image should be less than 1GB (reasonable for this application)
        assert image_size < 1000, f"Image size {image_size:.2f}MB is larger than expected"
        
        # Clean up
        client.images.remove("esg-engine:optimization-test", force=True)
        
    except (subprocess.TimeoutExpired, docker.errors.DockerException):
        pytest.skip("Docker not available or test conditions not met")


def test_docker_compose_services():
    """Test that docker-compose services can be parsed"""
    try:
        result = subprocess.run(
            ["docker-compose", "config"],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        assert result.returncode == 0, f"docker-compose config validation failed: {result.stderr}"
        assert "services:" in result.stdout, "Services not found in docker-compose config"
        
    except subprocess.TimeoutExpired:
        pytest.fail("docker-compose config validation timed out")
    except FileNotFoundError:
        pytest.skip("docker-compose not available on this system")


if __name__ == "__main__":
    pytest.main([__file__])