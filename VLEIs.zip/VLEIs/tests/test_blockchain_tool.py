"""
Unit tests for the Infura Blockchain Tool
"""

import pytest
from unittest.mock import Mock, patch
from src.tools.provenance import InfuraBlockchainTool, BlockchainError
from src.tools.registry import BaseTool
from web3 import Web3


def test_tool_interface():
    """Test BaseTool compliance and method signatures"""
    # Create the tool instance
    tool = InfuraBlockchainTool()
    
    # Verify it's a BaseTool instance
    assert isinstance(tool, BaseTool)
    
    # Verify attributes
    assert tool.name == "infura_blockchain"
    assert tool.description == "Logs data provenance to Ethereum blockchain via Infura's Sepolia testnet"
    
    # Verify methods exist
    assert hasattr(tool, 'run')
    assert callable(tool.run)


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_tool_initialization(mock_web3, mock_settings):
    """Test tool initialization with valid configuration"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = True
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Create tool instance
    tool = InfuraBlockchainTool()
    
    # Verify initialization
    assert tool.infura_api_key == "test-api-key"
    assert tool.infura_url == "https://sepolia.infura.io/v3/test-api-key"
    assert tool.web3 == mock_w3_instance


@patch('src.tools.provenance.settings')
def test_tool_initialization_missing_api_key(mock_settings):
    """Test tool initialization fails without API key"""
    # Mock settings with missing API key
    mock_settings.INFURA_API_KEY = None
    
    # Attempt to create tool instance
    with pytest.raises(BlockchainError, match="INFURA_API_KEY not found in environment variables"):
        InfuraBlockchainTool()


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_tool_initialization_failed_connection(mock_web3, mock_settings):
    """Test tool initialization fails with connection error"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection failure
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = False
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Attempt to create tool instance
    with pytest.raises(BlockchainError, match="Failed to connect to Infura Sepolia endpoint"):
        InfuraBlockchainTool()


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_run_method_invalid_data(mock_web3, mock_settings):
    """Test run method with invalid data"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = True
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Create tool instance
    tool = InfuraBlockchainTool()
    
    # Test with invalid data
    with pytest.raises(BlockchainError, match="Invalid data_hash provided"):
        tool.run(None, "test-private-key")
    
    with pytest.raises(BlockchainError, match="Invalid data_hash provided"):
        tool.run(123, "test-private-key")


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_prepare_transaction(mock_web3, mock_settings):
    """Test transaction preparation"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = True
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Mock account methods
    mock_account = Mock()
    mock_account.address = "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4"
    mock_w3_instance.eth.account.from_key.return_value = mock_account
    
    # Mock transaction methods
    mock_w3_instance.eth.get_transaction_count.return_value = 5
    mock_w3_instance.eth.estimate_gas.return_value = 21000
    mock_w3_instance.eth.gas_price.return_value = 20000000000
    mock_w3_instance.to_bytes.return_value = b"test-data"
    
    # Create tool instance
    tool = InfuraBlockchainTool()
    
    # Prepare transaction
    transaction = tool._prepare_transaction("test-data-hash", "test-private-key")
    
    # Verify transaction structure
    assert transaction['nonce'] == 5
    assert transaction['to'] == "0x742d35Cc6634C0532925a3b8D4C0532925a3b8D4"
    assert transaction['value'] == 0
    assert transaction['gas'] == 21000
    assert 'gasPrice' in transaction
    assert 'data' in transaction


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_sign_and_send_transaction(mock_web3, mock_settings):
    """Test signing and sending a transaction"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = True
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Mock account methods
    mock_signed_txn = Mock()
    mock_signed_txn.rawTransaction = b"signed-transaction-bytes"
    mock_w3_instance.eth.account.sign_transaction.return_value = mock_signed_txn
    
    # Mock transaction sending
    tx_hash = b"\x12\x34\x56\x78"  # Mock transaction hash bytes
    mock_w3_instance.eth.send_raw_transaction.return_value = tx_hash
    
    # Mock transaction receipt
    mock_receipt = Mock()
    mock_receipt.status = 1
    mock_w3_instance.eth.wait_for_transaction_receipt.return_value = mock_receipt
    
    # Mock to_hex method
    mock_w3_instance.to_hex.return_value = "0x12345678"
    
    # Create tool instance
    tool = InfuraBlockchainTool()
    
    # Sign and send transaction
    result_hash = tool._sign_and_send_transaction({"test": "transaction"}, "test-private-key")
    
    # Verify result
    assert result_hash == "0x12345678"


@patch('src.tools.provenance.settings')
@patch('src.tools.provenance.Web3')
def test_run_method_success(mock_web3, mock_settings):
    """Test successful run method execution"""
    # Mock settings
    mock_settings.INFURA_API_KEY = "test-api-key"
    
    # Mock Web3 connection
    mock_w3_instance = Mock()
    mock_w3_instance.is_connected.return_value = True
    mock_web3.return_value = mock_w3_instance
    mock_web3.HTTPProvider.return_value = Mock()
    
    # Create tool instance
    tool = InfuraBlockchainTool()
    
    # Mock private methods
    tool._prepare_transaction = Mock(return_value={"test": "transaction"})
    tool._sign_and_send_transaction = Mock(return_value="0x123456789abcdef")
    
    # Run the tool
    result = tool.run("test-data-hash", "test-private-key")
    
    # Verify result
    assert result["success"] is True
    assert result["transaction_hash"] == "0x123456789abcdef"
    assert "message" in result