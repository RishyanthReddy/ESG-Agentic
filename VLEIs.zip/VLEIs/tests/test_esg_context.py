"""
Unit tests for ESG Context Management
"""
import os
import json
import tempfile
import pytest
from src.llm.context import ESGContextManager


class TestESGContextManager:
    """Test cases for ESGContextManager"""
    
    def setup_method(self):
        """Set up test resources before each test method."""
        # Create temporary directory and files for testing
        self.test_dir = tempfile.mkdtemp()
        self.create_test_data()
        self.context_manager = ESGContextManager(context_data_dir=self.test_dir, cache_ttl=1)
    
    def create_test_data(self):
        """Create test JSON files for ESG regulations."""
        # Create test GRI data
        gri_data = {
            "standard": "GRI",
            "version": "2021",
            "description": "Global Reporting Initiative Sustainability Reporting Standards",
            "topics": [
                {
                    "id": "GRI 2-1",
                    "title": "Disclosure of the organization",
                    "description": "This standard covers organizational disclosure practices",
                    "principles": ["Principle 1", "Principle 2"]
                }
            ]
        }
        
        with open(os.path.join(self.test_dir, "gri_standards.json"), "w") as f:
            json.dump(gri_data, f)
            
        # Create test SASB data
        sasb_data = {
            "standard": "SASB",
            "version": "2018",
            "description": "Sustainability Accounting Standards Board Standards",
            "industries": [
                {
                    "name": "Oil and Gas",
                    "topics": [
                        {
                            "category": "Environment",
                            "issue": "Air Quality",
                            "description": "Impacts from stationary combustion",
                            "metrics": ["Metric 1", "Metric 2"]
                        }
                    ]
                }
            ]
        }
        
        with open(os.path.join(self.test_dir, "sasb_standards.json"), "w") as f:
            json.dump(sasb_data, f)
    
    def test_context_loading(self):
        """Test loading of ESG knowledge from files."""
        assert "GRI" in self.context_manager.regulation_data
        assert "SASB" in self.context_manager.regulation_data
        assert self.context_manager.regulation_data["GRI"]["version"] == "2021"
        assert self.context_manager.regulation_data["SASB"]["version"] == "2018"
    
    def test_get_regulation_embeddings(self):
        """Test that embeddings are generated for regulation content."""
        gri_embeddings = self.context_manager._get_regulation_embeddings("GRI")
        sasb_embeddings = self.context_manager._get_regulation_embeddings("SASB")
        
        assert len(gri_embeddings) > 0
        assert len(sasb_embeddings) > 0
        assert "topic_0" in gri_embeddings
    
    def test_get_relevant_context(self):
        """Test retrieving relevant context based on semantic similarity."""
        query = "organizational disclosure practices"
        context = self.context_manager.get_relevant_context(query, top_k=2)
        
        assert isinstance(context, list)
        assert len(context) <= 2
        assert all('standard' in item for item in context)
        assert all('similarity' in item for item in context)
        assert all('content' in item for item in context)
    
    def test_build_reasoning_prompt(self):
        """Test building a reasoning prompt with context."""
        query = "What are the GRI standards for organizational disclosure?"
        prompt = self.context_manager.build_reasoning_prompt(query)
        
        assert isinstance(prompt, str)
        assert len(prompt) > 0
        assert "GRI" in prompt
        assert query in prompt
    
    def test_cache_behavior(self):
        """Test caching and eviction policies."""
        # First call
        gri_embeddings1 = self.context_manager._get_regulation_embeddings("GRI")
        cache_info1 = self.context_manager._get_regulation_embeddings.cache_info()
        
        # Second call should use cache
        gri_embeddings2 = self.context_manager._get_regulation_embeddings("GRI")
        cache_info2 = self.context_manager._get_regulation_embeddings.cache_info()
        
        # Cache should have been hit
        assert cache_info2.hits > cache_info1.hits
        
        # Cached results should be the same
        assert gri_embeddings1 == gri_embeddings2
    
    def test_refresh_context_data(self):
        """Test refreshing context data clears caches."""
        # Get initial cache info
        initial_cache_info = self.context_manager._get_regulation_embeddings.cache_info()
        
        # Force cache population
        self.context_manager._get_regulation_embeddings("GRI")
        populated_cache_info = self.context_manager._get_regulation_embeddings.cache_info()
        
        # Ensure cache was used
        assert populated_cache_info.hits >= initial_cache_info.hits
        
        # Refresh context data
        self.context_manager.refresh_context_data()
        
        # Cache should be cleared
        refreshed_cache_info = self.context_manager._get_regulation_embeddings.cache_info()
        assert refreshed_cache_info.currsize == 0


if __name__ == "__main__":
    pytest.main([__file__])