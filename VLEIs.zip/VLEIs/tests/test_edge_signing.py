"""
Unit tests for the Edge Signing Tool implementation.
"""

import os
import tempfile
import json
import pytest
from scripts.sign_data import EdgeSigningTool


class TestEdgeSigningTool:
    """Test cases for the EdgeSigningTool class."""
    
    def setup_method(self):
        """Set up test resources."""
        self.tool = EdgeSigningTool()
        self.tool.generate_keys()
        
        # Create a temporary file for testing
        self.test_file = tempfile.NamedTemporaryFile(delete=False, suffix='.csv')
        self.test_file.write(b"company_name,emissions,energy_usage\n"
                             b"Test Company,100,500\n"
                             b"Another Company,200,750")
        self.test_file.close()
        
        # Create key files
        self.private_key_file = tempfile.NamedTemporaryFile(delete=False, suffix='.key')
        self.private_key_file.close()
        
        self.public_key_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pub')
        self.public_key_file.close()
        
        self.tool.save_keys(self.private_key_file.name, self.public_key_file.name)
    
    def teardown_method(self):
        """Clean up test resources."""
        os.unlink(self.test_file.name)
        os.unlink(self.private_key_file.name)
        os.unlink(self.public_key_file.name)
        
        # Remove signature files if they exist
        sig_file = self.test_file.name + ".sig"
        if os.path.exists(sig_file):
            os.unlink(sig_file)
    
    def test_key_generation(self):
        """Test RSA key pair generation."""
        tool = EdgeSigningTool()
        tool.generate_keys()
        
        assert tool.private_key is not None
        assert tool.public_key is not None
    
    def test_key_save_and_load(self):
        """Test saving and loading keys."""
        # Save keys
        private_key_path = self.private_key_file.name
        public_key_path = self.public_key_file.name
        
        # Load keys in a new tool instance
        new_tool = EdgeSigningTool()
        new_tool.load_keys(private_key_path, public_key_path)
        
        assert new_tool.private_key is not None
        assert new_tool.public_key is not None
    
    def test_file_hashing(self):
        """Test file hashing functionality."""
        file_hash = self.tool.hash_file(self.test_file.name)
        
        # Should be a valid hex string of length 64 (256 bits / 4 bits per hex char)
        assert len(file_hash) == 64
        assert all(c in '0123456789abcdef' for c in file_hash)
    
    def test_file_signing(self):
        """Test file signing functionality."""
        metadata = self.tool.sign_file(self.test_file.name, self.private_key_file.name)
        
        assert "file_path" in metadata
        assert "file_hash" in metadata
        assert "signature" in metadata
        assert "signature_algorithm" in metadata
        
        # Check that signature is a valid hex string
        assert all(c in '0123456789abcdef' for c in metadata["signature"])
    
    def test_signature_verification(self):
        """Test signature verification."""
        # Sign the file
        metadata = self.tool.sign_file(self.test_file.name, self.private_key_file.name)
        
        # Verify the signature
        is_valid = self.tool.verify_signature(self.test_file.name, metadata, self.public_key_file.name)
        
        assert is_valid is True
    
    def test_invalid_signature_verification(self):
        """Test verification of invalid signature."""
        # Sign the file
        metadata = self.tool.sign_file(self.test_file.name, self.private_key_file.name)
        
        # Modify the file hash to make signature invalid
        metadata["file_hash"] = "invalid_hash"
        
        # Verify the signature - should fail
        is_valid = self.tool.verify_signature(self.test_file.name, metadata, self.public_key_file.name)
        
        assert is_valid is False
    
    def test_embed_signature_in_file(self):
        """Test embedding signature in file."""
        # Sign the file
        metadata = self.tool.sign_file(self.test_file.name, self.private_key_file.name)
        
        # Embed signature
        sig_file_path = self.tool.embed_signature_in_file(self.test_file.name, metadata)
        
        # Check that signature file was created
        assert os.path.exists(sig_file_path)
        
        # Check that signature file contains the metadata
        with open(sig_file_path, 'r') as f:
            saved_metadata = json.load(f)
        
        assert saved_metadata == metadata


if __name__ == "__main__":
    pytest.main([__file__])