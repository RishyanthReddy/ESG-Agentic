"""
Unit tests for the ingestion agent
"""

import pytest
from src.agents.ingestion import ingestion_agent, IngestionError
from src.state.models import AppState
from pydantic import ValidationError


def test_task_queue_population_with_vlei_data():
    """Test correct tasks added to queue for vLEI credential data"""
    # Create initial state with vLEI credential data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "vlei_credential",
                "credential_data": {"issuer": "Test Issuer", "subject": "Test Subject"}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that the correct tasks were added to the queue
    expected_tasks = [
        "verify_vlei_credential",
        "log_to_blockchain",
        "map_to_regulatory_frameworks"
    ]
    
    assert "task_queue" in result
    assert result["task_queue"] == expected_tasks
    assert result["workflow_status"] == "data_ingested"


def test_task_queue_population_with_gri_data():
    """Test correct tasks added to queue for GRI report data"""
    # Create initial state with GRI report data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "gri_report",
                "report_data": {"year": 2023, "metrics": {}}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that the correct tasks were added to the queue
    expected_tasks = [
        "validate_gri_report",
        "analyze_gri_data",
        "map_to_regulatory_frameworks"
    ]
    
    assert "task_queue" in result
    assert result["task_queue"] == expected_tasks


def test_task_queue_population_with_sasb_data():
    """Test correct tasks added to queue for SASB report data"""
    # Create initial state with SASB report data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "sasb_report",
                "report_data": {"year": 2023, "metrics": {}}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that the correct tasks were added to the queue
    expected_tasks = [
        "validate_sasb_report",
        "analyze_sasb_data",
        "map_to_regulatory_frameworks"
    ]
    
    assert "task_queue" in result
    assert result["task_queue"] == expected_tasks


def test_task_queue_population_with_esg_data():
    """Test correct tasks added to queue for generic ESG data"""
    # Create initial state with generic ESG data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "esg_data",
                "esg_metrics": {"carbon_footprint": 100, "water_usage": 50}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that the correct tasks were added to the queue
    expected_tasks = [
        "process_esg_data",
        "verify_data_sources",
        "map_to_regulatory_frameworks"
    ]
    
    assert "task_queue" in result
    assert result["task_queue"] == expected_tasks


def test_task_queue_population_with_unknown_data():
    """Test correct tasks added to queue for unknown data type"""
    # Create initial state with unknown data type
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "unknown_type",
                "random_data": {"key": "value"}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that the default tasks were added to the queue
    expected_tasks = [
        "verify_data_integrity",
        "categorize_data",
        "map_to_regulatory_frameworks"
    ]
    
    assert "task_queue" in result
    assert result["task_queue"] == expected_tasks


def test_data_validation_with_valid_data():
    """Test handling of valid supplier data"""
    # Create initial state with valid supplier data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "vlei_credential",
                "credential_data": {"issuer": "Test Issuer", "subject": "Test Subject"}
            }
        }
    )
    
    # This should not raise an exception
    result = ingestion_agent(state)
    
    assert "workflow_status" in result
    assert result["workflow_status"] == "data_ingested"


def test_data_validation_with_invalid_data():
    """Test handling of invalid supplier data (missing required fields)"""
    # Create initial state with invalid supplier data (missing required fields)
    state = AppState(
        workflow_data={
            "supplier_data": {
                "data_type": "vlei_credential"  # Missing company_name
                # credential_data is also missing
            }
        }
    )
    
    # This should raise an IngestionError
    with pytest.raises(IngestionError):
        ingestion_agent(state)


def test_data_validation_with_non_dict_data():
    """Test handling of non-dictionary supplier data"""
    # Create initial state with non-dictionary supplier data
    state = AppState(
        workflow_data={
            "supplier_data": "invalid_data"  # Not a dictionary
        }
    )
    
    # This should raise an IngestionError
    with pytest.raises(IngestionError):
        ingestion_agent(state)


def test_state_mutation():
    """Verify state correctly modified by agent"""
    # Create initial state
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "data_type": "vlei_credential",
                "credential_data": {"issuer": "Test Issuer", "subject": "Test Subject"}
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that state was correctly modified
    assert "workflow_status" in result
    assert result["workflow_status"] == "data_ingested"
    
    assert "workflow_data" in result
    assert "processed_supplier_data" in result["workflow_data"]
    
    assert "task_queue" in result
    assert len(result["task_queue"]) > 0
    
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    assert result["agent_trace"][0]["agent"] == "ingestion_agent"


def test_error_scenarios_with_corrupted_data():
    """Test agent behavior with corrupted data"""
    # Create initial state with corrupted data (None value)
    state = AppState(
        workflow_data={
            "supplier_data": None  # Corrupted data
        }
    )
    
    # This should raise an IngestionError
    with pytest.raises(IngestionError):
        ingestion_agent(state)


def test_empty_supplier_data():
    """Test agent behavior with empty supplier data"""
    # Create initial state with empty supplier data
    state = AppState(
        workflow_data={
            "supplier_data": {}  # Empty data
        }
    )
    
    # This should raise an IngestionError due to missing required fields
    with pytest.raises(IngestionError):
        ingestion_agent(state)