"""
Unit tests for Pydantic models
"""

import pytest
from datetime import datetime
from uuid import UUID
from src.state.models import vLEICredential, GRIReport, SASBReport, AppState, CredentialStatus, VerificationStatus


class TestVLEICredential:
    """Test cases for vLEICredential model"""
    
    def test_vlei_credential_creation(self):
        """Test creation of vLEICredential with required fields"""
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com"
        )
        
        assert isinstance(credential.id, UUID)
        assert credential.issuer == "did:web:example.com"
        assert credential.subject == "did:web:company.com"
        assert isinstance(credential.issuance_date, datetime)
        assert credential.credential_status == CredentialStatus.ISSUED
        assert credential.verification_status == VerificationStatus.PENDING
        assert credential.claims == {}
        
    def test_vlei_credential_with_optional_fields(self):
        """Test creation of vLEICredential with optional fields"""
        expiration = datetime(2025, 12, 31, 23, 59, 59)
        claims = {"name": "Test Company", "country": "US"}
        proof = {"type": "Ed25519Signature2018", "proofValue": "xyz123"}
        
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            expiration_date=expiration,
            claims=claims,
            proof=proof
        )
        
        assert credential.expiration_date == expiration
        assert credential.claims == claims
        assert credential.proof == proof
        
    def test_vlei_credential_status_enums(self):
        """Test credential status enums"""
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com",
            credential_status=CredentialStatus.REVOKED,
            verification_status=VerificationStatus.VERIFIED
        )
        
        assert credential.credential_status == CredentialStatus.REVOKED
        assert credential.verification_status == VerificationStatus.VERIFIED


class TestGRIReport:
    """Test cases for GRIReport model"""
    
    def test_gri_report_creation(self):
        """Test creation of GRIReport"""
        report = GRIReport(
            company_name="Test Company",
            report_year=2023
        )
        
        assert isinstance(report.id, UUID)
        assert report.company_name == "Test Company"
        assert report.report_year == 2023
        assert isinstance(report.created_date, datetime)
        assert report.data is None
        
    def test_gri_report_with_data(self):
        """Test creation of GRIReport with data"""
        data = {"economic": {"revenue": 1000000}, "environmental": {"co2_emissions": 500}}
        report = GRIReport(
            company_name="Test Company",
            report_year=2023,
            data=data
        )
        
        assert report.data == data


class TestSASBReport:
    """Test cases for SASBReport model"""
    
    def test_sasb_report_creation(self):
        """Test creation of SASBReport"""
        report = SASBReport(
            company_name="Test Company",
            report_year=2023
        )
        
        assert isinstance(report.id, UUID)
        assert report.company_name == "Test Company"
        assert report.report_year == 2023
        assert isinstance(report.created_date, datetime)
        assert report.data is None


class TestAppState:
    """Test cases for AppState model"""
    
    def test_app_state_creation(self):
        """Test creation of AppState"""
        state = AppState()
        
        assert isinstance(state.id, UUID)
        assert isinstance(state.created_at, datetime)
        assert isinstance(state.updated_at, datetime)
        assert state.current_credential is None
        assert state.credentials == []
        assert state.gri_reports == []
        assert state.sasb_reports == []
        assert state.workflow_status == "initialized"
        assert state.workflow_step == 0
        assert state.workflow_data == {}
        assert state.processing_results == {}
        assert state.errors == []
        assert state.config == {}
        
    def test_app_state_with_data(self):
        """Test creation of AppState with data"""
        credential = vLEICredential(
            issuer="did:web:example.com",
            subject="did:web:company.com"
        )
        
        state = AppState(
            current_credential=credential,
            workflow_status="processing",
            workflow_step=1,
            workflow_data={"step": "validation"},
            config={"timeout": 30}
        )
        
        assert state.current_credential == credential
        assert state.workflow_status == "processing"
        assert state.workflow_step == 1
        assert state.workflow_data == {"step": "validation"}
        assert state.config == {"timeout": 30}