"""
Unit tests for the File Upload Tool
"""

import pytest
import pandas as pd
from io import StringIO, BytesIO
import tempfile
import os
from src.tools.ingestion import FileUploadTool, FileUploadError
from src.tools.registry import BaseTool


def test_tool_interface():
    """Test BaseTool compliance and method signatures"""
    # Create the tool instance
    tool = FileUploadTool()
    
    # Verify it's a BaseTool instance
    assert isinstance(tool, BaseTool)
    
    # Verify attributes
    assert tool.name == "file_upload"
    assert tool.description == "Processes supplier data from CSV or Excel files into canonical format"
    
    # Verify methods exist
    assert hasattr(tool, 'run')
    assert callable(tool.run)


def test_csv_parsing():
    """Test parsing CSV files"""
    # Create a simple CSV content
    csv_content = """company_name,data_type,revenue,employees
Test Company,gri_report,1000000,50
Another Company,esg_data,2000000,100"""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the CSV file
    result = tool.run(file_content, "test.csv")
    
    # Verify the result
    assert isinstance(result, dict)
    assert "company_name" in result
    assert result["company_name"] == "Test Company"
    assert "data_type" in result
    assert result["data_type"] == "gri_report"
    assert "revenue" in result
    assert result["revenue"] == 1000000
    assert "employees" in result
    assert result["employees"] == 50


def test_excel_parsing_xlsx():
    """Test parsing Excel (.xlsx) files"""
    # Create a simple DataFrame
    df = pd.DataFrame({
        'company_name': ['Test Company'],
        'data_type': ['sasb_report'],
        'revenue': [1000000],
        'employees': [50]
    })
    
    # Save to Excel in memory
    excel_buffer = BytesIO()
    df.to_excel(excel_buffer, index=False)
    excel_content = excel_buffer.getvalue()
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the Excel file
    result = tool.run(excel_content, "test.xlsx")
    
    # Verify the result
    assert isinstance(result, dict)
    assert "company_name" in result
    assert result["company_name"] == "Test Company"
    assert "data_type" in result
    assert result["data_type"] == "sasb_report"
    assert "revenue" in result
    assert result["revenue"] == 1000000
    assert "employees" in result
    assert result["employees"] == 50


def test_excel_parsing_xls():
    """Test parsing Excel (.xls) files"""
    # Create a simple DataFrame
    df = pd.DataFrame({
        'company_name': ['Test Company'],
        'data_type': ['vlei_credential'],
        'issuer': ['did:example:issuer'],
        'subject': ['did:example:subject']
    })
    
    # Save to Excel in memory (xls format)
    excel_buffer = BytesIO()
    df.to_excel(excel_buffer, index=False)
    excel_content = excel_buffer.getvalue()
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the Excel file
    result = tool.run(excel_content, "test.xls")
    
    # Verify the result
    assert isinstance(result, dict)
    assert "company_name" in result
    assert result["company_name"] == "Test Company"
    assert "data_type" in result
    assert result["data_type"] == "vlei_credential"
    assert "issuer" in result
    assert result["issuer"] == "did:example:issuer"
    assert "subject" in result
    assert result["subject"] == "did:example:subject"


def test_data_validation():
    """Test schema validation logic"""
    # Create a CSV with missing company_name
    csv_content = """data_type,revenue,employees
gri_report,1000000,50"""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the CSV file
    result = tool.run(file_content, "test.csv")
    
    # Should still work but with default company name
    assert isinstance(result, dict)
    assert "company_name" in result
    assert result["company_name"] == "Unknown Company"  # Default value
    assert "data_type" in result
    assert result["data_type"] == "gri_report"


def test_error_scenarios_corrupted_files():
    """Test handling of corrupted files"""
    # Create invalid CSV content
    csv_content = """company_name,data_type,revenue
"unclosed quote,esg_data,1000000"""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Should raise FileUploadError
    with pytest.raises(FileUploadError):
        tool.run(file_content, "corrupted.csv")


def test_format_support():
    """Test all supported file formats"""
    # Test CSV
    csv_content = "company_name,data_type\nTest Company,esg_data"
    csv_result = FileUploadTool().run(csv_content.encode('utf-8'), "test.csv")
    assert csv_result["company_name"] == "Test Company"
    
    # Test XLSX
    df = pd.DataFrame({'company_name': ['Test Company'], 'data_type': ['esg_data']})
    xlsx_buffer = BytesIO()
    df.to_excel(xlsx_buffer, index=False)
    xlsx_result = FileUploadTool().run(xlsx_buffer.getvalue(), "test.xlsx")
    assert xlsx_result["company_name"] == "Test Company"
    
    # Test XLS
    df = pd.DataFrame({'company_name': ['Test Company'], 'data_type': ['esg_data']})
    xls_buffer = BytesIO()
    df.to_excel(xls_buffer, index=False)
    xls_result = FileUploadTool().run(xls_buffer.getvalue(), "test.xls")
    assert xls_result["company_name"] == "Test Company"


def test_unsupported_format():
    """Test handling of unsupported file formats"""
    # Create some dummy content
    file_content = b"dummy content"
    
    # Create the tool
    tool = FileUploadTool()
    
    # Should raise FileUploadError for unsupported format
    with pytest.raises(FileUploadError, match="Unsupported file format"):
        tool.run(file_content, "test.unsupported")


def test_empty_csv():
    """Test handling of empty CSV files"""
    # Create empty CSV content
    csv_content = ""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Should raise FileUploadError
    with pytest.raises(FileUploadError):
        tool.run(file_content, "empty.csv")


def test_empty_excel():
    """Test handling of empty Excel files"""
    # Create empty Excel content
    excel_buffer = BytesIO()
    with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
        pd.DataFrame().to_excel(writer, index=False)
    excel_content = excel_buffer.getvalue()
    
    # Create the tool
    tool = FileUploadTool()
    
    # Should raise FileUploadError
    with pytest.raises(FileUploadError):
        tool.run(excel_content, "empty.xlsx")


def test_data_type_inference():
    """Test data type inference from content"""
    # Test GRI report inference
    csv_content = """company_name,revenue,environmental_metrics,social_metrics
Test Company,1000000,500,100"""
    result = FileUploadTool().run(csv_content.encode('utf-8'), "test.csv")
    # Should default to esg_data since we don't have clear gri indicators
    
    # Test with clearer indicators
    csv_content = """company_name,gri_data,economic,environmental
Test Company,2023_data,1000000,500"""
    result = FileUploadTool().run(csv_content.encode('utf-8'), "test.csv")
    assert result["data_type"] in ["gri_report", "esg_data"]  # Could be either based on our logic


def test_nan_handling():
    """Test handling of NaN values in data"""
    # Create DataFrame with NaN values
    df = pd.DataFrame({
        'company_name': ['Test Company'],
        'data_type': ['esg_data'],
        'revenue': [1000000],
        'employees': [None],  # NaN value
        'carbon_emissions': [float('nan')]  # NaN value
    })
    
    # Save to CSV in memory
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_content = csv_buffer.getvalue().encode('utf-8')
    
    # Process the CSV file
    result = FileUploadTool().run(csv_content, "test.csv")
    
    # Verify NaN values are handled correctly
    assert result["employees"] is None
    assert result["carbon_emissions"] is None