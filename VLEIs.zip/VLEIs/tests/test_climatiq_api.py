"""
Unit tests for the Climatiq API Tool
"""

import pytest
from unittest.mock import Mock, patch
import json
from src.tools.esg import ClimatiqApiTool, ActivityData, ClimatiqError


class TestClimatiqApiTool:
    """Test cases for Climatiq API Tool"""
    
    def test_activity_data_validation(self):
        """Test input data structure validation"""
        # Test valid activity data
        valid_data = {
            "activity_id": "passenger_vehicle-fuel_type_diesel-engine_size_na-distance_na-na-unknown",
            "amount": 100,
            "unit": "km",
            "region": "US"
        }
        
        activity_data = ActivityData(**valid_data)
        assert activity_data.activity_id == valid_data["activity_id"]
        assert activity_data.amount == valid_data["amount"]
        assert activity_data.unit == valid_data["unit"]
        assert activity_data.region == valid_data["region"]
        
        # Test invalid activity data (missing required fields)
        invalid_data = {
            "amount": 100,
            "unit": "km"
            # Missing activity_id
        }
        
        with pytest.raises(Exception):
            ActivityData(**invalid_data)
    
    def test_unit_conversion(self):
        """Test conversion between different units"""
        tool = ClimatiqApiTool()
        
        # Test weight conversions
        assert tool._convert_unit(1000, "g", "kg") == 1.0
        assert tool._convert_unit(1, "ton", "kg") == 1000.0
        assert tool._convert_unit(1, "lb", "kg") == pytest.approx(0.453592, 0.0001)
        
        # Test distance conversions
        assert tool._convert_unit(1, "mile", "km") == pytest.approx(1.60934, 0.0001)
        assert tool._convert_unit(1000, "m", "km") == 1.0
        
        # Test energy conversions
        assert tool._convert_unit(1, "mwh", "kwh") == 1000.0
        assert tool._convert_unit(1, "gwh", "kwh") == 1000000.0
        
        # Test same unit (no conversion)
        assert tool._convert_unit(100, "kg", "kg") == 100
        
        # Test unknown units (should return original amount)
        assert tool._convert_unit(100, "unknown_unit", "kg") == 100
    
    @patch('src.tools.esg.redis.Redis')
    def test_cache_key_generation(self, mock_redis):
        """Test cache key generation"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        
        tool = ClimatiqApiTool()
        
        activity_data = ActivityData(
            activity_id="test_activity",
            amount=100,
            unit="kg",
            region="US"
        )
        
        cache_key = tool._get_cache_key(activity_data)
        assert cache_key.startswith("climatiq:")
        assert len(cache_key) > 10  # Should be a proper hash
    
    @patch('src.tools.esg.redis.Redis')
    def test_cached_result_handling(self, mock_redis):
        """Test cached result handling"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        mock_redis_instance.get.return_value = json.dumps({"co2e": 50, "co2e_unit": "kg"})
        
        tool = ClimatiqApiTool()
        
        activity_data = ActivityData(
            activity_id="test_activity",
            amount=100,
            unit="kg",
            region="US"
        )
        
        result = tool._get_cached_result(activity_data)
        assert result is not None
        assert result["co2e"] == 50
        assert result["co2e_unit"] == "kg"
    
    @patch('src.tools.esg.redis.Redis')
    def test_error_handling_invalid_data(self, mock_redis):
        """Test error handling for invalid data"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        
        tool = ClimatiqApiTool()
        
        # Test with invalid activity data
        with pytest.raises(ClimatiqError, match="Invalid activity data"):
            tool.run({"invalid": "data"})
    
    @patch('src.tools.esg.redis.Redis')
    @patch('src.tools.esg.httpx.post')
    def test_api_error_handling(self, mock_post, mock_redis):
        """Test error handling for API errors"""
        mock_redis_instance = Mock()
        mock_redis.return_value = mock_redis_instance
        mock_redis_instance.ping.return_value = True
        mock_redis_instance.get.return_value = None  # No cache hit
        
        # Mock API error response
        mock_response = Mock()
        mock_response.status_code = 400
        mock_response.text = "Bad Request"
        mock_post.return_value = mock_response
        
        tool = ClimatiqApiTool()
        
        activity_data = ActivityData(
            activity_id="test_activity",
            amount=100,
            unit="kg",
            region="US"
        )
        
        with pytest.raises(ClimatiqError, match="Climatiq API request failed"):
            tool.run(activity_data)


if __name__ == "__main__":
    pytest.main([__file__])