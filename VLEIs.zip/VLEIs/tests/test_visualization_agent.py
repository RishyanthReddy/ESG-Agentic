"""
Unit tests for the Visualization Agent
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.visualization import visualization_agent
from src.state.models import AppState
from src.tools.visualization import NetworkXProvenanceTool, GraphSerializationTool
from src.utils.error_handling import WorkflowError


def test_visualization_agent_logic():
    """Test visualization agent workflow logic"""
    # Create initial state with agent traces and blockchain logs
    state = AppState(
        agent_trace=[
            {
                "agent": "test_agent",
                "action": "test_action",
                "timestamp": "2023-01-01T00:00:00"
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x123456789abcdef",
                "data_hash": "test_hash",
                "timestamp": "2023-01-01T00:00:00"
            }
        ]
    )
    
    # Mock the NetworkXProvenanceTool
    with patch('src.agents.visualization.NetworkXProvenanceTool') as mock_provenance_tool_class:
        mock_provenance_tool_instance = Mock()
        mock_provenance_tool_instance.run.return_value = {
            "success": True,
            "graph": Mock(),
            "node_count": 5,
            "edge_count": 4,
            "validation": {"is_dag": True},
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_provenance_tool_class.return_value = mock_provenance_tool_instance
        
        # Mock the GraphSerializationTool
        with patch('src.agents.visualization.GraphSerializationTool') as mock_serialization_tool_class:
            mock_serialization_tool_instance = Mock()
            mock_serialization_tool_instance.run.return_value = {
                "success": True,
                "serialized_graph": '{"nodes":[],"links":[]}',
                "format": "threejs",
                "size": 100,
                "compressed": True,
                "optimized": True,
                "timestamp": "2023-01-01T00:00:00"
            }
            mock_serialization_tool_class.return_value = mock_serialization_tool_instance
            
            # Run the agent
            result = visualization_agent(state)
            
            # Verify the result
            assert result["workflow_status"] == "visualization_generated"
            assert "visualization_assets" in result
            assert result["visualization_assets"] is not None
            assert "provenance_graph" in result["visualization_assets"]
            assert "serialized_graph" in result["visualization_assets"]
            assert result["visualization_assets"]["provenance_graph"]["node_count"] == 5
            assert result["visualization_assets"]["provenance_graph"]["edge_count"] == 4
            assert result["visualization_assets"]["serialized_graph"]["size"] == 100


def test_visualization_agent_with_tool_registry():
    """Test visualization agent when tools are retrieved from registry"""
    # Create initial state with agent traces and blockchain logs
    state = AppState(
        agent_trace=[
            {
                "agent": "test_agent",
                "action": "test_action",
                "timestamp": "2023-01-01T00:00:00"
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x123456789abcdef",
                "data_hash": "test_hash",
                "timestamp": "2023-01-01T00:00:00"
            }
        ]
    )
    
    # Mock the ToolRegistry
    with patch('src.agents.visualization.ToolRegistry') as mock_registry_class:
        mock_registry_instance = Mock()
        mock_provenance_tool = Mock()
        mock_provenance_tool.run.return_value = {
            "success": True,
            "graph": Mock(),
            "node_count": 3,
            "edge_count": 2,
            "validation": {"is_dag": True},
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_serialization_tool = Mock()
        mock_serialization_tool.run.return_value = {
            "success": True,
            "serialized_graph": '{"nodes":[],"links":[]}',
            "format": "threejs",
            "size": 50,
            "compressed": False,
            "optimized": True,
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_registry_instance.get_tool.side_effect = lambda name: mock_provenance_tool if name == "networkx_provenance" else mock_serialization_tool if name == "graph_serialization" else None
        mock_registry_class.return_value = mock_registry_instance
        
        # Run the agent
        result = visualization_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "visualization_generated"
        assert "visualization_assets" in result
        assert result["visualization_assets"] is not None
        assert result["visualization_assets"]["provenance_graph"]["node_count"] == 3
        assert result["visualization_assets"]["provenance_graph"]["edge_count"] == 2
        assert result["visualization_assets"]["serialized_graph"]["size"] == 50


def test_visualization_agent_missing_data():
    """Test visualization agent when no data is available for visualization"""
    # Create initial state with no agent traces or blockchain logs
    state = AppState()
    
    # Run the agent and expect it to raise an error
    result = visualization_agent(state)
    
    # Verify error was added to state
    assert result["workflow_status"] == "visualization_generation_failed"
    assert "errors" in result
    assert len(result["errors"]) > 0
    assert "No agent traces or blockchain logs found for visualization" in result["errors"][0]


def test_visualization_agent_provenance_tool_failure():
    """Test visualization agent when provenance tool fails"""
    # Create initial state with agent traces and blockchain logs
    state = AppState(
        agent_trace=[
            {
                "agent": "test_agent",
                "action": "test_action",
                "timestamp": "2023-01-01T00:00:00"
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x123456789abcdef",
                "data_hash": "test_hash",
                "timestamp": "2023-01-01T00:00:00"
            }
        ]
    )
    
    # Mock the NetworkXProvenanceTool to fail
    with patch('src.agents.visualization.NetworkXProvenanceTool') as mock_provenance_tool_class:
        mock_provenance_tool_instance = Mock()
        mock_provenance_tool_instance.run.return_value = {
            "success": False,
            "error": "Test error"
        }
        mock_provenance_tool_class.return_value = mock_provenance_tool_instance
        
        # Run the agent
        result = visualization_agent(state)
        
        # Verify error was added to state
        assert result["workflow_status"] == "visualization_generation_failed"
        assert "errors" in result
        assert len(result["errors"]) > 0
        assert "Failed to create provenance graph" in result["errors"][0]


def test_visualization_agent_serialization_tool_failure():
    """Test visualization agent when serialization tool fails"""
    # Create initial state with agent traces and blockchain logs
    state = AppState(
        agent_trace=[
            {
                "agent": "test_agent",
                "action": "test_action",
                "timestamp": "2023-01-01T00:00:00"
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x123456789abcdef",
                "data_hash": "test_hash",
                "timestamp": "2023-01-01T00:00:00"
            }
        ]
    )
    
    # Mock the NetworkXProvenanceTool to succeed
    with patch('src.agents.visualization.NetworkXProvenanceTool') as mock_provenance_tool_class:
        mock_provenance_tool_instance = Mock()
        mock_provenance_tool_instance.run.return_value = {
            "success": True,
            "graph": Mock(),
            "node_count": 5,
            "edge_count": 4,
            "validation": {"is_dag": True},
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_provenance_tool_class.return_value = mock_provenance_tool_instance
        
        # Mock the GraphSerializationTool to fail
        with patch('src.agents.visualization.GraphSerializationTool') as mock_serialization_tool_class:
            mock_serialization_tool_instance = Mock()
            mock_serialization_tool_instance.run.return_value = {
                "success": False,
                "error": "Test serialization error"
            }
            mock_serialization_tool_class.return_value = mock_serialization_tool_instance
            
            # Run the agent
            result = visualization_agent(state)
            
            # Verify error was added to state
            assert result["workflow_status"] == "visualization_generation_failed"
            assert "errors" in result
            assert len(result["errors"]) > 0
            assert "Failed to serialize graph" in result["errors"][0]


def test_visualization_agent_state_management():
    """Test visualization agent state updates"""
    # Create initial state with existing data
    initial_agent_trace = [
        {
            "agent": "existing_agent",
            "action": "existing_action",
            "timestamp": "2023-01-01T00:00:00"
        }
    ]
    
    state = AppState(
        agent_trace=initial_agent_trace,
        blockchain_log=[
            {
                "transaction_hash": "0x123456789abcdef",
                "data_hash": "test_hash",
                "timestamp": "2023-01-01T00:00:00"
            }
        ]
    )
    
    # Mock the tools
    with patch('src.agents.visualization.NetworkXProvenanceTool') as mock_provenance_tool_class:
        mock_provenance_tool_instance = Mock()
        mock_provenance_tool_instance.run.return_value = {
            "success": True,
            "graph": Mock(),
            "node_count": 2,
            "edge_count": 1,
            "validation": {"is_dag": True},
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_provenance_tool_class.return_value = mock_provenance_tool_instance
        
        with patch('src.agents.visualization.GraphSerializationTool') as mock_serialization_tool_class:
            mock_serialization_tool_instance = Mock()
            mock_serialization_tool_instance.run.return_value = {
                "success": True,
                "serialized_graph": '{"nodes":[],"links":[]}',
                "format": "threejs",
                "size": 25,
                "compressed": True,
                "optimized": True,
                "timestamp": "2023-01-01T00:00:00"
            }
            mock_serialization_tool_class.return_value = mock_serialization_tool_instance
            
            # Run the agent
            result = visualization_agent(state)
            
            # Verify state was properly updated
            assert result["workflow_status"] == "visualization_generated"
            # Check that agent trace was appended to, not replaced
            assert len(result["agent_trace"]) == len(initial_agent_trace) + 1
            assert result["agent_trace"][-1]["agent"] == "visualization_agent"
            assert "visualization_assets" in result
            assert result["visualization_assets"] is not None


if __name__ == "__main__":
    pytest.main([__file__])