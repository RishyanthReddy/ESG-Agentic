 """
Integration tests for the public verification portal frontend
"""

import unittest
import sys
import os
from unittest.mock import patch, MagicMock

# Add src directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src', 'dashboard'))

class TestPublicVerificationFrontendIntegration(unittest.TestCase):
    """Integration test cases for the public verification portal frontend"""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        pass
        
    def tearDown(self):
        """Tear down test fixtures after each test method."""
        pass
        
    @patch('requests.get')
    def test_api_integration_success(self, mock_get):
        """Test successful integration with backend API"""
        # Mock successful API response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "report_id": "test-report-123",
            "report_data": {"company": "Test Company", "esg_score": 85},
            "vc_jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "blockchain_hashes": ["0xabc123...", "0xdef456..."],
            "verification_status": "success",
            "message": "Report verified successfully"
        }
        mock_get.return_value = mock_response
        
        # Import the function to test
        import sys
        if 'public_portal' in sys.modules:
            del sys.modules['public_portal']
            
        from public_portal import verify_report
        
        # Call the function
        result = verify_report("test-report-123")
        
        # Assertions
        self.assertIsNotNone(result)
        self.assertEqual(result["report_id"], "test-report-123")
        self.assertEqual(result["verification_status"], "success")
        mock_get.assert_called_once_with(
            "http://localhost:8000/verify/test-report-123",
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
    @patch('requests.get')
    def test_api_integration_not_found(self, mock_get):
        """Test integration with backend API when report is not found"""
        # Mock 404 API response
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.json.return_value = {
            "detail": "Report with ID test-report-123 not found"
        }
        mock_get.return_value = mock_response
        
        # Import the function to test
        import sys
        if 'public_portal' in sys.modules:
            del sys.modules['public_portal']
            
        from public_portal import verify_report
        
        # Call the function
        result = verify_report("test-report-123")
        
        # Assertions
        self.assertIsNone(result)
        mock_get.assert_called_once_with(
            "http://localhost:8000/verify/test-report-123",
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
    @patch('requests.get')
    def test_api_integration_server_error(self, mock_get):
        """Test integration with backend API when server error occurs"""
        # Mock 500 API response
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {
            "detail": "Internal server error"
        }
        mock_get.return_value = mock_response
        
        # Import the function to test
        import sys
        if 'public_portal' in sys.modules:
            del sys.modules['public_portal']
            
        from public_portal import verify_report
        
        # Call the function
        result = verify_report("test-report-123")
        
        # Assertions
        self.assertIsNone(result)
        mock_get.assert_called_once_with(
            "http://localhost:8000/verify/test-report-123",
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
    @patch('requests.get')
    def test_api_integration_timeout(self, mock_get):
        """Test integration when API request times out"""
        # Mock timeout exception
        mock_get.side_effect = Exception("Request timed out")
        
        # Import the function to test
        import sys
        if 'public_portal' in sys.modules:
            del sys.modules['public_portal']
            
        from public_portal import verify_report
        
        # Call the function
        result = verify_report("test-report-123")
        
        # Assertions
        self.assertIsNone(result)
        mock_get.assert_called_once_with(
            "http://localhost:8000/verify/test-report-123",
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        
    def test_display_verification_result_success(self):
        """Test display of successful verification result"""
        # Mock Streamlit functions
        with patch('streamlit.markdown'), \
             patch('streamlit.subheader'), \
             patch('streamlit.write'), \
             patch('streamlit.json'), \
             patch('streamlit.code'), \
             patch('streamlit.expander'), \
             patch('streamlit.text'):
            
            # Import the function to test
            import sys
            if 'public_portal' in sys.modules:
                del sys.modules['public_portal']
                
            from public_portal import display_verification_result
            
            # Test data
            result = {
                "report_id": "test-report-123",
                "report_data": {"company": "Test Company", "esg_score": 85},
                "vc_jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                "blockchain_hashes": ["0xabc123...", "0xdef456..."],
                "verification_status": "success",
                "message": "Report verified successfully"
            }
            
            # Call the function
            display_verification_result(result)
            
            # If no exception is raised, the test passes
            
    def test_display_verification_result_empty(self):
        """Test display of empty verification result"""
        # Mock Streamlit functions
        with patch('streamlit.markdown'):
            
            # Import the function to test
            import sys
            if 'public_portal' in sys.modules:
                del sys.modules['public_portal']
                
            from public_portal import display_verification_result
            
            # Call the function with None
            display_verification_result(None)
            
            # If no exception is raised, the test passes

if __name__ == '__main__':
    unittest.main()