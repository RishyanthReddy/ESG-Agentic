"""
Unit tests for granular traceability functionality in the visualization agent.
"""

import pytest
import networkx as nx
from datetime import datetime
from src.agents.visualization import visualization_agent, _find_data_point_nodes
from src.state.models import AppState


def create_sample_agent_traces():
    """Create sample agent traces for testing."""
    return [
        {
            "agent_id": "supplier_data_collector",
            "agent_name": "Tier-3 Supplier Data Collector",
            "agent_role": "data_collection",
            "status": "completed",
            "timestamp": datetime.utcnow().isoformat(),
            "input_artifacts": [],
            "output_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "supplier_info": {
                "id": "supplier_tier3_abc_corp",
                "name": "ABC Corporation",
                "location": "Shanghai, China",
                "certifications": ["ISO 14001", "ISO 45001"],
                "timestamp": datetime.utcnow().isoformat()
            }
        },
        {
            "agent_id": "esg_data_processor",
            "agent_name": "ESG Data Processing Agent",
            "agent_role": "data_processing",
            "status": "completed",
            "timestamp": datetime.utcnow().isoformat(),
            "input_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "processed_esg_data_q1_2024",
                    "name": "Processed ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 51200,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
    ]


def create_sample_blockchain_logs():
    """Create sample blockchain logs for testing."""
    return [
        {
            "transaction_hash": "0x7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b",
            "data_hash": "f6e5d4c3b2a10987",
            "account": "0x9cEa8237BC8cc063768bD85883B01b8d66a1b61b",
            "block_number": 15783246,
            "gas_used": 21000,
            "timestamp": datetime.utcnow().isoformat()
        }
    ]


def test_find_data_point_nodes():
    """Test the _find_data_point_nodes function."""
    # Create a sample graph
    graph = nx.DiGraph()
    
    # Add nodes
    graph.add_node("artifact:raw_esg_data_q1_2024", type="artifact", name="Raw ESG Data Q1 2024")
    graph.add_node("agent:supplier_data_collector", type="agent", name="Supplier Data Collector")
    graph.add_node("agent:esg_data_processor", type="agent", name="ESG Data Processor")
    graph.add_node("artifact:processed_esg_data_q1_2024", type="artifact", name="Processed ESG Data Q1 2024")
    graph.add_node("blockchain:ethereum", type="blockchain", name="Ethereum")
    
    # Add edges
    graph.add_edge("agent:supplier_data_collector", "artifact:raw_esg_data_q1_2024")
    graph.add_edge("artifact:raw_esg_data_q1_2024", "agent:esg_data_processor")
    graph.add_edge("agent:esg_data_processor", "artifact:processed_esg_data_q1_2024")
    graph.add_edge("artifact:processed_esg_data_q1_2024", "blockchain:ethereum")
    
    # Test finding data point nodes
    source, target = _find_data_point_nodes(graph, "raw_esg_data_q1_2024")
    
    assert source == "artifact:raw_esg_data_q1_2024"
    assert target == "blockchain:ethereum"


def test_granular_traceability_visualization():
    """Test visualization with granular traceability."""
    # Create sample data
    agent_traces = create_sample_agent_traces()
    blockchain_logs = create_sample_blockchain_logs()
    
    # Create state with trace_data_point specified
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="raw_esg_data_q1_2024"
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was successful
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is included
    assert "granular_traceability" in visualization_assets
    assert visualization_assets["granular_traceability"]["data_point_id"] == "raw_esg_data_q1_2024"
    
    # Check that path analysis is included
    assert "path_analysis" in visualization_assets["granular_traceability"]


def test_regular_visualization_without_trace_point():
    """Test regular visualization without specifying a trace data point."""
    # Create sample data
    agent_traces = create_sample_agent_traces()
    blockchain_logs = create_sample_blockchain_logs()
    
    # Create state without trace_data_point
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was successful
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is not included
    assert "granular_traceability" not in visualization_assets


def test_visualization_with_invalid_data_point():
    """Test visualization when a non-existent data point is specified."""
    # Create sample data
    agent_traces = create_sample_agent_traces()
    blockchain_logs = create_sample_blockchain_logs()
    
    # Create state with non-existent trace_data_point
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="non_existent_data_point"
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was successful even with invalid data point
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is included but with failure info
    assert "granular_traceability" in visualization_assets
    assert visualization_assets["granular_traceability"]["data_point_id"] == "non_existent_data_point"


if __name__ == "__main__":
    pytest.main([__file__])