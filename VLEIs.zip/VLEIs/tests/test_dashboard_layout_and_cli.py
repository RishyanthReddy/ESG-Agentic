"""
Test suite for dashboard layout and CLI equivalents.
This module tests:
1. Responsive dashboard layout
2. Terminal interface usability and functionality
3. Component integration
4. Script orchestration
"""

import os
import sys
import subprocess
import pytest
import json
import time
import platform
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def test_dashboard_page_exists():
    """Test that the dashboard page exists"""
    page_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'app', 'page.tsx')
    assert os.path.exists(page_path), "Dashboard page (page.tsx) not found"

def test_dashboard_layout_implementation():
    """Test that the dashboard layout implements all required components"""
    page_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'app', 'page.tsx')
    
    assert os.path.exists(page_path), "Dashboard page (page.tsx) not found"
    
    with open(page_path, 'r') as f:
        content = f.read()
    
    # Check for required components
    assert 'MetricsPanel' in content, "MetricsPanel component not found in dashboard"
    assert 'RealTimeMetricsPanel' in content, "RealTimeMetricsPanel component not found in dashboard"
    assert 'ESGScoreChart' in content, "ESGScoreChart component not found in dashboard"
    assert 'SupplierComplianceChart' in content, "SupplierComplianceChart component not found in dashboard"
    assert 'RealTimeCarbonChart' in content, "RealTimeCarbonChart component not found in dashboard"
    assert 'ProvenanceGraph3D' in content, "ProvenanceGraph3D component not found in dashboard"
    assert 'PerformanceOptimizedGraph' in content, "PerformanceOptimizedGraph component not found in dashboard"
    
    # Check for responsive layout elements
    assert 'grid' in content.lower(), "CSS Grid not found in dashboard layout"
    assert 'flex' in content.lower(), "Flexbox not found in dashboard layout"
    assert 'responsive' in content.lower() or 'sm:' in content or 'md:' in content or 'lg:' in content, "Responsive design elements not found"

def test_complete_dashboard_simulation_script_exists():
    """Test that the complete_dashboard_simulation.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'complete_dashboard_simulation.py')
    assert os.path.exists(script_path), "complete_dashboard_simulation.py script not found"

def test_dashboard_workflow_script_exists():
    """Test that the dashboard_workflow.sh script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'dashboard_workflow.sh')
    assert os.path.exists(script_path), "dashboard_workflow.sh script not found"

def test_end_to_end_demo_script_exists():
    """Test that the end_to_end_demo.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'end_to_end_demo.py')
    assert os.path.exists(script_path), "end_to_end_demo.py script not found"

def test_presentation_mode_script_exists():
    """Test that the presentation_mode.sh script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'presentation_mode.sh')
    assert os.path.exists(script_path), "presentation_mode.sh script not found"

def test_complete_dashboard_simulation_script_execution():
    """Test that the complete_dashboard_simulation.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'complete_dashboard_simulation.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "complete_dashboard_simulation.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"complete_dashboard_simulation.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("complete_dashboard_simulation.py script timed out")
    except Exception as e:
        pytest.fail(f"complete_dashboard_simulation.py script failed with error: {e}")

def test_end_to_end_demo_script_execution():
    """Test that the end_to_end_demo.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'end_to_end_demo.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "end_to_end_demo.py script not found"
    
    # Skip this test on Windows as it has issues with subprocess execution
    if platform.system() == "Windows":
        pytest.skip("Skipping on Windows due to subprocess execution issues")
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"end_to_end_demo.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("end_to_end_demo.py script timed out")
    except Exception as e:
        pytest.fail(f"end_to_end_demo.py script failed with error: {e}")

def test_script_orchestration():
    """Test that scripts can be orchestrated together"""
    # Test that we can run the complete dashboard simulation for a short duration
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'complete_dashboard_simulation.py')
    
    try:
        result = subprocess.run(
            ['python', script_path, '--tab', 'overview', '--simple'], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"complete_dashboard_simulation.py failed with return code {result.returncode}"
        
        # Check that output contains expected information
        output = result.stdout.lower()
        assert 'dashboard' in output or 'metrics' in output or 'simulation' in output
        
    except subprocess.TimeoutExpired:
        pytest.fail("complete_dashboard_simulation.py script timed out")
    except Exception as e:
        pytest.fail(f"complete_dashboard_simulation.py script failed with error: {e}")

def test_cli_interface():
    """Test CLI interface usability and functionality"""
    # Test that the presentation mode script exists and is executable
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'presentation_mode.sh')
    assert os.path.exists(script_path), "presentation_mode.sh script not found"
    
    # Skip this test on Windows as bash may not be available
    if platform.system() == "Windows":
        pytest.skip("Skipping on Windows as bash may not be available")
    
    # Test that we can at least get help from the script
    try:
        result = subprocess.run(
            ['bash', '-c', f'head -n 20 {script_path}'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        
        # Check if we got some output
        assert result.returncode == 0, f"presentation_mode.sh failed with return code {result.returncode}"
        assert len(result.stdout) > 0, "presentation_mode.sh produced no output"
        
    except subprocess.TimeoutExpired:
        pytest.fail("presentation_mode.sh script timed out")
    except Exception as e:
        pytest.fail(f"presentation_mode.sh script failed with error: {e}")

def test_component_integration():
    """Test that all dashboard components work together"""
    # Test that the dashboard page contains imports for all required components
    page_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'app', 'page.tsx')
    
    assert os.path.exists(page_path), "Dashboard page (page.tsx) not found"
    
    with open(page_path, 'r') as f:
        content = f.read()
    
    # Check for component imports
    assert '@/components/panels' in content, "Panels components not imported in dashboard"
    assert '@/components/charts' in content, "Charts components not imported in dashboard"
    assert '@/components/threejs' in content, "Three.js components not imported in dashboard"
    
    # Check for tab navigation implementation
    assert 'setActiveTab' in content, "Tab navigation not implemented in dashboard"
    assert 'activeTab' in content, "Active tab state not found in dashboard"
    
    # Check for proper component usage
    assert 'MetricsPanel' in content, "MetricsPanel not used in dashboard"
    assert 'ESGScoreChart' in content, "ESGScoreChart not used in dashboard"
    assert 'SupplierComplianceChart' in content, "SupplierComplianceChart not used in dashboard"
    assert 'RealTimeCarbonChart' in content, "RealTimeCarbonChart not used in dashboard"
    assert 'ProvenanceGraph3D' in content or 'PerformanceOptimizedGraph' in content, "3D Graph component not used in dashboard"

if __name__ == "__main__":
    pytest.main([__file__])