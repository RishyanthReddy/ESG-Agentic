"""
Chaos Engineering Framework for VLEIs

This module implements a chaos engineering framework to test system resilience
against real-world disruptions like network latency, API errors, and blockchain
node unavailability.
"""

import asyncio
import time
import random
import json
import httpx
from typing import Callable, Any, Dict, Optional
from functools import wraps
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response as StarletteResponse
from starlette.types import ASGIApp
from loguru import logger
from toxiproxy import Toxiproxy


class ChaosError(Exception):
    """Custom exception for chaos engineering failures"""
    pass


class ToxiproxyChaosProxy:
    """
    Chaos proxy using Toxiproxy to simulate network failures.
    
    This class provides methods to simulate various network conditions
    like latency, bandwidth limitations, and connection failures.
    """
    
    def __init__(self, toxiproxy_host: str = "localhost", toxiproxy_port: int = 8474):
        """
        Initialize the Toxiproxy chaos proxy.
        
        Args:
            toxiproxy_host: Host where Toxiproxy is running
            toxiproxy_port: Port where Toxiproxy API is accessible
        """
        self.toxiproxy_host = toxiproxy_host
        self.toxiproxy_port = toxiproxy_port
        self.client = Toxiproxy(f"http://{toxiproxy_host}:{toxiproxy_port}")
        self.proxies = {}
        
    def create_proxy(self, name: str, listen_port: int, upstream_host: str, upstream_port: int):
        """
        Create a proxy for a service to inject chaos.
        
        Args:
            name: Name of the proxy
            listen_port: Port where the proxy will listen
            upstream_host: Host of the upstream service
            upstream_port: Port of the upstream service
        """
        try:
            proxy = self.client.create_proxy(name, f"localhost:{listen_port}", f"{upstream_host}:{upstream_port}")
            self.proxies[name] = proxy
            logger.info(f"Created proxy '{name}' listening on port {listen_port}")
            return proxy
        except Exception as e:
            raise ChaosError(f"Failed to create proxy '{name}': {str(e)}")
        
    def add_latency(self, proxy_name: str, latency_ms: int, jitter_ms: int = 0):
        """
        Add latency to a proxy.
        
        Args:
            proxy_name: Name of the proxy
            latency_ms: Latency in milliseconds
            jitter_ms: Jitter in milliseconds (optional)
        """
        if proxy_name not in self.proxies:
            raise ChaosError(f"Proxy '{proxy_name}' not found")
            
        try:
            proxy = self.proxies[proxy_name]
            proxy.add_toxic("latency", "latency", attributes={
                "latency": latency_ms,
                "jitter": jitter_ms
            })
            logger.info(f"Added latency of {latency_ms}ms to proxy '{proxy_name}'")
        except Exception as e:
            raise ChaosError(f"Failed to add latency to proxy '{proxy_name}': {str(e)}")
        
    def add_bandwidth_limit(self, proxy_name: str, rate_kbps: int):
        """
        Add bandwidth limitation to a proxy.
        
        Args:
            proxy_name: Name of the proxy
            rate_kbps: Bandwidth limit in kilobytes per second
        """
        if proxy_name not in self.proxies:
            raise ChaosError(f"Proxy '{proxy_name}' not found")
            
        try:
            proxy = self.proxies[proxy_name]
            proxy.add_toxic("bandwidth", "bandwidth", attributes={
                "rate": rate_kbps
            })
            logger.info(f"Added bandwidth limit of {rate_kbps}kbps to proxy '{proxy_name}'")
        except Exception as e:
            raise ChaosError(f"Failed to add bandwidth limit to proxy '{proxy_name}': {str(e)}")
        
    def add_connection_failure(self, proxy_name: str, percentage: float = 100.0):
        """
        Add connection failures to a proxy.
        
        Args:
            proxy_name: Name of the proxy
            percentage: Percentage of connections to fail (0-100)
        """
        if proxy_name not in self.proxies:
            raise ChaosError(f"Proxy '{proxy_name}' not found")
            
        try:
            proxy = self.proxies[proxy_name]
            proxy.add_toxic("connection_failure", "timeout", attributes={
                "timeout": 0  # Immediate timeout
            })
            logger.info(f"Added connection failure to proxy '{proxy_name}'")
        except Exception as e:
            raise ChaosError(f"Failed to add connection failure to proxy '{proxy_name}': {str(e)}")
            
    def add_http_error(self, proxy_name: str, status_code: int = 503):
        """
        Add HTTP error responses to a proxy.
        
        Args:
            proxy_name: Name of the proxy
            status_code: HTTP status code to return (default: 503)
        """
        if proxy_name not in self.proxies:
            raise ChaosError(f"Proxy '{proxy_name}' not found")
            
        # Note: HTTP error simulation would typically be done at the application level
        # or with a custom toxic. For now, we'll simulate with a timeout to cause errors.
        try:
            proxy = self.proxies[proxy_name]
            proxy.add_toxic("http_error", "timeout", attributes={
                "timeout": 1  # Very short timeout to cause failures
            })
            logger.info(f"Added HTTP error simulation (status {status_code}) to proxy '{proxy_name}'")
        except Exception as e:
            raise ChaosError(f"Failed to add HTTP error simulation to proxy '{proxy_name}': {str(e)}")
            
    def reset(self, proxy_name: str = None):
        """
        Reset toxics for a specific proxy or all proxies.
        
        Args:
            proxy_name: Name of the proxy to reset (optional, if None resets all)
        """
        try:
            if proxy_name:
                if proxy_name in self.proxies:
                    proxy = self.proxies[proxy_name]
                    proxy.destroy()
                    # Recreate the proxy without toxics
                    # We would need to store the original configuration to recreate it
                    logger.info(f"Reset proxy '{proxy_name}'")
            else:
                # Reset all proxies
                for name, proxy in self.proxies.items():
                    proxy.destroy()
                self.proxies.clear()
                logger.info("Reset all proxies")
        except Exception as e:
            raise ChaosError(f"Failed to reset proxies: {str(e)}")
            
    def remove_toxic(self, proxy_name: str, toxic_name: str):
        """
        Remove a specific toxic from a proxy.
        
        Args:
            proxy_name: Name of the proxy
            toxic_name: Name of the toxic to remove
        """
        if proxy_name not in self.proxies:
            raise ChaosError(f"Proxy '{proxy_name}' not found")
            
        try:
            proxy = self.proxies[proxy_name]
            proxy.remove_toxic(toxic_name)
            logger.info(f"Removed toxic '{toxic_name}' from proxy '{proxy_name}'")
        except Exception as e:
            raise ChaosError(f"Failed to remove toxic '{toxic_name}' from proxy '{proxy_name}': {str(e)}")


class ChaosMiddleware(BaseHTTPMiddleware):
    """
    Middleware to simulate chaos in HTTP requests.
    """
    
    def __init__(self, app: ASGIApp, failure_probability: float = 0.0):
        """
        Initialize chaos middleware.
        
        Args:
            app: The ASGI application
            failure_probability: Probability of request failure (0.0 to 1.0)
        """
        super().__init__(app)
        self.failure_probability = failure_probability
        
    async def dispatch(self, request: Request, call_next: Callable) -> StarletteResponse:
        """
        Dispatch request with potential chaos injection.
        
        Args:
            request: Incoming request
            call_next: Next middleware/app in chain
            
        Returns:
            Response from the application
        """
        # Simulate network failures based on probability
        if random.random() < self.failure_probability:
            logger.info("Chaos middleware injecting failure")
            return StarletteResponse(
                content=json.dumps({"error": "Service temporarily unavailable due to network issues"}),
                status_code=503
            )
            
        # Continue with normal request processing
        response = await call_next(request)
        return response


# Global chaos configuration
_network_failure_probability = 0.0
_timeout_duration = 0
_chaos_middleware = None


def set_network_failure_probability(probability: float):
    """
    Set the probability of network failures.
    
    Args:
        probability: Probability of failure (0.0 to 1.0)
    """
    global _network_failure_probability
    _network_failure_probability = probability


def set_timeout_failure(timeout: int):
    """
    Set timeout duration for requests.
    
    Args:
        timeout: Timeout in seconds
    """
    global _timeout_duration
    _timeout_duration = timeout


def simulate_network_failure():
    """
    Simulate a network failure based on configured probability.
    
    Raises:
        ChaosError: If a network failure is simulated
    """
    if random.random() < _network_failure_probability:
        raise ChaosError("Simulated network failure")


def simulate_network_latency(min_ms: int, max_ms: int):
    """
    Simulate network latency by sleeping for a random duration.
    
    Args:
        min_ms: Minimum latency in milliseconds
        max_ms: Maximum latency in milliseconds
    """
    latency_ms = random.randint(min_ms, max_ms)
    time.sleep(latency_ms / 1000.0)


def simulate_climatiq_api_failure():
    """
    Simulate a Climatiq API failure (503 Service Unavailable).
    
    Raises:
        httpx.HTTPStatusError: With 503 status code
    """
    # This would typically be handled at the HTTP client level
    # For now, we just log that we're simulating the failure
    logger.info("Simulating Climatiq API failure (503 Service Unavailable)")


def simulate_infura_api_failure():
    """
    Simulate an Infura API failure.
    
    Raises:
        httpx.HTTPStatusError: With 503 status code
    """
    # This would typically be handled at the HTTP client level
    # For now, we just log that we're simulating the failure
    logger.info("Simulating Infura API failure")


def simulate_connection_failure(service_name: str):
    """
    Simulate a connection failure to a specific service.
    
    Args:
        service_name: Name of the service to fail
    """
    logger.info(f"Simulating connection failure to {service_name}")


def simulate_bandwidth_limit(limit_kbps: int):
    """
    Simulate bandwidth limitation.
    
    Args:
        limit_kbps: Bandwidth limit in kilobytes per second
    """
    logger.info(f"Simulating bandwidth limit of {limit_kbps} KB/s")


def init_chaos_middleware(app, failure_probability: float = 0.05):
    """
    Initialize chaos middleware for the application.
    
    Args:
        app: FastAPI application
        failure_probability: Probability of request failure (0.0 to 1.0)
    """
    global _chaos_middleware
    _chaos_middleware = ChaosMiddleware(app, failure_probability)
    return _chaos_middleware


def reset_chaos():
    """
    Reset all chaos configurations to defaults.
    """
    global _network_failure_probability, _timeout_duration
    _network_failure_probability = 0.0
    _timeout_duration = 0
    logger.info("Reset chaos configurations to defaults")