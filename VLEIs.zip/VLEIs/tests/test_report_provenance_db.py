"""
Unit tests for the Report Provenance Database module.
"""

import os
import tempfile
import pytest
import shutil
from unittest.mock import patch, MagicMock
from src.utils.db import (
    store_report_proofs, 
    get_report_proofs, 
    backup_database, 
    restore_database,
    _get_encryption_key
)


class TestReportProvenanceDB:
    """Test cases for the report provenance database operations."""
    
    @pytest.fixture(autouse=True)
    def setup_and_teardown(self):
        """Setup and teardown for each test."""
        # Create a temporary directory for test data
        self.test_dir = tempfile.mkdtemp()
        self.test_db_file = os.path.join(self.test_dir, "test_report_provenance.json")
        self.test_key_file = os.path.join(self.test_dir, "test_db.key")
        
        # Patch the database file paths
        with patch("src.utils.db.DB_FILE", self.test_db_file), \
             patch("src.utils.db.DB_ENCRYPTION_KEY_FILE", self.test_key_file):
            yield
        
        # Cleanup
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    def test_store_and_retrieve_report_proofs(self):
        """Test storing and retrieving report proofs."""
        # Test data
        report_id = "test_report_001"
        proofs = {
            "vc_jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "blockchain_hash": "0x7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a",
            "signature": "3045022100f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a20220f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2"
        }
        
        # Store proofs
        doc_id = store_report_proofs(report_id, proofs)
        assert doc_id is not None
        assert isinstance(doc_id, int)
        
        # Retrieve proofs
        retrieved_proofs = get_report_proofs(report_id)
        assert retrieved_proofs is not None
        assert retrieved_proofs == proofs
    
    def test_retrieve_nonexistent_report_proofs(self):
        """Test retrieving proofs for a non-existent report."""
        # Try to retrieve proofs for a non-existent report
        retrieved_proofs = get_report_proofs("nonexistent_report")
        assert retrieved_proofs is None
    
    def test_update_existing_report_proofs(self):
        """Test updating proofs for an existing report."""
        # Test data
        report_id = "test_report_002"
        initial_proofs = {
            "vc_jwt": "initial_jwt_token",
            "blockchain_hash": "initial_hash"
        }
        updated_proofs = {
            "vc_jwt": "updated_jwt_token",
            "blockchain_hash": "updated_hash",
            "additional_proof": "additional_data"
        }
        
        # Store initial proofs
        initial_doc_id = store_report_proofs(report_id, initial_proofs)
        
        # Update proofs
        updated_doc_id = store_report_proofs(report_id, updated_proofs)
        
        # Verify the document ID is the same (update, not insert)
        assert updated_doc_id == initial_doc_id
        
        # Retrieve and verify updated proofs
        retrieved_proofs = get_report_proofs(report_id)
        assert retrieved_proofs == updated_proofs
        assert "additional_proof" in retrieved_proofs
    
    def test_encryption_key_generation(self):
        """Test encryption key generation and retrieval."""
        # Test that key is generated if it doesn't exist
        key1 = _get_encryption_key()
        assert key1 is not None
        assert isinstance(key1, bytes)
        
        # Test that same key is returned on subsequent calls
        key2 = _get_encryption_key()
        assert key1 == key2
    
    def test_database_encryption(self):
        """Test that database data is encrypted."""
        with patch("src.utils.db.DB_FILE", self.test_db_file), \
             patch("src.utils.db.DB_ENCRYPTION_KEY_FILE", self.test_key_file):
            # Store some data
            report_id = "encrypted_report"
            proofs = {"sensitive_data": "secret_value"}
            store_report_proofs(report_id, proofs)
            
            # Check that the database file exists
            assert os.path.exists(self.test_db_file)
            
            # Check that the content is encrypted (not readable as plain JSON)
            with open(self.test_db_file, 'r') as f:
                content = f.read()
                
            # Content should not be valid JSON (because it's encrypted)
            import json
            with pytest.raises(json.JSONDecodeError):
                json.loads(content)
    
    def test_backup_database(self):
        """Test database backup functionality."""
        with patch("src.utils.db.DB_FILE", self.test_db_file), \
             patch("src.utils.db.DB_ENCRYPTION_KEY_FILE", self.test_key_file):
            # Store some test data
            report_id = "backup_test_report"
            proofs = {"data": "test_value"}
            store_report_proofs(report_id, proofs)
            
            # Create backup
            backup_path = os.path.join(self.test_dir, "backup", "report_provenance_backup.json")
            success = backup_database(backup_path)
            
            # Verify backup was successful
            assert success is True
            assert os.path.exists(backup_path)
            
            # Verify backup file is not empty
            assert os.path.getsize(backup_path) > 0
    
    def test_restore_database(self):
        """Test database restore functionality."""
        with patch("src.utils.db.DB_FILE", self.test_db_file), \
             patch("src.utils.db.DB_ENCRYPTION_KEY_FILE", self.test_key_file):
            # Store some test data
            report_id = "restore_test_report"
            proofs = {"data": "original_value"}
            store_report_proofs(report_id, proofs)
            
            # Create backup
            backup_path = os.path.join(self.test_dir, "backup", "report_provenance_backup.json")
            backup_success = backup_database(backup_path)
            assert backup_success is True
            
            # Modify the original data
            modified_proofs = {"data": "modified_value"}
            store_report_proofs(report_id, modified_proofs)
            
            # Verify data was modified
            retrieved_proofs = get_report_proofs(report_id)
            assert retrieved_proofs == modified_proofs
            
            # Restore from backup
            restore_success = restore_database(backup_path)
            assert restore_success is True
            
            # Verify data was restored (this would require re-initializing the DB)
            # For this test, we'll just verify the restore function completed without error
    
    def test_restore_nonexistent_backup(self):
        """Test restoring from a non-existent backup file."""
        # Try to restore from non-existent backup
        backup_path = os.path.join(self.test_dir, "nonexistent", "backup.json")
        success = restore_database(backup_path)
        
        # Verify restore failed
        assert success is False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])