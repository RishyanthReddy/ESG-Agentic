"""
Test suite for chart components and visualization scripts.
This module tests:
1. React chart component rendering
2. Python chart generation and display
3. Chart data transformation logic
4. Chart export in both systems
"""

import os
import sys
import subprocess
import pytest
import json
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def test_recharts_components_exist():
    """Test that the Recharts components exist"""
    components_dir = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'components', 'charts')
    
    assert os.path.exists(components_dir), "Charts components directory not found"
    
    required_files = [
        'ESGScoreChart.tsx',
        'SupplierComplianceChart.tsx',
        'RealTimeCarbonChart.tsx',
        'index.ts'
    ]
    
    for file_name in required_files:
        file_path = os.path.join(components_dir, file_name)
        assert os.path.exists(file_path), f"Required chart component {file_name} not found"

def test_metrics_display_script_exists():
    """Test that the metrics_display.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'metrics_display.py')
    assert os.path.exists(script_path), "metrics_display.py script not found"

def test_kpi_dashboard_script_exists():
    """Test that the kpi_dashboard.sh script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'kpi_dashboard.sh')
    assert os.path.exists(script_path), "kpi_dashboard.sh script not found"

def test_chart_data_export_script_exists():
    """Test that the chart_data_export.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'chart_data_export.py')
    assert os.path.exists(script_path), "chart_data_export.py script not found"

def test_metrics_summary_script_exists():
    """Test that the metrics_summary.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'metrics_summary.py')
    assert os.path.exists(script_path), "metrics_summary.py script not found"

def test_metrics_display_script_execution():
    """Test that the metrics_display.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'metrics_display.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "metrics_display.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"metrics_display.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("metrics_display.py script timed out")
    except Exception as e:
        pytest.fail(f"metrics_display.py script failed with error: {e}")

def test_chart_data_export_script_execution():
    """Test that the chart_data_export.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'chart_data_export.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "chart_data_export.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"chart_data_export.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("chart_data_export.py script timed out")
    except Exception as e:
        pytest.fail(f"chart_data_export.py script failed with error: {e}")

def test_metrics_summary_script_execution():
    """Test that the metrics_summary.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'metrics_summary.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "metrics_summary.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"metrics_summary.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("metrics_summary.py script timed out")
    except Exception as e:
        pytest.fail(f"metrics_summary.py script failed with error: {e}")

def test_chart_export_functionality():
    """Test that the chart export functionality works"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'chart_data_export.py')
    
    # Create a temporary directory for export
    export_dir = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'test_export')
    os.makedirs(export_dir, exist_ok=True)
    
    try:
        # Run the export script
        result = subprocess.run(
            ['python', script_path, '--chart-type', 'esg', '--output-dir', export_dir], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"chart_data_export.py failed with return code {result.returncode}"
        
        # Check if export files were created
        export_files = os.listdir(export_dir)
        assert len(export_files) > 0, "No export files were created"
        
        # Check that at least one PNG file was created
        png_files = [f for f in export_files if f.endswith('.png')]
        assert len(png_files) > 0, "No PNG export files were created"
        
    except subprocess.TimeoutExpired:
        pytest.fail("chart_data_export.py script timed out")
    except Exception as e:
        pytest.fail(f"chart_data_export.py script failed with error: {e}")
    finally:
        # Clean up export files
        if os.path.exists(export_dir):
            for file in os.listdir(export_dir):
                os.remove(os.path.join(export_dir, file))
            os.rmdir(export_dir)

def test_metrics_summary_functionality():
    """Test that the metrics summary functionality works"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'metrics_summary.py')
    
    # Create a temporary directory for export
    export_dir = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'test_summary')
    os.makedirs(export_dir, exist_ok=True)
    
    try:
        # Run the summary script
        result = subprocess.run(
            ['python', script_path, '--format', 'text', '--output-dir', export_dir], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"metrics_summary.py failed with return code {result.returncode}"
        
        # Check if summary files were created
        summary_files = os.listdir(export_dir)
        assert len(summary_files) > 0, "No summary files were created"
        
        # Check that at least one TXT file was created
        txt_files = [f for f in summary_files if f.endswith('.txt')]
        assert len(txt_files) > 0, "No TXT summary files were created"
        
    except subprocess.TimeoutExpired:
        pytest.fail("metrics_summary.py script timed out")
    except Exception as e:
        pytest.fail(f"metrics_summary.py script failed with error: {e}")
    finally:
        # Clean up summary files
        if os.path.exists(export_dir):
            for file in os.listdir(export_dir):
                os.remove(os.path.join(export_dir, file))
            os.rmdir(export_dir)

if __name__ == "__main__":
    pytest.main([__file__])