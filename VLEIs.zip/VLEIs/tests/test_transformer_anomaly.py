"""
Unit tests for the Transformer-based Scope 3 Anomaly Detection Tool

This module contains tests for verifying the correct functionality of the 
Scope3AnomalyPredictorTool including model loading, interface compliance,
transformer predictions, and GPU compatibility.
"""

import pytest
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.tools.esg import Scope3AnomalyPredictorTool, Scope3DataPoint


class TestTransformerAnomalyDetection:
    """Test cases for the Transformer-based Scope3AnomalyPredictorTool class."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Skip tests if PyTorch is not available
        try:
            import torch
            self.torch_available = True
        except ImportError:
            self.torch_available = False
            return
        
        self.tool = Scope3AnomalyPredictorTool()
    
    def test_initialization(self):
        """Test that the tool initializes correctly."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        assert self.tool.name == "scope3_anomaly_predictor"
        assert self.tool.description is not None
        assert len(self.tool.description) > 0
        assert self.tool.model is not None
    
    def test_model_loading(self):
        """Test Transformer model loading and initialization."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Model should be loaded during initialization
        assert self.tool.model is not None
        
        # Check that model is in evaluation mode
        assert not self.tool.model.training
        
        # Check that it's the correct model type
        from src.tools.esg import AnomalyTransformerModel
        assert isinstance(self.tool.model, AnomalyTransformerModel)
    
    def test_interface_compliance(self):
        """Test that the tool complies with BaseTool interface."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Check that it has the required methods
        assert hasattr(self.tool, 'run')
        assert callable(self.tool.run)
        
        # Check that it has the required attributes
        assert hasattr(self.tool, 'name')
        assert hasattr(self.tool, 'description')
    
    def test_transformer_predictions_with_dict_data(self):
        """Test Transformer prediction functionality with dict data."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Create sample data points as dictionaries
        sample_data = [
            {
                "timestamp": "2023-01-01T00:00:00Z",
                "value": 100.5,
                "metric_type": "co2_emissions",
                "supplier_id": "supplier_1",
                "confidence_score": 0.95
            },
            {
                "timestamp": "2023-01-02T00:00:00Z",
                "value": 105.2,
                "metric_type": "co2_emissions",
                "supplier_id": "supplier_1",
                "confidence_score": 0.92
            },
            {
                "timestamp": "2023-01-03T00:00:00Z",
                "value": 500.0,  # Anomalous value
                "metric_type": "co2_emissions",
                "supplier_id": "supplier_1",
                "confidence_score": 0.1  # Low confidence might indicate anomaly
            }
        ]
        
        # Run the tool
        result = self.tool.run(sample_data)
        
        # Check result structure
        assert "success" in result
        assert result["success"] is True
        assert "anomaly_count" in result
        assert "total_points" in result
        assert "results" in result
        assert len(result["results"]) == len(sample_data)
        
        # Check individual results
        for res in result["results"]:
            assert "timestamp" in res
            assert "value" in res
            assert "anomaly_score" in res
            assert "is_anomaly" in res
            assert "confidence" in res
    
    def test_transformer_predictions_with_model_data(self):
        """Test Transformer prediction functionality with model data."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Create sample data points as models
        sample_data = [
            Scope3DataPoint(
                timestamp="2023-01-01T00:00:00Z",
                value=100.5,
                metric_type="co2_emissions",
                supplier_id="supplier_1",
                confidence_score=0.95
            ),
            Scope3DataPoint(
                timestamp="2023-01-02T00:00:00Z",
                value=105.2,
                metric_type="co2_emissions",
                supplier_id="supplier_1",
                confidence_score=0.92
            )
        ]
        
        # Run the tool
        result = self.tool.run(sample_data)
        
        # Check result structure
        assert "success" in result
        assert result["success"] is True
        assert "results" in result
        assert len(result["results"]) == len(sample_data)
    
    def test_gpu_compatibility(self):
        """Test GPU/CPU compatibility."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Check that device is properly set
        assert hasattr(self.tool, 'device')
        assert str(self.tool.device) in ["cpu", "cuda", "cuda:0"]
        
        # Result should include device information
        sample_data = [
            {
                "timestamp": "2023-01-01T00:00:00Z",
                "value": 100.5,
                "metric_type": "co2_emissions",
                "supplier_id": "supplier_1"
            }
        ]
        
        result = self.tool.run(sample_data)
        assert "device" in result
        assert result["device"] in ["cpu", "cuda", "cuda:0"]
    
    def test_error_handling(self):
        """Test error handling with invalid data."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Test with invalid data format
        invalid_data = [
            {
                "invalid_field": "missing_required_fields"
            }
        ]
        
        result = self.tool.run(invalid_data)
        assert "success" in result
        # With invalid data, it should either fail gracefully or succeed with empty results
        # Depending on implementation, it might return success=False or handle it differently
        # In our implementation, it should return success=False due to validation error
    
    def test_empty_data_handling(self):
        """Test handling of empty data."""
        if not self.torch_available:
            pytest.skip("PyTorch not available")
            
        # Test with empty data
        empty_data = []
        
        result = self.tool.run(empty_data)
        assert "success" in result
        assert result["success"] is True
        assert "results" in result


if __name__ == "__main__":
    pytest.main([__file__])