"""
Pact Contract Tests for ESG Intelligence Platform API
This module tests API contracts using Pact to ensure consumer and provider compatibility.
"""

import os
import sys
import pytest
import threading
import time
import requests
from multiprocessing import Process

# Add src to path to import the main app
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Only run pact tests if pact is installed
try:
    from pact import Consumer, Provider, Like, EachLike, Term
    PACT_AVAILABLE = True
except ImportError:
    PACT_AVAILABLE = False

if PACT_AVAILABLE:
    from main import app
    import uvicorn
    
    # Pact configuration
    pact = Consumer('ESGPlatformConsumer').has_pact_with(Provider('ESGPlatformAPI'))
    PACT_BASE_URL = 'http://localhost:1234'
    
    # Global variable to hold the server process
    uvicorn_process = None
    
    def run_uvicorn():
        """Run the FastAPI app with Uvicorn for Pact testing"""
        uvicorn.run(
            "main:app",
            host="localhost",
            port=1235,
            log_level="info"
        )
    
    @pytest.fixture(scope='session')
    def start_uvicorn_server(request):
        """Start Uvicorn server in a separate process for Pact tests"""
        global uvicorn_process
        uvicorn_process = Process(target=run_uvicorn)
        uvicorn_process.start()
        time.sleep(2)  # Give the server time to start
        
        def teardown():
            global uvicorn_process
            if uvicorn_process:
                uvicorn_process.terminate()
                uvicorn_process.join()
        
        request.addfinalizer(teardown)
        return uvicorn_process
    
    @pytest.mark.skipif(not PACT_AVAILABLE, reason="Pact is not installed")
    def test_get_root(pact):
        """Test the root endpoint contract"""
        expected = {
            'message': Like('Welcome to the ESG Intelligence Platform')
        }
        
        (pact
         .given('API is running')
         .upon_receiving('a request for the root endpoint')
         .with_request('get', '/')
         .will_respond_with(200, body=expected))
        
        with pact:
            result = requests.get(f'{PACT_BASE_URL}/')
            assert result.json()['message'] == 'Welcome to the ESG Intelligence Platform'
    
    @pytest.mark.skipif(not PACT_AVAILABLE, reason="Pact is not installed")
    def test_get_health(pact):
        """Test the health endpoint contract"""
        expected = {
            'status': Term('(healthy|degraded|unhealthy)', 'healthy'),
            'timestamp': Like('2023-01-01T00:00:00Z'),
            'components': Like({
                'llm': {
                    'status': 'healthy',
                    'response_time': 0.123
                },
                'blockchain': {
                    'status': 'healthy',
                    'response_time': 0.456
                }
            })
        }
        
        (pact
         .given('System components are healthy')
         .upon_receiving('a request for health status')
         .with_request('get', '/health')
         .will_respond_with(200, body=expected))
        
        with pact:
            result = requests.get(f'{PACT_BASE_URL}/health')
            assert 'status' in result.json()
    
    @pytest.mark.skipif(not PACT_AVAILABLE, reason="Pact is not installed")
    def test_post_ingest_json(pact):
        """Test the JSON ingestion endpoint contract"""
        expected_response = {
            'status': Like('success'),
            'message': Like('Data processed successfully'),
            'final_state': Like({
                'workflow_data': {},
                'config': {}
            })
        }
        
        (pact
         .given('System is ready to process data')
         .upon_receiving('a request to ingest JSON data')
         .with_request('post', '/ingest/json',
                       body={
                           'supplier_data': Like({
                               'name': 'Test Company',
                               'esg_score': 75
                           }),
                           'config': Like({
                               'verification_required': True
                           })
                       })
         .will_respond_with(200, body=expected_response))
        
        with pact:
            result = requests.post(
                f'{PACT_BASE_URL}/ingest/json',
                json={
                    'supplier_data': {
                        'name': 'Test Company',
                        'esg_score': 75
                    },
                    'config': {
                        'verification_required': True
                    }
                }
            )
            assert result.status_code == 200
    
    @pytest.mark.skipif(not PACT_AVAILABLE, reason="Pact is not installed")
    def test_get_verify_report(pact):
        """Test the report verification endpoint contract"""
        expected_response = {
            'report_id': Like('report_12345'),
            'report_data': Like({
                'some': 'data'
            }),
            'vc_jwt': Like('jwt_token_string'),
            'blockchain_hashes': EachLike('0x123456789abcdef'),
            'verification_status': Like('success'),
            'message': Like('Report report_12345 and associated cryptographic proofs retrieved successfully')
        }
        
        (pact
         .given('Report with ID report_12345 exists')
         .upon_receiving('a request to verify a report')
         .with_request('get', '/verify/report_12345')
         .will_respond_with(200, body=expected_response))
        
        with pact:
            result = requests.get(f'{PACT_BASE_URL}/verify/report_12345')
            assert result.status_code == 200

if __name__ == "__main__":
    pytest.main([__file__])