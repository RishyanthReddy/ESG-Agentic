"""
Integration tests for the File Upload Tool
"""

import pytest
import pandas as pd
from io import BytesIO
import time
import os
from src.tools.ingestion import FileUploadTool, FileUploadError
from src.tools.registry import ToolRegistry
from src.agents.ingestion import ingestion_agent
from src.state.models import AppState


def test_end_to_end_upload():
    """Test full file upload and processing workflow"""
    # Create a CSV file with realistic supplier data
    csv_content = """company_name,data_type,report_year,revenue,employees,carbon_emissions
Global Manufacturing Inc.,gri_report,2023,5000000,250,1250
Sustainable Products Ltd.,gri_report,2023,2500000,100,650"""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the file
    supplier_data = tool.run(file_content, "supplier_data.csv")
    
    # Create state with the processed data
    state = AppState(
        workflow_data={
            "supplier_data": supplier_data
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "data_ingested"
    assert "task_queue" in result
    assert len(result["task_queue"]) > 0
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0


def test_large_file_handling():
    """Test performance with large datasets"""
    # Create a large DataFrame
    row_count = 1000
    df = pd.DataFrame({
        'company_name': [f'Company {i}' for i in range(row_count)],
        'data_type': ['esg_data' for _ in range(row_count)],
        'metric_1': [i * 100 for i in range(row_count)],
        'metric_2': [i * 200 for i in range(row_count)],
        'metric_3': [i * 300 for i in range(row_count)]
    })
    
    # Save to CSV in memory
    csv_buffer = BytesIO()
    df.to_csv(csv_buffer, index=False)
    csv_content = csv_buffer.getvalue()
    
    # Create the tool
    tool = FileUploadTool()
    
    # Time the processing
    start_time = time.time()
    supplier_data = tool.run(csv_content, "large_file.csv")
    end_time = time.time()
    
    processing_time = end_time - start_time
    
    # Verify the result
    assert isinstance(supplier_data, dict)
    assert "company_name" in supplier_data
    assert supplier_data["data_type"] == "esg_data"
    
    # Should complete in reasonable time (less than 5 seconds)
    assert processing_time < 5.0


def test_data_quality():
    """Validate processed data quality"""
    # Create a CSV with various data types
    csv_content = """company_name,data_type,revenue,employees,carbon_emissions,bool_flag
Test Company,gri_report,1000000,50,1250.5,true
Another Company,sasb_report,2000000,100,650.2,false"""
    
    # Convert to bytes
    file_content = csv_content.encode('utf-8')
    
    # Create the tool
    tool = FileUploadTool()
    
    # Process the file
    supplier_data = tool.run(file_content, "quality_test.csv")
    
    # Verify data quality
    assert isinstance(supplier_data, dict)
    assert "company_name" in supplier_data
    assert isinstance(supplier_data["company_name"], str)
    assert "data_type" in supplier_data
    assert isinstance(supplier_data["data_type"], str)
    assert "revenue" in supplier_data
    assert isinstance(supplier_data["revenue"], (int, float))
    assert "employees" in supplier_data
    assert isinstance(supplier_data["employees"], int)
    assert "carbon_emissions" in supplier_data
    assert isinstance(supplier_data["carbon_emissions"], float)
    assert "bool_flag" in supplier_data
    # Note: CSV will read "true"/"false" as strings, which is expected


def test_error_recovery():
    """Test recovery from file processing errors"""
    # Create the tool
    tool = FileUploadTool()
    
    # Test with corrupted file content
    corrupted_content = b"\xff\xfe\xfd"  # Invalid UTF-8 bytes
    
    # Should raise FileUploadError
    with pytest.raises(FileUploadError):
        tool.run(corrupted_content, "corrupted.csv")
    
    # Test with valid content after corrupted content should work
    valid_content = "company_name,data_type\nValid Company,esg_data".encode('utf-8')
    result = tool.run(valid_content, "valid.csv")
    assert result["company_name"] == "Valid Company"
    assert result["data_type"] == "esg_data"


def test_security_testing():
    """Validate file upload security measures"""
    # Create the tool
    tool = FileUploadTool()
    
    # Test with path traversal attempt in filename
    csv_content = "company_name,data_type\nTest Company,esg_data".encode('utf-8')
    
    # Should handle filenames with special characters safely
    result = tool.run(csv_content, "../../../etc/passwd.csv")
    assert result["company_name"] == "Test Company"
    
    # Test with very long filename
    long_filename = "a" * 300 + ".csv"
    result = tool.run(csv_content, long_filename)
    assert result["company_name"] == "Test Company"
    
    # Test with special characters in filename
    special_filename = "test file (1).csv"
    result = tool.run(csv_content, special_filename)
    assert result["company_name"] == "Test Company"


def test_tool_registry_integration():
    """Test FileUploadTool integration with ToolRegistry"""
    # Create registry and clear it
    registry = ToolRegistry()
    registry.clear()
    
    # Create and register the tool
    tool = FileUploadTool()
    registry.register_tool(tool)
    
    # Retrieve the tool from registry
    retrieved_tool = registry.get_tool("file_upload")
    assert retrieved_tool is not None
    assert isinstance(retrieved_tool, FileUploadTool)
    assert retrieved_tool.name == "file_upload"
    
    # Test using the retrieved tool
    csv_content = "company_name,data_type\nRegistry Test Company,vlei_credential".encode('utf-8')
    result = retrieved_tool.run(csv_content, "registry_test.csv")
    
    assert result["company_name"] == "Registry Test Company"
    assert result["data_type"] == "vlei_credential"


def test_multiple_formats_in_workflow():
    """Test processing different file formats in a workflow"""
    # Create registry and clear it
    registry = ToolRegistry()
    registry.clear()
    
    # Register the tool
    tool = FileUploadTool()
    registry.register_tool(tool)
    
    # Test CSV
    csv_content = "company_name,data_type,revenue\nCSV Company,gri_report,1000000".encode('utf-8')
    csv_result = tool.run(csv_content, "test.csv")
    
    # Test Excel
    df = pd.DataFrame({
        'company_name': ['Excel Company'],
        'data_type': ['sasb_report'],
        'revenue': [2000000]
    })
    excel_buffer = BytesIO()
    df.to_excel(excel_buffer, index=False)
    excel_result = tool.run(excel_buffer.getvalue(), "test.xlsx")
    
    # Process both with ingestion agent
    csv_state = AppState(workflow_data={"supplier_data": csv_result})
    excel_state = AppState(workflow_data={"supplier_data": excel_result})
    
    csv_agent_result = ingestion_agent(csv_state)
    excel_agent_result = ingestion_agent(excel_state)
    
    # Both should be processed successfully
    assert csv_agent_result["workflow_status"] == "data_ingested"
    assert excel_agent_result["workflow_status"] == "data_ingested"
    
    # Check that appropriate tasks were generated
    assert "validate_gri_report" in csv_agent_result["task_queue"]
    assert "validate_sasb_report" in excel_agent_result["task_queue"]


def test_edge_cases():
    """Test edge cases in file processing"""
    # Create the tool
    tool = FileUploadTool()
    
    # Test with single column
    single_col_content = "company_name\nSingle Column Company".encode('utf-8')
    result = tool.run(single_col_content, "single_col.csv")
    assert result["company_name"] == "Single Column Company"
    assert result["data_type"] == "esg_data"  # Default when no clear type
    
    # Test with special characters in data
    special_content = "company_name,data_type\nCompany \"With Quotes\",gri_report".encode('utf-8')
    result = tool.run(special_content, "special_chars.csv")
    assert "With Quotes" in result["company_name"]
    
    # Test with unicode characters
    unicode_content = "company_name,data_type\nTést Çompany,esg_data".encode('utf-8')
    result = tool.run(unicode_content, "unicode.csv")
    assert "Tést Çompany" == result["company_name"]