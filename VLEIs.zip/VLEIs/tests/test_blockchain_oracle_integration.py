"""
Integration tests for the Blockchain Oracle Tool

This module contains tests for verifying the end-to-end functionality of the 
BlockchainOracleTool including complete oracle verification workflow, live 
blockchain testing, data integrity validation, performance testing, and 
security testing.
"""

import pytest
import os
import hashlib
import json
from unittest.mock import patch, Mock
from src.tools.audit import BlockchainOracleTool, OracleError
from src.state.models import AppState, vLEICredential
from src.tools.provenance import InfuraBlockchainTool


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_end_to_end_verification_workflow():
    """Test complete oracle verification workflow with real Infura connection"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Test Corp",
            "test_data": "integration test",
            "timestamp": "2023-01-01T00:00:00Z"
        }
    )
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # First, log data to blockchain using InfuraBlockchainTool
    blockchain_tool = InfuraBlockchainTool()
    
    # Serialize credential for consistent hashing
    credential_data = credential.model_dump(mode="json")
    credential_json = json.dumps(credential_data, sort_keys=True, separators=(',', ':'))
    credential_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
    
    # Log to blockchain
    blockchain_result = blockchain_tool.run(credential_hash, private_key)
    
    # Update state with blockchain log entry
    state.blockchain_log = [
        {
            "transaction_hash": blockchain_result["transaction_hash"],
            "data_hash": credential_hash,
            "data_id": str(credential.id),
            "account": blockchain_result["account"],
            "timestamp": blockchain_result["timestamp"],
            "status": "success"
        }
    ]
    
    # Now test the oracle verification
    oracle_tool = BlockchainOracleTool()
    result = oracle_tool.run(state)
    
    # Verify successful execution
    assert result["success"] is True
    assert result["verified_entries"] == 1
    assert result["total_entries"] == 1
    
    # Verify individual result
    entry_result = result["results"][0]
    assert entry_result["transaction_hash"] == blockchain_result["transaction_hash"]
    assert entry_result["verified"] is True
    assert entry_result["match"] is True
    assert entry_result["error"] is None


def test_live_blockchain_testing():
    """Test real testnet oracle verification"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111  # Sepolia chain ID
        mock_web3_class.return_value = mock_web3_instance
        
        # Mock transaction data
        test_transaction_hash = "0x7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b"
        test_data_hash = "a1b2c3d4e5f67890abcdef1234567890abcdef1234567890abcdef1234567890"
        
        # Mock web3.eth.get_transaction
        mock_transaction = Mock()
        mock_transaction.get.return_value = test_data_hash
        mock_web3_instance.eth.get_transaction.return_value = mock_transaction
        
        # Create test credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "data"}
        )
        
        # Create app state with matching data hash
        credential_data = credential.model_dump(mode="json")
        credential_json = json.dumps(credential_data, sort_keys=True, separators=(',', ':'))
        credential_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
        
        # Make sure the blockchain entry has the same hash as the credential
        state = AppState(
            current_credential=credential,
            blockchain_log=[
                {
                    "transaction_hash": test_transaction_hash,
                    "data_hash": credential_hash,  # Use the actual credential hash
                    "data_id": str(credential.id),
                    "account": "0xAccount123",
                    "block_number": 1000000,
                    "gas_used": 21000,
                    "timestamp": "2023-01-01T00:00:00Z"
                }
            ]
        )
        
        # Mock the transaction to return the same hash
        mock_transaction.get.return_value = credential_hash
        
        # Run oracle verification
        oracle_tool = BlockchainOracleTool()
        result = oracle_tool.run(state)
        
        # Verify the call was made
        mock_web3_instance.eth.get_transaction.assert_called_once_with(test_transaction_hash)
        
        # Verify result
        assert result["success"] is True
        assert result["verified_entries"] == 1
        assert result["total_entries"] == 1
        assert len(result["results"]) == 1
        
        entry_result = result["results"][0]
        assert entry_result["transaction_hash"] == test_transaction_hash
        assert entry_result["verified"] is True
        assert entry_result["on_chain_hash"] == credential_hash
        assert entry_result["off_chain_hash"] == credential_hash
        assert entry_result["match"] is True
        assert entry_result["error"] is None


def test_data_integrity_validation():
    """Test comprehensive data consistency testing"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        # Test with matching hashes
        test_transaction_hash = "0x1234567890abcdef"
        
        # Create test credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "data"}
        )
        
        # Create app state with matching data
        credential_data = credential.model_dump(mode="json")
        credential_json = json.dumps(credential_data, sort_keys=True, separators=(',', ':'))
        credential_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
        
        # Use the actual credential hash
        test_data_hash = credential_hash
        
        # Mock web3.eth.get_transaction
        mock_transaction = Mock()
        mock_transaction.get.return_value = test_data_hash
        mock_web3_instance.eth.get_transaction.return_value = mock_transaction
        
        state = AppState(
            current_credential=credential,
            blockchain_log=[
                {
                    "transaction_hash": test_transaction_hash,
                    "data_hash": test_data_hash,
                    "data_id": str(credential.id),
                    "account": "0xAccount123",
                    "block_number": 1000000,
                    "gas_used": 21000,
                    "timestamp": "2023-01-01T00:00:00Z"
                }
            ]
        )
        
        # Run oracle verification
        oracle_tool = BlockchainOracleTool()
        result = oracle_tool.run(state)
        
        # Verify integrity validation passed
        assert result["success"] is True
        assert result["verified_entries"] == 1
        entry_result = result["results"][0]
        assert entry_result["match"] is True
        
        # Test with mismatched hashes
        different_hash = "different_hash_value"
        state_mismatch = AppState(
            current_credential=credential,
            blockchain_log=[
                {
                    "transaction_hash": test_transaction_hash,
                    "data_hash": different_hash,  # Different hash
                    "data_id": str(credential.id),
                    "account": "0xAccount123",
                    "block_number": 1000000,
                    "gas_used": 21000,
                    "timestamp": "2023-01-01T00:00:00Z"
                }
            ]
        )
        
        # Mock the transaction to return the different hash
        mock_transaction.get.return_value = different_hash
        
        # Run oracle verification with mismatch
        result_mismatch = oracle_tool.run(state_mismatch)
        
        # Verify integrity validation failed
        assert result_mismatch["success"] is False
        assert result_mismatch["verified_entries"] == 0
        entry_result_mismatch = result_mismatch["results"][0]
        assert entry_result_mismatch["match"] is False


def test_performance_testing():
    """Test oracle verification performance and scalability"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        # Mock transaction data
        test_data_hash = "test_data_hash_value"
        mock_transaction = Mock()
        mock_transaction.get.return_value = test_data_hash
        mock_web3_instance.eth.get_transaction.return_value = mock_transaction
        
        # Create multiple test credentials
        credentials = []
        blockchain_logs = []
        
        for i in range(5):  # Test with 5 entries
            credential = vLEICredential(
                issuer=f"did:example:issuer{i}",
                subject=f"did:example:subject{i}",
                claims={"test": f"data{i}"}
            )
            credentials.append(credential)
            
            blockchain_logs.append({
                "transaction_hash": f"0x1234567890abcdef{i:02d}",
                "data_hash": test_data_hash,
                "data_id": str(credential.id),
                "account": "0xAccount123",
                "block_number": 1000000 + i,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            })
        
        # Create app state with multiple entries
        state = AppState(
            credentials=credentials,
            blockchain_log=blockchain_logs
        )
        
        # Run oracle verification
        oracle_tool = BlockchainOracleTool()
        result = oracle_tool.run(state)
        
        # Verify performance testing results
        assert result["total_entries"] == 5
        assert len(result["results"]) == 5
        # All should fail because we're not setting up proper data matching
        # but the important thing is that it processed all entries


def test_security_testing():
    """Test oracle security and tamper resistance"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        # Test with empty blockchain log
        state = AppState(blockchain_log=[])
        oracle_tool = BlockchainOracleTool()
        
        # Should raise OracleError
        with pytest.raises(OracleError, match="No blockchain log entries found"):
            oracle_tool.run(state)
        
        # Test with invalid transaction hash
        state_with_invalid_hash = AppState(
            blockchain_log=[{
                "transaction_hash": None,  # Invalid hash
                "data_hash": "test_hash"
            }]
        )
        
        result = oracle_tool.run(state_with_invalid_hash)
        assert result["success"] is False
        assert result["results"][0]["error"] == "No transaction hash in blockchain entry"
        
        # Test with transaction that cannot be retrieved
        mock_web3_instance.eth.get_transaction.side_effect = Exception("Transaction not found")
        
        state_with_valid_hash = AppState(
            blockchain_log=[{
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash"
            }]
        )
        
        result_error = oracle_tool.run(state_with_valid_hash)
        assert result_error["success"] is False
        assert "Transaction not found" in result_error["results"][0]["error"]


if __name__ == "__main__":
    pytest.main([__file__])