"""
Unit tests for the Public Verification Backend

This module contains tests for verifying the correct functionality of the 
public verification endpoint including endpoint testing, proof retrieval,
verification logic, and security testing.
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
from src.state.models import AppState, GRIReport
from src.state.storage import ReportStorage
from main import app, VerificationResponse


def test_endpoint_testing():
    """Test verification endpoint functionality"""
    # Create a test client
    client = TestClient(app)
    
    # Test with a non-existent report ID
    response = client.get("/verify/non-existent-id")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()


def test_proof_retrieval():
    """Test cryptographic proof retrieval"""
    # Create a test client
    client = TestClient(app)
    
    # Create a mock report and proofs
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return test data
        mock_storage.get_report.return_value = {
            "id": "test-report-id",
            "company_name": "Test Company",
            "report_year": 2023
        }
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "test_vc_jwt_token",
            "blockchain_hashes": ["0x123456789abcdef"],
            "report_type": "GRI"
        }
        
        # Test the endpoint
        response = client.get("/verify/test-report-id")
        assert response.status_code == 200
        
        # Parse the response
        data = response.json()
        assert data["report_id"] == "test-report-id"
        assert data["vc_jwt"] == "test_vc_jwt_token"
        assert data["blockchain_hashes"] == ["0x123456789abcdef"]
        assert data["verification_status"] == "success"


def test_verification_logic():
    """Test proof verification algorithms"""
    # Create a test client
    client = TestClient(app)
    
    # Create a mock report and proofs
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return test data
        mock_storage.get_report.return_value = {
            "id": "test-report-id-2",
            "company_name": "Test Company 2",
            "report_year": 2024
        }
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "test_vc_jwt_token_2",
            "blockchain_hashes": ["0xabcdef123456789", "0x987654321fedcba"],
            "report_type": "SASB"
        }
        
        # Test the endpoint
        response = client.get("/verify/test-report-id-2")
        assert response.status_code == 200
        
        # Parse the response
        data = response.json()
        assert data["report_id"] == "test-report-id-2"
        assert data["report_data"]["company_name"] == "Test Company 2"
        assert len(data["blockchain_hashes"]) == 2
        assert data["verification_status"] == "success"


def test_security_testing():
    """Test endpoint security and access controls"""
    # Create a test client
    client = TestClient(app)
    
    # Test rate limiting by making multiple requests
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return test data
        mock_storage.get_report.return_value = {
            "id": "test-report-id-3",
            "company_name": "Test Company 3",
            "report_year": 2025
        }
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "test_vc_jwt_token_3",
            "blockchain_hashes": ["0x111111111111111"],
            "report_type": "TCFD"
        }
        
        # Make 5 requests (should be allowed with 5/minute rate limit)
        responses = []
        for i in range(5):
            response = client.get("/verify/test-report-id-3")
            responses.append(response)
        
        # All should be successful
        for response in responses:
            assert response.status_code == 200
        
        # The 6th request should be rate limited (429)
        response = client.get("/verify/test-report-id-3")
        assert response.status_code == 429


def test_missing_report_data():
    """Test endpoint behavior when report data is missing"""
    # Create a test client
    client = TestClient(app)
    
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return None for report data
        mock_storage.get_report.return_value = None
        mock_storage.get_proofs.return_value = {
            "vc_jwt": "test_vc_jwt_token",
            "blockchain_hashes": ["0x123456789abcdef"],
            "report_type": "GRI"
        }
        
        # Test the endpoint
        response = client.get("/verify/missing-report-id")
        assert response.status_code == 404
        assert "not found" in response.json()["detail"].lower()


def test_missing_proofs():
    """Test endpoint behavior when cryptographic proofs are missing"""
    # Create a test client
    client = TestClient(app)
    
    with patch('main.report_storage') as mock_storage:
        # Mock the storage to return report data but no proofs
        mock_storage.get_report.return_value = {
            "id": "test-report-id-4",
            "company_name": "Test Company 4",
            "report_year": 2026
        }
        mock_storage.get_proofs.return_value = None
        
        # Test the endpoint
        response = client.get("/verify/test-report-id-4")
        assert response.status_code == 404
        assert "proofs" in response.json()["detail"].lower()


if __name__ == "__main__":
    pytest.main([__file__])