"""
Modal app for running report provenance database tests on GPU.
"""

import modal
import time
import pytest
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.insert(0, '/root/VLEIs')

from src.utils.db import store_report_proofs, get_report_proofs

# Create the Modal app
app = modal.App("vleis-report-provenance-tests")


# Define the image with all required dependencies
image = modal.Image.debian_slim(python_version="3.11") \
    .pip_install_from_requirements("/root/VLEIs/requirements.txt") \
    .copy_local_dir("/root/VLEIs", "/root/VLEIs")


@app.function(image=image, gpu="any")
def run_database_tests():
    """
    Run the database tests on Modal GPU platform.
    
    Returns:
        Dictionary with test results
    """
    print("Running report provenance database tests on Modal GPU platform...")
    
    try:
        # Test 1: Basic store and retrieve functionality
        print("Test 1: Basic store and retrieve functionality")
        report_id = "modal_test_report_001"
        proofs = {
            "vc_jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test_token",
            "blockchain_hash": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
            "signature": "3045022100_signature_data_0220_signature_data"
        }
        
        # Store the proofs
        doc_id = store_report_proofs(report_id, proofs)
        assert doc_id is not None, "Failed to store report proofs"
        
        # Retrieve the proofs
        retrieved_proofs = get_report_proofs(report_id)
        assert retrieved_proofs is not None, "Failed to retrieve report proofs"
        assert retrieved_proofs == proofs, "Retrieved proofs do not match stored proofs"
        
        print("✓ Test 1 passed")
        
        # Test 2: Update existing report
        print("Test 2: Update existing report")
        updated_proofs = {
            "vc_jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.updated_token",
            "blockchain_hash": "0xfedcba0987654321fedcba0987654321fedcba0987654321fedcba0987654321",
            "signature": "3045022100_updated_signature_0220_updated_signature",
            "additional_data": "extra_proof_info"
        }
        
        # Update the proofs
        updated_doc_id = store_report_proofs(report_id, updated_proofs)
        assert updated_doc_id == doc_id, "Document ID should remain the same when updating"
        
        # Retrieve the updated proofs
        retrieved_updated_proofs = get_report_proofs(report_id)
        assert retrieved_updated_proofs is not None, "Failed to retrieve updated report proofs"
        assert retrieved_updated_proofs == updated_proofs, "Retrieved updated proofs do not match stored updated proofs"
        assert "additional_data" in retrieved_updated_proofs, "Additional data not found in updated proofs"
        
        print("✓ Test 2 passed")
        
        # Test 3: Handle non-existent report
        print("Test 3: Handle non-existent report")
        nonexistent_proofs = get_report_proofs("nonexistent_report_id")
        assert nonexistent_proofs is None, "Non-existent report should return None"
        
        print("✓ Test 3 passed")
        
        # Test 4: Multiple reports
        print("Test 4: Multiple reports")
        reports_data = [
            {
                "id": "modal_test_report_002",
                "proofs": {
                    "vc_jwt": "token_2",
                    "hash": "hash_2"
                }
            },
            {
                "id": "modal_test_report_003",
                "proofs": {
                    "vc_jwt": "token_3",
                    "hash": "hash_3"
                }
            }
        ]
        
        # Store multiple reports
        for report_data in reports_data:
            doc_id = store_report_proofs(report_data["id"], report_data["proofs"])
            assert doc_id is not None, f"Failed to store report {report_data['id']}"
        
        # Retrieve multiple reports
        for report_data in reports_data:
            retrieved_proofs = get_report_proofs(report_data["id"])
            assert retrieved_proofs is not None, f"Failed to retrieve report {report_data['id']}"
            assert retrieved_proofs == report_data["proofs"], f"Retrieved proofs do not match for {report_data['id']}"
        
        print("✓ Test 4 passed")
        
        # Test 5: Performance test
        print("Test 5: Performance test")
        start_time = time.time()
        
        # Store multiple reports for performance testing
        num_reports = 50
        for i in range(num_reports):
            report_id = f"perf_test_report_{i:03d}"
            proofs = {
                "vc_jwt": f"perf_token_{i}",
                "blockchain_hash": f"0x{i:064x}",
                "timestamp": f"2023-01-{(i % 28) + 1:02d}T10:30:00Z"
            }
            store_report_proofs(report_id, proofs)
        
        store_time = time.time() - start_time
        print(f"Stored {num_reports} reports in {store_time:.4f} seconds")
        
        # Retrieve all reports
        start_time = time.time()
        for i in range(num_reports):
            report_id = f"perf_test_report_{i:03d}"
            retrieved_proofs = get_report_proofs(report_id)
            assert retrieved_proofs is not None, f"Failed to retrieve perf report {report_id}"
        
        retrieve_time = time.time() - start_time
        print(f"Retrieved {num_reports} reports in {retrieve_time:.4f} seconds")
        
        print("✓ Test 5 passed")
        
        # All tests passed
        result = {
            "status": "success",
            "tests_executed": 5,
            "tests_passed": 5,
            "tests_failed": 0,
            "performance": {
                "store_50_reports_time": store_time,
                "retrieve_50_reports_time": retrieve_time
            },
            "timestamp": time.time()
        }
        
        print("All tests passed successfully!")
        return result
        
    except Exception as e:
        print(f"Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            "status": "failure",
            "error": str(e),
            "tests_executed": 5,
            "tests_passed": 0,
            "tests_failed": 5,
            "timestamp": time.time()
        }


@app.local_entrypoint()
def main():
    """Local entrypoint to run the tests."""
    result = run_database_tests.remote()
    print(f"Test result: {result}")
    
    if result["status"] == "success":
        print("All database tests passed!")
        return 0
    else:
        print(f"Database tests failed: {result['error']}")
        return 1