"""
Modal app for running master orchestrator tests on GPU.
"""

import modal
import time
import pytest
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.insert(0, '/root/VLEIs')

from src.state.models import AppState
from src.agents.core import master_orchestrator, rule_based_routing

# Create the Modal app
app = modal.App("vleis-orchestrator-tests")


# Define the image with all required dependencies
image = modal.Image.debian_slim(python_version="3.11") \
    .pip_install_from_requirements("/root/VLEIs/requirements.txt") \
    .copy_local_dir("/root/VLEIs", "/root/VLEIs")


@app.function(image=image, gpu="any")
def run_orchestrator_tests():
    """
    Run the orchestrator tests on Modal GPU platform.
    
    Returns:
        Dictionary with test results
    """
    print("Running master orchestrator tests on Modal GPU platform...")
    
    try:
        # Test 1: Basic routing functionality
        print("Test 1: Basic routing functionality")
        state = AppState(
            task_queue=[
                "verify supplier credentials",
                "detect anomalies in esg data",
                "generate quarterly report",
                "run self-audit on blockchain logs",
                "finalize esg compliance report"
            ]
        )
        
        # Test rule-based routing directly
        agents = []
        for task in state.task_queue:
            agent = rule_based_routing(task)
            agents.append(agent)
        
        expected_agents = [
            "credential_agent",
            "anomaly_detection_agent",
            "reporting_agent",
            "audit_agent",
            "finalization_agent"
        ]
        
        assert agents == expected_agents, f"Expected {expected_agents}, got {agents}"
        print("✓ Test 1 passed")
        
        # Test 2: Master orchestrator with mocked LLM
        print("Test 2: Master orchestrator with mocked LLM")
        state2 = AppState(
            task_queue=[
                "detect anomalies in supplier data",
                "run self-audit on blockchain logs"
            ]
        )
        
        # Mock the LLM orchestrator to return specific agents
        def mock_llm_orchestrator(task, state, request_id):
            task_lower = task.lower()
            if "detect" in task_lower:
                return "anomaly_detection_agent"
            elif "audit" in task_lower:
                return "audit_agent"
            else:
                return "credential_agent"
        
        # We can't easily patch in Modal, so we'll test the structure indirectly
        # by checking that the task queue gets processed
        initial_queue_length = len(state2.task_queue)
        assert initial_queue_length == 2
        
        # Process one task
        agent1 = master_orchestrator(state2)
        assert len(state2.task_queue) == 1  # Should have one less task
        
        # Process second task
        agent2 = master_orchestrator(state2)
        assert len(state2.task_queue) == 0  # Should have no tasks left
        
        print("✓ Test 2 passed")
        
        # Test 3: Empty task queue handling
        print("Test 3: Empty task queue handling")
        empty_state = AppState(task_queue=[])
        result = master_orchestrator(empty_state)
        assert result == "__end__", f"Expected '__end__', got '{result}'"
        print("✓ Test 3 passed")
        
        # Test 4: Performance test with multiple tasks
        print("Test 4: Performance test with multiple tasks")
        many_tasks = [f"task_{i}_verify_data" for i in range(50)]
        perf_state = AppState(task_queue=many_tasks)
        
        start_time = time.time()
        
        # Process all tasks
        processed_count = 0
        while perf_state.task_queue and processed_count < 100:  # Safety limit
            result = master_orchestrator(perf_state)
            if result == "__end__":
                break
            processed_count += 1
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        assert processed_count == 50, f"Expected to process 50 tasks, processed {processed_count}"
        assert processing_time < 2.0, f"Processing took too long: {processing_time} seconds"
        print(f"Processed 50 tasks in {processing_time:.4f} seconds")
        print("✓ Test 4 passed")
        
        # Test 5: Complex task routing
        print("Test 5: Complex task routing")
        complex_tasks = [
            "detect unusual patterns in carbon emissions data",
            "audit blockchain transaction logs for integrity",
            "finalize and sign the annual ESG compliance report",
            "verify supplier sustainability credentials",
            "generate GRI and CSRD regulatory reports"
        ]
        
        complex_agents = []
        for task in complex_tasks:
            agent = rule_based_routing(task)
            complex_agents.append(agent)
        
        # Verify that all new agents are properly routed
        assert "anomaly_detection_agent" in complex_agents
        assert "audit_agent" in complex_agents
        assert "finalization_agent" in complex_agents
        assert "credential_agent" in complex_agents
        assert "reporting_agent" in complex_agents
        
        print("✓ Test 5 passed")
        
        # All tests passed
        result = {
            "status": "success",
            "tests_executed": 5,
            "tests_passed": 5,
            "tests_failed": 0,
            "performance": {
                "process_50_tasks_time": processing_time
            },
            "timestamp": time.time()
        }
        
        print("All orchestrator tests passed successfully!")
        return result
        
    except Exception as e:
        print(f"Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            "status": "failure",
            "error": str(e),
            "tests_executed": 5,
            "tests_passed": 0,
            "tests_failed": 5,
            "timestamp": time.time()
        }


@app.local_entrypoint()
def main():
    """Local entrypoint to run the tests."""
    result = run_orchestrator_tests.remote()
    print(f"Test result: {result}")
    
    if result["status"] == "success":
        print("All orchestrator tests passed!")
        return 0
    else:
        print(f"Orchestrator tests failed: {result['error']}")
        return 1