"""
Unit tests for the Anomaly Injection Utility

This module contains tests for verifying the correct functionality of the
anomaly injection utility for testing system detection capabilities.
"""

import pytest
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from tests.test_utils import inject_anomaly, inject_multiple_anomalies


class TestAnomalyInjection:
    """Test cases for the anomaly injection utility."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Create sample supplier data for testing
        self.sample_data = {
            "supplier_id": "supplier_123",
            "company_name": "Test Company",
            "reporting_period": "2023-Q1",
            "data_points": [
                {
                    "timestamp": "2023-01-01T00:00:00Z",
                    "value": 100.0,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_123",
                    "confidence_score": 0.95
                },
                {
                    "timestamp": "2023-01-02T00:00:00Z",
                    "value": 102.5,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_123",
                    "confidence_score": 0.94
                },
                {
                    "timestamp": "2023-01-03T00:00:00Z",
                    "value": 98.7,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_123",
                    "confidence_score": 0.96
                },
                {
                    "timestamp": "2023-01-04T00:00:00Z",
                    "value": 101.2,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_123",
                    "confidence_score": 0.93
                }
            ],
            "metadata": {
                "source": "api",
                "version": "1.0"
            }
        }
    
    def test_spike_anomaly_injection(self):
        """Test spike anomaly injection."""
        # Inject a spike anomaly
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_type="spike",
            anomaly_factor=3.0,
            anomaly_position=1
        )
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Check that the correct point was modified
        original_value = self.sample_data["data_points"][1]["value"]  # 102.5
        modified_value = modified_data["data_points"][1]["value"]
        expected_value = original_value * 3.0  # 307.5
        
        assert modified_value == expected_value
        # Check that other points are unchanged
        assert modified_data["data_points"][0]["value"] == self.sample_data["data_points"][0]["value"]
        assert modified_data["data_points"][2]["value"] == self.sample_data["data_points"][2]["value"]
    
    def test_offset_anomaly_injection(self):
        """Test offset anomaly injection."""
        # Inject an offset anomaly
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_type="offset",
            anomaly_factor=50.0,
            anomaly_position=2
        )
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Check that the correct point was modified
        original_value = self.sample_data["data_points"][2]["value"]  # 98.7
        modified_value = modified_data["data_points"][2]["value"]
        expected_value = original_value + 50.0  # 148.7
        
        assert modified_value == expected_value
        # Check that other points are unchanged
        assert modified_data["data_points"][0]["value"] == self.sample_data["data_points"][0]["value"]
        assert modified_data["data_points"][1]["value"] == self.sample_data["data_points"][1]["value"]
    
    def test_noise_anomaly_injection(self):
        """Test noise anomaly injection."""
        # Inject a noise anomaly with a fixed seed for reproducibility
        import random
        random.seed(42)
        
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_type="noise",
            anomaly_factor=10.0,
            anomaly_position=0
        )
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Check that the correct point was modified
        original_value = self.sample_data["data_points"][0]["value"]  # 100.0
        modified_value = modified_data["data_points"][0]["value"]
        
        # With seed 42, random.uniform(-10, 10) produces approximately 2.79
        # So the expected value should be 100.0 + 2.79 = 102.79
        expected_value = 102.78853596915768
        
        assert abs(modified_value - expected_value) < 0.01
        # Check that other points are unchanged
        assert modified_data["data_points"][1]["value"] == self.sample_data["data_points"][1]["value"]
        assert modified_data["data_points"][2]["value"] == self.sample_data["data_points"][2]["value"]
    
    def test_missing_anomaly_injection(self):
        """Test missing data anomaly injection."""
        # Inject a missing data anomaly
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_type="missing",
            anomaly_position=3
        )
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Check that the correct field was removed
        assert "value" not in modified_data["data_points"][3]
        # Check that other fields are still present
        assert "timestamp" in modified_data["data_points"][3]
        assert "metric_type" in modified_data["data_points"][3]
        # Check that other points are unchanged
        assert modified_data["data_points"][0]["value"] == self.sample_data["data_points"][0]["value"]
        assert modified_data["data_points"][1]["value"] == self.sample_data["data_points"][1]["value"]
        assert modified_data["data_points"][2]["value"] == self.sample_data["data_points"][2]["value"]
    
    def test_default_anomaly_injection(self):
        """Test default anomaly injection (should use spike with random position)."""
        # Inject an anomaly with default parameters
        modified_data = inject_anomaly(self.sample_data)
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Find which point was modified (one should have a different value)
        modified_point_index = None
        for i, (original_point, modified_point) in enumerate(
            zip(self.sample_data["data_points"], modified_data["data_points"])
        ):
            if original_point["value"] != modified_point["value"]:
                modified_point_index = i
                break
        
        assert modified_point_index is not None
        # Check that the modification is a spike (multiplied by default factor 2.0)
        original_value = self.sample_data["data_points"][modified_point_index]["value"]
        modified_value = modified_data["data_points"][modified_point_index]["value"]
        expected_value = original_value * 2.0
        
        assert modified_value == expected_value
    
    def test_invalid_anomaly_type(self):
        """Test injection with invalid anomaly type."""
        # Inject an anomaly with an invalid type
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_type="invalid_type"
        )
        
        # Should return the original data unchanged
        assert modified_data == self.sample_data
    
    def test_invalid_position(self):
        """Test injection with invalid position."""
        # Inject an anomaly with a position out of range
        modified_data = inject_anomaly(
            self.sample_data,
            anomaly_position=10  # Out of range
        )
        
        # Should still modify data (using last position)
        assert modified_data != self.sample_data
    
    def test_empty_data_points(self):
        """Test injection with empty data points."""
        # Create data with empty data points
        empty_data = self.sample_data.copy()
        empty_data["data_points"] = []
        
        # Inject an anomaly
        modified_data = inject_anomaly(empty_data)
        
        # Should return the original data unchanged
        assert modified_data == empty_data
    
    def test_multiple_anomalies_injection(self):
        """Test injection of multiple anomalies."""
        # Define multiple anomaly configurations
        anomaly_configs = [
            {"type": "spike", "factor": 2.0, "position": 0},
            {"type": "offset", "factor": 50.0, "position": 1},
            {"type": "noise", "factor": 5.0, "position": 2}
        ]
        
        # Inject multiple anomalies
        modified_data = inject_multiple_anomalies(self.sample_data, anomaly_configs)
        
        # Check that the data was modified
        assert modified_data != self.sample_data
        
        # Check specific modifications
        # Point 0: spike (100.0 * 2.0 = 200.0)
        assert modified_data["data_points"][0]["value"] == 200.0
        
        # Point 1: offset (102.5 + 50.0 = 152.5)
        assert modified_data["data_points"][1]["value"] == 152.5
        
        # Point 2: noise (98.7 + random value)
        # Since we can't predict the exact noise value, just check it's different
        assert modified_data["data_points"][2]["value"] != self.sample_data["data_points"][2]["value"]
        
        # Point 3: should be unchanged
        assert modified_data["data_points"][3]["value"] == self.sample_data["data_points"][3]["value"]


if __name__ == "__main__":
    pytest.main([__file__])