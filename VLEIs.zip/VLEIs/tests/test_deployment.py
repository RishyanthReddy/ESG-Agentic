"""
Deployment Tests for ESG Intelligence Platform

This module tests the deployment functionality including:
- Deployment configuration
- Health checks
- API accessibility
- Fallback systems
"""

import os
import sys
import pytest
import subprocess
import time
import requests
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from deploy.deployment_config import DeploymentConfig
from deploy.deployment_manager import DeploymentManager


class TestDeploymentConfiguration:
    """Test deployment configuration settings"""
    
    def test_deployment_config_constants(self):
        """Test that deployment configuration constants are properly defined"""
        config = DeploymentConfig()
        
        # Test that URLs are defined
        assert hasattr(config, 'CLOUD_BACKEND_URL')
        assert hasattr(config, 'LOCAL_BACKEND_URL')
        assert hasattr(config, 'CLOUD_FRONTEND_URL')
        assert hasattr(config, 'LOCAL_FRONTEND_URL')
        
        # Test that endpoints are defined
        assert isinstance(config.API_ENDPOINTS, dict)
        assert isinstance(config.CLI_ENDPOINTS, dict)
        assert len(config.API_ENDPOINTS) > 0
        assert len(config.CLI_ENDPOINTS) > 0
        
        # Test that health check settings are defined
        assert isinstance(config.HEALTH_CHECK_TIMEOUT, int)
        assert isinstance(config.HEALTH_CHECK_RETRIES, int)
    
    def test_get_backend_url(self):
        """Test getting backend URLs for different environments"""
        config = DeploymentConfig()
        
        # Test local environment
        local_url = config.get_backend_url("local")
        assert local_url == config.LOCAL_BACKEND_URL
        
        # Test cloud environment
        cloud_url = config.get_backend_url("cloud")
        assert cloud_url == config.CLOUD_BACKEND_URL
        
        # Test default environment
        default_url = config.get_backend_url()
        assert default_url == config.LOCAL_BACKEND_URL
    
    def test_get_frontend_url(self):
        """Test getting frontend URLs for different environments"""
        config = DeploymentConfig()
        
        # Test local environment
        local_url = config.get_frontend_url("local")
        assert local_url == config.LOCAL_FRONTEND_URL
        
        # Test cloud environment
        cloud_url = config.get_frontend_url("cloud")
        assert cloud_url == config.CLOUD_FRONTEND_URL
        
        # Test default environment
        default_url = config.get_frontend_url()
        assert default_url == config.LOCAL_FRONTEND_URL
    
    def test_get_api_endpoint(self):
        """Test getting API endpoints"""
        config = DeploymentConfig()
        
        # Test existing endpoint
        health_endpoint = config.get_api_endpoint("health")
        assert health_endpoint == "/health"
        
        # Test non-existing endpoint
        non_existing = config.get_api_endpoint("non-existing")
        assert non_existing == ""
    
    def test_get_cli_endpoint(self):
        """Test getting CLI endpoints"""
        config = DeploymentConfig()
        
        # Test existing endpoint
        health_endpoint = config.get_cli_endpoint("health_check")
        assert health_endpoint == "/health"
        
        # Test non-existing endpoint
        non_existing = config.get_cli_endpoint("non-existing")
        assert non_existing == ""


class TestDeploymentManager:
    """Test deployment manager functionality"""
    
    def test_deployment_manager_initialization(self):
        """Test that deployment manager initializes correctly"""
        dm = DeploymentManager()
        
        # Test that config is loaded
        assert dm.config is not None
        assert hasattr(dm.config, 'CLOUD_BACKEND_URL')
        
        # Test that docker client is initialized (might be None if Docker not available)
        assert hasattr(dm, 'docker_client')
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_local_deployment_success(self, mock_subprocess):
        """Test successful local deployment"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Success"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.deploy_local()
        
        assert success is True
        mock_subprocess.assert_called_once_with(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_local_deployment_failure(self, mock_subprocess):
        """Test failed local deployment"""
        # Mock failed subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "Error"
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.deploy_local()
        
        assert success is False
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_cloud_deployment_success(self, mock_subprocess):
        """Test successful cloud deployment"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Success"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.deploy_cloud()
        
        assert success is True
        mock_subprocess.assert_called_with(
            ["modal", "deploy", "modal_entrypoint.py"],
            capture_output=True,
            text=True,
            timeout=300
        )
    
    @patch('deploy.deployment_manager.requests.get')
    def test_health_check_healthy(self, mock_requests):
        """Test health check when system is healthy"""
        # Mock healthy response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok"}
        mock_requests.return_value = mock_response
        
        dm = DeploymentManager()
        health = dm.check_health("local")
        
        assert health["status"] == "healthy"
        assert health["status_code"] == 200
    
    @patch('deploy.deployment_manager.requests.get')
    def test_health_check_unhealthy(self, mock_requests):
        """Test health check when system is unhealthy"""
        # Mock connection error
        mock_requests.side_effect = requests.exceptions.ConnectionError("Connection failed")
        
        dm = DeploymentManager()
        health = dm.check_health("local")
        
        assert health["status"] == "unhealthy"
        assert "error" in health
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_fallback_to_local(self, mock_subprocess):
        """Test fallback to local deployment"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Success"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.fallback_to_local()
        
        assert success is True
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_stop_local_deployment(self, mock_subprocess):
        """Test stopping local deployment"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Success"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.stop_local_deployment()
        
        assert success is True


class TestAPIAccessibility:
    """Test API accessibility for both frontend and CLI"""
    
    def test_local_api_endpoints_defined(self):
        """Test that local API endpoints are properly defined"""
        config = DeploymentConfig()
        
        # Test that we have local URLs
        assert len(config.LOCAL_BACKEND_URL) > 0
        assert len(config.LOCAL_FRONTEND_URL) > 0
        
        # Test that API endpoints are defined
        assert len(config.API_ENDPOINTS) > 0
        assert "/health" in config.API_ENDPOINTS.values()
    
    def test_cli_endpoints_defined(self):
        """Test that CLI-accessible endpoints are properly defined"""
        config = DeploymentConfig()
        
        # Test that CLI endpoints are defined
        assert len(config.CLI_ENDPOINTS) > 0
        assert "/health" in config.CLI_ENDPOINTS.values()


class TestFallbackSystems:
    """Test local deployment fallback systems"""
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_fallback_deployment_process(self, mock_subprocess):
        """Test the complete fallback deployment process"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Success"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        
        # Test fallback process
        fallback_success = dm.fallback_to_local()
        assert fallback_success is True
        
        # Verify the correct command was called
        mock_subprocess.assert_called_with(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )


if __name__ == "__main__":
    pytest.main([__file__])