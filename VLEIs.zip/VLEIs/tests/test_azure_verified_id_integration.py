"""
Integration tests for the Azure Verified ID Tool
"""

import pytest
import asyncio
import os
from src.tools.verification import AzureVerifiedIDTool
from src.tools.registry import ToolRegistry
from config import settings
from datetime import datetime


@pytest.fixture(scope="module")
def azure_tool():
    """Create an AzureVerifiedIDTool instance for testing"""
    return AzureVerifiedIDTool()


@pytest.fixture(scope="module")
def tool_registry():
    """Get the tool registry instance"""
    return ToolRegistry()


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_azure_tool_instantiation(azure_tool):
    """Test that Azure Verified ID Tool can be instantiated with environment configuration"""
    assert azure_tool is not None
    assert azure_tool.name == "azure_verified_id"
    assert azure_tool.tenant_id == settings.AZURE_TENANT_ID
    assert azure_tool.client_id == settings.AZURE_CLIENT_ID


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_get_access_token_live(azure_tool):
    """Test live access token retrieval from Azure"""
    token = azure_tool._get_access_token()
    assert token is not None
    assert isinstance(token, str)
    assert len(token) > 0


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_tool_registration(tool_registry, azure_tool):
    """Test that Azure Verified ID Tool can be registered in the tool registry"""
    # Register the tool
    tool_registry.register_tool(azure_tool)
    
    # Retrieve the tool
    retrieved_tool = tool_registry.get_tool("azure_verified_id")
    
    assert retrieved_tool is not None
    assert retrieved_tool.name == "azure_verified_id"
    assert retrieved_tool.description == "Issues and verifies credentials using Microsoft's Azure Verified ID API"


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_credential_issuance_live(azure_tool):
    """Test live credential issuance using Azure Verified ID"""
    # Sample credential data
    credential_data = {
        "companyName": "Integration Test Company",
        "esgRating": "AAA",
        "reportYear": 2023,
        "verifiedDate": datetime.utcnow().isoformat(),
        "jurisdiction": "US-DE"
    }
    
    # Issue credential
    result = azure_tool.issue_credential(credential_data)
    
    # Validate result
    assert "issued" in result
    # Note: Actual issuance may fail in sandbox without proper configuration
    # but we're testing the API interaction, not the business logic


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_credential_verification_live(azure_tool):
    """Test live credential verification request using Azure Verified ID"""
    # Sample presentation request
    presentation_request = {
        "purpose": "Integration testing",
        "issuer": getattr(settings, 'AZURE_VERIFIED_ID_DID', 'did:web:test.example.com')
    }
    
    # Request verification
    result = azure_tool.verify_credential(presentation_request)
    
    # Validate result structure
    assert "verification_requested" in result
    # Note: Actual verification requires a wallet interaction
    # but we're testing the API request creation


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_authentication_flow(azure_tool):
    """Test end-to-end OAuth 2.0 authentication flow"""
    # Test token retrieval
    token = azure_tool._get_access_token()
    assert token is not None
    
    # Test that token can be used for API calls
    # This is implicitly tested by other methods that use the token


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_credential_lifecycle(azure_tool):
    """Test credential lifecycle: issue -> check status"""
    # Issue a credential
    credential_data = {
        "testId": "lifecycle-test",
        "timestamp": datetime.utcnow().isoformat()
    }
    
    issue_result = azure_tool.issue_credential(credential_data)
    
    # If issuance was requested, check the status
    if issue_result.get("issued") and issue_result.get("request_id"):
        request_id = issue_result["request_id"]
        status_result = azure_tool.check_request_status(request_id)
        assert "status" in status_result


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_performance_response_times(azure_tool):
    """Test API response times"""
    import time
    
    # Measure token retrieval time
    start_time = time.time()
    token = azure_tool._get_access_token()
    token_time = time.time() - start_time
    
    assert token is not None
    assert token_time < 5.0  # Should complete within 5 seconds


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_error_recovery_network_failure(azure_tool):
    """Test error recovery for network failures"""
    # This is difficult to test without mocking network failures
    # but we can test that the tool handles errors gracefully
    
    # Test with an invalid endpoint to trigger an error
    try:
        # This will fail because we're not mocking the credential
        result = azure_tool._make_azure_api_call("GET", "invalid/endpoint")
        # If we get here, something unexpected happened
        assert "error" in result or result.get("status") == "error"
    except Exception as e:
        # Expected to raise an exception for invalid endpoint
        assert "error" in str(e).lower() or "invalid" in str(e).lower()


@pytest.mark.skipif(
    not all([
        getattr(settings, 'AZURE_TENANT_ID', None),
        getattr(settings, 'AZURE_CLIENT_ID', None),
        getattr(settings, 'AZURE_CLIENT_SECRET', None)
    ]),
    reason="Azure credentials not configured"
)
def test_jwt_processing(azure_tool):
    """Test JWT processing functionality"""
    # Test that the tool can work with JWT tokens
    token = azure_tool._get_access_token()
    
    assert token is not None
    # A JWT token has 3 parts separated by dots
    assert len(token.split('.')) == 3


if __name__ == "__main__":
    pytest.main([__file__])