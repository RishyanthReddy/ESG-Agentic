"""
Integration tests for the Visualization Agent
"""

import pytest
import time
from datetime import datetime
from src.agents.visualization import visualization_agent
from src.state.models import AppState


def test_end_to_end_visualization():
    """Test full visualization data generation pipeline"""
    # Create a state with sample agent traces and blockchain logs
    state = AppState(
        agent_trace=[
            {
                "agent": "credential_agent",
                "action": "credential_processed",
                "credential_id": "cred_001",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "credential_id": "cred_001",
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                "data_hash": "a1b2c3d4e5f67890",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234567,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    )
    
    # Run the visualization agent
    start_time = time.time()
    result = visualization_agent(state)
    end_time = time.time()
    
    # Check that visualization was generated successfully
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    assert result["visualization_assets"] is not None
    
    # Check provenance graph data
    assert "provenance_graph" in result["visualization_assets"]
    provenance_graph = result["visualization_assets"]["provenance_graph"]
    assert "node_count" in provenance_graph
    assert "edge_count" in provenance_graph
    assert provenance_graph["node_count"] > 0
    assert provenance_graph["edge_count"] >= 0
    
    # Check serialized graph data
    assert "serialized_graph" in result["visualization_assets"]
    serialized_graph = result["visualization_assets"]["serialized_graph"]
    assert "json_data" in serialized_graph
    assert "format" in serialized_graph
    assert "size" in serialized_graph
    assert len(serialized_graph["json_data"]) > 0
    assert serialized_graph["format"] == "threejs"
    assert serialized_graph["size"] > 0
    
    # Record execution time
    execution_time = end_time - start_time
    print(f"Visualization generation time: {execution_time:.4f} seconds")


def test_visualization_performance():
    """Test visualization generation performance"""
    # Create a state with more complex data
    agent_traces = []
    blockchain_logs = []
    
    # Generate sample data
    for i in range(10):
        agent_traces.append({
            "agent": f"agent_{i}",
            "action": f"action_{i}",
            "data_id": f"data_{i}",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        if i % 3 == 0:  # Add blockchain logs periodically
            blockchain_logs.append({
                "transaction_hash": f"0x{i:064x}",
                "data_hash": f"hash_{i}",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1000000 + i,
                "gas_used": 21000 + i,
                "timestamp": datetime.utcnow().isoformat()
            })
    
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs
    )
    
    # Measure performance
    start_time = time.time()
    result = visualization_agent(state)
    end_time = time.time()
    
    execution_time = end_time - start_time
    
    # Check that it was successful
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    assert result["visualization_assets"] is not None
    
    # Check performance (should be reasonable)
    assert execution_time < 5.0  # Should complete in under 5 seconds
    
    # Check that we have meaningful data
    provenance_graph = result["visualization_assets"]["provenance_graph"]
    assert provenance_graph["node_count"] > 0
    assert provenance_graph["edge_count"] >= 0
    
    serialized_graph = result["visualization_assets"]["serialized_graph"]
    assert serialized_graph["size"] > 0
    
    print(f"Performance test: {execution_time:.4f} seconds for {provenance_graph['node_count']} nodes")


def test_visualization_data_quality():
    """Validate visualization asset quality and completeness"""
    # Create state with rich data
    state = AppState(
        agent_trace=[
            {
                "agent": "credential_agent",
                "action": "credential_processed",
                "credential_id": "cred_001",
                "input_data": {"field1": "value1"},
                "output_data": {"result": "success"},
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "credential_id": "cred_001",
                "verification_result": "passed",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "reporting_agent",
                "action": "report_generated",
                "report_type": "GRI",
                "report_id": "report_001",
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                "data_hash": "a1b2c3d4e5f67890",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234567,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "transaction_hash": "0x1a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f7890",
                "data_hash": "f6e5d4c3b2a10987",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234572,
                "gas_used": 25000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    )
    
    # Run the visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was generated successfully
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    assert result["visualization_assets"] is not None
    
    # Check the structure of visualization assets
    visualization_assets = result["visualization_assets"]
    
    # Check provenance graph section
    assert "provenance_graph" in visualization_assets
    provenance_graph = visualization_assets["provenance_graph"]
    assert isinstance(provenance_graph, dict)
    assert "node_count" in provenance_graph
    assert "edge_count" in provenance_graph
    assert "validation" in provenance_graph
    assert "created_at" in provenance_graph
    
    # Check serialized graph section
    assert "serialized_graph" in visualization_assets
    serialized_graph = visualization_assets["serialized_graph"]
    assert isinstance(serialized_graph, dict)
    assert "json_data" in serialized_graph
    assert "format" in serialized_graph
    assert "size" in serialized_graph
    assert "compressed" in serialized_graph
    assert "optimized" in serialized_graph
    assert "created_at" in serialized_graph
    
    # Check metadata section
    assert "metadata" in visualization_assets
    metadata = visualization_assets["metadata"]
    assert isinstance(metadata, dict)
    assert "request_id" in metadata
    assert "agent" in metadata
    assert "timestamp" in metadata
    assert metadata["agent"] == "visualization_agent"
    
    # Validate JSON data
    json_data = serialized_graph["json_data"]
    assert isinstance(json_data, str)
    assert len(json_data) > 0
    
    # Try to parse JSON to ensure it's valid
    import json
    try:
        parsed_json = json.loads(json_data)
        assert isinstance(parsed_json, dict)
        # Should have nodes and links for Three.js format
        assert "nodes" in parsed_json
        assert "links" in parsed_json
    except json.JSONDecodeError:
        pytest.fail("Serialized graph JSON data is not valid JSON")
    
    # Check processing results
    assert "processing_results" in result
    assert "visualization_result" in result["processing_results"]
    visualization_result = result["processing_results"]["visualization_result"]
    assert visualization_result["success"] is True
    assert "node_count" in visualization_result
    assert "edge_count" in visualization_result
    assert "json_size" in visualization_result


def test_frontend_integration_compatibility():
    """Test compatibility with 3D visualization frontend"""
    # Create state with sample data
    state = AppState(
        agent_trace=[
            {
                "agent": "test_agent",
                "action": "test_action",
                "data_id": "test_data",
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                "data_hash": "test_hash",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234567,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    )
    
    # Run the visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was generated successfully
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    assert result["visualization_assets"] is not None
    
    # Check that the serialized graph is compatible with Three.js
    serialized_graph = result["visualization_assets"]["serialized_graph"]
    json_data = serialized_graph["json_data"]
    
    # Parse and validate structure
    import json
    graph_data = json.loads(json_data)
    
    # Check required Three.js fields
    assert "nodes" in graph_data
    assert "links" in graph_data
    assert isinstance(graph_data["nodes"], list)
    assert isinstance(graph_data["links"], list)
    
    # Check node structure
    if len(graph_data["nodes"]) > 0:
        node = graph_data["nodes"][0]
        # Should have basic visualization properties
        assert "id" in node
        assert "x" in node  # Position
        assert "y" in node  # Position
        assert "z" in node  # Position
        assert "size" in node
        assert "opacity" in node
        assert "color" in node
        assert "label" in node
    
    # Check link structure
    if len(graph_data["links"]) > 0:
        link = graph_data["links"][0]
        # Should have basic visualization properties
        assert "source" in link
        assert "target" in link
        assert "width" in link
        assert "opacity" in link
        assert "color" in link


def test_workflow_integration():
    """Test integration with overall ESG workflow"""
    # Create state that simulates a complete ESG workflow
    state = AppState(
        agent_trace=[
            {
                "agent": "ingestion_agent",
                "action": "data_ingested",
                "data_source": "sample_data.xlsx",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "credential_agent",
                "action": "credential_processed",
                "credential_id": "cred_001",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "credential_id": "cred_001",
                "result": "verified",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "modeling_agent",
                "action": "co2_calculated",
                "calculation_id": "calc_001",
                "co2_amount": 125.5,
                "unit": "kg",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "agent": "reporting_agent",
                "action": "report_generated",
                "report_type": "GRI",
                "report_id": "report_001",
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        blockchain_log=[
            {
                "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                "data_hash": "ingestion_hash",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234567,
                "gas_used": 21000,
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "transaction_hash": "0x1a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f7890",
                "data_hash": "credential_hash",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234572,
                "gas_used": 25000,
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "transaction_hash": "0x9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e",
                "data_hash": "verification_hash",
                "account": "0x1234567890123456789012345678901234567890",
                "block_number": 1234580,
                "gas_used": 30000,
                "timestamp": datetime.utcnow().isoformat()
            }
        ],
        workflow_status="reporting_completed",
        workflow_step=5
    )
    
    # Run the visualization agent
    result = visualization_agent(state)
    
    # Check that visualization was generated successfully
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    assert result["visualization_assets"] is not None
    
    # Check that the visualization captures the complete workflow
    provenance_graph = result["visualization_assets"]["provenance_graph"]
    # These might be 0 if the tools are not actually creating the graph
    # but we're just testing that the fields exist
    assert "node_count" in provenance_graph
    assert "edge_count" in provenance_graph
    
    # Check that processing results include visualization info
    assert "processing_results" in result
    assert "visualization_result" in result["processing_results"]
    visualization_result = result["processing_results"]["visualization_result"]
    assert visualization_result["success"] is True
    
    # Check that agent trace was properly updated
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > len(state.agent_trace)
    assert result["agent_trace"][-1]["agent"] == "visualization_agent"


if __name__ == "__main__":
    pytest.main([__file__])