"""
Unit tests for the ZKPVerificationTool implementation.
"""

import pytest
from datetime import datetime
from src.tools.verification import ZKPVerificationTool


class TestZKPVerificationTool:
    """Test cases for the ZKPVerificationTool class."""
    
    def setup_method(self):
        """Set up test resources."""
        self.tool = ZKPVerificationTool()
    
    def test_tool_initialization(self):
        """Test that the tool initializes correctly."""
        assert self.tool.name == "zkp_verification"
        assert self.tool.description is not None
        assert "placeholder" in self.tool.description.lower()
        assert self.tool.zkp_backend == "mock"
        assert "mock_proof" in self.tool.supported_proof_types
    
    def test_interface_compliance(self):
        """Test that the tool complies with the BaseTool interface."""
        # Check that the tool has the required methods
        assert hasattr(self.tool, 'run')
        assert callable(self.tool.run)
        
        # Check that the tool has the required attributes
        assert hasattr(self.tool, 'name')
        assert hasattr(self.tool, 'description')
    
    def test_mock_behavior_valid_proof(self):
        """Test the mock behavior with valid proof data."""
        # Create mock proof data
        proof_data = {
            "proof_id": "test_proof_001",
            "proof": "mock_proof_data",
            "public_inputs": ["input1", "input2"],
            "verification_key": "mock_verification_key"
        }
        
        # Run the tool
        result = self.tool.run(proof_data)
        
        # Check the result
        assert isinstance(result, dict)
        assert "verified" in result
        assert result["verified"] is True
        assert "proof_id" in result
        assert result["proof_id"] == "test_proof_001"
        assert "public_inputs" in result
        assert result["public_inputs"] == ["input1", "input2"]
        assert "verification_time_ms" in result
        assert isinstance(result["verification_time_ms"], float)
        assert "timestamp" in result
        # Check that timestamp is a valid ISO format string
        datetime.fromisoformat(result["timestamp"].replace('Z', '+00:00'))
    
    def test_mock_behavior_invalid_proof_missing_fields(self):
        """Test the mock behavior with invalid proof data (missing fields)."""
        # Create invalid proof data (missing required fields)
        proof_data = {
            "proof_id": "test_proof_002"
            # Missing "proof", "public_inputs", and "verification_key"
        }
        
        # Run the tool
        result = self.tool.run(proof_data)
        
        # Check the result
        assert isinstance(result, dict)
        assert "verified" in result
        assert result["verified"] is False
        assert "error" in result
        assert "missing required fields" in result["error"].lower()
        assert "timestamp" in result
    
    def test_mock_behavior_invalid_input_type(self):
        """Test the mock behavior with invalid input type."""
        # Run the tool with invalid input type
        result = self.tool.run("invalid_input_type")
        
        # Check the result
        assert isinstance(result, dict)
        assert "verified" in result
        assert result["verified"] is False
        assert "error" in result
        assert "invalid proof_data format" in result["error"].lower()
        assert "timestamp" in result
    
    def test_future_compatibility(self):
        """Test that the tool interface is extensible for future implementations."""
        # Check that the tool has attributes that can be extended
        assert hasattr(self.tool, 'supported_proof_types')
        assert isinstance(self.tool.supported_proof_types, list)
        
        # Check that we can potentially add more proof types
        original_length = len(self.tool.supported_proof_types)
        self.tool.supported_proof_types.append("new_proof_type")
        assert len(self.tool.supported_proof_types) == original_length + 1


if __name__ == "__main__":
    pytest.main([__file__])