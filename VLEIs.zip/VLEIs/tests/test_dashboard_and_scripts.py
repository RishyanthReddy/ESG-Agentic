"""
Test suite for the Next.js dashboard and fallback scripts.
This module tests:
1. React component initialization
2. Python demo script functionality
3. State persistence in fallback scripts
4. API integration for both frontend and scripts
"""

import os
import sys
import subprocess
import pytest
import json
import time
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def test_api_test_suite_script_exists():
    """Test that the api_test_suite.sh script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'api_test_suite.sh')
    assert os.path.exists(script_path), "api_test_suite.sh script not found"

def test_state_simulation_script_exists():
    """Test that the state_simulation.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'state_simulation.py')
    assert os.path.exists(script_path), "state_simulation.py script not found"

def test_api_responses_file_exists():
    """Test that the api_responses.json file exists"""
    file_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'api_responses.json')
    assert os.path.exists(file_path), "api_responses.json file not found"
    
    # Check that it's valid JSON
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        assert isinstance(data, dict), "api_responses.json should be a JSON object"
    except json.JSONDecodeError:
        pytest.fail("api_responses.json is not valid JSON")

def test_state_simulation_script_execution():
    """Test that the state_simulation.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'state_simulation.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "state_simulation.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"state_simulation.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("state_simulation.py script timed out")
    except Exception as e:
        pytest.fail(f"state_simulation.py script failed with error: {e}")

def test_state_snapshot_file_creation():
    """Test that the state simulation can create a state snapshot file"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'state_simulation.py')
    
    # Path to the actual snapshot file that will be created
    snapshot_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'state_snapshot.json')
    
    try:
        # Run the state simulation with demo mode
        result = subprocess.run(
            ['python', script_path, '--demo'], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"state_simulation.py demo failed with return code {result.returncode}"
        
        # Check if the snapshot file was created
        assert os.path.exists(snapshot_path), "State snapshot file was not created"
        
        # Check if the snapshot file contains valid JSON
        with open(snapshot_path, 'r') as f:
            data = json.load(f)
        assert isinstance(data, dict), "State snapshot should be a JSON object"
        
    except subprocess.TimeoutExpired:
        pytest.fail("state_simulation.py demo timed out")
    except Exception as e:
        pytest.fail(f"state_simulation.py demo failed with error: {e}")
    finally:
        # Clean up the test snapshot file
        if os.path.exists(snapshot_path):
            os.remove(snapshot_path)

def test_nextjs_dashboard_structure():
    """Test that the Next.js dashboard structure exists"""
    dashboard_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard')
    assert os.path.exists(dashboard_path), "dashboard directory not found"
    
    # Check for required files
    required_files = [
        'package.json',
        'tsconfig.json',
        'README.md'
    ]
    
    for file_name in required_files:
        file_path = os.path.join(dashboard_path, file_name)
        assert os.path.exists(file_path), f"Required file {file_name} not found in dashboard"
    
    # Check for src directory structure
    src_path = os.path.join(dashboard_path, 'src')
    assert os.path.exists(src_path), "src directory not found in dashboard"
    
    required_dirs = [
        'app',
        'stores',
        'services',
        'types'
    ]
    
    for dir_name in required_dirs:
        dir_path = os.path.join(src_path, dir_name)
        assert os.path.exists(dir_path), f"Required directory {dir_name} not found in src"

def test_zustand_store_implementation():
    """Test that the Zustand store implementation exists and has required functions"""
    store_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'stores', 'esgStore.ts')
    assert os.path.exists(store_path), "esgStore.ts file not found"
    
    # Check file content for key elements
    with open(store_path, 'r') as f:
        content = f.read()
    
    # Check for required imports and functions
    assert 'create' in content, "Zustand create function not found"
    assert 'fetchHealth' in content, "fetchHealth function not found"
    assert 'processJsonData' in content, "processJsonData function not found"
    assert 'processFileData' in content, "processFileData function not found"
    assert 'verifyReport' in content, "verifyReport function not found"
    assert 'logState' in content, "logState function not found"

def test_api_service_layer():
    """Test that the API service layer exists and has required functions"""
    service_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'services', 'api.ts')
    assert os.path.exists(service_path), "api.ts file not found"
    
    # Check file content for key elements
    with open(service_path, 'r') as f:
        content = f.read()
    
    # Check for required classes and functions
    assert 'ApiService' in content, "ApiService class not found"
    assert 'getHealth' in content, "getHealth method not found"
    assert 'ingestJson' in content, "ingestJson method not found"
    assert 'ingestFile' in content, "ingestFile method not found"
    assert 'verifyReport' in content, "verifyReport method not found"

def test_typescript_types():
    """Test that TypeScript types exist"""
    types_path = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'types', 'appState.ts')
    assert os.path.exists(types_path), "appState.ts file not found"
    
    # Check file content for key elements
    with open(types_path, 'r') as f:
        content = f.read()
    
    # Check for required interfaces
    assert 'HealthStatus' in content, "HealthStatus interface not found"
    assert 'IngestResponse' in content, "IngestResponse interface not found"
    assert 'VerificationResponse' in content, "VerificationResponse interface not found"

if __name__ == "__main__":
    pytest.main([__file__])