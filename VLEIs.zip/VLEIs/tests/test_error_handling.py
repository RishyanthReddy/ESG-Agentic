"""
Unit tests for the Centralized Error Handling Framework
"""

import pytest
from datetime import datetime
from src.utils.error_handling import (
    BaseVLEIError, APIFailureError, DataValidationError, 
    ConfigurationError, WorkflowError, handle_error, log_error, safe_execute
)


class TestCustomExceptions:
    """Test cases for custom exception classes"""
    
    def test_base_vlei_error_creation(self):
        """Test BaseVLEIError creation and attributes"""
        error = BaseVLEIError("Test error message")
        
        assert isinstance(error, Exception)
        assert error.message == "Test error message"
        assert isinstance(error.error_code, str)
        assert isinstance(error.timestamp, datetime)
        assert isinstance(error.request_id, str)
        assert isinstance(error.details, dict)
        assert len(error.details) == 0
    
    def test_base_vlei_error_with_details(self):
        """Test BaseVLEIError creation with custom details"""
        details = {"key": "value", "number": 42}
        error = BaseVLEIError("Test error", error_code="TEST_001", details=details)
        
        assert error.message == "Test error"
        assert error.error_code == "TEST_001"
        assert error.details == details
    
    def test_api_failure_error(self):
        """Test APIFailureError creation and attributes"""
        error = APIFailureError(
            "API request failed",
            status_code=500,
            url="https://api.example.com/test",
            response_body="Internal Server Error"
        )
        
        assert isinstance(error, BaseVLEIError)
        assert error.message == "API request failed"
        assert error.status_code == 500
        assert error.url == "https://api.example.com/test"
        assert error.response_body == "Internal Server Error"
        assert "status_code" in error.details
        assert "url" in error.details
        assert "response_body" in error.details
    
    def test_data_validation_error(self):
        """Test DataValidationError creation and attributes"""
        error = DataValidationError(
            "Invalid email format",
            field="email",
            value="invalid-email"
        )
        
        assert isinstance(error, BaseVLEIError)
        assert error.message == "Invalid email format"
        assert error.field == "email"
        assert error.value == "invalid-email"
        assert "field" in error.details
        assert "value" in error.details
    
    def test_configuration_error(self):
        """Test ConfigurationError creation and attributes"""
        error = ConfigurationError(
            "Missing required configuration",
            config_key="DATABASE_URL"
        )
        
        assert isinstance(error, BaseVLEIError)
        assert error.message == "Missing required configuration"
        assert error.config_key == "DATABASE_URL"
        assert "config_key" in error.details
    
    def test_workflow_error(self):
        """Test WorkflowError creation and attributes"""
        error = WorkflowError(
            "Workflow step failed",
            workflow_step="data_processing"
        )
        
        assert isinstance(error, BaseVLEIError)
        assert error.message == "Workflow step failed"
        assert error.workflow_step == "data_processing"
        assert "workflow_step" in error.details
    
    def test_error_to_dict(self):
        """Test error conversion to dictionary"""
        error = BaseVLEIError("Test error", error_code="TEST_002")
        error_dict = error.to_dict()
        
        assert isinstance(error_dict, dict)
        assert error_dict["error_code"] == "TEST_002"
        assert error_dict["message"] == "Test error"
        assert "timestamp" in error_dict
        assert "request_id" in error_dict
        assert error_dict["type"] == "BaseVLEIError"
    
    def test_error_string_representation(self):
        """Test error string representation"""
        error = BaseVLEIError("Test error", error_code="TEST_003")
        error_str = str(error)
        
        assert "[TEST_003] Test error" == error_str


class TestErrorHandlingFunctions:
    """Test cases for error handling functions"""
    
    def test_handle_error_with_custom_error(self):
        """Test handle_error with custom error"""
        original_error = DataValidationError("Test validation error")
        handled_error = handle_error(original_error)
        
        assert handled_error is original_error  # Should return the same object
        assert isinstance(handled_error, BaseVLEIError)
    
    def test_handle_error_with_standard_error(self):
        """Test handle_error with standard Python error"""
        original_error = ValueError("Test value error")
        handled_error = handle_error(original_error)
        
        assert isinstance(handled_error, DataValidationError)
        assert handled_error.message == "Test value error"
    
    def test_handle_error_with_key_error(self):
        """Test handle_error with KeyError"""
        original_error = KeyError("missing_key")
        handled_error = handle_error(original_error)
        
        assert isinstance(handled_error, ConfigurationError)
        assert "missing_key" in handled_error.message
    
    def test_handle_error_with_context(self):
        """Test handle_error with additional context"""
        original_error = ValueError("Test error")
        context = {"function": "test_function", "parameter": "test_param"}
        handled_error = handle_error(original_error, context)
        
        assert isinstance(handled_error, DataValidationError)
        assert handled_error.details.get("function") == "test_function"
        assert handled_error.details.get("parameter") == "test_param"
    
    def test_log_error(self, caplog):
        """Test log_error function"""
        error = BaseVLEIError("Test error for logging")
        # This test primarily ensures no exceptions are raised
        log_error(error)
        # In a real scenario, we would check log output
    
    def test_safe_execute_success(self):
        """Test safe_execute with successful function execution"""
        def successful_function(x, y):
            return x + y
        
        result, error = safe_execute(successful_function, 2, 3)
        
        assert result == 5
        assert error is None
    
    def test_safe_execute_failure(self):
        """Test safe_execute with function that raises an exception"""
        def failing_function(x, y):
            raise ValueError("Test failure")
        
        result, error = safe_execute(failing_function, 2, 3)
        
        assert result is None
        assert isinstance(error, DataValidationError)
        assert error.message == "Test failure"


if __name__ == "__main__":
    pytest.main([__file__])