"""
Unit tests for the Report Signing Tool
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from src.tools.verification import SignReportTool
from datetime import datetime
import uuid
import hashlib
import json


@pytest.fixture
def sign_tool():
    """Create a SignReportTool instance for testing"""
    return SignReportTool()


@pytest.fixture
def mock_report_data():
    """Sample report data for testing"""
    return {
        "report_id": "report_12345",
        "title": "ESG Compliance Report Q1 2025",
        "company_name": "Test Company Inc.",
        "period": "Q1 2025",
        "esg_scores": {
            "environmental": 85.5,
            "social": 78.2,
            "governance": 92.1
        },
        "carbon_footprint": {
            "total_co2e": 1250.5,
            "unit": "kg"
        },
        "timestamp": datetime.utcnow().isoformat()
    }


def test_sign_tool_initialization(sign_tool):
    """Test Sign Report Tool initialization"""
    assert sign_tool.name == "sign_report"
    assert sign_tool.description == "Cryptographically signs reports and generates Verifiable Credentials using Azure Verified ID"
    assert hasattr(sign_tool, 'azure_tool')
    assert hasattr(sign_tool, 'redis_client')


def test_generate_report_hash(sign_tool, mock_report_data):
    """Test report hash generation"""
    # Test that the hash is generated consistently
    hash1 = sign_tool._generate_report_hash(mock_report_data)
    hash2 = sign_tool._generate_report_hash(mock_report_data)
    
    assert isinstance(hash1, str)
    assert len(hash1) == 64  # SHA-256 produces 64-character hex string
    assert hash1 == hash2  # Same input should produce same hash
    
    # Test that different inputs produce different hashes
    modified_data = mock_report_data.copy()
    modified_data["title"] = "Modified Title"
    hash3 = sign_tool._generate_report_hash(modified_data)
    
    assert hash1 != hash3  # Different input should produce different hash


def test_add_rfc3161_timestamp(sign_tool):
    """Test RFC 3161 timestamp addition"""
    test_hash = hashlib.sha256(b"test data").hexdigest()
    timestamp_info = sign_tool._add_rfc3161_timestamp(test_hash)
    
    assert isinstance(timestamp_info, dict)
    assert "timestamp" in timestamp_info
    assert "timestamp_authority" in timestamp_info
    assert "hashed_data" in timestamp_info
    assert "algorithm" in timestamp_info
    assert "timestamp_token" in timestamp_info
    
    assert timestamp_info["hashed_data"] == test_hash
    assert timestamp_info["algorithm"] == "SHA-256"
    assert "http://timestamp.acs.microsoft.com" in timestamp_info["timestamp_authority"]


def test_sign_with_azure_key_vault(sign_tool):
    """Test signing with Azure Key Vault simulation"""
    test_hash = hashlib.sha256(b"test data").hexdigest()
    signature_info = sign_tool._sign_with_azure_key_vault(test_hash)
    
    assert isinstance(signature_info, dict)
    assert "signature" in signature_info
    assert "key_id" in signature_info
    assert "algorithm" in signature_info
    assert "signed_at" in signature_info
    
    assert signature_info["algorithm"] == "RS256"
    # The hashed_data is added in the sign_report method, not in _sign_with_azure_key_vault directly


def test_generate_verifiable_credential(sign_tool, mock_report_data):
    """Test verifiable credential generation"""
    test_hash = hashlib.sha256(b"test data").hexdigest()
    signature_info = sign_tool._sign_with_azure_key_vault(test_hash)
    signature_info["hashed_data"] = test_hash
    timestamp_info = sign_tool._add_rfc3161_timestamp(test_hash)
    
    credential = sign_tool._generate_verifiable_credential(
        mock_report_data, signature_info, timestamp_info)
    
    assert isinstance(credential, dict)
    assert "credential_id" in credential
    assert "type" in credential
    assert "issuer" in credential
    assert "issuance_date" in credential
    assert "credential_subject" in credential
    assert "proof" in credential
    
    subject = credential["credential_subject"]
    assert subject["report_hash"] == test_hash
    assert subject["report_title"] == mock_report_data["title"]


@patch('src.tools.verification.AzureVerifiedIDTool.issue_credential')
def test_sign_report_success(mock_issue_credential, sign_tool, mock_report_data):
    """Test successful report signing"""
    # Mock the Azure Verified ID tool response
    mock_issue_credential.return_value = {
        "issued": True,
        "request_id": "request_123",
        "url": "https://example.com/issue/123",
        "expiry": "2025-12-31T23:59:59Z"
    }
    
    result = sign_tool.sign_report(mock_report_data)
    
    assert isinstance(result, dict)
    assert result["signed"] == True
    assert "report_hash" in result
    assert "signature_info" in result
    assert "timestamp_info" in result
    assert "verifiable_credential" in result
    assert "credential_issuance" in result
    
    # Verify the structure of nested objects
    assert isinstance(result["report_hash"], str)
    assert len(result["report_hash"]) == 64
    assert isinstance(result["signature_info"], dict)
    assert isinstance(result["timestamp_info"], dict)
    assert isinstance(result["verifiable_credential"], dict)
    assert isinstance(result["credential_issuance"], dict)
    
    # Verify the mock was called
    mock_issue_credential.assert_called_once()


@patch('src.tools.verification.AzureVerifiedIDTool.issue_credential')
def test_sign_report_failure(mock_issue_credential, sign_tool, mock_report_data):
    """Test report signing failure"""
    # Mock the Azure Verified ID tool to raise an exception
    mock_issue_credential.side_effect = Exception("Azure API error")
    
    result = sign_tool.sign_report(mock_report_data)
    
    assert isinstance(result, dict)
    assert result["signed"] == False
    assert "error" in result
    assert "Azure API error" in result["error"]
    
    # Verify the mock was called
    mock_issue_credential.assert_called_once()


def test_verify_signature_success(sign_tool, mock_report_data):
    """Test successful signature verification"""
    # Generate a valid-looking signature
    test_signature = "sig_" + hashlib.sha1(b"test data").hexdigest()[:32]
    
    result = sign_tool.verify_signature(mock_report_data, test_signature)
    
    assert isinstance(result, dict)
    assert result["verified"] == True
    assert "report_hash" in result
    assert "provided_signature" in result


def test_verify_signature_failure(sign_tool, mock_report_data):
    """Test signature verification failure"""
    # Use an invalid signature format
    invalid_signature = "invalid_signature"
    
    result = sign_tool.verify_signature(mock_report_data, invalid_signature)
    
    assert isinstance(result, dict)
    assert result["verified"] == False
    assert "report_hash" in result
    assert "provided_signature" in result


def test_run_sign_action(sign_tool, mock_report_data):
    """Test run method with sign action"""
    with patch.object(sign_tool, 'sign_report') as mock_sign_report:
        mock_sign_report.return_value = {"signed": True, "test": "result"}
        
        result = sign_tool.run("sign", report_data=mock_report_data)
        
        assert result["signed"] == True
        assert result["test"] == "result"
        mock_sign_report.assert_called_once_with(mock_report_data)


def test_run_verify_action(sign_tool, mock_report_data):
    """Test run method with verify action"""
    with patch.object(sign_tool, 'verify_signature') as mock_verify_signature:
        mock_verify_signature.return_value = {"verified": True, "test": "result"}
        
        result = sign_tool.run("verify", report_data=mock_report_data, signature="test_sig")
        
        assert result["verified"] == True
        assert result["test"] == "result"
        mock_verify_signature.assert_called_once_with(mock_report_data, "test_sig")


def test_run_invalid_action(sign_tool):
    """Test run method with invalid action"""
    result = sign_tool.run("invalid_action")
    
    assert "error" in result
    assert "Unsupported action" in result["error"]


def test_run_sign_missing_data(sign_tool):
    """Test run method with sign action but missing report data"""
    result = sign_tool.run("sign")
    
    assert result["signed"] == False
    assert "error" in result
    assert "report_data is required" in result["error"]


def test_run_verify_missing_data(sign_tool):
    """Test run method with verify action but missing data"""
    result = sign_tool.run("verify")
    
    assert result["verified"] == False
    assert "error" in result
    assert "report_data and signature are required" in result["error"]