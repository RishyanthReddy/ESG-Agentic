"""
Unit tests for the upgraded verification agent with multi-tool logic
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.verification import verification_agent, VerificationError
from src.state.models import AppState, vLEICredential, VerificationStatus
from src.tools.verification import GleifVerifierTool, AzureVerifiedIDTool
from src.tools.registry import ToolRegistry


class TestVerificationAgentUpgrade:
    """Test cases for upgraded verification agent logic"""
    
    def test_tool_orchestration_with_gleif_credential(self):
        """Test proper tool selection for GLEIF credential"""
        # Create a GLEIF credential (with LEI in subject)
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:lei:549300A6XUSR882F7N34",
            claims={"test": "value"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification results
        mock_gleif_result = {
            "verified": True,
            "credential_id": str(credential.id),
            "reason": "Credential is valid"
        }
        
        mock_azure_result = {
            "verification_requested": True,
            "request_id": "test-request-id"
        }
        
        # Patch both tools
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_gleif_result):
            with patch('src.tools.verification.AzureVerifiedIDTool.run', return_value=mock_azure_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Verify the result
                assert result["workflow_status"] == "credential_verified"
                assert "processing_results" in result
                assert "consolidated_result" in result["processing_results"]
                assert result["processing_results"]["consolidated_result"]["verified"] is True
                
                # Verify credential status was updated
                assert len(result["credentials"]) == 1
                assert result["credentials"][0].verification_status == VerificationStatus.VERIFIED
                
                # Verify both tools were used
                agent_trace = result["agent_trace"][-1]
                assert "tools_used" in agent_trace
                assert "gleif_verifier" in agent_trace["tools_used"]
    
    def test_tool_orchestration_with_azure_credential(self):
        """Test proper tool selection for Azure credential"""
        # Create an Azure credential (with Azure issuer)
        credential = vLEICredential(
            issuer="did:azure:issuer",
            subject="did:example:subject",
            claims={"test": "value"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification results
        mock_gleif_result = {
            "verified": False,
            "credential_id": str(credential.id),
            "reason": "LEI not found"
        }
        
        mock_azure_result = {
            "verification_requested": True,
            "request_id": "test-request-id"
        }
        
        # Patch both tools
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_gleif_result):
            with patch('src.tools.verification.AzureVerifiedIDTool.run', return_value=mock_azure_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Verify the result
                assert result["workflow_status"] == "credential_verified"
                assert "processing_results" in result
                assert "consolidated_result" in result["processing_results"]
                
                # Verify credential status was updated
                assert len(result["credentials"]) == 1
                
                # Verify Azure tool was used
                agent_trace = result["agent_trace"][-1]
                assert "tools_used" in agent_trace
                assert "azure_verified_id" in agent_trace["tools_used"]
    
    def test_decision_logic_with_neither_credential_type(self):
        """Test credential routing when neither specific type is detected"""
        # Create a generic credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "value"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification results
        mock_gleif_result = {
            "verified": True,
            "credential_id": str(credential.id),
            "reason": "Credential is valid"
        }
        
        mock_azure_result = {
            "verification_requested": True,
            "request_id": "test-request-id"
        }
        
        # Patch both tools
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_gleif_result):
            with patch('src.tools.verification.AzureVerifiedIDTool.run', return_value=mock_azure_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Verify the result
                assert result["workflow_status"] == "credential_verified"
                assert "processing_results" in result
                assert "consolidated_result" in result["processing_results"]
                
                # Verify both tools were used
                agent_trace = result["agent_trace"][-1]
                assert "tools_used" in agent_trace
                assert "gleif_verifier" in agent_trace["tools_used"]
                assert "azure_verified_id" in agent_trace["tools_used"]
    
    def test_state_updates_with_consolidated_verification_status(self):
        """Test consolidated verification status updates"""
        # Create a credential
        credential = vLEICredential(
            issuer="did:lei:issuer",
            subject="did:lei:549300A6XUSR882F7N34",
            claims={"lei": "549300A6XUSR882F7N34"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification results where both tools succeed
        mock_gleif_result = {
            "verified": True,
            "credential_id": str(credential.id),
            "reason": "Credential is valid"
        }
        
        mock_azure_result = {
            "verification_requested": True,
            "request_id": "test-request-id"
        }
        
        # Patch both tools
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_gleif_result):
            with patch('src.tools.verification.AzureVerifiedIDTool.run', return_value=mock_azure_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Verify consolidated result is successful
                consolidated_result = result["processing_results"]["consolidated_result"]
                assert consolidated_result["verified"] is True
                
                # Verify credential status was updated to VERIFIED
                assert len(result["credentials"]) == 1
                assert result["credentials"][0].verification_status == VerificationStatus.VERIFIED
    
    def test_error_handling_with_partial_failure(self):
        """Test error handling with partial tool failures"""
        # Create a credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:lei:549300A6XUSR882F7N34",
            claims={"lei": "549300A6XUSR882F7N34"}
        )
        
        # Create initial state with the credential
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Mock verification results where GLEIF succeeds but Azure fails
        mock_gleif_result = {
            "verified": True,
            "credential_id": str(credential.id),
            "reason": "Credential is valid"
        }
        
        mock_azure_result = {
            "verification_requested": False,
            "error": "Authentication failed"
        }
        
        # Patch both tools
        with patch('src.tools.verification.GleifVerifierTool.run', return_value=mock_gleif_result):
            with patch('src.tools.verification.AzureVerifiedIDTool.run', return_value=mock_azure_result):
                # Run the verification agent
                result = verification_agent(state)
                
                # Should still be verified due to GLEIF success
                consolidated_result = result["processing_results"]["consolidated_result"]
                assert consolidated_result["verified"] is True
                
                # Should contain details of at least one result (GLEIF)
                assert len(consolidated_result["details"]) >= 1


if __name__ == "__main__":
    pytest.main([__file__])