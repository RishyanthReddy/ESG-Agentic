"""
Unit tests for the Automated Audit Agent

This module contains tests for verifying the correct functionality of the 
automated_audit_agent including sampling logic, audit execution, result logging,
and scheduling.
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.audit import automated_audit_agent, _sample_blockchain_logs, AuditError
from src.state.models import AppState, vLEICredential, AuditTrailEntry
from src.tools.registry import ToolRegistry


def test_sampling_logic():
    """Test blockchain log sampling strategies"""
    # Test with empty list
    empty_logs = []
    sampled = _sample_blockchain_logs(empty_logs)
    assert sampled == []
    
    # Test with fewer entries than sample size
    few_logs = [{"hash": "0x1"}, {"hash": "0x2"}]
    sampled = _sample_blockchain_logs(few_logs, sample_size=5)
    assert len(sampled) == 2
    assert all(log in few_logs for log in sampled)
    
    # Test with more entries than sample size
    many_logs = [{"hash": f"0x{i}"} for i in range(10)]
    sampled = _sample_blockchain_logs(many_logs, sample_size=5)
    assert len(sampled) == 5
    assert all(log in many_logs for log in sampled)


def test_audit_execution():
    """Test automated audit execution"""
    # Create test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create app state with blockchain logs
    state = AppState(
        current_credential=credential,
        blockchain_log=[
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash_1",
                "data_id": str(credential.id),
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            },
            {
                "transaction_hash": "0xabcdef1234567890",
                "data_hash": "test_hash_2",
                "data_id": str(credential.id),
                "account": "0xAccount123",
                "block_number": 1000001,
                "gas_used": 25000,
                "timestamp": "2023-01-01T00:01:00Z"
            }
        ]
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock successful verification result
        mock_oracle_tool.run.return_value = {
            "success": True,
            "verified_entries": 1,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef",
                    "verified": True,
                    "match": True,
                    "error": None
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "audit_completed"
        assert "audit_trail" in result
        assert len(result["audit_trail"]) == 2  # Two audit trail entries for two blockchain logs
        assert "processing_results" in result
        assert "audit_result" in result["processing_results"]
        
        # Verify audit results
        audit_result = result["processing_results"]["audit_result"]
        assert audit_result["total_audited"] == 2
        assert audit_result["successful_audits"] == 2
        assert audit_result["failed_audits"] == 0
        assert len(audit_result["audit_results"]) == 2


def test_result_logging():
    """Test audit trail result logging"""
    # Create app state
    state = AppState(
        blockchain_log=[
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash",
                "data_id": "test_id",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            }
        ]
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock verification result
        mock_oracle_tool.run.return_value = {
            "success": True,
            "verified_entries": 1,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef",
                    "verified": True,
                    "match": True,
                    "error": None
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify audit trail entries
        assert len(result["audit_trail"]) == 1
        audit_entry = result["audit_trail"][0]
        assert isinstance(audit_entry, AuditTrailEntry)
        assert audit_entry.audit_type == "blockchain_verification"
        assert audit_entry.transaction_hash == "0x1234567890abcdef"
        assert audit_entry.verification_result is True
        assert audit_entry.details["verified"] is True
        assert audit_entry.details["match"] is True


def test_scheduling():
    """Test periodic audit scheduling functionality"""
    # This test focuses on the agent's ability to handle being called periodically
    # Create app state with no blockchain logs
    state = AppState()
    
    # Mock the tool registry
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        mock_registry.get_tool.return_value = Mock()
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify it handles the case with no logs gracefully
        assert result["workflow_status"] == "audit_completed"
        assert len(result["agent_trace"]) > 0
        trace_entry = result["agent_trace"][-1]
        assert trace_entry["action"] == "audit_skipped"
        assert trace_entry["reason"] == "no_blockchain_entries"


def test_audit_error_handling():
    """Test audit agent error handling"""
    # Create app state
    state = AppState(
        blockchain_log=[
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash",
                "data_id": "test_id",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            }
        ]
    )
    
    # Test when BlockchainOracleTool is not available
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        mock_registry.get_tool.return_value = None  # Tool not found
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify error handling
        assert result["workflow_status"] == "audit_failed"
        assert len(result["errors"]) > 0
        assert "BlockchainOracleTool not found" in result["errors"][0]
        assert len(result["agent_trace"]) > 0
        trace_entry = result["agent_trace"][-1]
        assert trace_entry["action"] == "audit_failed"


if __name__ == "__main__":
    pytest.main([__file__])