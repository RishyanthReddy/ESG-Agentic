"""
Deployment Integration Tests for ESG Intelligence Platform

This module tests the complete deployment workflow including:
- Production deployment
- Public access validation
- Load testing
- Fallback deployment
- Demo readiness
"""

import os
import sys
import pytest
import subprocess
import time
import requests
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from deploy.deployment_config import DeploymentConfig
from deploy.deployment_manager import DeploymentManager


class TestProductionDeployment:
    """Test complete system deployment"""
    
    def test_deployment_components(self):
        """Test that all required deployment components exist"""
        # Check that deployment files exist
        required_files = [
            "deploy/deployment_config.py",
            "deploy/deployment_manager.py",
            "demo_scripts/deployment/cli_deploy.py",
            "docker-compose.yml",
            "modal_entrypoint.py"
        ]
        
        for file_path in required_files:
            full_path = Path(file_path)
            assert full_path.exists(), f"Required deployment file {file_path} not found"
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_cloud_deployment_process(self, mock_subprocess):
        """Test the complete cloud deployment process"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Deployed to https://esg-intelligence-platform.modal.run"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.deploy_cloud()
        
        assert success is True
        # Check that modal deploy was called
        mock_subprocess.assert_any_call(
            ["modal", "deploy", "modal_entrypoint.py"],
            capture_output=True,
            text=True,
            timeout=300
        )


class TestPublicAccess:
    """Test external access validation"""
    
    @patch('deploy.deployment_manager.requests.get')
    def test_backend_public_access(self, mock_requests):
        """Test that backend is accessible externally"""
        # Mock successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "ok", "services": ["redis", "api"]}
        mock_requests.return_value = mock_response
        
        config = DeploymentConfig()
        dm = DeploymentManager()
        
        # Test cloud backend access
        backend_url = config.get_backend_url("cloud")
        health_endpoint = config.get_api_endpoint("health")
        health_url = f"{backend_url}{health_endpoint}"
        
        response = requests.get(health_url)
        assert response.status_code == 200
        
        # Test local backend access
        backend_url = config.get_backend_url("local")
        health_url = f"{backend_url}{health_endpoint}"
        
        response = requests.get(health_url)
        assert response.status_code == 200
    
    def test_frontend_urls_defined(self):
        """Test that frontend URLs are properly defined for public access"""
        config = DeploymentConfig()
        
        # Test cloud frontend URL
        cloud_frontend = config.get_frontend_url("cloud")
        assert isinstance(cloud_frontend, str)
        assert len(cloud_frontend) > 0
        # Should be a valid URL format
        assert cloud_frontend.startswith(("http://", "https://"))
        
        # Test local frontend URL
        local_frontend = config.get_frontend_url("local")
        assert isinstance(local_frontend, str)
        assert len(local_frontend) > 0
        # Should be a valid URL format
        assert local_frontend.startswith(("http://", "https://"))


class TestLoadTesting:
    """Test deployed system under presentation load"""
    
    def test_deployment_can_handle_concurrent_requests(self):
        """Test that deployment can handle concurrent requests"""
        config = DeploymentConfig()
        
        # Test that configuration supports load testing parameters
        assert hasattr(config, 'HEALTH_CHECK_TIMEOUT')
        assert config.HEALTH_CHECK_TIMEOUT > 0
        
        assert hasattr(config, 'HEALTH_CHECK_RETRIES')
        assert config.HEALTH_CHECK_RETRIES >= 0


class TestFallbackDeployment:
    """Test local system deployment and access"""
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_local_deployment_process(self, mock_subprocess):
        """Test the complete local deployment process"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Creating esg-engine ... done\nCreating esg-redis ... done"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.deploy_local()
        
        assert success is True
        mock_subprocess.assert_called_with(
            ["docker-compose", "up", "-d"],
            capture_output=True,
            text=True,
            timeout=120
        )
    
    @patch('deploy.deployment_manager.subprocess.run')
    def test_stop_local_deployment_process(self, mock_subprocess):
        """Test stopping local deployment"""
        # Mock successful subprocess run
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Stopping esg-engine ... done\nStopping esg-redis ... done"
        mock_result.stderr = ""
        mock_subprocess.return_value = mock_result
        
        dm = DeploymentManager()
        success = dm.stop_local_deployment()
        
        assert success is True
        mock_subprocess.assert_called_with(
            ["docker-compose", "down"],
            capture_output=True,
            text=True,
            timeout=60
        )


class TestDemoReadiness:
    """Test complete deployment verification for hackathon"""
    
    def test_required_demo_endpoints_available(self):
        """Test that all required endpoints for demo are available"""
        config = DeploymentConfig()
        
        # Test CLI endpoints are defined
        required_cli_endpoints = [
            "health_check",
            "system_status",
            "demo_ingest",
            "demo_verify",
            "metrics"
        ]
        
        for endpoint in required_cli_endpoints:
            endpoint_url = config.get_cli_endpoint(endpoint)
            assert isinstance(endpoint_url, str), f"CLI endpoint {endpoint} not properly defined"
            assert len(endpoint_url) > 0, f"CLI endpoint {endpoint} is empty"
    
    def test_deployment_documentation_exists(self):
        """Test that deployment documentation exists"""
        # Check for key documentation files that actually exist
        documentation_files = [
            "Project Plan.md",  # Main project plan
            "docker-compose.yml",  # Docker Compose file
            "modal_entrypoint.py"  # Modal deployment entrypoint
        ]
        
        for file_path in documentation_files:
            full_path = Path(file_path)
            assert full_path.exists(), f"Documentation file {file_path} not found"
    
    @patch('deploy.deployment_manager.subprocess.run')
    @patch('deploy.deployment_manager.requests.get')
    def test_complete_deployment_workflow(self, mock_requests, mock_subprocess):
        """Test complete deployment workflow from start to finish"""
        # Mock subprocess for deployment
        mock_deploy_result = MagicMock()
        mock_deploy_result.returncode = 0
        mock_deploy_result.stdout = "Deployment successful"
        mock_deploy_result.stderr = ""
        
        # Mock requests for health check
        mock_health_response = MagicMock()
        mock_health_response.status_code = 200
        mock_health_response.json.return_value = {"status": "ok"}
        
        mock_subprocess.return_value = mock_deploy_result
        mock_requests.return_value = mock_health_response
        
        # Test the complete workflow
        dm = DeploymentManager()
        
        # 1. Deploy locally
        deploy_success = dm.deploy_local()
        assert deploy_success is True
        
        # 2. Check health
        health = dm.check_health("local")
        assert health["status"] == "healthy"
        
        # 3. Get status
        status = dm.get_deployment_status("local")
        assert "environment" in status
        
        # 4. Stop deployment
        stop_success = dm.stop_local_deployment()
        assert stop_success is True


if __name__ == "__main__":
    pytest.main([__file__])