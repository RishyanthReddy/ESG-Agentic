"""
Unit tests for the Blockchain Oracle Tool

This module contains tests for verifying the correct functionality of the 
BlockchainOracleTool including hash calculation, blockchain queries, 
verification logic, and error handling.
"""

import pytest
import hashlib
import json
from unittest.mock import Mock, patch
from src.tools.audit import BlockchainOracleTool, OracleError
from src.state.models import AppState, vLEICredential


def test_hash_calculation():
    """Test data hash calculation consistency"""
    # Create oracle tool
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111  # Sepolia chain ID
        mock_web3_class.return_value = mock_web3_instance
        
        oracle_tool = BlockchainOracleTool()
        
        # Create test data
        test_data = {
            "id": "test-id",
            "value": "test-value",
            "nested": {
                "inner": "data"
            }
        }
        
        # Calculate hash manually
        data_json = json.dumps(test_data, sort_keys=True, separators=(',', ':'))
        expected_hash = hashlib.sha256(data_json.encode('utf-8')).hexdigest()
        
        # Calculate hash using tool method
        actual_hash = oracle_tool._recompute_data_hash(test_data)
        
        # Verify hashes match
        assert actual_hash == expected_hash
        assert len(actual_hash) == 64  # SHA-256 produces 64-character hex string


def test_blockchain_queries():
    """Test blockchain transaction retrieval"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        oracle_tool = BlockchainOracleTool()
        
        # Mock transaction data
        test_transaction_hash = "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
        test_data = "test_data_hash"
        
        # Mock web3.eth.get_transaction
        mock_transaction = Mock()
        mock_transaction.get.return_value = test_data
        mock_web3_instance.eth.get_transaction.return_value = mock_transaction
        
        # Test transaction data retrieval
        result = oracle_tool._get_transaction_data(test_transaction_hash)
        
        # Verify the call was made
        mock_web3_instance.eth.get_transaction.assert_called_once_with(test_transaction_hash)
        
        # Verify result
        assert result == test_data


def test_verification_logic():
    """Test hash comparison and validation"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        oracle_tool = BlockchainOracleTool()
        
        # Create test credential
        credential = vLEICredential(
            issuer="did:example:issuer",
            subject="did:example:subject",
            claims={"test": "data"}
        )
        
        # Serialize credential for hash calculation using model_dump with mode="json"
        credential_data = credential.model_dump(mode="json")
        credential_json = json.dumps(credential_data, sort_keys=True, separators=(',', ':'))
        credential_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
        
        # Create app state
        state = AppState(
            current_credential=credential,
            blockchain_log=[
                {
                    "transaction_hash": "0x1234567890abcdef",
                    "data_hash": credential_hash,
                    "data_id": str(credential.id),
                    "account": "0xAccount123",
                    "block_number": 1000000,
                    "gas_used": 21000,
                    "timestamp": "2023-01-01T00:00:00Z"
                }
            ]
        )
        
        # Mock transaction data retrieval to return the same hash
        mock_transaction = Mock()
        mock_transaction.get.return_value = credential_hash
        mock_web3_instance.eth.get_transaction.return_value = mock_transaction
        
        # Run verification
        result = oracle_tool.run(state)
        
        # Verify result structure
        assert result["success"] is True
        assert result["verified_entries"] == 1
        assert result["total_entries"] == 1
        assert len(result["results"]) == 1
        
        # Verify individual result
        entry_result = result["results"][0]
        assert entry_result["transaction_hash"] == "0x1234567890abcdef"
        assert entry_result["verified"] is True
        assert entry_result["on_chain_hash"] == credential_hash
        assert entry_result["off_chain_hash"] == credential_hash
        assert entry_result["match"] is True
        assert entry_result["error"] is None


def test_error_handling():
    """Test oracle failure scenarios"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        oracle_tool = BlockchainOracleTool()
        
        # Test with empty blockchain log
        state = AppState(blockchain_log=[])
        
        # Should raise OracleError
        with pytest.raises(OracleError, match="No blockchain log entries found"):
            oracle_tool.run(state)
        
        # Test with blockchain entry missing transaction hash
        state = AppState(blockchain_log=[{"data_hash": "test"}])
        
        result = oracle_tool.run(state)
        assert result["success"] is False
        assert result["verified_entries"] == 0
        assert result["total_entries"] == 1
        assert len(result["results"]) == 1
        assert result["results"][0]["error"] == "No transaction hash in blockchain entry"


def test_oracle_initialization():
    """Test BlockchainOracleTool initialization"""
    with patch('src.tools.audit.Web3') as mock_web3_class:
        mock_web3_instance = Mock()
        mock_web3_instance.is_connected.return_value = True
        mock_web3_instance.eth.chain_id = 11155111
        mock_web3_class.return_value = mock_web3_instance
        
        # Test successful initialization
        oracle_tool = BlockchainOracleTool()
        assert oracle_tool.name == "blockchain_oracle"
        assert oracle_tool.description == "Verifies data consistency between on-chain provenance logs and off-chain data sources"
        
        # Test initialization failure when not connected
        mock_web3_instance.is_connected.return_value = False
        with pytest.raises(OracleError, match="Failed to connect to Infura Sepolia endpoint"):
            BlockchainOracleTool()


if __name__ == "__main__":
    pytest.main([__file__])