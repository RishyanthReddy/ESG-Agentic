"""
Integration tests for ESG Context Management with LLM
"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.llm.context import ESGContextManager


def test_context_retrieval_and_prompt_building():
    """Test that the context manager can retrieve relevant context and build prompts."""
    # Initialize the context manager
    context_manager = ESGContextManager()
    
    # Test query
    query = "What are the key requirements for ESG reporting under the GRI standards?"
    
    # Get relevant context
    relevant_context = context_manager.get_relevant_context(query, top_k=3)
    
    # Verify we got context
    assert len(relevant_context) > 0, "Should retrieve relevant context"
    assert all('standard' in item for item in relevant_context), "Each context item should have a standard"
    assert all('similarity' in item for item in relevant_context), "Each context item should have a similarity score"
    
    # Build reasoning prompt
    prompt = context_manager.build_reasoning_prompt(query)
    
    # Verify prompt was built
    assert len(prompt) > 0, "Prompt should be built successfully"
    assert "GRI" in prompt, "Prompt should contain GRI context"
    assert query in prompt, "Prompt should contain the original query"
    
    print("Integration test passed!")
    print(f"Retrieved {len(relevant_context)} context items")
    print(f"Prompt length: {len(prompt)} characters")
    print("\nFirst 500 characters of prompt:")
    print(prompt[:500])


def test_semantic_search():
    """Test semantic search functionality."""
    context_manager = ESGContextManager()
    
    # Test with a query related to employment practices
    query = "What are the employment practices that companies should report on?"
    context = context_manager.get_relevant_context(query, top_k=2)
    
    # Verify results
    assert len(context) > 0, "Should find relevant context for employment practices"
    
    print("\nSemantic search test passed!")
    print(f"Query: {query}")
    print("Top relevant contexts:")
    for i, item in enumerate(context):
        print(f"  {i+1}. Standard: {item['standard']}, Similarity: {item['similarity']:.3f}")


if __name__ == "__main__":
    test_context_retrieval_and_prompt_building()
    test_semantic_search()
    print("\nAll integration tests passed!")