"""
Integration tests for the ingestion agent
"""

import pytest
from src.agents.ingestion import ingestion_agent
from src.state.models import AppState


def test_workflow_integration():
    """Test agent in complete workflow context"""
    # Create initial state with realistic supplier data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Global Manufacturing Inc.",
                "data_type": "vlei_credential",
                "credential_data": {
                    "issuer": "Credential Authority",
                    "subject": "Global Manufacturing Inc.",
                    "claims": {
                        "legal_entity_id": "LEI1234567890",
                        "registration_date": "2023-01-15",
                        "status": "active"
                    }
                }
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Verify the result contains expected fields
    assert "workflow_status" in result
    assert "workflow_data" in result
    assert "task_queue" in result
    assert "agent_trace" in result
    
    # Verify workflow status
    assert result["workflow_status"] == "data_ingested"
    
    # Verify task queue is populated
    assert len(result["task_queue"]) > 0
    
    # Verify agent trace is updated
    assert len(result["agent_trace"]) > 0
    assert result["agent_trace"][-1]["agent"] == "ingestion_agent"


def test_data_flow_to_subsequent_agents():
    """Validate data flows correctly to subsequent agents"""
    # Create initial state with supplier data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Eco Products Ltd.",
                "data_type": "gri_report",
                "report_year": 2023,
                "gri_data": {
                    "economic_performance": {"revenue": 1000000},
                    "environmental_metrics": {"co2_emissions": 500},
                    "social_metrics": {"employee_count": 100}
                }
            }
        }
    )
    
    # Process with ingestion agent
    result = ingestion_agent(state)
    
    # Check that processed data is available
    assert "processed_supplier_data" in result["workflow_data"]
    processed_data = result["workflow_data"]["processed_supplier_data"]
    
    # Verify processed data contains expected fields
    assert "company_name" in processed_data
    assert "data_type" in processed_data
    assert "processing_timestamp" in processed_data
    assert "processing_id" in processed_data
    
    # Verify the data is unchanged except for added metadata
    assert processed_data["company_name"] == "Eco Products Ltd."
    assert processed_data["data_type"] == "gri_report"


def test_performance_with_large_datasets():
    """Agent performance with large datasets"""
    import time
    
    # Create a large supplier data set
    large_data = {
        "company_name": "Big Data Corp",
        "data_type": "esg_data",
        "metrics": {}
    }
    
    # Add a lot of data
    for i in range(1000):
        large_data["metrics"][f"metric_{i}"] = {
            "value": i,
            "unit": "tons",
            "description": f"Environmental metric {i}"
        }
    
    state = AppState(workflow_data={"supplier_data": large_data})
    
    # Time the ingestion process
    start_time = time.time()
    result = ingestion_agent(state)
    end_time = time.time()
    
    # Check that it completed successfully
    assert result["workflow_status"] == "data_ingested"
    assert len(result["task_queue"]) > 0
    
    # Check performance (should complete in reasonable time)
    processing_time = end_time - start_time
    assert processing_time < 5.0  # Should complete in less than 5 seconds


def test_error_recovery():
    """Test recovery from data processing errors"""
    # Test with missing data_type field
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Company"
                # Missing data_type
            }
        }
    )
    
    # Should raise IngestionError
    with pytest.raises(Exception):  # Catch any exception type
        ingestion_agent(state)
    
    # Test with valid data after invalid data should work
    state2 = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Company",
                "data_type": "vlei_credential",
                "credential_data": {"issuer": "Test", "subject": "Test"}
            }
        }
    )
    
    # Should work fine
    result = ingestion_agent(state2)
    assert result["workflow_status"] == "data_ingested"


def test_real_data_structures():
    """Test with realistic supplier data structures"""
    # Test with realistic vLEI credential data
    vlei_data = {
        "supplier_data": {
            "company_name": "Verifiable Credentials Inc.",
            "data_type": "vlei_credential",
            "credential": {
                "id": "did:example:123",
                "issuer": "did:example:issuer",
                "issuanceDate": "2023-06-15T10:00:00Z",
                "credentialSubject": {
                    "id": "did:example:subject",
                    "organization": {
                        "name": "Verifiable Credentials Inc.",
                        "lei": "LEI01234567890123456789"
                    }
                },
                "proof": {
                    "type": "Ed25519Signature2018",
                    "created": "2023-06-15T10:00:00Z",
                    "proofValue": "example_signature"
                }
            }
        }
    }
    
    state = AppState(workflow_data=vlei_data)
    result = ingestion_agent(state)
    
    # Verify correct tasks for vLEI credential
    expected_tasks = [
        "verify_vlei_credential",
        "log_to_blockchain",
        "map_to_regulatory_frameworks"
    ]
    
    assert result["task_queue"] == expected_tasks
    
    # Test with realistic GRI report data
    gri_data = {
        "supplier_data": {
            "company_name": "Sustainability Reports Ltd.",
            "data_type": "gri_report",
            "report_data": {
                "reference": "GRI 2023-001",
                "reportingPeriod": "2022-01-01/2022-12-31",
                "content": {
                    "economic": {
                        "ec101": {
                            "description": "Direct economic value generated and distributed",
                            "value": 5000000,
                            "unit": "USD"
                        }
                    },
                    "environmental": {
                        "en15": {
                            "description": "GHG emissions intensity",
                            "value": 0.25,
                            "unit": "tonnes CO2e / USD million revenue"
                        }
                    },
                    "social": {
                        "s101": {
                            "description": "New employee hires by gender",
                            "value": {"male": 45, "female": 55},
                            "unit": "employees"
                        }
                    }
                }
            }
        }
    }
    
    state2 = AppState(workflow_data=gri_data)
    result2 = ingestion_agent(state2)
    
    # Verify correct tasks for GRI report
    expected_tasks2 = [
        "validate_gri_report",
        "analyze_gri_data",
        "map_to_regulatory_frameworks"
    ]
    
    assert result2["task_queue"] == expected_tasks2