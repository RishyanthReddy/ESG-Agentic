"""
Integration tests for the upgraded Provenance Agent
"""

import pytest
import os
import hashlib
from src.agents.provenance import provenance_agent, ProvenanceError
from src.state.models import AppState, vLEICredential
from src.tools.provenance import InfuraBlockchainTool


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_blockchain_logging_end_to_end():
    """Test end-to-end data logging to testnet"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Test Corp",
            "test_data": "integration test",
            "timestamp": "2023-01-01T00:00:00Z"
        }
    )
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # Run the agent
    result = provenance_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "data_logged_to_blockchain"
    assert "blockchain_log" in result
    assert len(result["blockchain_log"]) == 1
    
    # Verify log entry structure
    log_entry = result["blockchain_log"][0]
    assert "data_id" in log_entry
    assert "data_hash" in log_entry
    assert "transaction_hash" in log_entry
    assert "timestamp" in log_entry
    assert "status" in log_entry
    
    # Verify data_id matches credential id
    assert log_entry["data_id"] == str(credential.id)
    
    # Verify data_hash is a valid SHA-256 hash
    assert len(log_entry["data_hash"]) == 64  # SHA-256 hex digest length
    assert all(c in '0123456789abcdef' for c in log_entry["data_hash"])
    
    # Verify transaction_hash format
    assert log_entry["transaction_hash"].startswith("0x")
    assert len(log_entry["transaction_hash"]) == 66  # 0x + 64 hex chars
    
    # Verify status
    assert log_entry["status"] == "success"


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_data_integrity_hash_consistency():
    """Verify hash consistency across workflow"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "test_metric": 42,
            "test_string": "integration test data",
            "test_boolean": True
        }
    )
    
    # Manually calculate expected hash
    credential_json = credential.model_dump_json()
    expected_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # Run the agent
    result = provenance_agent(state)
    
    # Verify the hash in blockchain log matches our manual calculation
    log_entry = result["blockchain_log"][0]
    assert log_entry["data_hash"] == expected_hash


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_performance_impact_measurement():
    """Measure blockchain logging overhead"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    import time
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "large_data": "x" * 1000,  # Create a larger credential
            "test_metrics": list(range(100)),
            "nested_structure": {
                "level1": {
                    "level2": {
                        "data": "test data"
                    }
                }
            }
        }
    )
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # Measure execution time
    start_time = time.time()
    result = provenance_agent(state)
    end_time = time.time()
    
    execution_time = end_time - start_time
    
    # Verify successful execution
    assert result["workflow_status"] == "data_logged_to_blockchain"
    
    # Log execution time for monitoring (in a real test, we might assert this is under a threshold)
    print(f"Blockchain logging took {execution_time:.2f} seconds")
    
    # Verify reasonable execution time (should complete within 30 seconds)
    assert execution_time < 30


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_recovery_during_blockchain_failures():
    """Test behavior during blockchain failures"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # Test with valid configuration first
    result = provenance_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "data_logged_to_blockchain"
    assert len(result["blockchain_log"]) >= 1


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_audit_trail_creation():
    """Verify complete audit trail creation"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create multiple test credentials
    credentials = [
        vLEICredential(
            issuer="did:example:issuer1",
            subject="did:example:subject1",
            claims={"test": f"data-{i}"}
        ) for i in range(3)
    ]
    
    blockchain_log = []
    
    # Process each credential
    for credential in credentials:
        state = AppState(
            current_credential=credential,
            blockchain_log=blockchain_log,  # Pass existing log
            config={"blockchain_private_key": private_key}
        )
        
        result = provenance_agent(state)
        blockchain_log = result["blockchain_log"]  # Update log for next iteration
    
    # Verify complete audit trail
    assert len(blockchain_log) == 3
    
    # Verify each entry has required fields
    for i, log_entry in enumerate(blockchain_log):
        assert "data_id" in log_entry
        assert "data_hash" in log_entry
        assert "transaction_hash" in log_entry
        assert "timestamp" in log_entry
        assert "status" in log_entry
        assert log_entry["status"] == "success"
        assert log_entry["data_id"] == str(credentials[i].id)


if __name__ == "__main__":
    pytest.main([__file__])