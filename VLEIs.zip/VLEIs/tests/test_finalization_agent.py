"""
Unit tests for the Finalization Agent
"""

import pytest
from unittest.mock import Mock, patch
from datetime import datetime
from src.agents.core import finalization_agent
from src.state.models import AppState, vLEICredential
from src.tools.registry import ToolRegistry
from src.tools.verification import SignReportTool


@pytest.fixture
def mock_state():
    """Create a mock AppState for testing"""
    return AppState(
        workflow_status="processing",
        task_queue=["finalization_task"],
        credentials=[
            vLEICredential(
                issuer="did:example:issuer",
                subject="did:example:subject",
                claims={
                    "organization": {
                        "name": "Test Company"
                    }
                }
            )
        ]
    )


def test_finalization_agent_success(mock_state):
    """Test successful finalization agent execution"""
    # Mock the regulatory reporting agent result
    mock_report_result = {
        "workflow_status": "regulatory_report_generated",
        "regulatory_report": {
            "id": "test-report-id",
            "company_name": "Test Company",
            "report_year": 2023,
            "generated_date": datetime.now().isoformat(),
            "frameworks": {
                "gri": {
                    "report_id": "gri-report-id",
                    "standards": ["GRI 101"],
                    "mapped_data": {"test": "data"}
                }
            }
        }
    }
    
    # Mock the sign tool result
    mock_sign_result = {
        "signed": True,
        "report_hash": "test_hash",
        "signature_info": {
            "signature": "test_signature",
            "key_id": "test_key"
        },
        "timestamp_info": {
            "timestamp": datetime.now().isoformat()
        }
    }
    
    # Mock the reporting module
    with patch('src.agents.reporting.regulatory_reporting_agent', return_value=mock_report_result):
        with patch.object(SignReportTool, 'run', return_value=mock_sign_result):
            # Run the finalization agent
            result = finalization_agent(mock_state)
            
            # Verify the result
            assert result["workflow_status"] == "finalized"
            assert "signed_report" in result
            assert result["signed_report"]["signed"] == True
            assert len(result["task_queue"]) == 0  # Task queue should be cleared
            
            # Verify agent trace was updated
            assert len(result["agent_trace"]) > 0
            last_trace = result["agent_trace"][-1]
            assert last_trace["agent"] == "finalization_agent"
            assert last_trace["action"] == "workflow_finalized"


def test_finalization_agent_report_generation_failure(mock_state):
    """Test finalization agent when report generation fails"""
    # Mock the regulatory reporting agent to raise an exception
    with patch('src.agents.reporting.regulatory_reporting_agent', side_effect=Exception("Report generation failed")):
        # Run the finalization agent
        result = finalization_agent(mock_state)
        
        # Verify the result
        assert result["workflow_status"] == "finalization_failed"
        assert "errors" in result
        assert len(result["errors"]) > 0
        assert "Report generation failed" in result["errors"][-1]
        
        # Verify agent trace was updated
        assert len(result["agent_trace"]) > 0
        last_trace = result["agent_trace"][-1]
        assert last_trace["agent"] == "finalization_agent"
        assert last_trace["action"] == "finalization_failed"


def test_finalization_agent_signing_failure(mock_state):
    """Test finalization agent when report signing fails"""
    # Mock the regulatory reporting agent result
    mock_report_result = {
        "workflow_status": "regulatory_report_generated",
        "regulatory_report": {
            "id": "test-report-id",
            "company_name": "Test Company",
            "report_year": 2023
        }
    }
    
    # Mock the sign tool to fail
    mock_sign_result = {
        "signed": False,
        "error": "Signing failed due to invalid key"
    }
    
    with patch('src.agents.reporting.regulatory_reporting_agent', return_value=mock_report_result):
        with patch.object(SignReportTool, 'run', return_value=mock_sign_result):
            # Run the finalization agent
            result = finalization_agent(mock_state)
            
            # Verify the result
            assert result["workflow_status"] == "finalization_failed"
            assert "errors" in result
            assert len(result["errors"]) > 0
            assert "Report signing failed" in result["errors"][-1]
            
            # Verify agent trace was updated
            assert len(result["agent_trace"]) > 0
            last_trace = result["agent_trace"][-1]
            assert last_trace["agent"] == "finalization_agent"
            assert last_trace["action"] == "finalization_failed"


def test_finalization_agent_with_empty_state():
    """Test finalization agent with minimal state"""
    # Create a minimal state
    state = AppState()
    
    # Mock the regulatory reporting agent result
    mock_report_result = {
        "workflow_status": "regulatory_report_generated",
        "regulatory_report": {
            "id": "test-report-id",
            "company_name": "Unknown Company",
            "report_year": 2023
        }
    }
    
    # Mock the sign tool result
    mock_sign_result = {
        "signed": True,
        "report_hash": "test_hash",
        "signature_info": {
            "signature": "test_signature",
            "key_id": "test_key"
        },
        "timestamp_info": {
            "timestamp": datetime.now().isoformat()
        }
    }
    
    with patch('src.agents.reporting.regulatory_reporting_agent', return_value=mock_report_result):
        with patch.object(SignReportTool, 'run', return_value=mock_sign_result):
            # Run the finalization agent
            result = finalization_agent(state)
            
            # Verify the result
            assert result["workflow_status"] == "finalized"
            assert "signed_report" in result
            assert result["signed_report"]["signed"] == True
            assert len(result["task_queue"]) == 0  # Task queue should be cleared


def test_finalization_agent_tool_registration():
    """Test that SignReportTool is properly registered if not found in registry"""
    # Create a state
    state = AppState()
    
    # Clear the registry
    registry = ToolRegistry()
    registry.clear()
    
    # Mock the regulatory reporting agent result
    mock_report_result = {
        "workflow_status": "regulatory_report_generated",
        "regulatory_report": {
            "id": "test-report-id",
            "company_name": "Test Company",
            "report_year": 2023
        }
    }
    
    # Mock the sign tool result
    mock_sign_result = {
        "signed": True,
        "report_hash": "test_hash",
        "signature_info": {
            "signature": "test_signature",
            "key_id": "test_key"
        },
        "timestamp_info": {
            "timestamp": datetime.now().isoformat()
        }
    }
    
    with patch('src.agents.reporting.regulatory_reporting_agent', return_value=mock_report_result):
        with patch.object(SignReportTool, 'run', return_value=mock_sign_result):
            # Run the finalization agent
            result = finalization_agent(state)
            
            # Verify the result
            assert result["workflow_status"] == "finalized"
            
            # Verify the tool was registered
            registered_tool = registry.get_tool("sign_report")
            assert registered_tool is not None
            assert registered_tool.name == "sign_report"


if __name__ == "__main__":
    pytest.main([__file__])