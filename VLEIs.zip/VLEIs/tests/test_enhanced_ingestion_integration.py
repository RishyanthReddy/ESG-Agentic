"""
Integration tests for enhanced ingestion functionality including multi-format data handling.
"""

import pytest
import pandas as pd
from io import BytesIO
import time

from src.tools.ingestion import FileUploadTool, FileUploadError
from src.agents.ingestion import ingestion_agent, IngestionError
from src.state.models import AppState


class TestEnhancedIngestionIntegration:
    """Integration test suite for enhanced ingestion functionality."""

    def test_multi_format_processing(self):
        """Test CSV, Excel, and JSON format handling."""
        tool = FileUploadTool()
        
        # Test CSV processing
        csv_data = """company_name,data_type,revenue,employees
        CSVCorp,esg_data,1000000,500"""
        csv_result = tool.run(csv_data.encode('utf-8'), "data.csv")
        assert csv_result["company_name"] == "CSVCorp"
        assert csv_result["data_type"] == "esg_data"
        
        # Test Excel processing
        df = pd.DataFrame({
            'company_name': ['ExcelCorp'],
            'data_type': ['gri_report'],
            'report_year': [2023]
        })
        excel_buffer = BytesIO()
        df.to_excel(excel_buffer, index=False)
        excel_buffer.seek(0)
        excel_result = tool.run(excel_buffer.getvalue(), "data.xlsx")
        assert excel_result["company_name"] == "ExcelCorp"
        assert excel_result["data_type"] == "gri_report"

    def test_large_file_performance(self):
        """Test performance with large datasets."""
        tool = FileUploadTool()
        
        # Create a large CSV dataset
        large_data = pd.DataFrame({
            'company_name': [f'Company{i}' for i in range(1000)],
            'data_type': ['esg_data'] * 1000,
            'revenue': [i * 1000 for i in range(1000)],
            'employees': [i * 5 for i in range(1000)]
        })
        
        csv_buffer = BytesIO()
        large_data.to_csv(csv_buffer, index=False)
        csv_content = csv_buffer.getvalue()
        
        # Measure processing time
        start_time = time.time()
        result = tool.run(csv_content, "large_data.csv")
        end_time = time.time()
        
        # Should process in reasonable time (less than 5 seconds)
        assert (end_time - start_time) < 5.0
        assert result["company_name"] == "Company0"  # First row

    def test_data_quality_validation(self):
        """Test end-to-end data quality validation."""
        # Test with the ingestion agent processing file upload data
        state = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": b"company_name,data_type,revenue\nQualityCorp,esg_data,500000",
                    "name": "quality_test.csv"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Process with ingestion agent
        result = ingestion_agent(state)
        
        # Check data quality in the result
        assert result["workflow_status"] == "data_ingested"
        processed_data = result["workflow_data"]["processed_supplier_data"]
        assert "processing_timestamp" in processed_data
        assert "processing_id" in processed_data
        assert processed_data["company_name"] == "QualityCorp"

    def test_workflow_integration(self):
        """Test integration with downstream agents through task queue generation."""
        # Test with file upload data
        state = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": b"company_name,data_type,issuer\nVLEICorp,vlei_credential,TestIssuer",
                    "name": "vlei_data.xlsx"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Process with ingestion agent
        result = ingestion_agent(state)
        
        # Check that tasks are properly generated for downstream processing
        assert result["workflow_status"] == "data_ingested"
        assert len(result["task_queue"]) > 0
        assert "verify_vlei_credential" in result["task_queue"]
        assert "log_to_blockchain" in result["task_queue"]

    def test_error_recovery(self):
        """Test recovery from file processing errors."""
        # Test with empty file
        state_empty = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": b"",
                    "name": "empty.csv"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Should raise IngestionError for empty file
        with pytest.raises(IngestionError):
            ingestion_agent(state_empty)
        
        # Test with valid file after error
        state_valid = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": b"company_name,data_type\nValidCorp,esg_data",
                    "name": "valid.csv"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Should process successfully
        result = ingestion_agent(state_valid)
        assert result["workflow_status"] == "data_ingested"
        processed_data = result["workflow_data"]["processed_supplier_data"]
        assert processed_data["company_name"] == "ValidCorp"

    def test_format_mapping_integration(self):
        """Test integration with custom format mapping."""
        tool = FileUploadTool()
        
        # Test with custom column names
        csv_data = """CompanyName,DataType,AnnualRevenue,NumEmployees
        MapCorp,esg_data,2000000,1000"""
        
        format_mapping = {
            "CompanyName": "company_name",
            "DataType": "data_type",
            "AnnualRevenue": "revenue",
            "NumEmployees": "employees"
        }
        
        result = tool.run(
            csv_data.encode('utf-8'),
            "mapped_data.csv",
            format_mapping=format_mapping
        )
        
        assert result["company_name"] == "MapCorp"
        assert result["data_type"] == "esg_data"
        assert "revenue" in result
        assert "employees" in result

    def test_end_to_end_ingestion_workflow(self):
        """Test complete end-to-end ingestion workflow."""
        # Create a complete workflow from file upload to task generation
        csv_data = """company_name,data_type,carbon_emissions,renewable_percentage
        EndToEndCorp,esg_data,1200,45"""
        
        # Initial state with file upload
        initial_state = AppState(
            workflow_data={
                "file_upload_data": {
                    "content": csv_data.encode('utf-8'),
                    "name": "end_to_end_test.csv"
                }
            },
            workflow_status="pending",
            task_queue=[],
            agent_trace=[]
        )
        
        # Run through ingestion agent
        final_state_updates = ingestion_agent(initial_state)
        
        # Verify complete workflow
        assert final_state_updates["workflow_status"] == "data_ingested"
        
        # Check processed data
        processed_data = final_state_updates["workflow_data"]["processed_supplier_data"]
        assert processed_data["company_name"] == "EndToEndCorp"
        assert processed_data["data_type"] == "esg_data"
        assert "carbon_emissions" in processed_data
        assert "renewable_percentage" in processed_data
        
        # Check task queue generation
        task_queue = final_state_updates["task_queue"]
        assert len(task_queue) > 0
        assert "process_esg_data" in task_queue
        assert "verify_data_sources" in task_queue
        
        # Check agent trace
        agent_trace = final_state_updates["agent_trace"]
        assert len(agent_trace) > 0
        assert agent_trace[0]["agent"] == "ingestion_agent"
        assert "tasks_generated" in agent_trace[0]


if __name__ == "__main__":
    pytest.main([__file__])