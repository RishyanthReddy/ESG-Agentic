"""
Unit tests for Phase 1 Integration Test components
"""

import pytest
from pathlib import Path


def test_integration_test_file_exists():
    """Test that the Phase 1 integration test file exists"""
    test_path = Path("tests/test_phase1_integration.py")
    assert test_path.exists(), "Phase 1 integration test file not found"


def test_integration_test_imports():
    """Test that the integration test has required imports"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    required_imports = [
        "import pytest",
        "import httpx",
        "import asyncio",
        "from src.state.models import AppState"
    ]
    
    for import_stmt in required_imports:
        assert import_stmt in content, f"Required import missing: {import_stmt}"


def test_integration_test_functions():
    """Test that the integration test has required functions"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    required_functions = [
        "test_end_to_end_integration_stream_endpoint",
        "test_end_to_end_integration_with_minimal_data",
        "test_data_flow_validation",
        "test_performance_validation",
        "test_credential_verification_status",
        "test_blockchain_transaction_hash_validity",
        "test_error_scenario_handling"
    ]
    
    for func_name in required_functions:
        assert f"def {func_name}" in content, f"Required function missing: {func_name}"


def test_tech_stack_implementation():
    """Test that the tech stack components are implemented"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    # Check for HTTP Testing with httpx
    assert "httpx.AsyncClient" in content, "httpx.AsyncClient not used for HTTP testing"
    
    # Check for Response Validation with Pydantic
    assert "AppState(**final_state)" in content, "Pydantic model validation not implemented"
    
    # Check for pytest assertions
    assert "assert" in content, "pytest assertions not used"
    
    # Check for live service testing
    assert "http_client.post" in content, "Live service testing not implemented"
    
    # Check for blockchain validation
    assert "transaction_hash" in content, "Blockchain transaction validation not implemented"


def test_test_data_generation():
    """Test that test data generation is implemented"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    # Check for test data
    assert "TEST_SUPPLIER_DATA" in content, "Test data not generated"
    assert "TEST_CONFIG" in content, "Test configuration not generated"
    
    # Check for proper data structure
    assert '"company_name"' in content, "Company name not in test data"
    assert '"esg_rating"' in content, "ESG rating not in test data"


def test_response_parsing():
    """Test that JSON response parsing and validation is implemented"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    # Check for JSON response parsing
    assert "response.json()" in content, "JSON response parsing not implemented"
    
    # Check for response validation
    assert "response_data[\"status\"]" in content, "Response validation not implemented"
    assert "final_state" in content, "Final state validation not implemented"


def test_assertion_logic():
    """Test that individual assertion components are implemented"""
    test_path = Path("tests/test_phase1_integration.py")
    
    with open(test_path, "r") as f:
        content = f.read()
    
    # Check for various assertion types
    assert "assert response.status_code" in content, "Status code assertion not implemented"
    assert "assert response_data[\"status\"]" in content, "Response status assertion not implemented"
    assert "assert app_state.workflow_status" in content, "Workflow status assertion not implemented"
    assert "assert isinstance" in content, "Type assertion not implemented"


if __name__ == "__main__":
    pytest.main([__file__])