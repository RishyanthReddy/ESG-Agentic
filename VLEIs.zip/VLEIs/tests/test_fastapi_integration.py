"""
Integration tests for state functionality
"""

import pytest
import json
from src.state.models import AppState, vLEICredential


def test_state_persistence_simulation():
    """Test state persistence simulation"""
    # Create initial state
    initial_state = AppState(
        workflow_status="step1",
        workflow_step=1,
        workflow_data={"input": "test_data"}
    )
    
    # Serialize to JSON (simulating storage)
    state_json = initial_state.model_dump_json()
    
    # Deserialize from JSON (simulating retrieval)
    retrieved_state = AppState.model_validate_json(state_json)
    
    # Verify the states match
    assert retrieved_state.workflow_status == initial_state.workflow_status
    assert retrieved_state.workflow_step == initial_state.workflow_step
    assert retrieved_state.workflow_data == initial_state.workflow_data


def test_cross_model_relationships():
    """Test relationships between vLEICredential and AppState"""
    # Create a credential
    credential = vLEICredential(
        issuer="did:web:example.com",
        subject="did:web:company.com",
        claims={"name": "Test Company"}
    )
    
    # Create state with the credential
    state = AppState(
        current_credential=credential,
        credentials=[credential],
        workflow_status="credential_created"
    )
    
    # Verify the relationship
    assert state.current_credential is not None
    assert state.current_credential.issuer == credential.issuer
    assert state.current_credential.subject == credential.subject
    assert len(state.credentials) == 1
    assert state.credentials[0].claims == credential.claims
    
    # Test serialization of the relationship
    state_data = state.model_dump(mode="json")
    assert "current_credential" in state_data
    assert len(state_data["credentials"]) == 1