"""
Unit tests for CSRD compliance validation
"""

import pytest
import uuid
from datetime import datetime
from src.state.models import CSRDReport, vLEICredential
from src.agents.transformation_utils import transform_to_csrd


class TestCSRDCompliance:
    """Test CSRD compliance mapping and validation"""

    def test_csrd_requirement_mapping_accuracy(self):
        """Test CSRD requirement mapping accuracy with sample data"""
        # Create a sample credential with comprehensive ESG data
        credential = vLEICredential(
            issuer="test-issuer",
            subject="test-subject",
            claims={
                "organization": {
                    "name": "Test Company",
                    "description": "A test company for ESG reporting",
                    "sector": "Technology"
                },
                "business_model": {
                    "overview": "Digital services provider",
                    "value_chain": ["manufacturing", "distribution", "retail"]
                },
                "materiality_assessment": {
                    "process": "Stakeholder engagement and impact assessment",
                    "impacts": ["carbon_emissions", "data_privacy"],
                    "risks": ["regulatory_changes", "reputation_damage"]
                },
                "environmental": {
                    "ghg_emissions": {
                        "scope1": 1000,
                        "scope2": 500,
                        "scope3": 15000
                    },
                    "climate_risks": {
                        "physical_risks": ["flooding"],
                        "transition_risks": ["policy_changes"]
                    },
                    "pollution": {
                        "sox": 10,
                        "nox": 5
                    },
                    "water": {
                        "consumption": 50000,
                        "discharge": 45000
                    },
                    "biodiversity": {
                        "impact_areas": ["forests", "wetlands"],
                        "protection_measures": ["conservation_programs"]
                    },
                    "resources": {
                        "materials_used": 100000,
                        "circularity_rate": 0.3
                    }
                },
                "social": {
                    "workforce": {
                        "demographics": {
                            "total_employees": 1000,
                            "gender_distribution": {"male": 0.6, "female": 0.4}
                        },
                        "health_safety": {
                            "incident_rate": 0.05,
                            "programs": ["safety_training"]
                        }
                    },
                    "value_chain_workers": {
                        "assessment": "Supplier code of conduct compliance",
                        "improvements": ["training_programs"]
                    },
                    "communities": {
                        "impact": ["local_development", "infrastructure"],
                        "engagement": ["community_meetings", "investment"]
                    },
                    "products": {
                        "safety": "Product safety testing conducted",
                        "complaints": 5
                    }
                },
                "governance": {
                    "body": {
                        "sustainability_committee": True,
                        "responsibilities": ["oversight", "reporting"]
                    },
                    "remuneration": {
                        "ceo_pay": 1000000,
                        "sustainability_linked": 0.2
                    },
                    "prevention": {
                        "due_diligence": "Human rights due diligence process",
                        "monitoring": ["audits", "assessments"]
                    },
                    "breaches": {
                        "incidents": 2,
                        "corrective_actions": ["training", "policy_update"]
                    }
                },
                "targets": {
                    "climate": {
                        "net_zero_year": 2040,
                        "emission_reduction_2030": 0.5
                    }
                }
            }
        )
        
        # Transform to CSRD format
        csrd_data = transform_to_csrd(credential)
        
        # Verify key mappings
        assert "business_model" in csrd_data
        assert "greenhouse_gas_emissions" in csrd_data
        assert "workforce_demographics" in csrd_data
        assert "governance_body" in csrd_data
        
        # Verify specific data mappings
        assert csrd_data["greenhouse_gas_emissions"]["scope1"] == 1000
        assert csrd_data["greenhouse_gas_emissions"]["scope2"] == 500
        assert csrd_data["greenhouse_gas_emissions"]["scope3"] == 15000
        assert csrd_data["workforce_demographics"]["total_employees"] == 1000
        assert csrd_data["governance_body"]["sustainability_committee"] is True

    def test_updated_csrd_schema_validation(self):
        """Test updated CSRD schema validation with detailed fields"""
        # Create a comprehensive CSRD report with all new fields
        csrd_report = CSRDReport(
            company_name="Test Company",
            report_year=2024,
            business_model={
                "description": "A sample business model description",
                "value_chain": ["manufacturing", "distribution", "retail"]
            },
            double_materiality_assessment={
                "process": "Stakeholder engagement and impact assessment",
                "impacts": ["carbon_emissions", "data_privacy"]
            },
            greenhouse_gas_emissions={
                "scope1": 1000,
                "scope2": 500,
                "scope3": 15000
            },
            workforce_demographics={
                "total_employees": 1000,
                "gender_distribution": {"male": 0.6, "female": 0.4}
            },
            governance_body={
                "sustainability_committee": True,
                "responsibilities": ["oversight", "reporting"]
            }
        )
        
        # Verify the report is valid
        assert csrd_report.company_name == "Test Company"
        assert csrd_report.report_year == 2024
        assert "scope1" in csrd_report.greenhouse_gas_emissions
        assert "sustainability_committee" in csrd_report.governance_body

    def test_compliance_documentation_completeness(self):
        """Test compliance documentation completeness"""
        # Check that our mapping document exists and contains required sections
        import os
        mapping_doc_path = "docs/compliance/csrd_mapping.md"
        assert os.path.exists(mapping_doc_path), "CSRD mapping document should exist"
        
        with open(mapping_doc_path, 'r') as f:
            content = f.read()
            
        # Check for key sections in the documentation
        assert "# EU CSRD Compliance Mapping Document" in content
        assert "Double Materiality Principle" in content
        assert "Cross-Cutting Disclosures" in content
        assert "Environmental Disclosures" in content
        assert "Social Disclosures" in content
        assert "Governance Disclosures" in content

    def test_csrd_compliance_validation_algorithms(self):
        """Test CSRD compliance validation algorithms"""
        # Create a minimal CSRD report
        csrd_report = CSRDReport(
            company_name="Test Company",
            report_year=2024
        )
        
        # Create a complete CSRD report
        complete_csrd_report = CSRDReport(
            company_name="Test Company",
            report_year=2024,
            business_model={"description": "Business model description"},
            double_materiality_assessment={"process": "Materiality assessment process"},
            impact_management_process={"description": "Impact management process"},
            due_diligence={"process": "Due diligence process"},
            policies={"sustainability_policy": "Sustainability policy description"},
            greenhouse_gas_emissions={"scope1": 1000, "scope2": 500},
            climate_risks_and_opportunities={"risks": ["physical", "transition"]},
            climate_targets_and_actions={"net_zero_year": 2040},
            pollution_emissions={"sox": 10, "nox": 5},
            water_consumption_and_discharge={"consumption": 50000},
            biodiversity_impact={"areas": ["forests"]},
            resource_consumption={"materials": 100000},
            workforce_demographics={"total_employees": 1000},
            workforce_health_safety={"incident_rate": 0.05},
            value_chain_workers_assessment={"description": "Value chain assessment"},
            community_impact_assessment={"impacts": ["local_development"]},
            product_safety={"testing": "Product safety testing"},
            governance_body={"committee": True},
            executive_remuneration={"ceo_pay": 1000000},
            prevention_of_adverse_impacts={"due_diligence": "Human rights due diligence"},
            breach_reporting={"incidents": 2}
        )
        
        # Verify both reports are valid CSRD reports
        assert isinstance(csrd_report, CSRDReport)
        assert isinstance(complete_csrd_report, CSRDReport)
        
        # Check that the complete report has more fields populated
        assert complete_csrd_report.business_model is not None
        assert complete_csrd_report.greenhouse_gas_emissions is not None
        assert complete_csrd_report.governance_body is not None


if __name__ == "__main__":
    pytest.main([__file__])