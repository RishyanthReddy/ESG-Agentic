"""
Phase 2 Integration Test - Comprehensive end-to-end test validating live, integrated architecture with enhanced features

This test validates that the entire system works correctly in an integrated manner,
including API endpoints, LangGraph workflow execution, agent coordination,
credential processing, blockchain interactions, data validation, path highlighting,
and anomaly detection.
"""

import pytest
import httpx
import asyncio
import os
from typing import Dict, Any
import re
from src.state.models import AppState


# Test data for integration testing with ESG metrics for anomaly detection
TEST_SUPPLIER_DATA = {
    "company_name": "Test Company Ltd",
    "esg_rating": "AA",
    "report_year": 2023,
    "revenue": 1000000,
    "industry": "Technology",
    "employees": 500,
    "hq_location": "New York, NY",
    "scope3_data": [
        {
            "timestamp": "2023-01-01T00:00:00Z",
            "value": 100.0,
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.95
        },
        {
            "timestamp": "2023-01-02T00:00:00Z",
            "value": 102.5,
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.94
        },
        {
            "timestamp": "2023-01-03T00:00:00Z",
            "value": 98.7,
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.96
        },
        {
            "timestamp": "2023-01-04T00:00:00Z",
            "value": 101.2,
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.93
        },
        {
            "timestamp": "2023-01-05T00:00:00Z",
            "value": 250.0,  # Anomalous value
            "metric_type": "co2_emissions",
            "supplier_id": "supplier_1",
            "confidence_score": 0.95
        }
    ]
}

# Configuration for testing
TEST_CONFIG = {
    "processing_timeout": 30,
    "verification_depth": "standard",
    "report_format": "json"
}


@pytest.fixture(scope="module")
def api_base_url():
    """Get the base URL for the API"""
    return os.getenv("API_BASE_URL", "http://localhost:8000")


@pytest.fixture(scope="module")
def http_client():
    """Create an HTTP client for testing"""
    client = httpx.AsyncClient(timeout=30.0)
    yield client
    asyncio.run(client.aclose())


@pytest.mark.asyncio
async def test_end_to_end_integration_stream_endpoint(http_client, api_base_url):
    """
    Test the complete end-to-end integration using the /ingest/stream endpoint.
    This test validates:
    1. API endpoint accessibility
    2. JSON data ingestion
    3. LangGraph workflow execution
    4. Pydantic model validation of response
    5. Final status validation
    6. Agent trace validation
    7. Blockchain transaction hash validation
    8. Path highlighting in visualization
    9. Anomaly detection results
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse JSON response
    response_data = response.json()
    
    # Validate response structure
    assert "status" in response_data, "Response missing 'status' field"
    assert "message" in response_data, "Response missing 'message' field"
    assert "final_state" in response_data, "Response missing 'final_state' field"
    
    # Validate response values
    assert response_data["status"] == "success", f"Expected status 'success', got '{response_data['status']}'"
    assert len(response_data["message"]) > 0, "Response message is empty"
    
    # Validate final state structure using Pydantic model
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate final status
    assert app_state.workflow_status in ["completed", "success", "finished"], \
        f"Expected completed workflow status, got '{app_state.workflow_status}'"
    
    # Validate agent trace
    assert isinstance(app_state.agent_trace, list), "Agent trace should be a list"
    assert len(app_state.agent_trace) > 0, "Agent trace should not be empty"
    
    # Validate that agent trace contains expected information
    for trace_entry in app_state.agent_trace:
        assert "agent" in trace_entry, "Agent trace entry missing 'agent' field"
        assert "action" in trace_entry, "Agent trace entry missing 'action' field"
        assert "timestamp" in trace_entry, "Agent trace entry missing 'timestamp' field"
    
    # Validate blockchain transaction information
    assert isinstance(app_state.blockchain_log, list), "Blockchain log should be a list"
    
    # If there are blockchain transactions, validate their format
    for transaction in app_state.blockchain_log:
        assert "transaction_hash" in transaction, "Blockchain log entry missing 'transaction_hash' field"
        assert "timestamp" in transaction, "Blockchain log entry missing 'timestamp' field"
        assert "status" in transaction, "Blockchain log entry missing 'status' field"
        
        # Validate transaction hash format (should be a hex string of 64 characters)
        transaction_hash = transaction["transaction_hash"]
        assert isinstance(transaction_hash, str), "Transaction hash should be a string"
        assert re.match(r"^0x[a-fA-F0-9]{64}$", transaction_hash), \
            f"Invalid transaction hash format: {transaction_hash}"
    
    # Validate processing results
    assert isinstance(app_state.processing_results, dict), "Processing results should be a dict"
    assert len(app_state.processing_results) >= 0, "Processing results should exist"
    
    # Validate visualization assets with path highlighting
    assert app_state.visualization_assets is not None, "Visualization assets should exist"
    assert isinstance(app_state.visualization_assets, dict), "Visualization assets should be a dict"
    
    # Check for provenance graph data
    assert "provenance_graph" in app_state.visualization_assets, "Provenance graph should be in visualization assets"
    provenance_graph = app_state.visualization_assets["provenance_graph"]
    assert "node_count" in provenance_graph, "Provenance graph should have node_count"
    assert "edge_count" in provenance_graph, "Provenance graph should have edge_count"
    assert provenance_graph["node_count"] > 0, "Provenance graph should have nodes"
    assert provenance_graph["edge_count"] > 0, "Provenance graph should have edges"
    
    # Check for serialized graph data
    assert "serialized_graph" in app_state.visualization_assets, "Serialized graph should be in visualization assets"
    serialized_graph = app_state.visualization_assets["serialized_graph"]
    assert "json_data" in serialized_graph, "Serialized graph should have json_data"
    assert "format" in serialized_graph, "Serialized graph should have format"
    assert len(serialized_graph["json_data"]) > 0, "Serialized graph JSON data should not be empty"
    
    # Check for highlighted path (path highlighting feature)
    assert "highlighted_path" in app_state.visualization_assets, "Highlighted path should be in visualization assets"
    highlighted_path = app_state.visualization_assets["highlighted_path"]
    # The highlighted path can be None if no path was found, but the field should exist
    assert highlighted_path is None or isinstance(highlighted_path, list), "Highlighted path should be None or a list"
    
    # Validate that no errors occurred
    assert isinstance(app_state.errors, list), "Errors should be a list"
    # Note: Some warnings or non-critical errors might be acceptable
    # but critical errors should fail the workflow
    
    # Validate task queue is empty (indicating workflow completion)
    assert isinstance(app_state.task_queue, list), "Task queue should be a list"
    # In a completed workflow, the task queue should be empty or contain only completion markers


@pytest.mark.asyncio
async def test_end_to_end_integration_with_anomaly_detection(http_client, api_base_url):
    """
    Test the end-to-end integration with focus on anomaly detection capabilities.
    """
    # Prepare test data with scope3_data for anomaly detection
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse JSON response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Check for anomaly detection in processing results
    assert "anomaly_detection" in app_state.processing_results, "Anomaly detection results should be in processing results"
    anomaly_results = app_state.processing_results["anomaly_detection"]
    
    # Validate anomaly detection results structure
    assert isinstance(anomaly_results, dict), "Anomaly detection results should be a dict"
    assert "success" in anomaly_results, "Anomaly detection results should have success field"
    assert anomaly_results["success"] is True, "Anomaly detection should be successful"
    
    # Validate anomaly detection metrics
    assert "anomaly_count" in anomaly_results, "Anomaly detection results should have anomaly_count"
    assert "total_points" in anomaly_results, "Anomaly detection results should have total_points"
    assert "anomaly_percentage" in anomaly_results, "Anomaly detection results should have anomaly_percentage"
    assert "results" in anomaly_results, "Anomaly detection results should have results"
    
    # Check that we detected at least one anomaly (because we injected one)
    assert anomaly_results["anomaly_count"] >= 1, "Should detect at least one anomaly in the test data"
    assert anomaly_results["total_points"] == 5, "Should have processed 5 data points"
    assert anomaly_results["anomaly_percentage"] > 0, "Should have non-zero anomaly percentage"
    
    # Validate individual anomaly results
    individual_results = anomaly_results["results"]
    assert isinstance(individual_results, list), "Individual anomaly results should be a list"
    assert len(individual_results) == 5, "Should have 5 individual results"
    
    # Check that the anomalous value was detected
    # Find the result with the anomalous value (250.0)
    anomalous_result = None
    for result in individual_results:
        if result["value"] == 250.0:
            anomalous_result = result
            break
    
    assert anomalous_result is not None, "Should find the anomalous data point"
    assert anomalous_result["is_anomaly"] is True, "The anomalous data point should be flagged as an anomaly"
    assert anomalous_result["anomaly_score"] > 0.8, "The anomalous data point should have a high anomaly score"


@pytest.mark.asyncio
async def test_data_flow_validation(http_client, api_base_url):
    """
    Test that data flows correctly through the enhanced system.
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse JSON response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate that all phases of the workflow were executed
    agent_names = [trace["agent"] for trace in app_state.agent_trace]
    
    # Check for key agents in the trace
    expected_agents = ["ingestion_agent", "verification_agent", "carbon_calculation_agent", "visualization_agent"]
    for agent in expected_agents:
        assert agent in agent_names, f"Expected {agent} in agent trace"
    
    # Validate that the workflow data contains the original supplier data
    assert "supplier_data" in app_state.workflow_data, "Workflow data should contain supplier_data"
    supplier_data = app_state.workflow_data["supplier_data"]
    assert supplier_data["company_name"] == "Test Company Ltd", "Company name should match"
    
    # Validate that scope3_data was processed
    assert "scope3_data" in supplier_data, "Supplier data should contain scope3_data"
    scope3_data = supplier_data["scope3_data"]
    assert len(scope3_data) == 5, "Should have 5 scope3 data points"


@pytest.mark.asyncio
async def test_performance_validation(http_client, api_base_url):
    """
    Test the performance of the enhanced system.
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Validate response time (should be under 30 seconds based on client timeout)
    assert response.elapsed.total_seconds() < 30, "Response should be received within 30 seconds"
    
    # Parse JSON response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate that all processing was completed in a reasonable time
    # Check that we have results from all expected processing steps
    assert len(app_state.processing_results) > 0, "Should have processing results"
    assert len(app_state.agent_trace) > 0, "Should have agent trace entries"
    assert len(app_state.blockchain_log) >= 0, "Should have blockchain log entries"


@pytest.mark.asyncio
async def test_regression_validation(http_client, api_base_url):
    """
    Test that Phase 1 functionality remains intact with Phase 2 enhancements.
    """
    # Prepare minimal test data (similar to Phase 1 test)
    minimal_data = {
        "supplier_data": {
            "company_name": "Minimal Test Company"
        }
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=minimal_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse JSON response
    response_data = response.json()
    
    # Validate response structure (same as Phase 1)
    assert "status" in response_data, "Response missing 'status' field"
    assert "message" in response_data, "Response missing 'message' field"
    assert "final_state" in response_data, "Response missing 'final_state' field"
    
    # Validate response values
    assert response_data["status"] == "success", f"Expected status 'success', got '{response_data['status']}'"
    
    # Validate final state structure using Pydantic model
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate final status
    assert app_state.workflow_status in ["completed", "success", "finished"], \
        f"Expected completed workflow status, got '{app_state.workflow_status}'"
    
    # Validate agent trace
    assert isinstance(app_state.agent_trace, list), "Agent trace should be a list"
    assert len(app_state.agent_trace) > 0, "Agent trace should not be empty"
    
    # Validate blockchain transaction information
    assert isinstance(app_state.blockchain_log, list), "Blockchain log should be a list"
    
    # Validate processing results
    assert isinstance(app_state.processing_results, dict), "Processing results should be a dict"
    
    # Validate that no critical errors occurred
    assert isinstance(app_state.errors, list), "Errors should be a list"


# Unit tests for individual components
def test_test_data_generation():
    """
    Test that comprehensive test data sets are generated correctly.
    """
    # Validate the structure of TEST_SUPPLIER_DATA
    assert isinstance(TEST_SUPPLIER_DATA, dict), "TEST_SUPPLIER_DATA should be a dict"
    assert "company_name" in TEST_SUPPLIER_DATA, "TEST_SUPPLIER_DATA should have company_name"
    assert "scope3_data" in TEST_SUPPLIER_DATA, "TEST_SUPPLIER_DATA should have scope3_data"
    
    # Validate scope3_data structure
    scope3_data = TEST_SUPPLIER_DATA["scope3_data"]
    assert isinstance(scope3_data, list), "scope3_data should be a list"
    assert len(scope3_data) == 5, "scope3_data should have 5 data points"
    
    # Validate individual data points
    for i, data_point in enumerate(scope3_data):
        assert isinstance(data_point, dict), f"Data point {i} should be a dict"
        assert "timestamp" in data_point, f"Data point {i} should have timestamp"
        assert "value" in data_point, f"Data point {i} should have value"
        assert "metric_type" in data_point, f"Data point {i} should have metric_type"
        assert "supplier_id" in data_point, f"Data point {i} should have supplier_id"
        assert "confidence_score" in data_point, f"Data point {i} should have confidence_score"


def test_mock_configuration():
    """
    Test that API mocking configuration is correct.
    """
    # This test ensures that pytest-httpx is properly installed and available
    try:
        import pytest_httpx
        assert pytest_httpx is not None, "pytest-httpx should be importable"
    except ImportError:
        pytest.fail("pytest-httpx is not installed or not importable")


if __name__ == "__main__":
    pytest.main([__file__])