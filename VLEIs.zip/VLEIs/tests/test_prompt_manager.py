"""
Unit tests for the PromptManager
"""

import pytest
import os
import tempfile
import yaml
from src.prompts import PromptManager, PromptError


def test_prompt_manager_singleton():
    """Test that PromptManager follows singleton pattern"""
    pm1 = PromptManager()
    pm2 = PromptManager()
    assert pm1 is pm2


def test_prompt_loading():
    """Test loading prompts from YAML file"""
    prompt_manager = PromptManager()
    
    # Check that prompts were loaded
    assert len(prompt_manager.prompts) > 0
    
    # Check that specific prompts exist
    assert "esg_data_reasoning" in prompt_manager.prompts
    assert "report_summary_generation" in prompt_manager.prompts
    assert "credential_validation" in prompt_manager.prompts
    
    # Check prompt structure
    prompt = prompt_manager.get_prompt("esg_data_reasoning")
    assert "name" in prompt
    assert "description" in prompt
    assert "template" in prompt


def test_template_rendering():
    """Test Jinja2 template processing"""
    prompt_manager = PromptManager()
    
    # Test rendering a simple prompt
    rendered = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 85},
        context="Test context"
    )
    
    assert isinstance(rendered, str)
    assert "score" in rendered
    assert "Test context" in rendered
    
    # Test rendering without optional context
    rendered = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 90}
    )
    
    assert isinstance(rendered, str)
    assert "score" in rendered


def test_cache_behavior():
    """Test prompt caching functionality"""
    prompt_manager = PromptManager()
    
    # Clear cache to start fresh
    prompt_manager.clear_cache()
    
    # Render a prompt
    rendered1 = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 85}
    )
    
    # Render the same prompt again
    rendered2 = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 85}
    )
    
    # Should get the same result
    assert rendered1 == rendered2


def test_error_handling_malformed_prompts():
    """Test handling of malformed prompts"""
    prompt_manager = PromptManager()
    
    # Test non-existent prompt
    with pytest.raises(PromptError):
        prompt_manager.get_prompt("non_existent_prompt")
    
    # Test rendering non-existent prompt
    with pytest.raises(PromptError):
        prompt_manager.render_prompt("non_existent_prompt")


def test_list_prompts():
    """Test listing available prompts"""
    prompt_manager = PromptManager()
    
    # Get list of prompts
    prompt_list = prompt_manager.list_prompts()
    
    # Check that it's a dictionary
    assert isinstance(prompt_list, dict)
    
    # Check that it contains expected prompts
    assert "esg_data_reasoning" in prompt_list
    assert "report_summary_generation" in prompt_list
    assert len(prompt_list) > 0


def test_get_prompt_names():
    """Test getting prompt names"""
    prompt_manager = PromptManager()
    
    # Get list of prompt names
    prompt_names = prompt_manager.get_prompt_names()
    
    # Check that it's a list
    assert isinstance(prompt_names, list)
    
    # Check that it contains expected prompts
    assert "esg_data_reasoning" in prompt_names
    assert "report_summary_generation" in prompt_names


def test_clear_cache():
    """Test clearing the prompt cache"""
    prompt_manager = PromptManager()
    
    # Render a prompt to populate cache
    prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 85}
    )
    
    # Clear cache
    prompt_manager.clear_cache()
    
    # Cache should be empty now
    assert len(prompt_manager._cache) == 0


def test_reload_prompts():
    """Test reloading prompts from file"""
    prompt_manager = PromptManager()
    
    # Store original prompt count
    original_count = len(prompt_manager.prompts)
    
    # Reload prompts
    prompt_manager.reload_prompts()
    
    # Count should be the same
    assert len(prompt_manager.prompts) == original_count


def test_complex_template_rendering():
    """Test rendering complex templates with lists and nested data"""
    prompt_manager = PromptManager()
    
    # Test with complex data structures
    rendered = prompt_manager.render_prompt(
        "report_summary_generation",
        report_content="Test report content",
        report_type="GRI",
        key_points=["Point 1", "Point 2", "Point 3"]
    )
    
    assert isinstance(rendered, str)
    assert "Test report content" in rendered
    assert "Point 1" in rendered
    assert "Point 2" in rendered
    assert "Point 3" in rendered


def test_prompt_structure_validation():
    """Test that all prompts have required structure"""
    prompt_manager = PromptManager()
    
    for prompt_key, prompt_data in prompt_manager.prompts.items():
        # All prompts should have these fields
        assert "name" in prompt_data, f"Prompt '{prompt_key}' missing 'name'"
        assert "description" in prompt_data, f"Prompt '{prompt_key}' missing 'description'"
        assert "template" in prompt_data, f"Prompt '{prompt_key}' missing 'template'"
        
        # Template should be a string
        assert isinstance(prompt_data["template"], str), f"Prompt '{prompt_key}' template is not a string"


def test_template_with_no_context():
    """Test rendering templates that don't require context"""
    prompt_manager = PromptManager()
    
    # This should work even with minimal context
    rendered = prompt_manager.render_prompt(
        "routing_decision",
        task_description="Test task"
    )
    
    assert isinstance(rendered, str)
    assert "Test task" in rendered