"""
Integration tests for the Climatiq API Tool
"""

import pytest
import os
from src.tools.esg import ClimatiqApiTool, ActivityData, ClimatiqError
from config import settings


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_live_api_testing():
    """Test Climatiq sandbox environment integration"""
    tool = ClimatiqApiTool()
    
    # Test with a simple activity (electricity)
    activity_data = ActivityData(
        activity_id="electricity-supply_grid-source_residual_mix",
        amount=100,
        unit="kwh",
        region="AU",
        data_version="^3"
    )
    
    result = tool.run(activity_data)
    
    # Verify result structure
    assert result["success"] is True
    assert "co2e" in result
    assert "co2e_unit" in result
    assert "activity_data" in result
    assert result["co2e"] >= 0
    assert result["co2e_unit"] == "kg"


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_calculation_accuracy():
    """Validate carbon calculation results"""
    tool = ClimatiqApiTool()
    
    # Test with a known activity
    activity_data = ActivityData(
        activity_id="electricity-supply_grid-source_residual_mix",
        amount=100,
        unit="kwh",
        region="AU",
        data_version="^3"
    )
    
    result = tool.run(activity_data)
    
    # Verify result is reasonable (electricity should produce CO2)
    assert result["success"] is True
    assert result["co2e"] > 0
    assert result["co2e_unit"] == "kg"
    
    # No changes needed here


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_performance_testing():
    """Test API response times and caching effectiveness"""
    import time
    
    tool = ClimatiqApiTool()
    
    # Test with an activity
    activity_data = ActivityData(
        activity_id="electricity-supply_grid-source_residual_mix",
        amount=50,
        unit="kwh",
        region="AU",
        data_version="^3"
    )
    
    # Measure first request (no cache)
    start_time = time.time()
    result1 = tool.run(activity_data)
    first_request_time = time.time() - start_time
    
    # Measure second request (should be cached)
    start_time = time.time()
    result2 = tool.run(activity_data)
    second_request_time = time.time() - start_time
    
    # Verify both requests succeeded
    assert result1["success"] is True
    assert result2["success"] is True
    
    # Second request should be faster (cached)
    assert second_request_time < first_request_time or second_request_time < 0.1
    
    # Results should be identical
    assert result1["co2e"] == result2["co2e"]


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_data_coverage():
    """Test various activity types and emission factors"""
    tool = ClimatiqApiTool()
    
    # Test with different regions
    test_cases = [
        {
            "activity_id": "electricity-supply_grid-source_residual_mix",
            "amount": 100,
            "unit": "kwh",
            "region": "AU",  # Australia
            "data_version": "^3"
        },
        {
            "activity_id": "electricity-supply_grid-source_residual_mix",
            "amount": 100,
            "unit": "kwh",
            "region": "GB",  # United Kingdom
            "data_version": "^3"
        }
    ]
    
    for test_case in test_cases:
        activity_data = ActivityData(**test_case)
        result = tool.run(activity_data)
        
        # Verify successful calculation
        assert result["success"] is True
        assert result["co2e"] >= 0
        assert result["co2e_unit"] == "kg"


@pytest.mark.skipif(
    not settings.CLIMATIQ_API_KEY,
    reason="CLIMATIQ_API_KEY not set in environment"
)
def test_error_recovery():
    """Test error handling and recovery"""
    tool = ClimatiqApiTool()
    
    # Test with invalid activity ID
    invalid_activity_data = ActivityData(
        activity_id="invalid_activity_id",
        amount=100,
        unit="kwh",
        region="US"
    )
    
    # Should raise ClimatiqError
    with pytest.raises(ClimatiqError):
        tool.run(invalid_activity_data)

    # Test with valid activity but invalid region
    activity_with_invalid_region = ActivityData(
        activity_id="electricity-energy_source_grid-average",
        amount=100,
        unit="kwh",
        region="INVALID_REGION"
    )
    
    # Should raise an error for invalid region
    with pytest.raises(ClimatiqError):
        tool.run(activity_with_invalid_region)


if __name__ == "__main__":
    pytest.main([__file__])