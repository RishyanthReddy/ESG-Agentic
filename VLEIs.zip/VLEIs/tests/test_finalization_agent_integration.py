"""
Integration tests for the Finalization Agent
"""

import pytest
import time
from datetime import datetime
from src.agents.core import finalization_agent
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport
from src.tools.registry import ToolRegistry
from src.tools.verification import SignReportTool
from src.agents.reporting import regulatory_reporting_agent

# Initialize tool registry once for tests that need it
@pytest.fixture
def tool_registry():
    """Fixture to set up a clean tool registry for each test"""
    registry = ToolRegistry()
    registry.clear()
    sign_tool = SignReportTool()
    registry.register_tool(sign_tool)
    return registry


def test_complete_finalization_workflow():
    """Test the complete finalization workflow"""
    # Create a comprehensive test state
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company",
                "description": "A test company for ESG reporting",
                "sector": "Technology",
                "countries": ["US", "CA"],
                "employee_count": 1000
            },
            "policies": {
                "environmental": "Environmental Policy Statement",
                "social": "Social Responsibility Policy"
            },
            "governance": {
                "board_oversight": "Board oversees climate risks",
                "ethics": "Code of Ethics Program"
            },
            "strategies": {
                "climate_risks": "Climate Risk Strategy",
                "resilience": "Climate Resilience Analysis"
            },
            "environmental": {
                "emissions": {"scope1": 1000, "scope2": 500},
                "energy": {"renewable_percentage": 30},
                "water": {"consumption": 50000}
            },
            "social": {
                "workforce": {"training_hours": 20000},
                "products": {"safety_incidents": 0},
                "data": {"breaches": 0}
            },
            "metrics": {
                "emissions": {"total_ghg": 1500},
                "intensity": {"ghg_per_employee": 1.5}
            },
            "targets": {
                "emission_reduction": "50% by 2030"
            }
        }
    )
    
    gri_report = GRIReport(
        company_name="Test Company",
        report_year=2023,
        data={
            "environmental": {
                "en15": {
                    "description": "GHG emissions intensity",
                    "value": 0.18,
                    "unit": "tonnes CO2e / USD million revenue"
                }
            }
        }
    )
    
    sasb_report = SASBReport(
        company_name="Test Company",
        report_year=2023,
        data={
            "environment": {
                "air_quality": {
                    "description": "Impacts from stationary combustion",
                    "metrics": ["Total GHG emissions: 8000 tonnes CO2e"]
                }
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential,
        credentials=[credential],
        gri_reports=[gri_report],
        sasb_reports=[sasb_report],
        workflow_status="processing"
    )
    
    # Run the finalization agent
    result = finalization_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "finalized"
    assert "signed_report" in result
    assert result["signed_report"]["signed"] == True
    assert "report_hash" in result["signed_report"]
    assert "signature_info" in result["signed_report"]
    assert "timestamp_info" in result["signed_report"]
    
    # Verify task queue is cleared
    assert len(result["task_queue"]) == 0
    
    # Verify agent trace
    assert len(result["agent_trace"]) > 0
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "finalization_agent"
    assert last_trace["action"] == "workflow_finalized"




def test_state_integrity():
    """Test final state consistency and completeness"""
    # Create initial state
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Integrity Test Company"
            }
        }
    )
    
    state = AppState(
        current_credential=credential,
        workflow_status="processing"
    )
    
    # Run the finalization agent
    result = finalization_agent(state)
    
    # Verify state integrity
    assert result["workflow_status"] == "finalized"
    
    # Verify task queue is properly cleared
    assert "task_queue" in result
    assert len(result["task_queue"]) == 0
    
    # Verify agent trace is properly maintained
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    
    # Verify signed report structure
    assert "signed_report" in result
    signed_report = result["signed_report"]
    assert "signed" in signed_report
    assert "report_hash" in signed_report
    assert "signature_info" in signed_report
    assert "timestamp_info" in signed_report
    assert signed_report["signed"] == True


def test_workflow_integration():
    """Test integration with overall ESG workflow"""
    # Create a state that simulates the end of an ESG workflow
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Workflow Integration Test Company",
                "sector": "Energy"
            }
        }
    )
    
    state = AppState(
        current_credential=credential,
        credentials=[credential],
        workflow_status="verification_completed",
        agent_trace=[
            {
                "agent": "credential_agent",
                "action": "credential_processed",
                "timestamp": datetime.now().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "timestamp": datetime.now().isoformat()
            }
        ]
    )
    
    # Run the finalization agent
    result = finalization_agent(state)
    
    # Verify workflow integration
    assert result["workflow_status"] == "finalized"
    
    # Verify the entire agent trace is maintained
    assert len(result["agent_trace"]) >= 3  # At least the 2 existing + 1 new
    
    # Verify the final agent was added to the trace
    final_trace = result["agent_trace"][-1]
    assert final_trace["agent"] == "finalization_agent"
    assert final_trace["action"] == "workflow_finalized"
    
    # Verify signed report is created
    assert "signed_report" in result
    assert result["signed_report"]["signed"] == True


if __name__ == "__main__":
    pytest.main([__file__])