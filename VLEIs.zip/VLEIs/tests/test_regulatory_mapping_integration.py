"""
Integration tests for the Regulatory Mapping functionality
"""

import pytest
from datetime import datetime
from src.agents.reporting import regulatory_reporting_agent
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport, TCFDReport, CSRDReport


def test_end_to_end_mapping():
    """Test complete regulatory report generation workflow"""
    # Create a comprehensive test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company",
                "description": "A test company for ESG reporting",
                "sector": "Technology",
                "countries": ["US", "CA"],
                "employee_count": 1000
            },
            "policies": {
                "environmental": "Environmental Policy Statement",
                "social": "Social Responsibility Policy"
            },
            "governance": {
                "board_oversight": "Board oversees climate risks",
                "ethics": "Code of Ethics Program"
            },
            "strategies": {
                "climate_risks": "Climate Risk Strategy",
                "resilience": "Climate Resilience Analysis"
            },
            "environmental": {
                "ghg_emissions": {"scope1": 1000, "scope2": 500},
                "energy": {"renewable_percentage": 30},
                "water": {"consumption": 50000}
            },
            "social": {
                "workforce": {"training_hours": 20000},
                "products": {"safety_incidents": 0},
                "data": {"breaches": 0}
            },
            "metrics": {
                "emissions": {"total_ghg": 1500},
                "intensity": {"ghg_per_employee": 1.5}
            },
            "targets": {
                "emission_reduction": "50% by 2030"
            }
        }
    )
    
    # Create initial state with a credential
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    
    # Verify all report types are created
    assert "gri_reports" in result
    assert "sasb_reports" in result
    assert "tcfd_reports" in result
    assert "csrd_reports" in result
    
    # Verify at least one report of each type is created
    assert len(result["gri_reports"]) >= 1
    assert len(result["sasb_reports"]) >= 1
    assert len(result["tcfd_reports"]) >= 1
    assert len(result["csrd_reports"]) >= 1
    
    # Verify the reports are of the correct types
    assert isinstance(result["gri_reports"][-1], GRIReport)
    assert isinstance(result["sasb_reports"][-1], SASBReport)
    assert isinstance(result["tcfd_reports"][-1], TCFDReport)
    assert isinstance(result["csrd_reports"][-1], CSRDReport)


def test_standard_compliance():
    """Test that generated reports comply with official standard schemas"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify regulatory report structure
    regulatory_report = result["regulatory_report"]
    assert "id" in regulatory_report
    assert "company_name" in regulatory_report
    assert "report_year" in regulatory_report
    assert "generated_date" in regulatory_report
    assert "frameworks" in regulatory_report
    assert "summary" in regulatory_report
    
    # Verify all frameworks are present with correct structure
    frameworks = regulatory_report["frameworks"]
    for framework in ["gri", "sasb", "tcfd", "csrd"]:
        assert framework in frameworks
        assert "report_id" in frameworks[framework]
        assert "standards" in frameworks[framework]
        assert "mapped_data" in frameworks[framework]
        assert "valid" in frameworks[framework]


def test_multi_standard_generation():
    """Test simultaneous generation of multiple standard reports"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify all four standards are generated
    mapping_result = result["processing_results"]["regulatory_mapping_result"]
    assert set(mapping_result["mapped_frameworks"]) == {"GRI", "SASB", "TCFD", "CSRD"}
    
    # Verify all four reports are created
    assert len(mapping_result["report_ids"]) == 4
    
    # Verify validation results for all standards
    validation_results = mapping_result["validation_results"]
    assert "gri" in validation_results
    assert "sasb" in validation_results
    assert "tcfd" in validation_results
    assert "csrd" in validation_results


def test_data_integrity():
    """Ensure no data loss during mapping transformations"""
    # Create a test credential with specific data
    company_name = "Test Company with Specific Name"
    employee_count = 1234
    
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": company_name,
                "employee_count": employee_count
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify data integrity across all reports
    assert result["regulatory_report"]["company_name"] == company_name
    
    frameworks = result["regulatory_report"]["frameworks"]
    for framework in ["gri", "sasb", "tcfd", "csrd"]:
        assert frameworks[framework]["mapped_data"]["company_name"] == company_name


if __name__ == "__main__":
    # This allows running the integration test directly
    test_end_to_end_mapping()
    test_standard_compliance()
    test_multi_standard_generation()
    test_data_integrity()
    print("All integration tests passed!")