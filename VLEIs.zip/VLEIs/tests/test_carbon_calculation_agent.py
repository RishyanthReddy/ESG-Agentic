"""
Unit tests for the Carbon Calculation Agent
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.esg import carbon_calculation_agent, CarbonCalculationError
from src.state.models import AppState
from src.tools.esg import ActivityData


def test_data_extraction_with_explicit_activity_data():
    """Test activity data identification from supplier data with explicit activity data"""
    # Create state with explicit activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": [
                    {
                        "activity_id": "electricity-energy_source_grid-average",
                        "amount": 1000,
                        "unit": "kwh",
                        "region": "US"
                    }
                ]
            }
        }
    )
    
    # Mock the Climatiq API tool
    mock_tool = Mock()
    mock_tool.run.return_value = {
        "success": True,
        "co2e": 0.5,
        "co2e_unit": "kg",
        "calculation_method": "ar4",
        "calculation_origin": "climatiq"
    }
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent
        result = carbon_calculation_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "carbon_calculation_completed"
        assert "processing_results" in result
        assert "carbon_metrics" in result["processing_results"]
        assert "carbon_footprints" in result["processing_results"]["carbon_metrics"]
        assert len(result["processing_results"]["carbon_metrics"]["carbon_footprints"]) == 1
        assert result["processing_results"]["carbon_metrics"]["carbon_footprints"][0]["co2e"] == 0.5
        assert result["processing_results"]["carbon_metrics"]["total_carbon_footprint"]["co2e"] == 0.5


def test_data_extraction_with_esg_metrics():
    """Test activity data identification from supplier data with ESG metrics"""
    # Create state with ESG metrics
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "esg_metrics": {
                    "energy_consumption_kwh": 1000,
                    "vehicle_distance_km": 500
                },
                "hq_location": "EU"
            }
        }
    )
    
    # Mock the Climatiq API tool
    mock_tool = Mock()
    mock_tool.run.side_effect = [
        {
            "success": True,
            "co2e": 0.5,
            "co2e_unit": "kg",
            "calculation_method": "ar4",
            "calculation_origin": "climatiq"
        },
        {
            "success": True,
            "co2e": 0.3,
            "co2e_unit": "kg",
            "calculation_method": "ar4",
            "calculation_origin": "climatiq"
        }
    ]
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent
        result = carbon_calculation_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "carbon_calculation_completed"
        assert "processing_results" in result
        assert "carbon_metrics" in result["processing_results"]
        assert "carbon_footprints" in result["processing_results"]["carbon_metrics"]
        assert len(result["processing_results"]["carbon_metrics"]["carbon_footprints"]) == 2
        assert result["processing_results"]["carbon_metrics"]["total_carbon_footprint"]["co2e"] == 0.8


def test_tool_integration_with_registry():
    """Test ClimatiqApiTool interactions with tool registry"""
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": {
                    "activity_id": "electricity-energy_source_grid-average",
                    "amount": 1000,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        }
    )
    
    # Mock the Climatiq API tool
    mock_tool = Mock()
    mock_tool.run.return_value = {
        "success": True,
        "co2e": 0.5,
        "co2e_unit": "kg",
        "calculation_method": "ar4",
        "calculation_origin": "climatiq"
    }
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent
        result = carbon_calculation_agent(state)
        
        # Verify tool was called with correct parameters
        mock_tool.run.assert_called_once()
        call_args = mock_tool.run.call_args[0][0]
        assert isinstance(call_args, ActivityData)
        assert call_args.activity_id == "electricity-energy_source_grid-average"
        assert call_args.amount == 1000
        assert call_args.unit == "kwh"
        assert call_args.region == "US"


def test_metrics_calculation():
    """Test carbon metrics aggregation"""
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": [
                    {
                        "activity_id": "electricity-energy_source_grid-average",
                        "amount": 1000,
                        "unit": "kwh",
                        "region": "US"
                    },
                    {
                        "activity_id": "passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                        "amount": 100,
                        "unit": "km",
                        "region": "US"
                    }
                ]
            }
        },
        processing_results={
            "existing_metric": "value"
        }
    )
    
    # Mock the Climatiq API tool
    mock_tool = Mock()
    mock_tool.run.side_effect = [
        {
            "success": True,
            "co2e": 0.5,
            "co2e_unit": "kg",
            "calculation_method": "ar4",
            "calculation_origin": "climatiq"
        },
        {
            "success": True,
            "co2e": 0.2,
            "co2e_unit": "kg",
            "calculation_method": "ar4",
            "calculation_origin": "climatiq"
        }
    ]
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent
        result = carbon_calculation_agent(state)
        
        # Verify carbon metrics aggregation
        assert "processing_results" in result
        assert "carbon_metrics" in result["processing_results"]
        assert "carbon_footprints" in result["processing_results"]["carbon_metrics"]
        assert len(result["processing_results"]["carbon_metrics"]["carbon_footprints"]) == 2
        assert result["processing_results"]["carbon_metrics"]["total_carbon_footprint"]["co2e"] == 0.7


def test_state_management():
    """Test processing_results field updates"""
    # Create initial state
    initial_processing_results = {
        "existing_metric": "value"
    }
    
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": {
                    "activity_id": "electricity-energy_source_grid-average",
                    "amount": 1000,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        },
        processing_results=initial_processing_results
    )
    
    # Mock the Climatiq API tool
    mock_tool = Mock()
    mock_tool.run.return_value = {
        "success": True,
        "co2e": 0.5,
        "co2e_unit": "kg",
        "calculation_method": "ar4",
        "calculation_origin": "climatiq"
    }
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent
        result = carbon_calculation_agent(state)
        
        # Verify state updates
        assert "processing_results" in result
        # Check that existing metrics are preserved
        assert "existing_metric" in result["processing_results"]
        assert result["processing_results"]["existing_metric"] == "value"
        # Check that new metrics are added
        assert "carbon_metrics" in result["processing_results"]
        assert "carbon_footprints" in result["processing_results"]["carbon_metrics"]


def test_no_supplier_data():
    """Test behavior when no supplier data is available"""
    # Create state without supplier data
    state = AppState(workflow_data={})
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_skipped"
    assert "errors" in result
    assert len(result["errors"]) > 0


def test_no_activity_data():
    """Test behavior when no activity data is available"""
    # Create state with supplier data but no activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp"
            }
        }
    )
    
    # Run the agent
    result = carbon_calculation_agent(state)
    
    # Verify the result
    assert result["workflow_status"] == "carbon_calculation_skipped"
    assert "errors" in result
    assert len(result["errors"]) > 0


def test_tool_error_handling():
    """Test error handling when Climatiq API tool fails"""
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Corp",
                "activity_data": {
                    "activity_id": "electricity-energy_source_grid-average",
                    "amount": 1000,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        }
    )
    
    # Mock the Climatiq API tool to raise an exception
    mock_tool = Mock()
    mock_tool.run.side_effect = Exception("API error")
    
    # Mock the tool registry
    with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
        mock_registry = Mock()
        mock_registry.get_tool.return_value = mock_tool
        mock_registry_class.return_value = mock_registry
        
        # Run the agent and expect it to raise an exception
        with pytest.raises(CarbonCalculationError):
            carbon_calculation_agent(state)


if __name__ == "__main__":
    pytest.main([__file__])