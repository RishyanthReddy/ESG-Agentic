"""
Test suite for real-time communication functionality.
This module tests:
1. WebSocket connection lifecycle and message handling
2. Polling logic and REST endpoint behavior
3. Message consistency between WebSocket and polling
4. Connection recovery and fallback logic
"""

import os
import sys
import pytest
import json
import time
import asyncio
from unittest.mock import patch, MagicMock
from fastapi import FastAPI
from fastapi.testclient import TestClient
from websockets.exceptions import ConnectionClosed

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.websockets.manager import ConnectionManager
from src.websockets.routes import router


def test_websocket_connection_lifecycle():
    """Test WebSocket connection lifecycle"""
    # Create a FastAPI app and include the WebSocket router
    app = FastAPI()
    app.include_router(router)
    
    # Create a test client
    client = TestClient(app)
    
    # Test that the WebSocket endpoint exists
    with client.websocket_connect("/api/v1/ws/dashboard") as websocket:
        # Receive initial connection message
        data = websocket.receive_text()
        assert data is not None
        assert "connection_ack" in data


def test_polling_endpoint():
    """Test polling REST endpoint"""
    # Create a FastAPI app and include the WebSocket router
    app = FastAPI()
    app.include_router(router)
    
    # Create a test client
    client = TestClient(app)
    
    # Test polling endpoint
    response = client.get("/api/v1/poll/dashboard", headers={"Authorization": "Bearer demo_token"})
    assert response.status_code == 200
    
    data = response.json()
    assert "status" in data
    assert "data" in data
    assert "timestamp" in data


def test_message_consistency():
    """Test message consistency between WebSocket and polling"""
    # Create a FastAPI app and include the WebSocket router
    app = FastAPI()
    app.include_router(router)
    
    # Create a test client
    client = TestClient(app)
    
    # Test polling endpoint first
    poll_response = client.get("/api/v1/poll/dashboard", headers={"Authorization": "Bearer demo_token"})
    assert poll_response.status_code == 200
    
    poll_data = poll_response.json()
    assert "status" in poll_data
    assert "data" in poll_data
    assert "timestamp" in poll_data
    
    # Test WebSocket connection
    with client.websocket_connect("/api/v1/ws/dashboard") as websocket:
        # Receive initial connection message
        data = websocket.receive_text()
        assert data is not None


def test_connection_manager():
    """Test connection manager functionality"""
    # Create connection manager
    manager = ConnectionManager()
    
    # Test initial state
    assert len(manager.active_connections) == 0
    assert manager.message_queue.empty()
    
    # Test message history (should be empty initially)
    history = asyncio.run(manager.get_message_history())
    assert isinstance(history, list)
    assert len(history) == 0


def test_message_broadcasting():
    """Test message broadcasting functionality"""
    # Create connection manager
    manager = ConnectionManager()
    
    # Test adding message to queue
    test_message = "Test message"
    asyncio.run(manager.broadcast(test_message))
    
    # Test retrieving message history
    history = asyncio.run(manager.get_message_history())
    assert len(history) >= 1
    # Note: We can't guarantee our test message is the only one due to concurrent tests


def test_cli_script_execution():
    """Test that CLI scripts execute without errors"""
    import subprocess
    import sys
    
    # Test websocket_client.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/websocket_client.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"websocket_client.py failed with return code {result.returncode}"
    
    # Test polling_client.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/polling_client.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"polling_client.py failed with return code {result.returncode}"
    
    # Test connection_manager.py
    result = subprocess.run(
        [sys.executable, "demo_scripts/connection_manager.py", "--help"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, f"connection_manager.py failed with return code {result.returncode}"


def test_authentication():
    """Test authentication for both WebSocket and polling"""
    # Create a FastAPI app and include the WebSocket router
    app = FastAPI()
    app.include_router(router)
    
    # Create a test client
    client = TestClient(app)
    
    # Test polling endpoint without authentication (should fail)
    response = client.get("/api/v1/poll/dashboard")
    assert response.status_code == 403  # Forbidden due to missing auth
    
    # Test polling endpoint with invalid authentication (should fail)
    response = client.get("/api/v1/poll/dashboard", headers={"Authorization": "Bearer invalid_token"})
    assert response.status_code == 401  # Unauthorized
    
    # Test polling endpoint with valid authentication (should succeed)
    response = client.get("/api/v1/poll/dashboard", headers={"Authorization": "Bearer demo_token"})
    assert response.status_code == 200


if __name__ == "__main__":
    pytest.main([__file__])