"""
Unit tests for the Stress Testing Framework

This module contains tests for verifying the correct configuration and
functionality of the Locust-based stress testing framework.
"""

import pytest
import sys
import os
from unittest.mock import patch, MagicMock

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

try:
    from locust.env import Environment
    from benchmarks.stress_test import ESGIngestionUser
    LOCUST_AVAILABLE = True
except ImportError as e:
    print(f"Locust import error: {e}")
    LOCUST_AVAILABLE = False


class TestStressFramework:
    """Test cases for the stress testing framework."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        if not LOCUST_AVAILABLE:
            pytest.skip("Locust not available")
        
        # Create a mock environment for testing
        self.environment = Environment()
        
        # Create a mock client for testing
        self.mock_client = MagicMock()
        
        # Create an instance of the user class
        self.user = ESGIngestionUser(self.environment)
        self.user.client = self.mock_client
        
        # Initialize sample data
        self.user.on_start()
    
    def test_user_initialization(self):
        """Test that the user class initializes correctly."""
        assert hasattr(self.user, 'wait_time')
        assert hasattr(self.user, 'sample_data')
        assert isinstance(self.user.sample_data, dict)
        assert 'data_points' in self.user.sample_data
        assert len(self.user.sample_data['data_points']) > 0
    
    def test_sample_data_generation(self):
        """Test that sample data is generated correctly."""
        sample_data = self.user._generate_sample_supplier_data()
        
        # Check structure
        assert isinstance(sample_data, dict)
        assert 'supplier_id' in sample_data
        assert 'company_name' in sample_data
        assert 'data_points' in sample_data
        assert 'metadata' in sample_data
        
        # Check data points
        assert isinstance(sample_data['data_points'], list)
        assert len(sample_data['data_points']) == 30  # 30 days of data
        
        # Check a data point
        if sample_data['data_points']:
            point = sample_data['data_points'][0]
            assert 'timestamp' in point
            assert 'co2_emissions' in point
            assert 'energy_usage' in point
            assert 'water_usage' in point
            assert 'supplier_id' in point
            assert 'location' in point
            assert 'confidence_score' in point
    
    def test_normal_ingestion_task(self):
        """Test the normal ingestion task."""
        # Mock the client's post method
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "message": "Data processed successfully"}
        self.mock_client.post.return_value.__enter__.return_value = mock_response
        
        # Run the task
        self.user.ingest_stream_normal()
        
        # Verify the post was called with correct parameters
        self.mock_client.post.assert_called_once()
        call_args = self.mock_client.post.call_args
        assert call_args[0][0] == "/ingest/stream"
        assert "json" in call_args[1]
        assert "name" in call_args[1]
        assert call_args[1]["name"] == "Ingest Stream - Normal"
    
    def test_large_ingestion_task(self):
        """Test the large ingestion task."""
        # Mock the client's post method
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success", "message": "Data processed successfully"}
        self.mock_client.post.return_value.__enter__.return_value = mock_response
        
        # Run the task
        self.user.ingest_stream_large()
        
        # Verify the post was called with correct parameters
        self.mock_client.post.assert_called_once()
        call_args = self.mock_client.post.call_args
        assert call_args[0][0] == "/ingest/stream"
        assert "json" in call_args[1]
        assert "name" in call_args[1]
        assert call_args[1]["name"] == "Ingest Stream - Large"
        
        # Check that the data has more points than normal
        json_data = call_args[1]["json"]
        assert "supplier_data" in json_data
        assert "data_points" in json_data["supplier_data"]
        assert len(json_data["supplier_data"]["data_points"]) == 90  # 90 days of data
    
    def test_health_check_task(self):
        """Test the health check task."""
        # Mock the client's get method
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "healthy", "timestamp": "2023-01-01T00:00:00Z"}
        self.mock_client.get.return_value.__enter__.return_value = mock_response
        
        # Run the task
        self.user.health_check()
        
        # Verify the get was called with correct parameters
        self.mock_client.get.assert_called_once()
        call_args = self.mock_client.get.call_args
        assert call_args[0][0] == "/health"
        assert "name" in call_args[1]
        assert call_args[1]["name"] == "Health Check"
    
    def test_request_success_event(self):
        """Test the request success event listener."""
        # This test ensures the event listener exists and can be called
        from benchmarks.stress_test import on_request_success
        
        # Call the event listener (should not raise an exception)
        try:
            on_request_success("POST", "Test Request", 100, 1024)
        except Exception as e:
            pytest.fail(f"on_request_success raised an exception: {e}")
    
    def test_request_failure_event(self):
        """Test the request failure event listener."""
        # This test ensures the event listener exists and can be called
        from benchmarks.stress_test import on_request_failure
        
        # Call the event listener (should not raise an exception)
        try:
            on_request_failure("POST", "Test Request", 100, 1024, Exception("Test error"))
        except Exception as e:
            pytest.fail(f"on_request_failure raised an exception: {e}")


if __name__ == "__main__":
    pytest.main([__file__])