"""
Integration tests for CSRD compliance validation
"""

import pytest
import uuid
from datetime import datetime
from src.state.models import AppState, vLEICredential, CSRDReport
from src.agents.reporting import regulatory_reporting_agent


class TestCSRDIntegration:
    """Integration tests for CSRD compliance"""

    def test_end_to_end_compliance(self):
        """Test complete CSRD compliance validation workflow"""
        # Create a sample credential with ESG data
        credential = vLEICredential(
            issuer="test-issuer",
            subject="test-subject",
            claims={
                "organization": {
                    "name": "Test Company",
                    "description": "A test company for ESG reporting",
                    "sector": "Technology"
                },
                "business_model": {
                    "overview": "Digital services provider",
                    "value_chain": ["manufacturing", "distribution", "retail"]
                },
                "materiality_assessment": {
                    "process": "Stakeholder engagement and impact assessment",
                    "impacts": ["carbon_emissions", "data_privacy"],
                    "risks": ["regulatory_changes", "reputation_damage"]
                },
                "environmental": {
                    "ghg_emissions": {
                        "scope1": 1000,
                        "scope2": 500,
                        "scope3": 15000
                    },
                    "climate_risks": {
                        "physical_risks": ["flooding"],
                        "transition_risks": ["policy_changes"]
                    }
                },
                "social": {
                    "workforce": {
                        "demographics": {
                            "total_employees": 1000,
                            "gender_distribution": {"male": 0.6, "female": 0.4}
                        }
                    }
                },
                "governance": {
                    "body": {
                        "sustainability_committee": True,
                        "responsibilities": ["oversight", "reporting"]
                    }
                }
            }
        )
        
        # Create initial app state
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Run the regulatory reporting agent
        result = regulatory_reporting_agent(state)
        
        # Verify that the result contains CSRD report data
        assert "csrd_reports" in result
        assert len(result["csrd_reports"]) > 0
        
        # Verify that the regulatory report contains CSRD framework data
        assert "regulatory_report" in result
        assert result["regulatory_report"] is not None
        assert "frameworks" in result["regulatory_report"]
        assert "csrd" in result["regulatory_report"]["frameworks"]
        
        # Verify CSRD report validation
        csrd_framework = result["regulatory_report"]["frameworks"]["csrd"]
        assert "valid" in csrd_framework
        assert "mapped_data" in csrd_framework

    def test_regulatory_reporting_generation(self):
        """Test CSRD report generation and validation"""
        # Create a sample credential
        credential = vLEICredential(
            issuer="test-issuer",
            subject="test-subject",
            claims={
                "organization": {
                    "name": "Test Company",
                    "description": "A test company for ESG reporting"
                },
                "environmental": {
                    "ghg_emissions": {
                        "scope1": 1000,
                        "scope2": 500
                    }
                }
            }
        )
        
        # Create app state
        state = AppState(
            current_credential=credential
        )
        
        # Run the regulatory reporting agent
        result = regulatory_reporting_agent(state)
        
        # Verify CSRD report generation
        assert "csrd_reports" in result
        assert len(result["csrd_reports"]) > 0
        
        # Verify the structure of the generated CSRD report
        csrd_report = result["csrd_reports"][0]
        assert isinstance(csrd_report, CSRDReport)
        assert csrd_report.company_name == "Test Company"
        assert csrd_report.greenhouse_gas_emissions is not None

    def test_documentation_quality(self):
        """Validate compliance documentation accuracy"""
        # Check that mapping document exists and contains key elements
        import os
        mapping_doc_path = "docs/compliance/csrd_mapping.md"
        assert os.path.exists(mapping_doc_path), "CSRD mapping document should exist"
        
        with open(mapping_doc_path, 'r') as f:
            content = f.read()
            
        # Check for required sections
        assert "Double Materiality Principle" in content
        assert "Cross-Cutting Disclosures" in content
        assert "Environmental Disclosures" in content
        assert "Social Disclosures" in content
        assert "Governance Disclosures" in content
        
        # Check for ESRS standards references
        assert "ESRS E1" in content
        assert "ESRS S1" in content
        assert "ESRS G1" in content

    def test_ongoing_monitoring(self):
        """Test continuous CSRD compliance monitoring"""
        # Create initial state with multiple credentials
        credential1 = vLEICredential(
            issuer="test-issuer-1",
            subject="test-subject-1",
            claims={
                "organization": {"name": "Company 1"},
                "environmental": {"ghg_emissions": {"scope1": 1000}}
            }
        )
        
        credential2 = vLEICredential(
            issuer="test-issuer-2",
            subject="test-subject-2",
            claims={
                "organization": {"name": "Company 2"},
                "environmental": {"ghg_emissions": {"scope1": 2000}}
            }
        )
        
        state = AppState(
            credentials=[credential1, credential2]
        )
        
        # Run regulatory reporting for multiple credentials
        result1 = regulatory_reporting_agent(AppState(current_credential=credential1))
        result2 = regulatory_reporting_agent(AppState(current_credential=credential2))
        
        # Verify reports are generated for both
        assert "csrd_reports" in result1
        assert "csrd_reports" in result2
        assert len(result1["csrd_reports"]) > 0
        assert len(result2["csrd_reports"]) > 0
        
        # Verify different companies
        assert result1["csrd_reports"][0].company_name == "Company 1"
        assert result2["csrd_reports"][0].company_name == "Company 2"

    def test_external_validation(self):
        """Test external CSRD compliance verification"""
        # Create a credential with data that should comply with CSRD requirements
        credential = vLEICredential(
            issuer="test-issuer",
            subject="test-subject",
            claims={
                "organization": {
                    "name": "Test Company"
                },
                "business_model": {
                    "description": "Digital services provider"
                },
                "materiality_assessment": {
                    "process": "Stakeholder engagement and impact assessment"
                },
                "environmental": {
                    "ghg_emissions": {
                        "scope1": 1000,
                        "scope2": 500,
                        "scope3": 15000
                    }
                },
                "governance": {
                    "body": {
                        "sustainability_committee": True
                    }
                }
            }
        )
        
        # Create app state and run reporting agent
        state = AppState(current_credential=credential)
        result = regulatory_reporting_agent(state)
        
        # Verify that the CSRD report is marked as valid
        regulatory_report = result["regulatory_report"]
        csrd_framework = regulatory_report["frameworks"]["csrd"]
        
        # The report should be valid according to our schema
        assert csrd_framework["valid"] is True
        
        # Verify key data points are present
        mapped_data = csrd_framework["mapped_data"]
        assert "business_model" in mapped_data
        assert "greenhouse_gas_emissions" in mapped_data
        assert "governance_body" in mapped_data


if __name__ == "__main__":
    pytest.main([__file__])