"""
Unit tests for LLM Orchestration in Master Router
"""

import pytest
from unittest.mock import patch, MagicMock
from src.agents.core import master_orchestrator, llm_orchestrator, rule_based_routing, RoutingError
from src.state.models import AppState, vLEICredential
from src.llm.interface import LLMInterface, GeminiLLMInterface


class TestLLMOrchestrator:
    """Test cases for LLM-based orchestration"""
    
    def test_rule_based_routing(self):
        """Test rule-based fallback routing logic"""
        # Test credential-related tasks
        assert rule_based_routing("verify credential") == "credential_agent"
        assert rule_based_routing("validate credential") == "credential_agent"
        assert rule_based_routing("check credential") == "credential_agent"
        
        # Test report-related tasks
        assert rule_based_routing("generate report") == "reporting_agent"
        assert rule_based_routing("create report") == "reporting_agent"
        assert rule_based_routing("produce report") == "reporting_agent"
        
        # Test default fallback
        assert rule_based_routing("unknown task") == "credential_agent"
    
    def test_llm_orchestrator(self):
        """Test LLM-based routing logic"""
        # Create a mock state
        state = AppState()
        
        # Test with a credential task
        agent_name = llm_orchestrator("verify vlei credential", state, "test-request-id")
        assert isinstance(agent_name, str)
        # The mock implementation returns "credential_agent" for credential tasks
        assert agent_name in ["credential_agent", "reporting_agent"]
    
    @patch('src.agents.core.GeminiLLMInterface')
    def test_master_orchestrator_with_llm_success(self, mock_llm_interface):
        """Test master orchestrator with successful LLM routing"""
        # Configure the mock
        mock_instance = MagicMock()
        mock_instance.determine_routing_path.return_value = "credential_agent"
        mock_llm_interface.return_value = mock_instance
        
        # Create state with tasks
        state = AppState(
            task_queue=["verify_vlei_credential", "generate_report"]
        )
        
        # Test routing
        result = master_orchestrator(state)
        assert result == "credential_agent"
        assert len(state.task_queue) == 1  # Task should be popped
        
        # Verify LLM was called
        mock_instance.determine_routing_path.assert_called_once()
    
    @patch('src.agents.core.GeminiLLMInterface')
    def test_master_orchestrator_with_llm_failure(self, mock_llm_interface):
        """Test master orchestrator with LLM failure falling back to rule-based routing"""
        # Configure the mock to raise an exception
        mock_llm_interface.side_effect = Exception("LLM unavailable")
        
        # Create state with tasks
        state = AppState(
            task_queue=["verify_vlei_credential"]
        )
        
        # Test routing - should fallback to rule-based routing
        result = master_orchestrator(state)
        assert result == "credential_agent"  # Rule-based routing result
        assert len(state.task_queue) == 0  # Task should be popped
    
    def test_master_orchestrator_empty_queue(self):
        """Test master orchestrator with empty task queue"""
        state = AppState(task_queue=[])
        result = master_orchestrator(state)
        assert result == "__end__"
    
    def test_master_orchestrator_invalid_task_name(self):
        """Test master orchestrator with invalid task name"""
        # Create a state with an invalid task (non-string)
        state = AppState()
        state.task_queue = [123]  # Invalid task type
        
        # This should raise a RoutingError when we try to process it
        with pytest.raises(RoutingError, match="Task name must be a string"):
            master_orchestrator(state)
    
    def test_master_orchestrator_empty_task_name(self):
        """Test master orchestrator with empty task name"""
        state = AppState(task_queue=[""])  # Empty task name
        with pytest.raises(RoutingError):
            master_orchestrator(state)


class TestLLMInterface:
    """Test cases for LLM Interface"""
    
    def test_llm_interface_abstract_methods(self):
        """Test that LLMInterface enforces abstract methods"""
        # This should raise TypeError because it's an abstract class
        with pytest.raises(TypeError):
            LLMInterface()
    
    def test_gemini_llm_interface_implementation(self):
        """Test concrete implementation of LLM interface"""
        interface = GeminiLLMInterface()
        
        # Test that all abstract methods are implemented
        assert hasattr(interface, 'reason_about_esg_data')
        assert hasattr(interface, 'determine_routing_path')
        assert hasattr(interface, 'assess_data_complexity')
        
        # Test method calls
        assert callable(interface.reason_about_esg_data)
        assert callable(interface.determine_routing_path)
        assert callable(interface.assess_data_complexity)


if __name__ == "__main__":
    pytest.main([__file__])