"""
Unit tests for the Provenance Agent
"""

import pytest
from unittest.mock import Mock, patch
from src.agents.provenance import provenance_agent, ProvenanceError
from src.state.models import AppState, vLEICredential
from src.tools.provenance import InfuraBlockchainTool


def test_provenance_agent_logic():
    """Test provenance agent workflow logic"""
    # Create a mock credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create initial state with a credential
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": "test-key"}
    )
    
    # Mock the InfuraBlockchainTool
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class:
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0x123456789abcdef",
            "message": "Data successfully logged to blockchain"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        # Run the agent
        result = provenance_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "data_logged_to_blockchain"
        assert "blockchain_log" in result
        assert len(result["blockchain_log"]) == 1
        assert result["blockchain_log"][0]["transaction_hash"] == "0x123456789abcdef"
        assert result["blockchain_log"][0]["data_id"] == str(credential.id)


def test_provenance_agent_with_credentials_list():
    """Test provenance agent when using credentials list instead of current_credential"""
    # Create a mock credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create initial state with credentials list but no current_credential
    state = AppState(
        credentials=[credential],
        config={"blockchain_private_key": "test-key"}
    )
    
    # Mock the InfuraBlockchainTool
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class:
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0xabcdef123456789",
            "message": "Data successfully logged to blockchain"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        # Run the agent
        result = provenance_agent(state)
        
        # Verify the result
        assert result["workflow_status"] == "data_logged_to_blockchain"
        assert "blockchain_log" in result
        assert len(result["blockchain_log"]) == 1
        assert result["blockchain_log"][0]["transaction_hash"] == "0xabcdef123456789"


def test_provenance_agent_missing_data():
    """Test provenance agent when no data is available to log"""
    # Create initial state with no credentials
    state = AppState(
        config={"blockchain_private_key": "test-key"}
    )
    
    # Run the agent and expect it to raise an error
    result = provenance_agent(state)
    
    # Verify error was added to state
    assert result["workflow_status"] == "blockchain_logging_failed"
    assert "errors" in result
    assert len(result["errors"]) > 0
    assert "No data found to log to blockchain" in result["errors"][0]


def test_provenance_agent_missing_private_key():
    """Test provenance agent when private key is missing"""
    # Create a mock credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create initial state without private key
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent and expect it to raise an error
    result = provenance_agent(state)
    
    # Verify error was added to state
    assert result["workflow_status"] == "blockchain_logging_failed"
    assert "errors" in result
    assert len(result["errors"]) > 0
    assert "Blockchain private key not found in state configuration" in result["errors"][0]


@patch('src.tools.registry.ToolRegistry.get_tool')
def test_provenance_agent_tool_registry_integration(mock_get_tool):
    """Test provenance agent integration with ToolRegistry"""
    # Create a mock credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": "test-key"}
    )
    
    # Mock the ToolRegistry to return a tool
    mock_tool = Mock()
    mock_tool.run.return_value = {
        "success": True,
        "transaction_hash": "0x987654321fedcba",
        "message": "Data successfully logged to blockchain"
    }
    mock_get_tool.return_value = mock_tool
    
    # Run the agent
    result = provenance_agent(state)
    
    # Verify the tool registry was called
    mock_get_tool.assert_called_once_with("infura_blockchain")
    
    # Verify the result
    assert result["workflow_status"] == "data_logged_to_blockchain"
    assert result["blockchain_log"][0]["transaction_hash"] == "0x987654321fedcba"


@patch('src.tools.registry.ToolRegistry.get_tool')
def test_provenance_agent_tool_creation_when_not_registered(mock_get_tool):
    """Test provenance agent creates tool when not found in registry"""
    # Create a mock credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": "test-key"}
    )
    
    # Mock the ToolRegistry to return None (tool not registered)
    mock_get_tool.return_value = None
    
    # Mock the InfuraBlockchainTool
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class:
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0xabcdefabcdef",
            "message": "Data successfully logged to blockchain"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        # Run the agent
        result = provenance_agent(state)
        
        # Verify the tool registry was called
        mock_get_tool.assert_called_once_with("infura_blockchain")
        
        # Verify a new tool instance was created
        mock_tool_class.assert_called_once()
        
        # Verify the result
        assert result["workflow_status"] == "data_logged_to_blockchain"
        assert result["blockchain_log"][0]["transaction_hash"] == "0xabcdefabcdef"