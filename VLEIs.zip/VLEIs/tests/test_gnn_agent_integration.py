"""
Integration tests for the GNN Modeling Agent
"""

import pytest
import time
from src.agents.modeling import gnn_modeling_agent
from src.state.models import AppState


def test_workflow_integration():
    """Test agent in complete workflow context"""
    # Create initial state with realistic data
    state = AppState(
        workflow_status="processing",
        task_queue=["gnn_modeling_task"],
        processing_results={
            "previous_analysis": "completed"
        }
    )
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify the result contains expected fields
    assert "workflow_status" in result
    assert "agent_trace" in result
    assert "processing_results" in result
    
    # Verify workflow status was updated
    assert result["workflow_status"] == "gnn_modeling_placeholder_executed"
    
    # Verify agent trace was updated
    assert len(result["agent_trace"]) > 0
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "gnn_modeling_agent"
    
    # Verify processing results were updated
    assert "gnn_modeling" in result["processing_results"]
    gnn_results = result["processing_results"]["gnn_modeling"]
    assert gnn_results["status"] == "placeholder"


def test_state_flow():
    """Validate state flows correctly through agent"""
    # Create initial state
    initial_state = AppState(
        workflow_status="initial",
        processing_results={"step_1": "completed"}
    )
    
    # Store initial counts
    initial_trace_count = len(initial_state.agent_trace)
    initial_processing_results_count = len(initial_state.processing_results)
    
    # Call the agent
    result = gnn_modeling_agent(initial_state)
    
    # Verify state elements are preserved and extended
    assert len(result["agent_trace"]) > initial_trace_count
    
    # Verify existing data is preserved
    assert result["processing_results"]["step_1"] == "completed"


def test_performance_impact():
    """Measure placeholder agent overhead"""
    # Create initial state
    state = AppState()
    
    # Measure execution time
    start_time = time.time()
    result = gnn_modeling_agent(state)
    end_time = time.time()
    
    execution_time = end_time - start_time
    
    # Verify execution completed successfully
    assert result["workflow_status"] == "gnn_modeling_placeholder_executed"
    
    # Verify performance is acceptable (should be very fast for placeholder)
    assert execution_time < 1.0  # Should complete in under 1 second


def test_future_compatibility():
    """Ensure architecture supports future GNN addition"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify the agent documents its future capabilities
    last_trace = result["agent_trace"][-1]
    assert "future_capabilities" in last_trace
    assert isinstance(last_trace["future_capabilities"], list)
    assert len(last_trace["future_capabilities"]) > 0
    
    # Verify the processing results indicate placeholder status but future intent
    gnn_results = result["processing_results"]["gnn_modeling"]
    assert gnn_results["status"] == "placeholder"
    assert "Graph Neural Network" in gnn_results["intended_for"]


def test_documentation_validation():
    """Verify clear documentation of future capabilities"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Check that the agent's docstring content is reflected in behavior
    last_trace = result["agent_trace"][-1]
    
    # Verify key concepts from the docstring are present
    assert "intended_purpose" in last_trace
    assert "Graph Neural Network" in last_trace["intended_purpose"]
    
    # Verify future capabilities are documented
    capabilities = last_trace["future_capabilities"]
    capability_keywords = [
        "Graph Neural Networks",
        "ESG data",
        "relationships",
        "patterns",
        "anomalies",
        "Predict",
        "regulatory compliance",
        "multi-dimensional"
    ]
    
    # Check that most keywords are covered in capabilities
    found_keywords = 0
    for keyword in capability_keywords:
        if any(keyword in cap for cap in capabilities):
            found_keywords += 1
    
    # At least 70% of keywords should be found
    assert found_keywords >= len(capability_keywords) * 0.7


def test_consistent_behavior_under_load():
    """Test consistent behavior when called multiple times"""
    results = []
    
    # Call the agent multiple times
    for i in range(10):
        state = AppState(
            workflow_status=f"test_{i}",
            processing_results={"iteration": i}
        )
        result = gnn_modeling_agent(state)
        results.append(result)
    
    # Verify all results have consistent structure
    for result in results:
        assert result["workflow_status"] == "gnn_modeling_placeholder_executed"
        assert "agent_trace" in result
        assert "processing_results" in result
        assert "gnn_modeling" in result["processing_results"]
        
        # Verify the last trace entry is for this agent
        last_trace = result["agent_trace"][-1]
        assert last_trace["agent"] == "gnn_modeling_agent"


def test_integration_with_existing_agents():
    """Test that the GNN agent integrates well with other agents"""
    # This test simulates how the GNN agent would work in a sequence with other agents
    
    # Start with initial state
    state = AppState(
        workflow_status="initial",
        task_queue=[]
    )
    
    # Simulate processing by another agent that adds a task for GNN modeling
    intermediate_state = {
        **state.model_dump(),
        "workflow_status": "data_prepared",
        "task_queue": ["gnn_modeling_task"],
        "processing_results": {
            **state.processing_results,
            "data_preparation": "completed"
        }
    }
    
    # Convert back to AppState for the agent
    app_state = AppState(**intermediate_state)
    
    # Call the GNN modeling agent
    result = gnn_modeling_agent(app_state)
    
    # Verify the agent processed the state correctly
    assert result["workflow_status"] == "gnn_modeling_placeholder_executed"
    assert "data_preparation" in result["processing_results"]
    assert len(result["agent_trace"]) > len(app_state.agent_trace)


def test_error_recovery():
    """Test graceful error handling and recovery"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # In normal operation, there should be no errors
    # But we want to verify the structure would handle errors correctly
    assert "workflow_status" in result


def test_traceability_features():
    """Test comprehensive traceability features"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify comprehensive traceability
    last_trace = result["agent_trace"][-1]
    
    # Check required trace fields
    required_fields = ["agent", "request_id", "action", "timestamp"]
    for field in required_fields:
        assert field in last_trace
        assert last_trace[field] is not None
    
    # Check that request_id is a valid UUID-like string
    assert len(last_trace["request_id"]) > 0
    assert isinstance(last_trace["request_id"], str)
    
    # Check timestamp format
    assert isinstance(last_trace["timestamp"], str)
    # Should be able to parse as ISO format
    try:
        # Handle potential 'Z' suffix
        timestamp_str = last_trace["timestamp"].replace('Z', '+00:00')
        parsed_time = __import__('datetime').datetime.fromisoformat(timestamp_str)
        assert parsed_time is not None
    except ValueError:
        pytest.fail("Timestamp is not in valid ISO format")