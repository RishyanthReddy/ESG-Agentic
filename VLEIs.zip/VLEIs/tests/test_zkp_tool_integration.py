"""
Integration tests for the ZKPVerificationTool implementation.
"""

import pytest
import time
from src.tools.verification import ZKPVerificationTool
from src.tools.registry import ToolRegistry


class TestZKPVerificationToolIntegration:
    """Integration tests for the ZKPVerificationTool."""
    
    def setup_method(self):
        """Set up test resources."""
        self.tool = ZKPVerificationTool()
        self.registry = ToolRegistry()
    
    def test_workflow_integration(self):
        """Test integration of ZKP tool in verification workflow."""
        # Test that the tool can be registered
        self.registry.register_tool(self.tool)
        
        # Test that the tool can be retrieved
        retrieved_tool = self.registry.get_tool("zkp_verification")
        assert retrieved_tool is not None
        assert retrieved_tool.name == "zkp_verification"
        
        # Test that the tool can be executed through the registry
        proof_data = {
            "proof": "mock_proof_data",
            "public_inputs": ["input1", "input2"],
            "verification_key": "mock_verification_key"
        }
        
        result = retrieved_tool.run(proof_data)
        assert result["verified"] is True
        
        # Test that the tool can be unregistered
        self.registry.unregister_tool("zkp_verification")
        assert self.registry.get_tool("zkp_verification") is None
    
    def test_performance_baseline(self):
        """Establish baseline for future ZKP implementation performance."""
        # Create test proof data
        proof_data = {
            "proof": "mock_proof_data",
            "public_inputs": ["input1", "input2", "input3"],
            "verification_key": "mock_verification_key"
        }
        
        # Measure execution time
        start_time = time.time()
        result = self.tool.run(proof_data)
        end_time = time.time()
        
        execution_time = end_time - start_time
        
        # With the mock implementation, this should be very fast
        # Future real ZKP implementations will be slower, and we'll use this test
        # to track performance regressions
        assert execution_time < 1.0  # Should complete in under 1 second
        
        # Check that the result includes timing information
        assert "verification_time_ms" in result
        assert isinstance(result["verification_time_ms"], float)
        
        # Record performance metrics for future reference
        print(f"Mock ZKP verification time: {execution_time:.4f} seconds")
        print(f"Reported verification time: {result['verification_time_ms']} ms")
    
    def test_architecture_validation(self):
        """Validate architectural readiness for future ZKP integration."""
        # Check that the tool follows the expected architecture
        assert hasattr(self.tool, 'zkp_backend')
        assert hasattr(self.tool, 'supported_proof_types')
        
        # Check that the tool has the expected methods for future extension
        assert hasattr(self.tool, '_mock_verify_proof')
    
    def test_interface_stability(self):
        """Test interface stability across changes."""
        # Test that the run method signature is stable
        proof_data = {
            "proof": "mock_proof_data",
            "public_inputs": ["input1"],
            "verification_key": "mock_verification_key"
        }
        
        # This should not raise any exceptions
        result = self.tool.run(proof_data)
        assert isinstance(result, dict)
        
        # Test with various input formats
        test_cases = [
            {"proof": "data", "public_inputs": [], "verification_key": "key"},
            {"proof": "data", "public_inputs": ["a", "b"], "verification_key": "key"},
            {"proof": "data", "public_inputs": [1, 2, 3], "verification_key": "key"},
        ]
        
        for test_case in test_cases:
            result = self.tool.run(test_case)
            assert isinstance(result, dict)
            # Either verified or has an error
            assert ("verified" in result) or ("error" in result)
    
    def test_future_proofing(self):
        """Validate future ZKP integration compatibility."""
        # Check that the tool is designed to support future extensions
        assert self.tool.zkp_backend == "mock"
        
        # Check that the tool can be extended with new proof types
        assert isinstance(self.tool.supported_proof_types, list)
        assert len(self.tool.supported_proof_types) > 0
        
        # Check that the tool's implementation is modular
        # (has separate methods that can be overridden)
        assert callable(getattr(self.tool, '_mock_verify_proof', None))
        
        # Check that the tool follows the BaseTool interface
        assert hasattr(self.tool, 'run')
        assert callable(self.tool.run)
        
        # Check that the tool has a name and description
        assert hasattr(self.tool, 'name')
        assert hasattr(self.tool, 'description')


if __name__ == "__main__":
    pytest.main([__file__])