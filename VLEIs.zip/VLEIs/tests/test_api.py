"""
Unit tests for the Workflow Orchestration API
"""

import pytest
from fastapi.testclient import TestClient
from pydantic import BaseModel
from typing import Dict, Any, Optional
import json

# Import the app from main
from main import app, IngestRequest


class IngestResponse(BaseModel):
    """Response model for ingestion endpoints"""
    status: str
    message: str
    final_state: Dict[str, Any]


# Create test client - using the correct method for the FastAPI version
client = TestClient(app)


def test_root_endpoint():
    """Test the root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()
    assert response.json()["message"] == "Welcome to the ESG Intelligence Platform"


def test_health_endpoint():
    """Test the health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert "status" in data
    assert "timestamp" in data
    assert "components" in data


def test_ingest_stream_endpoint_validation():
    """Test validation for the ingest stream endpoint"""
    # Test with valid data
    valid_data = {
        "supplier_data": {
            "company_name": "Test Company",
            "esg_rating": "AA",
            "report_year": 2023
        }
    }
    
    response = client.post("/ingest/stream", json=valid_data)
    assert response.status_code == 200
    
    # Test response structure
    data = response.json()
    assert "status" in data
    assert "message" in data
    assert "final_state" in data
    assert data["status"] == "success"


def test_ingest_stream_endpoint_empty_data():
    """Test the ingest stream endpoint with empty data"""
    empty_data = {
        "supplier_data": {}
    }
    
    response = client.post("/ingest/stream", json=empty_data)
    assert response.status_code == 200


def test_ingest_stream_endpoint_with_config():
    """Test the ingest stream endpoint with configuration"""
    data_with_config = {
        "supplier_data": {
            "company_name": "Test Company"
        },
        "config": {
            "timeout": 30,
            "retries": 3
        }
    }
    
    response = client.post("/ingest/stream", json=data_with_config)
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"


def test_ingest_stream_endpoint_invalid_json():
    """Test the ingest stream endpoint with invalid JSON"""
    # Test with malformed JSON
    response = client.post("/ingest/stream", content='{"invalid": json}')
    assert response.status_code == 422  # Validation error


def test_cors_headers():
    """Test that CORS headers are present"""
    response = client.get("/", headers={"Origin": "http://localhost:3000"})
    assert response.status_code == 200
    # CORS headers should be present
    assert "access-control-allow-origin" in response.headers


def test_openapi_docs():
    """Test that OpenAPI docs are available"""
    response = client.get("/docs")
    assert response.status_code == 200
    
    response = client.get("/redoc")
    assert response.status_code == 200
    
    response = client.get("/openapi.json")
    assert response.status_code == 200


def test_request_models():
    """Test the Pydantic request models"""
    # Test IngestRequest model
    request_data = {
        "supplier_data": {"key": "value"},
        "config": {"setting": "value"}
    }
    
    request = IngestRequest(**request_data)
    assert request.supplier_data == {"key": "value"}
    assert request.config == {"setting": "value"}
    
    # Test with optional config
    request_data_no_config = {
        "supplier_data": {"key": "value"}
    }
    
    request = IngestRequest(**request_data_no_config)
    assert request.supplier_data == {"key": "value"}
    assert request.config is None


def test_response_models():
    """Test the Pydantic response models"""
    # Test IngestResponse model
    response_data = {
        "status": "success",
        "message": "Test message",
        "final_state": {
            "workflow_status": "completed",
            "task_queue": []
        }
    }
    
    response = IngestResponse(**response_data)
    assert response.status == "success"
    assert response.message == "Test message"
    assert "workflow_status" in response.final_state


if __name__ == "__main__":
    pytest.main([__file__])