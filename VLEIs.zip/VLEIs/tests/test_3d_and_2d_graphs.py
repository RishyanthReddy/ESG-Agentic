"""
Test suite for 3D and 2D graph visualization components.
This module tests:
1. Three.js scene initialization and rendering
2. NetworkX graph creation and layout
3. Node selection and highlighting
4. Memory usage and rendering performance
"""

import os
import sys
import subprocess
import pytest
import json
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def test_threejs_components_exist():
    """Test that the Three.js components exist"""
    components_dir = os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'src', 'components', 'threejs')
    
    assert os.path.exists(components_dir), "Three.js components directory not found"
    
    required_files = [
        'ProvenanceGraph3D.tsx',
        'PerformanceOptimizedGraph.tsx',
        'index.ts'
    ]
    
    for file_name in required_files:
        file_path = os.path.join(components_dir, file_name)
        assert os.path.exists(file_path), f"Required Three.js component {file_name} not found"

def test_graph_visualizer_script_exists():
    """Test that the graph_visualizer.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'graph_visualizer.py')
    assert os.path.exists(script_path), "graph_visualizer.py script not found"

def test_provenance_trace_script_exists():
    """Test that the provenance_trace.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'provenance_trace.py')
    assert os.path.exists(script_path), "provenance_trace.py script not found"

def test_graph_export_script_exists():
    """Test that the graph_export.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'graph_export.py')
    assert os.path.exists(script_path), "graph_export.py script not found"

def test_interactive_graph_demo_script_exists():
    """Test that the interactive_graph_demo.py script exists"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'interactive_graph_demo.py')
    assert os.path.exists(script_path), "interactive_graph_demo.py script not found"

def test_graph_visualizer_script_execution():
    """Test that the graph_visualizer.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'graph_visualizer.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "graph_visualizer.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"graph_visualizer.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("graph_visualizer.py script timed out")
    except Exception as e:
        pytest.fail(f"graph_visualizer.py script failed with error: {e}")

def test_provenance_trace_script_execution():
    """Test that the provenance_trace.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'provenance_trace.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "provenance_trace.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"provenance_trace.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("provenance_trace.py script timed out")
    except Exception as e:
        pytest.fail(f"provenance_trace.py script failed with error: {e}")

def test_graph_export_script_execution():
    """Test that the graph_export.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'graph_export.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "graph_export.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"graph_export.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("graph_export.py script timed out")
    except Exception as e:
        pytest.fail(f"graph_export.py script failed with error: {e}")

def test_interactive_graph_demo_script_execution():
    """Test that the interactive_graph_demo.py script executes without errors"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'interactive_graph_demo.py')
    
    # Check if script exists
    assert os.path.exists(script_path), "interactive_graph_demo.py script not found"
    
    # Try to execute the script with --help flag
    try:
        result = subprocess.run(
            ['python', script_path, '--help'], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        # Script should execute without errors
        assert result.returncode == 0, f"interactive_graph_demo.py failed with return code {result.returncode}"
    except subprocess.TimeoutExpired:
        pytest.fail("interactive_graph_demo.py script timed out")
    except Exception as e:
        pytest.fail(f"interactive_graph_demo.py script failed with error: {e}")

def test_graph_export_functionality():
    """Test that the graph export functionality works"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'graph_export.py')
    
    # Create a temporary directory for export
    export_dir = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'test_graph_export')
    os.makedirs(export_dir, exist_ok=True)
    
    try:
        # Run the export script
        result = subprocess.run(
            ['python', script_path, '--format', 'matplotlib', '--output-file', f'{export_dir}/test_graph.png'], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"graph_export.py failed with return code {result.returncode}"
        
        # Check if export files were created
        export_files = os.listdir(export_dir)
        assert len(export_files) > 0, "No export files were created"
        
        # Check that at least one PNG file was created
        png_files = [f for f in export_files if f.endswith('.png')]
        assert len(png_files) > 0, "No PNG export files were created"
        
    except subprocess.TimeoutExpired:
        pytest.fail("graph_export.py script timed out")
    except Exception as e:
        pytest.fail(f"graph_export.py script failed with error: {e}")
    finally:
        # Clean up export files
        if os.path.exists(export_dir):
            for file in os.listdir(export_dir):
                os.remove(os.path.join(export_dir, file))
            os.rmdir(export_dir)

def test_provenance_trace_functionality():
    """Test that the provenance trace functionality works"""
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'provenance_trace.py')
    
    try:
        # Run the trace script
        result = subprocess.run(
            ['python', script_path, '--source', '1', '--target', '6'], 
            capture_output=True, 
            text=True, 
            timeout=15
        )
        
        # Check if the script ran successfully
        assert result.returncode == 0, f"provenance_trace.py failed with return code {result.returncode}"
        
        # Check that output contains expected information
        output = result.stdout.lower()
        assert 'provenance trace' in output or 'supply chain path' in output
        
    except subprocess.TimeoutExpired:
        pytest.fail("provenance_trace.py script timed out")
    except Exception as e:
        pytest.fail(f"provenance_trace.py script failed with error: {e}")

if __name__ == "__main__":
    pytest.main([__file__])