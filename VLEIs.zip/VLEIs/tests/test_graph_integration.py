"""
Integration tests for the graph workflow
"""

import pytest
import time
from src.graph.builder import graph
from src.state.models import AppState


def create_complete_initial_state(task_queue=None):
    """Helper function to create a complete initial state"""
    if task_queue is None:
        task_queue = []
        
    return {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "created_at": "2023-01-01T00:00:00",
        "updated_at": "2023-01-01T00:00:00",
        "credentials": [],
        "gri_reports": [],
        "sasb_reports": [],
        "workflow_status": "initial",
        "workflow_step": 0,
        "workflow_data": {},
        "processing_results": {},
        "errors": [],
        "config": {},
        "task_queue": task_queue
    }


def test_full_graph_execution():
    """Run complete workflow with mock data"""
    # Test with a task queue that routes to credential_agent
    initial_state = create_complete_initial_state(["credential_agent"])
    
    start_time = time.time()
    result = graph.invoke(initial_state)
    end_time = time.time()
    
    # Check that the workflow executed
    assert result is not None
    # Note: The actual result might vary based on the node execution
    
    # Record execution time
    execution_time = end_time - start_time
    print(f"Execution time: {execution_time:.4f} seconds")


def test_agent_connectivity():
    """Validate all agents can be reached through routing"""
    # Test routing to credential_agent
    result1 = graph.invoke(create_complete_initial_state(["credential_agent"]))
    assert result1 is not None
    
    # Test routing to reporting_agent
    result2 = graph.invoke(create_complete_initial_state(["reporting_agent"]))
    assert result2 is not None


def test_state_flow():
    """Test state persistence through entire graph execution"""
    # Start with a state that has some initial data
    initial_state = create_complete_initial_state(["credential_agent"])
    initial_state["workflow_status"] = "started"
    
    # Execute the graph
    result = graph.invoke(initial_state)
    
    # Check that we got a result
    assert result is not None


def test_error_propagation():
    """Ensure errors in agents are handled at graph level"""
    # Test with an invalid task in the queue
    # The master_orchestrator should handle this gracefully
    try:
        result = graph.invoke(create_complete_initial_state(["nonexistent_agent"]))
        # If we get here, it means the error was handled
        assert result is not None
    except Exception as e:
        # If there's an exception, it should be a routing error, not a validation error
        error_str = str(e).lower()
        # It's okay if it's a routing error, but not a validation error
        # We're focusing on testing that the graph can be invoked with proper state


def test_performance():
    """Graph execution time under various scenarios"""
    # Test with empty queue (should be fast)
    start_time = time.time()
    graph.invoke(create_complete_initial_state([]))
    empty_queue_time = time.time() - start_time
    
    # Test with single task
    start_time = time.time()
    graph.invoke(create_complete_initial_state(["credential_agent"]))
    single_task_time = time.time() - start_time
    
    # Both operations should be reasonably fast (less than 1 second)
    assert empty_queue_time < 1.0
    assert single_task_time < 1.0
    
    print(f"Empty queue execution time: {empty_queue_time:.4f} seconds")
    print(f"Single task execution time: {single_task_time:.4f} seconds")


if __name__ == "__main__":
    pytest.main([__file__])