"""
Integration tests for the upgraded verification agent with multi-tool workflow
"""

import pytest
import asyncio
from src.agents.verification import verification_agent
from src.state.models import AppState, vLEICredential, VerificationStatus
from src.tools.verification import GleifVerifierTool, AzureVerifiedIDTool
from src.tools.registry import ToolRegistry


@pytest.mark.asyncio
async def test_multi_tool_workflow_with_real_credentials():
    """Test end-to-end verification with both tools using real credentials"""
    # Create a GLEIF credential
    gleif_credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:HXB0UMUMDLF1QQF6UY42",  # Apple Inc. LEI
        claims={"lei": "HXB0UMUMDLF1QQF6UY42", "entity_name": "Apple Inc."}
    )
    
    # Create an Azure-like credential
    azure_credential = vLEICredential(
        issuer="did:azure:example",
        subject="did:example:subject",
        claims={"appid": "test-app", "azp": "azure-app"}
    )
    
    # Test GLEIF credential
    gleif_state = AppState(
        current_credential=gleif_credential,
        credentials=[gleif_credential]
    )
    
    # Run the verification agent
    gleif_result = verification_agent(gleif_state)
    
    # Should have attempted verification
    assert "workflow_status" in gleif_result
    assert "agent_trace" in gleif_result
    assert len(gleif_result["agent_trace"]) > 0
    
    # Test Azure credential
    azure_state = AppState(
        current_credential=azure_credential,
        credentials=[azure_credential]
    )
    
    # Run the verification agent
    azure_result = verification_agent(azure_state)
    
    # Should have attempted verification
    assert "workflow_status" in azure_result
    assert "agent_trace" in azure_result
    assert len(azure_result["agent_trace"]) > 0
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_performance_analysis_single_vs_multi_tool():
    """Compare single vs multi-tool verification times"""
    # Create a credential that would use both tools
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "HXB0UMUMDLF1QQF6UY42"}
    )
    
    state = AppState(
        current_credential=credential,
        credentials=[credential]
    )
    
    # Measure multi-tool verification
    import time
    start_time = time.time()
    result = verification_agent(state)
    multi_tool_time = time.time() - start_time
    
    # Should have processed the verification
    assert "workflow_status" in result
    assert "processing_results" in result
    
    # Check that both tools were attempted
    agent_trace = result["agent_trace"][-1] if result["agent_trace"] else {}
    tools_used = agent_trace.get("tools_used", [])
    
    # With our logic, it should try both tools for this credential
    assert len(tools_used) >= 1
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_failure_recovery_when_individual_tools_fail():
    """Test behavior when individual tools fail"""
    # Create a credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "value"}
    )
    
    state = AppState(
        current_credential=credential,
        credentials=[credential]
    )
    
    # Run the verification agent
    result = verification_agent(state)
    
    # Should handle failures gracefully
    assert "workflow_status" in result
    # Either successful verification or graceful failure handling
    assert result["workflow_status"] in ["credential_verified", "verification_failed"]
    
    # Should have trace information
    assert "agent_trace" in result
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_state_consistency_across_tool_failures():
    """Verify state integrity across tool failures"""
    # Create a credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:INVALIDLEI123456789",
        claims={"lei": "INVALIDLEI123456789"}
    )
    
    # Create state with multiple credentials
    other_credential = vLEICredential(
        issuer="did:example:other",
        subject="did:example:other",
        claims={"other": "data"}
    )
    
    state = AppState(
        current_credential=credential,
        credentials=[credential, other_credential]
    )
    
    # Run the verification agent
    result = verification_agent(state)
    
    # Should maintain state consistency
    assert "credentials" in result
    assert len(result["credentials"]) >= 2  # Should not lose credentials
    
    # Should have trace information
    assert "agent_trace" in result
    
    # Add a small delay to avoid rate limiting
    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_real_credential_testing_various_types():
    """Test with various credential types"""
    # Test GLEIF credential with LEI in subject
    gleif_credential1 = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:549300A6XUSR882F7N34",
        claims={"entity_name": "Example Corp"}
    )
    
    # Test GLEIF credential with LEI in claims
    gleif_credential2 = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"lei": "549300A6XUSR882F7N34", "entity_name": "Example Corp"}
    )
    
    # Test Azure-like credential
    azure_credential = vLEICredential(
        issuer="https://verifiedid.did.msidentity.com",
        subject="did:example:subject",
        claims={"appid": "test-app"}
    )
    
    credentials_to_test = [
        (gleif_credential1, "GLEIF credential with LEI in subject"),
        (gleif_credential2, "GLEIF credential with LEI in claims"),
        (azure_credential, "Azure-like credential")
    ]
    
    for credential, description in credentials_to_test:
        state = AppState(
            current_credential=credential,
            credentials=[credential]
        )
        
        # Run the verification agent
        result = verification_agent(state)
        
        # Should process the credential
        assert "workflow_status" in result, f"Failed for {description}"
        
        # Add a small delay to avoid rate limiting
        await asyncio.sleep(1)


if __name__ == "__main__":
    pytest.main([__file__])