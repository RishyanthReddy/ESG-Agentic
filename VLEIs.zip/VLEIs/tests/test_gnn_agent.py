"""
Unit tests for the GNN Modeling Agent
"""

import pytest
from datetime import datetime
from src.agents.modeling import gnn_modeling_agent, GNNModelingError
from src.state.models import AppState


def test_agent_function_signature_and_behavior():
    """Test agent function signature and basic behavior"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify result is a dictionary
    assert isinstance(result, dict)
    
    # Verify basic structure
    assert "workflow_status" in result
    assert "agent_trace" in result
    assert "processing_results" in result


def test_state_passthrough():
    """Verify state correctly passed through"""
    # Create initial state with some data
    initial_state = AppState(
        workflow_status="initial",
        processing_results={"previous_step": "completed"}
    )
    
    # Call the agent
    result = gnn_modeling_agent(initial_state)
    
    # Verify existing data is preserved
    assert "previous_step" in result["processing_results"]
    
    # Check that the agent_trace was extended, not replaced
    assert len(result["agent_trace"]) > 0


def test_logging_functionality():
    """Test agent trace logging functionality"""
    # Create initial state
    state = AppState()
    initial_trace_count = len(state.agent_trace)
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify agent trace was updated
    assert len(result["agent_trace"]) > initial_trace_count
    
    # Check the last trace entry
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "gnn_modeling_agent"
    assert "request_id" in last_trace
    assert last_trace["action"] == "placeholder_execution"
    assert "timestamp" in last_trace


def test_placeholder_behavior():
    """Validate placeholder behavior"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify placeholder behavior
    assert result["workflow_status"] == "gnn_modeling_placeholder_executed"
    
    # Check processing results indicate placeholder status
    gnn_results = result["processing_results"]["gnn_modeling"]
    assert gnn_results["status"] == "placeholder"
    assert "placeholder" in gnn_results["message"]
    assert "Graph Neural Network" in gnn_results["intended_for"]


def test_future_capabilities_documentation():
    """Test that future capabilities are documented"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Check the last trace entry for future capabilities
    last_trace = result["agent_trace"][-1]
    assert "future_capabilities" in last_trace
    assert isinstance(last_trace["future_capabilities"], list)
    assert len(last_trace["future_capabilities"]) > 0
    
    # Verify some expected capabilities are documented
    capabilities = last_trace["future_capabilities"]
    assert any("Graph Neural Networks" in cap for cap in capabilities)
    assert any("ESG data" in cap for cap in capabilities)
    assert any("regulatory compliance" in cap for cap in capabilities)


def test_error_handling():
    """Test error handling in the agent"""
    # Create a mock state that would cause an error
    # We'll patch the datetime to raise an exception
    state = AppState()
    
    # This test is a bit artificial since it's hard to cause an error in the current implementation
    # But we can at least verify the error handling structure
    result = gnn_modeling_agent(state)
    
    # Should not have errors in normal execution
    # But we can check the structure would handle errors correctly
    assert "workflow_status" in result
    assert "agent_trace" in result


def test_intended_purpose_logging():
    """Test that intended purpose is clearly logged"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Check the last trace entry for intended purpose
    last_trace = result["agent_trace"][-1]
    assert "intended_purpose" in last_trace
    assert "Graph Neural Network" in last_trace["intended_purpose"]


def test_request_id_generation():
    """Test that request IDs are generated for traceability"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Check the last trace entry has a request ID
    last_trace = result["agent_trace"][-1]
    assert "request_id" in last_trace
    assert isinstance(last_trace["request_id"], str)
    assert len(last_trace["request_id"]) > 0


def test_timestamp_logging():
    """Test that timestamps are properly logged"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Check the last trace entry has a timestamp
    last_trace = result["agent_trace"][-1]
    assert "timestamp" in last_trace
    assert isinstance(last_trace["timestamp"], str)
    
    # Verify it's a valid ISO format timestamp
    try:
        datetime.fromisoformat(last_trace["timestamp"].replace('Z', '+00:00'))
    except ValueError:
        pytest.fail("Timestamp is not in valid ISO format")


def test_consistent_return_structure():
    """Test that the agent returns a consistent structure"""
    # Create initial state
    state = AppState()
    
    # Call the agent
    result = gnn_modeling_agent(state)
    
    # Verify all expected keys are present
    expected_keys = {"workflow_status", "agent_trace", "processing_results"}
    assert expected_keys.issubset(result.keys())
    
    # Verify processing_results structure
    assert "gnn_modeling" in result["processing_results"]
    gnn_results = result["processing_results"]["gnn_modeling"]
    assert "status" in gnn_results
    assert "message" in gnn_results
    assert "intended_for" in gnn_results