"""
Unit tests for the upgraded Provenance Agent
"""

import pytest
from unittest.mock import Mock, patch
import hashlib
import json
from src.agents.provenance import provenance_agent, ProvenanceError
from src.state.models import AppState, vLEICredential


def test_data_hashing_consistency():
    """Test consistent hash generation for the same data"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create state with credential
    state = AppState(
        current_credential=credential,
        workflow_status="processing",
        workflow_step=2,
        config={"blockchain_private_key": "test-key"}
    )
    
    # Run the agent twice with the same data
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class, \
         patch('src.agents.provenance.datetime') as mock_datetime:
        
        # Mock datetime to return consistent timestamps
        mock_datetime.utcnow.return_value.isoformat.return_value = "2023-01-01T00:00:00"
        
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0x123456789abcdef",
            "message": "Data successfully logged to blockchain",
            "data_hash": "test_hash",
            "account": "0xaccount",
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        result1 = provenance_agent(state)
        result2 = provenance_agent(state)
        
        # Verify both results have the same data_hash in blockchain_log
        assert len(result1["blockchain_log"]) == 1
        assert len(result2["blockchain_log"]) == 1
        assert result1["blockchain_log"][0]["data_hash"] == result2["blockchain_log"][0]["data_hash"]


def test_state_serialization():
    """Validate state serialization and deserialization"""
    # Create a complex credential with nested data
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Test Corp",
            "metrics": {
                "emissions": 100,
                "energy": 500
            },
            "verified": True
        }
    )
    
    # Create state with credential
    state = AppState(
        current_credential=credential,
        workflow_status="processing",
        workflow_step=2,
        config={"blockchain_private_key": "test-key"}
    )
    
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class, \
         patch('src.agents.provenance.datetime') as mock_datetime:
        
        # Mock datetime to return consistent timestamps
        mock_datetime.utcnow.return_value.isoformat.return_value = "2023-01-01T00:00:00"
        
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0x123456789abcdef",
            "message": "Data successfully logged to blockchain",
            "data_hash": "consistent_hash",
            "account": "0xaccount",
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        result = provenance_agent(state)
        
        # Verify the data_hash in blockchain_log is present
        assert "data_hash" in result["blockchain_log"][0]
        assert len(result["blockchain_log"][0]["data_hash"]) == 64  # SHA-256 hash length


def test_tool_integration():
    """Test blockchain tool interactions"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create state with credential
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": "test-key"}
    )
    
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class:
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0xabcd1234",
            "message": "Data successfully logged to blockchain",
            "data_hash": "test_hash",
            "account": "0xaccount",
            "timestamp": "2023-01-01T00:00:00"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        result = provenance_agent(state)
        
        # Verify tool was called with correct parameters
        mock_tool_instance.run.assert_called_once()
        call_args = mock_tool_instance.run.call_args[0]
        assert call_args[1] == "test-key"  # private key
        
        # Verify blockchain_log was updated correctly
        assert len(result["blockchain_log"]) == 1
        log_entry = result["blockchain_log"][0]
        assert log_entry["transaction_hash"] == "0xabcd1234"
        assert log_entry["data_id"] == str(credential.id)


def test_log_management():
    """Test blockchain log state updates"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create state with existing blockchain log entries
    state = AppState(
        current_credential=credential,
        blockchain_log=[
            {
                "data_id": "existing-id",
                "data_hash": "existing-hash",
                "transaction_hash": "existing-tx",
                "timestamp": "2023-01-01T00:00:00",
                "status": "success"
            }
        ],
        config={"blockchain_private_key": "test-key"}
    )
    
    with patch('src.agents.provenance.InfuraBlockchainTool') as mock_tool_class:
        mock_tool_instance = Mock()
        mock_tool_instance.run.return_value = {
            "success": True,
            "transaction_hash": "0xnewtx",
            "message": "Data successfully logged to blockchain",
            "data_hash": "new-hash",
            "account": "0xaccount",
            "timestamp": "2023-01-02T00:00:00"
        }
        mock_tool_class.return_value = mock_tool_instance
        
        result = provenance_agent(state)
        
        # Verify blockchain_log contains both old and new entries
        assert len(result["blockchain_log"]) == 2
        assert result["blockchain_log"][0]["transaction_hash"] == "existing-tx"
        assert result["blockchain_log"][1]["transaction_hash"] == "0xnewtx"


def test_error_handling():
    """Test error handling in provenance agent"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "data"}
    )
    
    # Create state without private key (should cause error)
    state = AppState(
        current_credential=credential,
        config={}  # Missing private key
    )
    
    result = provenance_agent(state)
    
    # Verify error handling
    assert result["workflow_status"] == "blockchain_logging_failed"
    assert "errors" in result
    assert len(result["errors"]) > 0
    assert "blockchain private key not found" in result["errors"][0].lower()


if __name__ == "__main__":
    pytest.main([__file__])