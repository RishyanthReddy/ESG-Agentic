"""
Unit tests for the GraphSerializationTool implementation.
"""

import pytest
import networkx as nx
from src.tools.visualization import GraphSerializationTool


class TestGraphSerializationTool:
    """Test cases for the GraphSerializationTool class."""
    
    def setup_method(self):
        """Set up test resources."""
        self.tool = GraphSerializationTool()
    
    def test_tool_initialization(self):
        """Test that the tool initializes correctly."""
        assert self.tool.name == "graph_serialization"
        assert self.tool.description is not None
        assert "three.js" in self.tool.description.lower()
    
    def test_json_generation_simple_graph(self):
        """Test JSON format generation from simple graphs."""
        # Create a simple graph
        graph = nx.DiGraph()
        graph.add_node("A", type="agent", name="Agent A")
        graph.add_node("B", type="artifact", name="Artifact B")
        graph.add_edge("A", "B", relationship="produced")
        
        # Test serialization
        result = self.tool.run(graph, format="json")
        
        assert result['success'] is True
        assert 'serialized_graph' in result
        assert isinstance(result['serialized_graph'], str)
        assert len(result['serialized_graph']) > 0
        
        # Verify it's valid JSON
        import json
        data = json.loads(result['serialized_graph'])
        assert 'nodes' in data
        assert 'links' in data
        assert len(data['nodes']) == 2
        assert len(data['links']) == 1
    
    def test_threejs_generation_simple_graph(self):
        """Test Three.js format generation from simple graphs."""
        # Create a simple graph
        graph = nx.DiGraph()
        graph.add_node("A", type="agent", name="Agent A")
        graph.add_node("B", type="artifact", name="Artifact B")
        graph.add_edge("A", "B", relationship="produced")
        
        # Test serialization
        result = self.tool.run(graph, format="threejs")
        
        assert result['success'] is True
        assert 'serialized_graph' in result
        assert isinstance(result['serialized_graph'], str)
        assert len(result['serialized_graph']) > 0
        
        # Verify it's valid JSON
        import json
        data = json.loads(result['serialized_graph'])
        assert 'nodes' in data
        assert 'links' in data
        assert 'metadata' in data
        assert len(data['nodes']) == 2
        assert len(data['links']) == 1
    
    def test_format_validation(self):
        """Validate JSON structure for Three.js compatibility."""
        # Create a simple graph
        graph = nx.DiGraph()
        graph.add_node("A", type="agent", name="Agent A", id="A")
        graph.add_node("B", type="artifact", name="Artifact B", id="B")
        graph.add_edge("A", "B", relationship="produced", source="A", target="B")
        
        # Test validation
        data = nx.node_link_data(graph, edges="links")
        is_valid = self.tool.validate_threejs_compatibility(data)
        
        assert is_valid is True
    
    def test_data_integrity(self):
        """Test data preservation during serialization."""
        # Create a graph with specific data
        graph = nx.DiGraph()
        graph.add_node("agent_1", type="agent", name="Test Agent", role="tester")
        graph.add_node("artifact_1", type="artifact", name="Test Artifact", size=1024)
        graph.add_edge("agent_1", "artifact_1", relationship="produced", weight=1.0)
        
        # Serialize to JSON
        result = self.tool.run(graph, format="json")
        assert result['success'] is True
        
        # Parse the JSON back
        import json
        data = json.loads(result['serialized_graph'])
        
        # Check that all data is preserved
        nodes = {node['id']: node for node in data['nodes']}
        assert "agent_1" in nodes
        assert nodes["agent_1"]["type"] == "agent"
        assert nodes["agent_1"]["name"] == "Test Agent"
        assert nodes["agent_1"]["role"] == "tester"
        
        assert "artifact_1" in nodes
        assert nodes["artifact_1"]["type"] == "artifact"
        assert nodes["artifact_1"]["name"] == "Test Artifact"
        assert nodes["artifact_1"]["size"] == 1024
        
        # Check edges
        assert len(data['links']) == 1
        link = data['links'][0]
        assert link['source'] == "agent_1"
        assert link['target'] == "artifact_1"
        assert link['relationship'] == "produced"
        assert link['weight'] == 1.0
    
    def test_performance(self):
        """Test serialization performance with various graph sizes."""
        import time
        
        # Create graphs of different sizes
        for node_count in [10, 50, 100]:
            # Create a graph
            graph = nx.DiGraph()
            for i in range(node_count):
                graph.add_node(f"node_{i}", type="agent", name=f"Agent {i}")
            
            # Add some edges
            for i in range(node_count - 1):
                graph.add_edge(f"node_{i}", f"node_{i+1}", relationship="connected")
            
            # Measure serialization time
            start_time = time.time()
            result = self.tool.run(graph, format="json")
            end_time = time.time()
            
            # Check that it was successful
            assert result['success'] is True
            assert result['size'] > 0
            
            # Record time (should be reasonable)
            elapsed_time = end_time - start_time
            assert elapsed_time < 1.0  # Should complete in under 1 second
            
            print(f"Graph with {node_count} nodes serialized in {elapsed_time:.4f} seconds")


if __name__ == "__main__":
    pytest.main([__file__])