"""
Integration tests for the master orchestrator with LangGraph
"""

import pytest
from langgraph.graph import StateGraph, END
from src.state.models import AppState
from src.agents.core import master_orchestrator


def test_basic_orchestrator_functionality():
    """Test basic orchestrator functionality with minimal LangGraph setup"""
    
    # Create a simple graph with just the orchestrator
    workflow = StateGraph(AppState)
    
    # Simple node that just updates the workflow status
    def simple_node(state):
        return {
            "workflow_status": "processed",
            "task_queue": []  # Clear tasks to end workflow
        }
    
    # Add node
    workflow.add_node("simple_node", simple_node)
    workflow.set_entry_point("simple_node")
    
    # Add conditional edge that uses our orchestrator
    workflow.add_conditional_edges(
        "simple_node",
        master_orchestrator,
        {
            "simple_node": "simple_node",
            "__end__": END
        }
    )
    
    # Compile the graph
    app = workflow.compile()
    
    # Test with a task in the queue and complete state
    initial_state = {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "created_at": "2023-01-01T00:00:00",
        "updated_at": "2023-01-01T00:00:00",
        "credentials": [],
        "gri_reports": [],
        "sasb_reports": [],
        "workflow_status": "initial",
        "workflow_step": 0,
        "workflow_data": {},
        "processing_results": {},
        "errors": [],
        "config": {},
        "task_queue": ["simple_node"]
    }
    result = app.invoke(initial_state)
    
    # Should have processed the task
    assert result["workflow_status"] == "processed"


def test_orchestrator_with_empty_queue():
    """Test orchestrator behavior with empty task queue"""
    
    workflow = StateGraph(AppState)
    
    def test_node(state):
        return {
            "workflow_status": "executed",
            "task_queue": []  # Clear tasks to end workflow
        }
    
    workflow.add_node("test_node", test_node)
    workflow.set_entry_point("test_node")
    
    workflow.add_conditional_edges(
        "test_node",
        master_orchestrator,
        {
            "test_node": "test_node",
            "__end__": END
        }
    )
    
    app = workflow.compile()
    
    # Test with empty task queue and complete state
    initial_state = {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "created_at": "2023-01-01T00:00:00",
        "updated_at": "2023-01-01T00:00:00",
        "credentials": [],
        "gri_reports": [],
        "sasb_reports": [],
        "workflow_status": "initial",
        "workflow_step": 0,
        "workflow_data": {},
        "processing_results": {},
        "errors": [],
        "config": {},
        "task_queue": []
    }
    result = app.invoke(initial_state)
    
    # Should end immediately since queue is empty
    # The node should still execute since it's the entry point
    assert result["workflow_status"] == "executed"


def test_multiple_tasks_processing():
    """Test orchestrator with multiple tasks"""
    
    # Create state with multiple tasks
    state = AppState(task_queue=["task1", "task2", "task3"])
    
    # Process first task
    result1 = master_orchestrator(state)
    assert result1 == "task1"
    assert state.task_queue == ["task2", "task3"]
    
    # Process second task
    result2 = master_orchestrator(state)
    assert result2 == "task2"
    assert state.task_queue == ["task3"]
    
    # Process third task
    result3 = master_orchestrator(state)
    assert result3 == "task3"
    assert len(state.task_queue) == 0
    
    # Process with empty queue
    result4 = master_orchestrator(state)
    assert result4 == "__end__"


def test_error_recovery():
    """Test graceful handling of failed routing decisions"""
    
    # Test with empty string task (should raise RoutingError)
    state = AppState(task_queue=[""])
    
    with pytest.raises(Exception):  # RoutingError
        master_orchestrator(state)


if __name__ == "__main__":
    pytest.main([__file__])