"""
Integration tests for granular traceability functionality.
"""

import pytest
import sys
import os
from datetime import datetime

# Add the project root to the Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from src.state.models import AppState
from src.agents.visualization import visualization_agent


def create_sample_data():
    """Create sample agent traces and blockchain logs for testing."""
    agent_traces = [
        {
            "agent_id": "supplier_data_collector",
            "agent_name": "Tier-3 Supplier Data Collector",
            "agent_role": "data_collection",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [],
            "output_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "supplier_info": {
                "id": "supplier_tier3_abc_corp",
                "name": "ABC Corporation",
                "location": "Shanghai, China",
                "certifications": ["ISO 14001", "ISO 45001"],
                "timestamp": datetime.now().isoformat()
            }
        },
        {
            "agent_id": "esg_data_processor",
            "agent_name": "ESG Data Processing Agent",
            "agent_role": "data_processing",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [
                {
                    "id": "raw_esg_data_q1_2024",
                    "name": "Raw ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 102400,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "processed_esg_data_q1_2024",
                    "name": "Processed ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 51200,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        },
        {
            "agent_id": "carbon_calculator",
            "agent_name": "Carbon Footprint Calculator",
            "agent_role": "carbon_calculation",
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "input_artifacts": [
                {
                    "id": "processed_esg_data_q1_2024",
                    "name": "Processed ESG Data Q1 2024",
                    "type": "esg_data",
                    "size": 51200,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.now().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "carbon_footprint_q1_2024",
                    "name": "Carbon Footprint Q1 2024",
                    "type": "carbon_data",
                    "size": 2048,
                    "hash": "abcd1234ef567890",
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
    ]
    
    blockchain_logs = [
        {
            "transaction_hash": "0x7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b",
            "data_hash": "abcd1234ef567890",
            "account": "0x9cEa8237BC8cc063768bD85883B01b8d66a1b61b",
            "block_number": 15783246,
            "gas_used": 21000,
            "timestamp": datetime.now().isoformat()
        }
    ]
    
    return agent_traces, blockchain_logs


def test_end_to_end_granular_traceability():
    """Test end-to-end granular traceability workflow."""
    # Create sample data
    agent_traces, blockchain_logs = create_sample_data()
    
    # Create state with trace_data_point specified
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="raw_esg_data_q1_2024"
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Validate the result
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is included
    assert "granular_traceability" in visualization_assets
    granular_data = visualization_assets["granular_traceability"]
    assert granular_data["data_point_id"] == "raw_esg_data_q1_2024"
    
    # Check that path analysis is successful
    path_analysis = granular_data["path_analysis"]
    assert path_analysis["success"] is True
    assert path_analysis["source"] == "artifact:raw_esg_data_q1_2024"
    assert "blockchain" in path_analysis["target"]
    assert path_analysis["node_count"] > 0
    assert path_analysis["edge_count"] >= 0
    assert len(path_analysis["path"]) == path_analysis["node_count"]
    assert len(path_analysis["path_edges"]) == path_analysis["edge_count"]
    
    # Check that all path nodes are in the graph
    provenance_graph = visualization_assets["provenance_graph"]
    # This is a simple check - in a real implementation, we would validate more thoroughly


def test_granular_traceability_with_different_data_point():
    """Test granular traceability with a different data point."""
    # Create sample data
    agent_traces, blockchain_logs = create_sample_data()
    
    # Create state with a different trace_data_point
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="carbon_footprint_q1_2024"
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Validate the result
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is included
    assert "granular_traceability" in visualization_assets
    granular_data = visualization_assets["granular_traceability"]
    assert granular_data["data_point_id"] == "carbon_footprint_q1_2024"
    
    # Check that path analysis is successful
    path_analysis = granular_data["path_analysis"]
    assert path_analysis["success"] is True
    assert path_analysis["source"] == "artifact:carbon_footprint_q1_2024"
    assert "blockchain" in path_analysis["target"]


def test_regular_visualization_without_granular_traceability():
    """Test regular visualization without granular traceability."""
    # Create sample data
    agent_traces, blockchain_logs = create_sample_data()
    
    # Create state without trace_data_point
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs
    )
    
    # Run visualization agent
    result = visualization_agent(state)
    
    # Validate the result
    assert result["workflow_status"] == "visualization_generated"
    assert "visualization_assets" in result
    
    visualization_assets = result["visualization_assets"]
    
    # Check that granular traceability data is NOT included
    assert "granular_traceability" not in visualization_assets
    
    # But general highlighted path should still be available
    assert "highlighted_path" in visualization_assets


def test_visualization_performance_with_granular_traceability():
    """Test that granular traceability doesn't significantly impact performance."""
    # Create sample data
    agent_traces, blockchain_logs = create_sample_data()
    
    # Create state with trace_data_point
    state = AppState(
        agent_trace=agent_traces,
        blockchain_log=blockchain_logs,
        trace_data_point="raw_esg_data_q1_2024"
    )
    
    # Run visualization agent
    import time
    start_time = time.time()
    result = visualization_agent(state)
    end_time = time.time()
    
    # Validate the result was successful
    assert result["workflow_status"] == "visualization_generated"
    
    # Check that it completed in a reasonable time (less than 5 seconds)
    assert (end_time - start_time) < 5.0


if __name__ == "__main__":
    pytest.main([__file__])