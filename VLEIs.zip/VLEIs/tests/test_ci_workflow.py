"""
Unit tests for CI workflow validation
"""

import pytest
import yaml
from pathlib import Path


def test_workflow_file_exists():
    """Test that the GitHub Actions workflow file exists"""
    workflow_path = Path(".github/workflows/ci.yml")
    assert workflow_path.exists(), "CI workflow file not found"


def test_workflow_structure():
    """Test that the workflow file has the correct structure"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for required elements
    assert "name: CI" in workflow_content, "Workflow name missing"
    assert "on:" in workflow_content, "Workflow triggers missing"
    assert "jobs:" in workflow_content, "Workflow jobs missing"
    
    # Check for required jobs
    required_jobs = ["validate", "build", "test-unit", "test-integration"]
    for job in required_jobs:
        assert job in workflow_content, f"Required job '{job}' missing"


def test_workflow_triggers():
    """Test that the workflow has proper triggers"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for push and pull_request triggers
    assert "push:" in workflow_content, "Push trigger missing"
    assert "pull_request:" in workflow_content, "Pull request trigger missing"
    
    # Check for proper branch configuration
    assert "main" in workflow_content, "Main branch not configured"
    assert "develop" in workflow_content, "Develop branch not configured"


def test_workflow_jobs():
    """Test that the workflow has all required jobs"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for all required jobs
    required_jobs = [
        "validate", 
        "build", 
        "test-unit", 
        "test-integration",
        "test-all",
        "performance-monitoring",
        "ci-success"
    ]
    
    for job in required_jobs:
        assert job in workflow_content, f"Required job '{job}' missing"


def test_docker_compose_in_workflow():
    """Test that Docker Compose is properly referenced in the workflow"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for Docker Compose usage
    assert "docker-compose" in workflow_content.lower(), "Docker Compose not referenced"
    
    # Check for containerized testing
    assert "services:" in workflow_content, "Services not configured for containerized testing"


def test_parallel_testing_configured():
    """Test that parallel testing is configured"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for parallel testing configuration
    assert "-n auto" in workflow_content, "Parallel testing not configured"
    assert "pytest" in workflow_content, "Pytest not configured"


def test_caching_configured():
    """Test that build caching is configured"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for caching configuration
    assert "cache" in workflow_content.lower(), "Caching not configured"
    assert "docker/setup-buildx-action" in workflow_content, "Docker buildx caching not configured"


def test_environment_setup():
    """Test that CI environment setup is properly configured"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for proper environment setup
    assert "actions/checkout" in workflow_content, "Checkout action not configured"
    assert "actions/setup-python" in workflow_content, "Python setup not configured"
    assert "ubuntu-latest" in workflow_content, "Runner not configured"


def test_dependency_installation():
    """Test that dependency installation is properly configured"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for dependency installation
    assert "pip install" in workflow_content, "Pip installation not configured"
    assert "requirements.txt" in workflow_content, "Requirements file not used"


def test_test_coverage():
    """Test that test coverage is configured"""
    workflow_path = Path(".github/workflows/ci.yml")
    
    with open(workflow_path, "r") as f:
        workflow_content = f.read()
    
    # Check for test coverage configuration
    assert "pytest-cov" in workflow_content, "Test coverage not configured"
    assert "--cov" in workflow_content, "Coverage reporting not configured"


if __name__ == "__main__":
    pytest.main([__file__])