"""
Integration tests for the ShortestPathTool with real supply chain graphs.

This module contains integration tests for verifying the correct functionality of 
the ShortestPathTool when used with actual supply chain provenance graphs.
"""

import pytest
import networkx as nx
from src.tools.visualization import ShortestPathTool, NetworkXProvenanceTool


class TestShortestPathIntegration:
    """Integration test cases for the ShortestPathTool with supply chain graphs."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.path_tool = ShortestPathTool()
        self.provenance_tool = NetworkXProvenanceTool()
    
    def test_shortest_path_with_provenance_graph(self):
        """Test finding shortest path in a generated provenance graph."""
        # Create sample agent traces
        agent_traces = [
            {
                "agent_id": "agent_1",
                "agent_name": "Supplier A",
                "agent_role": "supplier",
                "status": "active",
                "timestamp": "2023-01-01T00:00:00Z",
                "input_artifacts": [],
                "output_artifacts": [
                    {
                        "id": "artifact_1",
                        "name": "Raw Material",
                        "type": "material",
                        "size": 100,
                        "hash": "hash1",
                        "timestamp": "2023-01-01T00:00:00Z"
                    }
                ],
                "supplier_info": {
                    "id": "supplier_a",
                    "name": "Supplier A",
                    "location": "Location A",
                    "certifications": ["ISO 14001"],
                    "timestamp": "2023-01-01T00:00:00Z"
                }
            },
            {
                "agent_id": "agent_2",
                "agent_name": "Manufacturer B",
                "agent_role": "manufacturer",
                "status": "active",
                "timestamp": "2023-01-02T00:00:00Z",
                "input_artifacts": [
                    {
                        "id": "artifact_1",
                        "name": "Raw Material",
                        "type": "material",
                        "size": 100,
                        "hash": "hash1",
                        "timestamp": "2023-01-01T00:00:00Z"
                    }
                ],
                "output_artifacts": [
                    {
                        "id": "artifact_2",
                        "name": "Finished Product",
                        "type": "product",
                        "size": 150,
                        "hash": "hash2",
                        "timestamp": "2023-01-02T00:00:00Z"
                    }
                ]
            }
        ]
        
        # Create sample blockchain logs
        blockchain_logs = [
            {
                "transaction_hash": "0x123456789abcdef123456789abcdef123456789abcdef123456789abcdef1234",
                "data_hash": "hash1",
                "account": "0xAccount1",
                "block_number": 1000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            },
            {
                "transaction_hash": "0xabcdef123456789abcdef123456789abcdef123456789abcdef123456789abcd",
                "data_hash": "hash2",
                "account": "0xAccount2",
                "block_number": 1001,
                "gas_used": 25000,
                "timestamp": "2023-01-02T00:00:00Z"
            }
        ]
        
        # Create provenance graph
        provenance_result = self.provenance_tool.run(agent_traces, blockchain_logs)
        assert provenance_result["success"] is True
        
        graph = provenance_result["graph"]
        
        # Get node IDs for path finding
        agent_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "agent"]
        artifact_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "artifact"]
        
        assert len(agent_nodes) >= 2
        assert len(artifact_nodes) >= 2
        
        # Find shortest path between two agents
        result = self.path_tool.run(graph, agent_nodes[0], agent_nodes[1])
        
        # Validate result
        assert result["success"] is True
        assert isinstance(result["path"], list)
        assert len(result["path"]) >= 2  # At least source and target
        assert result["source"] == agent_nodes[0]
        assert result["target"] == agent_nodes[1]
    
    def test_shortest_path_visualization_integration(self):
        """Test that the path can be used for visualization highlighting."""
        # Create a simple supply chain graph
        graph = nx.DiGraph()
        
        # Add nodes with types for visualization
        graph.add_node("supplier:1", type="supplier", name="Supplier A")
        graph.add_node("agent:1", type="agent", name="Manufacturer B")
        graph.add_node("agent:2", type="agent", name="Distributor C")
        graph.add_node("artifact:1", type="artifact", name="Product X")
        
        # Add edges with relationship types
        graph.add_edge("supplier:1", "agent:1", relationship="provides_service_to")
        graph.add_edge("agent:1", "agent:2", relationship="ships_to")
        graph.add_edge("agent:1", "artifact:1", relationship="produced")
        graph.add_edge("agent:2", "artifact:1", relationship="handled")
        
        # Find shortest path
        result = self.path_tool.run(graph, "supplier:1", "artifact:1")
        
        assert result["success"] is True
        assert len(result["path"]) > 0
        assert result["source"] == "supplier:1"
        assert result["target"] == "artifact:1"
        
        # Check that path edges are correctly formatted for visualization
        assert len(result["path_edges"]) > 0
        for edge in result["path_edges"]:
            assert "source" in edge
            assert "target" in edge
            assert "data" in edge