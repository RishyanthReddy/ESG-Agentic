"""
Unit tests for the Regulatory Mapping functionality
"""

import pytest
import json
import os
from datetime import datetime
from src.agents.reporting import regulatory_reporting_agent, RegulatoryReportingError
from src.agents.transformation_utils import (
    transform_to_gri, 
    transform_to_sasb, 
    transform_to_tcfd, 
    transform_to_csrd
)
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport, TCFDReport, CSRDReport


def test_mapping_logic():
    """Test data mapping to all regulatory formats"""
    # Create a test credential with comprehensive data
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company",
                "description": "A test company for ESG reporting",
                "sector": "Technology",
                "countries": ["US", "CA"],
                "employee_count": 1000
            },
            "policies": {
                "environmental": "Environmental Policy Statement",
                "social": "Social Responsibility Policy"
            },
            "governance": {
                "board_oversight": "Board oversees climate risks",
                "ethics": "Code of Ethics Program"
            },
            "strategies": {
                "climate_risks": "Climate Risk Strategy",
                "resilience": "Climate Resilience Analysis"
            },
            "environmental": {
                "emissions": {"scope1": 1000, "scope2": 500},
                "energy": {"renewable_percentage": 30},
                "water": {"consumption": 50000}
            },
            "social": {
                "workforce": {"training_hours": 20000},
                "products": {"safety_incidents": 0},
                "data": {"breaches": 0}
            },
            "metrics": {
                "emissions": {"total_ghg": 1500},
                "intensity": {"ghg_per_employee": 1.5}
            },
            "targets": {
                "emission_reduction": "50% by 2030"
            }
        }
    )
    
    # Create initial state with a credential
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "regulatory_report_generated"
    assert "regulatory_report" in result
    assert result["regulatory_report"]["company_name"] == "Test Company"
    
    # Verify all frameworks are included
    frameworks = result["regulatory_report"]["frameworks"]
    assert "gri" in frameworks
    assert "sasb" in frameworks
    assert "tcfd" in frameworks
    assert "csrd" in frameworks
    
    # Verify processing results
    assert "processing_results" in result
    assert "regulatory_mapping_result" in result["processing_results"]
    mapping_result = result["processing_results"]["regulatory_mapping_result"]
    assert "mapped_frameworks" in mapping_result
    assert set(mapping_result["mapped_frameworks"]) == {"GRI", "SASB", "TCFD", "CSRD"}


def test_data_validation():
    """Test data validation compliance with regulatory standards"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify report validation
    regulatory_report = result["regulatory_report"]
    frameworks = regulatory_report["frameworks"]
    
    # All reports should pass validation
    assert frameworks["gri"]["valid"] == True
    assert frameworks["sasb"]["valid"] == True
    assert frameworks["tcfd"]["valid"] == True
    assert frameworks["csrd"]["valid"] == True


def test_template_rendering():
    """Test report template generation"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company"
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify report structure for each framework
    frameworks = result["regulatory_report"]["frameworks"]
    
    # Check GRI report structure
    gri_data = frameworks["gri"]["mapped_data"]
    assert "report_type" in gri_data
    assert gri_data["report_type"] == "GRI"
    assert "company_name" in gri_data
    assert "report_year" in gri_data
    assert "generated_date" in gri_data
    
    # Check SASB report structure
    sasb_data = frameworks["sasb"]["mapped_data"]
    assert "report_type" in sasb_data
    assert sasb_data["report_type"] == "SASB"
    assert "company_name" in sasb_data
    assert "report_year" in sasb_data
    assert "generated_date" in sasb_data
    
    # Check TCFD report structure
    tcfd_data = frameworks["tcfd"]["mapped_data"]
    assert "report_type" in tcfd_data
    assert tcfd_data["report_type"] == "TCFD"
    assert "company_name" in tcfd_data
    assert "report_year" in tcfd_data
    assert "generated_date" in tcfd_data
    
    # Check CSRD report structure
    csrd_data = frameworks["csrd"]["mapped_data"]
    assert "report_type" in csrd_data
    assert csrd_data["report_type"] == "CSRD"
    assert "company_name" in csrd_data
    assert "report_year" in csrd_data
    assert "generated_date" in csrd_data


def test_cross_standard_consistency():
    """Ensure data consistency across different standards"""
    # Create a test credential with comprehensive data
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company",
                "employee_count": 1000
            },
            "environmental": {
                "emissions": {"scope1": 1000, "scope2": 500}
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential
    )
    
    # Run the agent
    result = regulatory_reporting_agent(state)
    
    # Verify company name consistency across frameworks
    frameworks = result["regulatory_report"]["frameworks"]
    company_name = result["regulatory_report"]["company_name"]
    
    assert frameworks["gri"]["mapped_data"]["company_name"] == company_name
    assert frameworks["sasb"]["mapped_data"]["company_name"] == company_name
    assert frameworks["tcfd"]["mapped_data"]["company_name"] == company_name
    assert frameworks["csrd"]["mapped_data"]["company_name"] == company_name
    
    # Verify report year consistency
    report_year = result["regulatory_report"]["report_year"]
    assert frameworks["gri"]["mapped_data"]["report_year"] == report_year
    assert frameworks["sasb"]["mapped_data"]["report_year"] == report_year
    assert frameworks["tcfd"]["mapped_data"]["report_year"] == report_year
    assert frameworks["csrd"]["mapped_data"]["report_year"] == report_year


def test_transformation_utils():
    """Test individual standard mapping functions"""
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Test Company",
                "description": "A test company",
                "sector": "Technology"
            },
            "environmental": {
                "emissions": {"scope1": 1000, "scope2": 500},
                "energy": {"renewable": 30}
            },
            "social": {
                "workforce": {"diversity": 0.4}
            },
            "governance": {
                "ethics": "Code of Ethics"
            }
        }
    )
    
    # Test GRI transformation
    gri_data = transform_to_gri(credential)
    assert "general_disclosure" in gri_data
    assert "management_approach" in gri_data
    assert "topic_specific_disclosure" in gri_data
    assert gri_data["general_disclosure"]["company_name"] == "Test Company"
    
    # Test SASB transformation
    sasb_data = transform_to_sasb(credential)
    assert "environmental_indicators" in sasb_data
    assert "social_indicators" in sasb_data
    assert "governance_indicators" in sasb_data
    assert "emissions" in sasb_data["environmental_indicators"]
    
    # Test TCFD transformation
    tcfd_data = transform_to_tcfd(credential)
    assert "governance" in tcfd_data
    assert "strategy" in tcfd_data
    assert "risk_management" in tcfd_data
    assert "metrics_and_targets" in tcfd_data
    
    # Test CSRD transformation
    csrd_data = transform_to_csrd(credential)
    assert "cross_cutting_disclosure" in csrd_data
    assert "environmental_disclosure" in csrd_data
    assert "social_disclosure" in csrd_data
    assert "governance_disclosure" in csrd_data


def test_model_compliance():
    """Test Pydantic model compliance for all standards"""
    # Create test data
    company_name = "Test Company"
    report_year = 2023
    
    # Test GRI Report model
    gri_report = GRIReport(
        company_name=company_name,
        report_year=report_year,
        general_disclosure={"disclosure": "test"},
        management_approach={"approach": "test"},
        topic_specific_disclosure={"topics": "test"}
    )
    assert gri_report.company_name == company_name
    assert gri_report.report_year == report_year
    
    # Test SASB Report model
    sasb_report = SASBReport(
        company_name=company_name,
        report_year=report_year,
        environmental_indicators={"emissions": 1000},
        social_indicators={"incidents": 0},
        governance_indicators={"ethics": "program"}
    )
    assert sasb_report.company_name == company_name
    assert sasb_report.report_year == report_year
    
    # Test TCFD Report model
    tcfd_report = TCFDReport(
        company_name=company_name,
        report_year=report_year,
        governance={"board_oversight": "test"},
        strategy={"climate_risks": "test"},
        risk_management={"identification": "test"},
        metrics_and_targets={"emissions": 1000}
    )
    assert tcfd_report.company_name == company_name
    assert tcfd_report.report_year == report_year
    
    # Test CSRD Report model
    csrd_report = CSRDReport(
        company_name=company_name,
        report_year=report_year,
        cross_cutting_disclosure={"business_model": "test"},
        environmental_disclosure={"emissions": "test"},
        social_disclosure={"workforce": "test"},
        governance_disclosure={"body": "test"}
    )
    assert csrd_report.company_name == company_name
    assert csrd_report.report_year == report_year