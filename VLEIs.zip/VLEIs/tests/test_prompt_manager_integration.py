"""
Integration tests for the PromptManager
"""

import pytest
import os
import time
from src.prompts import PromptManager, PromptError
from src.llm.interface import GeminiLLMInterface


def test_llm_integration():
    """Test prompts work with LLM interface"""
    prompt_manager = PromptManager()
    llm_interface = GeminiLLMInterface()
    
    # Test rendering a prompt that would be used with the LLM
    prompt = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={
            "environmental_score": 85,
            "social_score": 78,
            "governance_score": 92
        },
        context="Test company ESG assessment"
    )
    
    # Verify the prompt was rendered correctly
    assert isinstance(prompt, str)
    assert "environmental_score" in prompt
    assert "social_score" in prompt
    assert "governance_score" in prompt
    assert "Test company ESG assessment" in prompt


def test_dynamic_generation_with_context():
    """Test dynamic prompt generation with context"""
    prompt_manager = PromptManager()
    
    # Test with various context combinations
    contexts = [
        {"company": "TestCorp", "esg_score": 85},
        {"company": "AnotherCorp", "industry": "Manufacturing", "esg_score": 75},
        {"company": "GreenTech", "industry": "Technology", "esg_score": 95, "location": "EU"}
    ]
    
    for context in contexts:
        rendered = prompt_manager.render_prompt(
            "routing_decision",
            task_description="Process ESG data",
            task_complexity="medium",
            supplier_risk="low",
            context=f"Company: {context['company']}",
        )
        
        assert isinstance(rendered, str)
        assert "Process ESG data" in rendered
        assert context['company'] in rendered


def test_performance_impact():
    """Measure prompt management overhead"""
    prompt_manager = PromptManager()
    
    # Test rendering performance
    test_data = {
        "environmental_score": 85,
        "social_score": 78,
        "governance_score": 92,
        "additional_metrics": list(range(100))  # Large data set
    }
    
    # Time multiple renderings
    times = []
    for _ in range(10):
        start_time = time.time()
        rendered = prompt_manager.render_prompt(
            "esg_data_reasoning",
            esg_data=test_data,
            context="Performance test"
        )
        end_time = time.time()
        times.append(end_time - start_time)
        assert isinstance(rendered, str)
    
    # Calculate average time
    avg_time = sum(times) / len(times)
    
    # Should be very fast (less than 100ms on average)
    assert avg_time < 0.1, f"Average rendering time {avg_time}s is too slow"


def test_version_control():
    """Test prompt versioning and rollback"""
    prompt_manager = PromptManager()
    
    # Test that we can access version information
    assert hasattr(prompt_manager, 'prompts')
    assert len(prompt_manager.prompts) > 0
    
    # Test reloading functionality (simulates version update)
    original_prompt_count = len(prompt_manager.prompts)
    prompt_manager.reload_prompts()
    assert len(prompt_manager.prompts) == original_prompt_count


def test_template_validation():
    """Validate all prompt templates render correctly"""
    prompt_manager = PromptManager()
    
    # Test each prompt with minimal required context
    test_contexts = {
        "esg_data_reasoning": {"esg_data": {"score": 80}},
        "report_summary_generation": {
            "report_content": "Test content", 
            "report_type": "GRI"
        },
        "credential_validation": {
            "credential_data": {"id": "test"},
            "validation_rules": ["rule1", "rule2"]
        },
        "esg_entity_extraction": {
            "text_content": "Test text",
            "entity_types": ["type1", "type2"]
        },
        "routing_decision": {"task_description": "Test task"},
        "data_complexity_assessment": {"data": {"key": "value"}},
        "regulatory_reporting": {"company_data": {"name": "Test"}},
        "verification_analysis": {"verification_data": {"status": "pass"}}
    }
    
    for prompt_key in prompt_manager.get_prompt_names():
        # Skip prompts that might need special handling
        if prompt_key in test_contexts:
            rendered = prompt_manager.render_prompt(prompt_key, **test_contexts[prompt_key])
            assert isinstance(rendered, str)
            assert len(rendered) > 0


def test_complex_rendering_scenarios():
    """Test complex rendering scenarios"""
    prompt_manager = PromptManager()
    
    # Test with nested data structures
    complex_data = {
        "company": "TestCorp",
        "esg_scores": {
            "environmental": {
                "score": 85,
                "metrics": ["carbon", "water", "waste"]
            },
            "social": {
                "score": 78,
                "metrics": ["diversity", "engagement", "training"]
            },
            "governance": {
                "score": 92,
                "metrics": ["ethics", "compliance", "transparency"]
            }
        },
        "benchmarks": [
            {"year": 2023, "score": 78},
            {"year": 2024, "score": 85}
        ]
    }
    
    rendered = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data=complex_data,
        context="Annual ESG assessment"
    )
    
    assert isinstance(rendered, str)
    assert "TestCorp" in rendered
    assert "carbon" in rendered
    assert "diversity" in rendered
    assert "ethics" in rendered
    assert "2023" in rendered
    assert "2024" in rendered


def test_prompt_consistency():
    """Test that prompts render consistently"""
    prompt_manager = PromptManager()
    
    # Render the same prompt multiple times
    context = {
        "esg_data": {"score": 85},
        "context": "Consistency test"
    }
    
    results = []
    for _ in range(5):
        rendered = prompt_manager.render_prompt("esg_data_reasoning", **context)
        results.append(rendered)
    
    # All results should be identical
    for result in results[1:]:
        assert result == results[0]


def test_cache_efficiency():
    """Test cache efficiency with repeated prompts"""
    prompt_manager = PromptManager()
    prompt_manager.clear_cache()
    
    context = {"esg_data": {"score": 85}}
    
    # Render the same prompt multiple times
    for _ in range(10):
        prompt_manager.render_prompt("esg_data_reasoning", **context)
    
    # Cache should have at least one entry
    assert len(prompt_manager._cache) >= 1


def test_error_recovery():
    """Test graceful error handling and recovery"""
    prompt_manager = PromptManager()
    
    # Test with invalid prompt key
    try:
        prompt_manager.render_prompt("invalid_prompt_key")
        assert False, "Should have raised PromptError"
    except PromptError:
        pass  # Expected
    
    # Test that valid prompts still work after error
    rendered = prompt_manager.render_prompt(
        "esg_data_reasoning",
        esg_data={"score": 80}
    )
    assert isinstance(rendered, str)


def test_memory_management():
    """Test memory management with large contexts"""
    prompt_manager = PromptManager()
    
    # Create a large context
    large_context = {
        "esg_data": {
            f"metric_{i}": f"value_{i}" 
            for i in range(1000)  # Large number of metrics
        },
        "context": "Large context test"
    }
    
    # Should handle large contexts without issues
    rendered = prompt_manager.render_prompt(
        "esg_data_reasoning",
        **large_context
    )
    
    assert isinstance(rendered, str)
    assert len(rendered) > 0


def test_concurrent_access():
    """Test concurrent access to prompt manager"""
    prompt_manager = PromptManager()
    
    # Simulate concurrent access by calling methods in sequence
    results = []
    
    for i in range(10):
        # Mix of different operations
        if i % 3 == 0:
            result = prompt_manager.get_prompt_names()
            results.append(len(result))
        elif i % 3 == 1:
            result = prompt_manager.list_prompts()
            results.append(len(result))
        else:
            rendered = prompt_manager.render_prompt(
                "esg_data_reasoning",
                esg_data={"score": 80 + i}
            )
            results.append(len(rendered))
    
    # All operations should succeed
    assert len(results) == 10