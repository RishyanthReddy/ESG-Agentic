"""
Integration tests for the Infura Blockchain Tool
"""

import pytest
import os
from src.tools.provenance import InfuraBlockchainTool, BlockchainError
from web3 import Web3
from eth_account import Account


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment variables"
)
def test_tool_initialization_with_real_connection():
    """Test tool initialization with real Infura connection"""
    # This test requires a valid INFURA_API_KEY in the environment
    tool = InfuraBlockchainTool()
    
    # Verify the tool is properly initialized
    assert tool.name == "infura_blockchain"
    assert tool.web3.is_connected()
    
    # Verify we're connected to the correct network (Sepolia chain ID is 11155111)
    chain_id = tool.web3.eth.chain_id
    assert chain_id == 11155111, f"Expected Sepolia chain ID (11155111), got {chain_id}"


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY") or not os.getenv("BLOCKCHAIN_PRIVATE_KEY"),
    reason="INFURA_API_KEY or BLOCKCHAIN_PRIVATE_KEY not set in environment variables"
)
def test_transaction_building_with_real_network():
    """Test transaction building with real network data"""
    # This test requires both INFURA_API_KEY and BLOCKCHAIN_PRIVATE_KEY
    tool = InfuraBlockchainTool()
    
    # Get account from private key
    private_key = os.getenv("BLOCKCHAIN_PRIVATE_KEY")
    account = Account.from_key(private_key)
    
    # Test gas estimation with real network
    gas_estimate = tool.web3.eth.estimate_gas({
        'from': account.address,
        'to': account.address,
        'value': 0,
        'data': tool.web3.to_bytes(text="test-data")
    })
    
    # Verify gas estimate is reasonable
    assert gas_estimate > 0
    assert gas_estimate < 1000000  # Reasonable upper limit


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY") or not os.getenv("BLOCKCHAIN_PRIVATE_KEY"),
    reason="INFURA_API_KEY or BLOCKCHAIN_PRIVATE_KEY not set in environment variables"
)
def test_prepare_transaction_with_real_account():
    """Test transaction preparation with real account"""
    # This test requires both INFURA_API_KEY and BLOCKCHAIN_PRIVATE_KEY
    tool = InfuraBlockchainTool()
    
    # Get account from private key
    private_key = os.getenv("BLOCKCHAIN_PRIVATE_KEY")
    account = Account.from_key(private_key)
    
    # Prepare transaction
    transaction = tool._prepare_transaction("test-data-hash", private_key)
    
    # Verify transaction structure
    assert 'nonce' in transaction
    assert transaction['to'] == account.address
    assert transaction['value'] == 0
    assert 'gas' in transaction
    assert 'gasPrice' in transaction
    assert 'data' in transaction


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY") or not os.getenv("BLOCKCHAIN_PRIVATE_KEY"),
    reason="INFURA_API_KEY or BLOCKCHAIN_PRIVATE_KEY not set in environment variables"
)
def test_gas_estimation_and_pricing():
    """Test gas estimation and pricing mechanisms"""
    # This test requires both INFURA_API_KEY and BLOCKCHAIN_PRIVATE_KEY
    tool = InfuraBlockchainTool()
    
    # Get current gas price
    gas_price = tool.web3.eth.gas_price
    
    # Verify gas price is reasonable (not zero and not extremely high)
    assert gas_price > 0
    assert gas_price < 1000000000000  # 1000 Gwei - reasonable upper limit
    
    # Get account details
    private_key = os.getenv("BLOCKCHAIN_PRIVATE_KEY")
    account = Account.from_key(private_key)
    
    # Check account balance
    balance = tool.web3.eth.get_balance(account.address)
    
    # Verify account has some balance (at least 0.001 ETH in wei)
    assert balance >= 1000000000000000, f"Insufficient balance: {Web3.from_wei(balance, 'ether')} ETH"


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY") or not os.getenv("BLOCKCHAIN_PRIVATE_KEY"),
    reason="INFURA_API_KEY or BLOCKCHAIN_PRIVATE_KEY not set in environment variables"
)
def test_transaction_confirmation_with_real_network():
    """Test transaction confirmation with real network (skipped by default to avoid spending ETH)"""
    # This test is marked to be skipped by default as it would spend real ETH
    pytest.skip("Skipping real transaction test to avoid spending ETH on Sepolia")
    
    # To run this test, manually remove the skip line above
    tool = InfuraBlockchainTool()
    
    # Get account from private key
    private_key = os.getenv("BLOCKCHAIN_PRIVATE_KEY")
    account = Account.from_key(private_key)
    
    # Check account balance first
    balance = tool.web3.eth.get_balance(account.address)
    if balance < Web3.to_wei(0.0001, 'ether'):
        pytest.skip("Insufficient funds for transaction test")
    
    # Try to send a minimal transaction with data
    try:
        transaction = tool._prepare_transaction("integration-test-data", private_key)
        tx_hash = tool._sign_and_send_transaction(transaction, private_key)
        
        # Verify transaction hash format
        assert tx_hash.startswith("0x")
        assert len(tx_hash) == 66  # "0x" + 64 hex characters
    except Exception as e:
        # If there's an error, it might be due to network conditions
        pytest.fail(f"Transaction failed: {str(e)}")


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment variables"
)
def test_error_handling_with_real_connection():
    """Test error handling with real connection"""
    # This test requires a valid INFURA_API_KEY in the environment
    tool = InfuraBlockchainTool()
    
    # Test with invalid private key
    with pytest.raises(BlockchainError):
        tool.run("test-data-hash", "invalid-private-key")
    
    # Test with invalid data hash
    with pytest.raises(BlockchainError, match="Invalid data_hash provided"):
        tool.run("", "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef12")