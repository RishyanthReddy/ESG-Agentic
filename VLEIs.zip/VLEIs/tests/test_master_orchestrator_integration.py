"""
Integration tests for the upgraded Master Orchestrator with all agents.
"""

import pytest
import time
from unittest.mock import patch, MagicMock
from src.state.models import AppState
from src.agents.core import master_orchestrator


class TestMasterOrchestratorIntegration:
    """Integration test cases for the upgraded master orchestrator."""
    
    def test_complete_task_flow_with_all_agents(self):
        """Test complete task flow with all agent types."""
        # Create a state with tasks for all agent types
        # Changed task names to avoid conflicts in routing rules
        state = AppState(
            task_queue=[
                "verify supplier credentials",              # routes to credential_agent
                "detect anomalies in esg data",            # routes to anomaly_detection_agent
                "generate quarterly report",               # routes to reporting_agent
                "run self-audit on blockchain logs",       # routes to audit_agent
                "finalize esg compliance"                  # routes to finalization_agent (avoiding "report" keyword)
            ]
        )
        
        # Track the execution order
        execution_order = []
        
        # Mock the LLM orchestrator to return appropriate agents
        def mock_llm_orchestrator(task, state, request_id):
            task_lower = task.lower()
            if "verify" in task_lower or "credential" in task_lower:
                execution_order.append("credential_agent")
                return "credential_agent"
            elif "detect" in task_lower or "anomaly" in task_lower:
                execution_order.append("anomaly_detection_agent")
                return "anomaly_detection_agent"
            elif "generate" in task_lower or "report" in task_lower:
                execution_order.append("reporting_agent")
                return "reporting_agent"
            elif "audit" in task_lower:
                execution_order.append("audit_agent")
                return "audit_agent"
            elif "finalize" in task_lower or "final" in task_lower:
                execution_order.append("finalization_agent")
                return "finalization_agent"
            else:
                execution_order.append("credential_agent")
                return "credential_agent"
        
        with patch('src.agents.core.llm_orchestrator', side_effect=mock_llm_orchestrator):
            # Process all tasks
            agents_called = []
            while state.task_queue:
                agent = master_orchestrator(state)
                if agent != "__end__":
                    agents_called.append(agent)
                # Break if we've processed too many tasks (safety check)
                if len(agents_called) > 10:
                    break
            
            # Verify all tasks were processed
            assert len(state.task_queue) == 0
            
            # Verify the expected agents were called in the right order
            expected_agents = [
                "credential_agent",
                "anomaly_detection_agent", 
                "reporting_agent",
                "audit_agent",
                "finalization_agent"
            ]
            
            assert agents_called == expected_agents
            assert execution_order == expected_agents
    
    def test_performance_with_multiple_tasks(self):
        """Test orchestrator performance with multiple tasks."""
        # Create a state with many tasks
        tasks = [
            f"task_{i}_{['verify', 'detect', 'generate', 'audit', 'finalize'][i % 5]}_data"
            for i in range(100)
        ]
        
        state = AppState(task_queue=tasks)
        
        # Mock the LLM orchestrator to cycle through agents
        agent_cycle = ["credential_agent", "anomaly_detection_agent", "reporting_agent", "audit_agent", "finalization_agent"]
        
        def mock_llm_orchestrator(task, state, request_id):
            # Simple round-robin assignment
            task_index = int(task.split('_')[1])
            return agent_cycle[task_index % len(agent_cycle)]
        
        with patch('src.agents.core.llm_orchestrator', side_effect=mock_llm_orchestrator):
            start_time = time.time()
            
            # Process all tasks
            agents_called = []
            while state.task_queue:
                agent = master_orchestrator(state)
                if agent != "__end__":
                    agents_called.append(agent)
                # Break if we've processed too many tasks (safety check)
                if len(agents_called) > 150:
                    break
            
            end_time = time.time()
            
            # Verify all tasks were processed
            assert len(state.task_queue) == 0
            
            # Verify performance (should process 100 tasks quickly)
            processing_time = end_time - start_time
            assert processing_time < 5.0  # Should be less than 5 seconds
            
            # Verify we called the expected number of agents
            assert len(agents_called) == 100
    
    def test_error_handling_in_routing(self):
        """Test error handling in the orchestrator."""
        # Create a state with an empty task (will cause routing error)
        state = AppState(task_queue=["", "verify credentials"])
        
        with pytest.raises(Exception) as exc_info:
            master_orchestrator(state)
        
        # Verify the error is related to routing
        assert "Failed to route task" in str(exc_info.value)
        assert "Task name cannot be empty" in str(exc_info.value)
        
        # Verify that the first task was consumed even though it caused an error
        assert len(state.task_queue) == 1
    
    def test_fallback_to_rule_based_routing(self):
        """Test fallback to rule-based routing when LLM fails."""
        state = AppState(task_queue=["detect anomalies in supplier data"])
        
        # Mock LLM orchestrator to raise an exception (simulating failure)
        def failing_llm_orchestrator(task, state, request_id):
            raise Exception("LLM service unavailable")
        
        with patch('src.agents.core.llm_orchestrator', side_effect=failing_llm_orchestrator):
            # Should fallback to rule-based routing
            agent = master_orchestrator(state)
            
            # Should correctly route to anomaly detection agent via rule-based routing
            assert agent == "anomaly_detection_agent"
            assert len(state.task_queue) == 0  # Task should be consumed
    
    def test_task_flow_validation(self):
        """Test validation of complete task flow execution."""
        # Create a realistic task flow with tasks that avoid routing conflicts
        state = AppState(
            task_queue=[
                "verify supplier credentials",              # routes to credential_agent
                "detect anomalies in esg data",            # routes to anomaly_detection_agent
                "generate quarterly esg",                  # routes to reporting_agent
                "run self-audit on blockchain logs",       # routes to audit_agent
                "finalize and sign esg compliance"         # routes to finalization_agent
            ]
        )
        
        # Expected execution order based on task content
        expected_execution_order = [
            "credential_agent",
            "anomaly_detection_agent",
            "reporting_agent", 
            "audit_agent",
            "finalization_agent"
        ]
        
        # Track actual execution
        actual_execution_order = []
        
        def mock_llm_orchestrator(task, state, request_id):
            task_lower = task.lower()
            if "verify" in task_lower or "credential" in task_lower:
                actual_execution_order.append("credential_agent")
                return "credential_agent"
            elif "detect" in task_lower or "anomaly" in task_lower:
                actual_execution_order.append("anomaly_detection_agent")
                return "anomaly_detection_agent"
            elif "generate" in task_lower or "report" in task_lower:
                actual_execution_order.append("reporting_agent")
                return "reporting_agent"
            elif "audit" in task_lower:
                actual_execution_order.append("audit_agent")
                return "audit_agent"
            elif "finalize" in task_lower or "sign" in task_lower or "final" in task_lower:
                actual_execution_order.append("finalization_agent")
                return "finalization_agent"
            else:
                actual_execution_order.append("credential_agent")
                return "credential_agent"
        
        with patch('src.agents.core.llm_orchestrator', side_effect=mock_llm_orchestrator):
            # Process all tasks
            while state.task_queue:
                agent = master_orchestrator(state)
                if agent == "__end__":
                    break
                # Safety break
                if len(actual_execution_order) > 10:
                    break
            
            # Verify the execution order matches expected
            assert actual_execution_order == expected_execution_order
            assert len(state.task_queue) == 0  # All tasks should be processed


if __name__ == "__main__":
    pytest.main([__file__, "-v"])