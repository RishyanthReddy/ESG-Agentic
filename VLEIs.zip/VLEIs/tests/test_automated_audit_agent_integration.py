"""
Integration tests for the Automated Audit Agent

This module contains tests for verifying the end-to-end functionality of the 
automated_audit_agent including continuous auditing, audit coverage, performance 
impact, compliance validation, and alert testing.
"""

import pytest
import os
import hashlib
import json
from unittest.mock import Mock, patch
from src.agents.audit import automated_audit_agent, AuditError
from src.state.models import AppState, vLEICredential, AuditTrailEntry
from src.tools.audit import BlockchainOracleTool
from src.tools.provenance import InfuraBlockchainTool
from src.tools.registry import ToolRegistry


@pytest.mark.skipif(
    not os.getenv("INFURA_API_KEY"),
    reason="INFURA_API_KEY not set in environment"
)
def test_continuous_auditing():
    """Test long-term automated audit execution"""
    # Skip if we don't have a private key for testing
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if not private_key:
        pytest.skip("TEST_PRIVATE_KEY not set in environment")
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Test Corp",
            "test_data": "integration test",
            "timestamp": "2023-01-01T00:00:00Z"
        }
    )
    
    # Create state with credential and private key
    state = AppState(
        current_credential=credential,
        config={"blockchain_private_key": private_key}
    )
    
    # First, log data to blockchain using InfuraBlockchainTool
    blockchain_tool = InfuraBlockchainTool()
    
    # Serialize credential for consistent hashing
    credential_data = credential.model_dump(mode="json")
    credential_json = json.dumps(credential_data, sort_keys=True, separators=(',', ':'))
    credential_hash = hashlib.sha256(credential_json.encode('utf-8')).hexdigest()
    
    # Log to blockchain
    blockchain_result = blockchain_tool.run(credential_hash, private_key)
    
    # Update state with blockchain log entry
    state.blockchain_log = [
        {
            "transaction_hash": blockchain_result["transaction_hash"],
            "data_hash": credential_hash,
            "data_id": str(credential.id),
            "account": blockchain_result["account"],
            "timestamp": blockchain_result["timestamp"],
            "status": "success"
        }
    ]
    
    # Register the BlockchainOracleTool
    registry = ToolRegistry.get_instance()
    oracle_tool = BlockchainOracleTool()
    registry.register_tool(oracle_tool)
    
    # Run the audit agent
    result = automated_audit_agent(state)
    
    # Verify successful execution
    assert result["workflow_status"] == "audit_completed"
    assert "audit_trail" in result
    assert len(result["audit_trail"]) >= 1
    
    # Verify audit trail entry
    audit_entry = result["audit_trail"][0]
    assert isinstance(audit_entry, AuditTrailEntry)
    assert audit_entry.audit_type == "blockchain_verification"
    assert audit_entry.transaction_hash == blockchain_result["transaction_hash"]
    
    # Verify processing results
    assert "processing_results" in result
    assert "audit_result" in result["processing_results"]
    audit_result = result["processing_results"]["audit_result"]
    assert audit_result["total_audited"] >= 1
    assert audit_result["successful_audits"] >= 0
    assert audit_result["failed_audits"] >= 0


def test_audit_coverage():
    """Test comprehensive audit coverage validation"""
    # Create multiple test credentials
    credentials = []
    blockchain_logs = []
    
    for i in range(3):
        credential = vLEICredential(
            issuer=f"did:example:issuer{i}",
            subject=f"did:example:subject{i}",
            claims={"test": f"data{i}"}
        )
        credentials.append(credential)
        
        blockchain_logs.append({
            "transaction_hash": f"0x1234567890abcdef{i:02d}",
            "data_hash": f"test_hash_{i}",
            "data_id": str(credential.id),
            "account": "0xAccount123",
            "block_number": 1000000 + i,
            "gas_used": 21000,
            "timestamp": "2023-01-01T00:00:00Z"
        })
    
    # Create app state with multiple entries
    state = AppState(
        credentials=credentials,
        blockchain_log=blockchain_logs
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock verification results
        mock_oracle_tool.run.return_value = {
            "success": True,
            "verified_entries": 1,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef00",
                    "verified": True,
                    "match": True,
                    "error": None
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify audit coverage
        assert result["workflow_status"] == "audit_completed"
        assert len(result["audit_trail"]) == 3  # All entries should be audited
        assert all(isinstance(entry, AuditTrailEntry) for entry in result["audit_trail"])
        
        # Verify processing results show proper coverage
        audit_result = result["processing_results"]["audit_result"]
        assert audit_result["total_audited"] == 3
        assert audit_result["successful_audits"] == 3
        assert audit_result["failed_audits"] == 0


def test_performance_impact():
    """Test audit performance impact on system"""
    # Create a large number of blockchain log entries
    blockchain_logs = []
    for i in range(20):  # Create 20 entries
        blockchain_logs.append({
            "transaction_hash": f"0x1234567890abcdef{i:02d}",
            "data_hash": f"test_hash_{i}",
            "data_id": f"test_id_{i}",
            "account": "0xAccount123",
            "block_number": 1000000 + i,
            "gas_used": 21000,
            "timestamp": "2023-01-01T00:00:00Z"
        })
    
    # Create app state
    state = AppState(
        blockchain_log=blockchain_logs
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock verification results
        mock_oracle_tool.run.return_value = {
            "success": True,
            "verified_entries": 1,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef00",
                    "verified": True,
                    "match": True,
                    "error": None
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify it sampled a reasonable number (not all 20)
        assert result["workflow_status"] == "audit_completed"
        audit_result = result["processing_results"]["audit_result"]
        assert audit_result["total_audited"] == 5  # Should sample 5 by default
        assert len(result["audit_trail"]) == 5


def test_compliance_validation():
    """Test audit compliance with regulatory requirements"""
    # Create app state with blockchain logs
    state = AppState(
        blockchain_log=[
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash",
                "data_id": "test_id",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            }
        ]
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock successful verification result
        mock_oracle_tool.run.return_value = {
            "success": True,
            "verified_entries": 1,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef",
                    "verified": True,
                    "match": True,
                    "on_chain_hash": "test_hash",
                    "off_chain_hash": "test_hash",
                    "error": None
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify compliance by checking audit trail
        assert result["workflow_status"] == "audit_completed"
        assert len(result["audit_trail"]) == 1
        
        # Verify audit trail entry contains required compliance information
        audit_entry = result["audit_trail"][0]
        assert audit_entry.audit_type == "blockchain_verification"
        assert audit_entry.transaction_hash == "0x1234567890abcdef"
        assert audit_entry.verification_result is True
        assert "verified" in audit_entry.details
        assert "match" in audit_entry.details


def test_alert_testing():
    """Test audit failure detection and alerting"""
    # Create app state with blockchain logs
    state = AppState(
        blockchain_log=[
            {
                "transaction_hash": "0x1234567890abcdef",
                "data_hash": "test_hash",
                "data_id": "test_id",
                "account": "0xAccount123",
                "block_number": 1000000,
                "gas_used": 21000,
                "timestamp": "2023-01-01T00:00:00Z"
            }
        ]
    )
    
    # Mock the tool registry and oracle tool
    with patch('src.agents.audit.ToolRegistry') as mock_registry_class:
        mock_registry = Mock(spec=ToolRegistry)
        mock_registry_class.get_instance.return_value = mock_registry
        
        # Mock oracle tool
        mock_oracle_tool = Mock()
        mock_registry.get_tool.return_value = mock_oracle_tool
        
        # Mock failed verification result
        mock_oracle_tool.run.return_value = {
            "success": False,
            "verified_entries": 0,
            "total_entries": 1,
            "results": [
                {
                    "transaction_hash": "0x1234567890abcdef",
                    "verified": False,
                    "match": False,
                    "error": "Hash mismatch detected"
                }
            ]
        }
        
        # Run the audit agent
        result = automated_audit_agent(state)
        
        # Verify alerting by checking audit trail
        assert result["workflow_status"] == "audit_completed"
        assert len(result["audit_trail"]) == 1
        
        # Verify audit trail entry shows failure
        audit_entry = result["audit_trail"][0]
        assert audit_entry.audit_type == "blockchain_verification"
        assert audit_entry.transaction_hash == "0x1234567890abcdef"
        assert audit_entry.verification_result is False  # Failed verification
        
        # Verify processing results show the failure
        audit_result = result["processing_results"]["audit_result"]
        assert audit_result["total_audited"] == 1
        assert audit_result["successful_audits"] == 0
        assert audit_result["failed_audits"] == 1
        
        # Verify the error is properly recorded
        assert len(audit_result["audit_results"]) == 1
        assert audit_result["audit_results"][0]["error"] == "Hash mismatch detected"


if __name__ == "__main__":
    pytest.main([__file__])