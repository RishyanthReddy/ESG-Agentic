"""
Simple syntax check script for the modal entrypoint

This script checks the Python syntax of the modal_entrypoint.py file
without requiring Modal to be installed.
"""

import pytest
import os
import ast

def test_modal_entrypoint_syntax():
    """Test that the modal entrypoint file has valid Python syntax."""
    # Get the path to the modal entrypoint file
    current_dir = os.path.dirname(__file__)
    project_root = os.path.dirname(current_dir)
    entrypoint_path = os.path.join(project_root, 'modal_entrypoint.py')
    
    # Check if the file exists
    assert os.path.exists(entrypoint_path), "modal_entrypoint.py file should exist"
    
    # Read the file content
    with open(entrypoint_path, 'r') as f:
        content = f.read()
    
    # Try to parse the content
    try:
        ast.parse(content)
    except SyntaxError as e:
        pytest.fail(f"modal_entrypoint.py has syntax errors: {e}")
"""
Unit tests for Modal platform integration

This module contains tests for verifying the correct configuration and
functionality of the Modal deployment setup.
"""

import pytest
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Skip all tests if Modal is not available or not compatible
try:
    import modal
    MODAL_AVAILABLE = True
except (ImportError, RuntimeError):
    MODAL_AVAILABLE = False

if MODAL_AVAILABLE:
    try:
        from modal_entrypoint import (
            app as modal_app,
            fastapi,
            run_anomaly_detection,
            run_visualization_with_path_highlighting,
            batch_process_esg_data
        )
    except Exception:
        MODAL_AVAILABLE = False


class TestModalIntegration:
    """Test cases for the Modal integration."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        if not MODAL_AVAILABLE:
            pytest.skip("Modal not available or not compatible with current Python version")
    
    def test_modal_app_creation(self):
        """Test that the Modal app is created correctly."""
        assert modal_app is not None
        assert isinstance(modal_app, modal.App)
    
    def test_fastapi_function_definition(self):
        """Test that the FastAPI function is defined correctly."""
        # Check that the fastapi function exists
        assert fastapi is not None
        
        # Check that it has the proper decorators
        assert hasattr(fastapi, "web_url") or hasattr(fastapi, "mount_url")
    
    def test_anomaly_detection_function_definition(self):
        """Test that the anomaly detection function is defined correctly."""
        # Check that the function exists
        assert run_anomaly_detection is not None
        
        # Check that it has the proper decorators
        assert hasattr(run_anomaly_detection, "remote")
    
    def test_visualization_function_definition(self):
        """Test that the visualization function is defined correctly."""
        # Check that the function exists
        assert run_visualization_with_path_highlighting is not None
        
        # Check that it has the proper decorators
        assert hasattr(run_visualization_with_path_highlighting, "remote")
    
    def test_batch_processing_function_definition(self):
        """Test that the batch processing function is defined correctly."""
        # Check that the function exists
        assert batch_process_esg_data is not None
        
        # Check that it has the proper decorators
        assert hasattr(batch_process_esg_data, "remote")
    
    def test_gpu_configuration(self):
        """Test that GPU configuration is properly set."""
        # This test ensures that GPU configuration is specified
        # In the actual implementation, we check for the A10G GPU config
        from modal_entrypoint import GPU_CONFIG
        assert GPU_CONFIG is not None
        # We can't easily test the exact type without importing modal internals
        # but we can check that it's not None
    
    def test_mounts_configuration(self):
        """Test that mounts are properly configured."""
        # This test ensures that mounts are specified
        # We check that the mounts list exists and is not empty
        from modal_entrypoint import mounts
        assert mounts is not None
        assert isinstance(mounts, list)
        # We should have at least one mount
        assert len(mounts) > 0


# Simple validation test that doesn't require Modal
class TestModalCodeValidation:
    """Simple validation tests that don't require Modal to be installed."""
    
    def test_modal_entrypoint_exists(self):
        """Test that the modal entrypoint file exists."""
        import os
        
        # Check if the file exists
        entrypoint_path = os.path.join(os.path.dirname(__file__), '..', 'modal_entrypoint.py')
        assert os.path.exists(entrypoint_path), "modal_entrypoint.py file should exist"
    
    def test_requirements_includes_modal(self):
        """Test that requirements.txt includes modal."""
        import os
        
        requirements_path = os.path.join(os.path.dirname(__file__), '..', 'requirements.txt')
        assert os.path.exists(requirements_path), "requirements.txt file should exist"
        
        with open(requirements_path, 'r') as f:
            content = f.read()
            assert 'modal==' in content, "requirements.txt should include modal"


if __name__ == "__main__":
    pytest.main([__file__])