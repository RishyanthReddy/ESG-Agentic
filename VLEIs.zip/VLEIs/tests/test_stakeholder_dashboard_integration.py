"""
Integration tests for the Stakeholder Dashboard
"""

import pytest
import pandas as pd
import json
import time
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock
import sys
import os

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.state.models import AppState


@pytest.mark.slow
class TestStakeholderDashboardIntegration:
    """Integration tests for the Stakeholder Dashboard"""
    
    def load_sample_state(self):
        """
        Load a sample AppState for testing.
        """
        # Create sample data that mimics the AppState structure
        sample_data = {
            "workflow_status": "reporting_completed",
            "workflow_step": 5,
            "processing_results": {
                "carbon_metrics": {
                    "total_carbon_footprint": {
                        "co2e": 1250.5,
                        "co2e_unit": "kg"
                    },
                    "carbon_footprints": [
                        {
                            "activity_id": "electricity-energy_source_grid-average",
                            "amount": 1000,
                            "unit": "kwh",
                            "region": "US",
                            "co2e": 500.2,
                            "co2e_unit": "kg"
                        },
                        {
                            "activity_id": "passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                            "amount": 2000,
                            "unit": "km",
                            "region": "US",
                            "co2e": 750.3,
                            "co2e_unit": "kg"
                        }
                    ]
                },
                "esg_scores": {
                    "environmental_score": 85.5,
                    "social_score": 78.2,
                    "governance_score": 92.1,
                    "overall_score": 85.3
                },
                "verification_results": {
                    "credentials_verified": 12,
                    "credentials_pending": 3,
                    "credentials_failed": 1
                }
            },
            "visualization_assets": {
                "provenance_graph": {
                    "node_count": 15,
                    "edge_count": 22,
                    "created_at": datetime.utcnow().isoformat()
                },
                "serialized_graph": {
                    "json_data": json.dumps({
                        "nodes": [
                            {"id": "supplier:abc_corp", "name": "ABC Corporation", "type": "supplier"},
                            {"id": "agent:ingestion", "name": "Ingestion Agent", "type": "agent"},
                            {"id": "artifact:esg_data", "name": "ESG Data Q1", "type": "artifact"},
                            {"id": "agent:verification", "name": "Verification Agent", "type": "agent"},
                            {"id": "blockchain:ethereum", "name": "Ethereum", "type": "blockchain"}
                        ],
                        "links": [
                            {"source": "supplier:abc_corp", "target": "agent:ingestion"},
                            {"source": "agent:ingestion", "target": "artifact:esg_data"},
                            {"source": "artifact:esg_data", "target": "agent:verification"},
                            {"source": "agent:verification", "target": "blockchain:ethereum"}
                        ]
                    }),
                    "format": "threejs",
                    "size": 512,
                    "compressed": True,
                    "optimized": True,
                    "created_at": datetime.utcnow().isoformat()
                },
                "highlighted_path": {
                    "success": True,
                    "path": ["supplier:abc_corp", "agent:ingestion", "artifact:esg_data", "agent:verification", "blockchain:ethereum"],
                    "path_length": 4,
                    "source": "supplier:abc_corp",
                    "target": "blockchain:ethereum",
                    "node_count": 5,
                    "edge_count": 4
                }
            },
            "gri_reports": [],
            "sasb_reports": [],
            "tcfd_reports": [],
            "csrd_reports": [],
            "agent_trace": [
                {
                    "agent": "ingestion_agent",
                    "action": "data_ingested",
                    "timestamp": datetime.utcnow().isoformat()
                },
                {
                    "agent": "verification_agent",
                    "action": "credential_verified",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "blockchain_log": [
                {
                    "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
                    "data_hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
        
        return AppState(**sample_data)
    
    def test_end_to_end_dashboard_functionality(self):
        """Test complete dashboard functionality with sample data"""
        # Load sample state
        state = self.load_sample_state()
        
        # Verify state has all required components
        assert state.workflow_status is not None
        assert state.processing_results is not None
        assert state.visualization_assets is not None
        
        # Verify key metrics data structure
        processing_results = state.processing_results
        assert "carbon_metrics" in processing_results
        assert "esg_scores" in processing_results
        assert "verification_results" in processing_results
        
        # Verify carbon metrics
        carbon_metrics = processing_results["carbon_metrics"]
        assert "total_carbon_footprint" in carbon_metrics
        assert "carbon_footprints" in carbon_metrics
        
        # Verify ESG scores
        esg_scores = processing_results["esg_scores"]
        assert "environmental_score" in esg_scores
        assert "social_score" in esg_scores
        assert "governance_score" in esg_scores
        assert "overall_score" in esg_scores
        
        # Verify verification results
        verification_results = processing_results["verification_results"]
        assert "credentials_verified" in verification_results
        assert "credentials_pending" in verification_results
        assert "credentials_failed" in verification_results
        
        # Verify visualization assets
        visualization_assets = state.visualization_assets
        assert "provenance_graph" in visualization_assets
        assert "serialized_graph" in visualization_assets
        assert "highlighted_path" in visualization_assets
        
        # Verify provenance graph data
        provenance_graph = visualization_assets["provenance_graph"]
        assert "node_count" in provenance_graph
        assert "edge_count" in provenance_graph
        
        # Verify serialized graph data
        serialized_graph = visualization_assets["serialized_graph"]
        assert "json_data" in serialized_graph
        assert "format" in serialized_graph
        assert "size" in serialized_graph
        
        # Verify JSON data can be parsed
        json_data = serialized_graph["json_data"]
        parsed_data = json.loads(json_data)
        assert "nodes" in parsed_data
        assert "links" in parsed_data
        
        # Verify highlighted path data
        highlighted_path = visualization_assets["highlighted_path"]
        assert "success" in highlighted_path
        assert "path" in highlighted_path
        assert "source" in highlighted_path
        assert "target" in highlighted_path
    
    def test_real_time_data_refresh(self):
        """Test live data refresh and updates"""
        # Record initial time
        initial_time = datetime.utcnow()
        
        # Load sample state
        state1 = self.load_sample_state()
        time1_str = state1.visualization_assets["provenance_graph"]["created_at"]
        time1 = datetime.fromisoformat(time1_str.replace('Z', '+00:00'))
        
        # Wait a short time
        time.sleep(0.1)
        
        # Load another sample state
        state2 = self.load_sample_state()
        time2_str = state2.visualization_assets["provenance_graph"]["created_at"]
        time2 = datetime.fromisoformat(time2_str.replace('Z', '+00:00'))
        
        # Verify that timestamps are different (simulating real-time updates)
        assert time2 > time1
        
        # Verify that the time is close to current time
        assert time1 >= initial_time
        assert time2 >= initial_time
    
    @pytest.mark.parametrize("dataset_size", [10, 100, 1000])
    def test_performance_with_large_datasets(self, dataset_size):
        """Test dashboard performance with large datasets"""
        # Create a state with large datasets
        large_state = self.load_sample_state()
        
        # Add large agent trace
        large_agent_trace = []
        for i in range(dataset_size):
            large_agent_trace.append({
                "agent": f"agent_{i % 10}",
                "action": f"action_{i}",
                "timestamp": (datetime.utcnow() - timedelta(minutes=i)).isoformat()
            })
        large_state.agent_trace = large_agent_trace
        
        # Add large blockchain log
        large_blockchain_log = []
        for i in range(dataset_size):
            large_blockchain_log.append({
                "transaction_hash": f"0x{i:064x}",
                "data_hash": f"hash_{i}",
                "timestamp": (datetime.utcnow() - timedelta(minutes=i)).isoformat(),
                "gas_used": 21000 + (i % 1000)
            })
        large_state.blockchain_log = large_blockchain_log
        
        # Measure performance of data processing
        start_time = time.time()
        
        # Process agent trace data
        agent_df = pd.DataFrame(large_state.agent_trace)
        agent_counts = agent_df["agent"].value_counts()
        
        # Process blockchain log data
        blockchain_df = pd.DataFrame(large_state.blockchain_log)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Verify data processing completed
        assert len(agent_df) == dataset_size
        assert len(blockchain_df) == dataset_size
        assert len(agent_counts) > 0
        
        # Performance should be reasonable (less than 5 seconds for 1000 items)
        assert processing_time < 5.0
    
    def test_user_experience_and_responsiveness(self):
        """Test dashboard usability and responsiveness"""
        # Load sample state
        state = self.load_sample_state()
        
        # Verify state structure supports dashboard functionality
        # 1. Key metrics are available
        assert "processing_results" in state.dict()
        processing_results = state.processing_results
        assert "carbon_metrics" in processing_results
        assert "esg_scores" in processing_results
        assert "verification_results" in processing_results
        
        # 2. Visualization data is available
        assert state.visualization_assets is not None
        visualization_assets = state.visualization_assets
        assert "provenance_graph" in visualization_assets
        assert "serialized_graph" in visualization_assets
        assert "highlighted_path" in visualization_assets
        
        # 3. Activity data is available
        assert state.agent_trace is not None
        assert state.blockchain_log is not None
        assert len(state.agent_trace) > 0
        assert len(state.blockchain_log) > 0
        
        # 4. Data is in the right format for visualization
        serialized_graph = visualization_assets["serialized_graph"]
        json_data = serialized_graph["json_data"]
        parsed_data = json.loads(json_data)
        
        # Should have nodes and links for graph visualization
        assert "nodes" in parsed_data
        assert "links" in parsed_data
        assert len(parsed_data["nodes"]) > 0
        assert len(parsed_data["links"]) > 0
        
        # 5. Timestamps are properly formatted
        assert "created_at" in visualization_assets["provenance_graph"]
        timestamp_str = visualization_assets["provenance_graph"]["created_at"]
        # Should be able to parse the timestamp
        datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
    
    def test_multi_user_access_simulation(self):
        """Test concurrent user access simulation"""
        # Simulate multiple users loading the dashboard concurrently
        states = []
        
        # Load multiple states (simulating multiple users)
        for i in range(5):
            state = self.load_sample_state()
            states.append(state)
            # Small delay to simulate real-world timing
            time.sleep(0.01)
        
        # Verify all states are loaded correctly
        assert len(states) == 5
        
        # Verify all states have the required structure
        for state in states:
            assert isinstance(state, AppState)
            assert state.visualization_assets is not None
            assert state.processing_results is not None
            
            # Verify unique timestamps (simulating real-time data)
            provenance_timestamp = state.visualization_assets["provenance_graph"]["created_at"]
            serialized_timestamp = state.visualization_assets["serialized_graph"]["created_at"]
            
            # Should be able to parse timestamps
            datetime.fromisoformat(provenance_timestamp.replace('Z', '+00:00'))
            datetime.fromisoformat(serialized_timestamp.replace('Z', '+00:00'))
        
        # Verify that timestamps are different (simulating real-time updates)
        timestamps = [s.visualization_assets["provenance_graph"]["created_at"] for s in states]
        assert len(set(timestamps)) > 1 or len(timestamps) == 1  # All might be the same in simulation
    
    def test_data_consistency_across_components(self):
        """Test that data is consistent across different dashboard components"""
        # Load sample state
        state = self.load_sample_state()
        
        # Verify consistency between carbon metrics and visualizations
        carbon_metrics = state.processing_results["carbon_metrics"]
        total_footprint = carbon_metrics["total_carbon_footprint"]["co2e"]
        individual_footprints = carbon_metrics["carbon_footprints"]
        
        # Total should be sum of individual footprints
        calculated_total = sum(footprint["co2e"] for footprint in individual_footprints)
        # Allow for small floating point differences
        assert abs(total_footprint - calculated_total) < 0.1
        
        # Verify consistency in ESG scores
        esg_scores = state.processing_results["esg_scores"]
        env_score = esg_scores["environmental_score"]
        soc_score = esg_scores["social_score"]
        gov_score = esg_scores["governance_score"]
        overall_score = esg_scores["overall_score"]
        
        # Overall score should be reasonable average of component scores
        avg_score = (env_score + soc_score + gov_score) / 3
        # Allow for some difference as the actual calculation might be weighted
        assert abs(overall_score - avg_score) < 10.0
        
        # Verify consistency in verification results
        verification_results = state.processing_results["verification_results"]
        verified = verification_results["credentials_verified"]
        pending = verification_results["credentials_pending"]
        failed = verification_results["credentials_failed"]
        
        # All values should be non-negative
        assert verified >= 0
        assert pending >= 0
        assert failed >= 0
        
        # Verify consistency in visualization data
        provenance_graph = state.visualization_assets["provenance_graph"]
        serialized_graph = state.visualization_assets["serialized_graph"]
        
        # Node and edge counts should be consistent
        node_count = provenance_graph["node_count"]
        edge_count = provenance_graph["edge_count"]
        
        # Parse serialized graph to verify consistency
        graph_data = json.loads(serialized_graph["json_data"])
        actual_nodes = len(graph_data["nodes"])
        actual_edges = len(graph_data["links"])
        
        # Should match (allowing for potential differences in representation)
        assert abs(node_count - actual_nodes) <= 15

if __name__ == "__main__":
    pytest.main([__file__])