"""
Unit tests for the health endpoint
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, Mock, patch
from fastapi.testclient import TestClient
from main import app
from src.llm.client import LLMError

client = TestClient(app)

def test_health_endpoint_structure():
    """Test that health endpoint returns correct format"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert "status" in data
    assert "timestamp" in data
    assert "checks" in data
    assert "response_time" in data
    
    # Check that all required components are present in checks
    checks = data["checks"]
    assert "llm" in checks
    assert "blockchain" in checks
    assert "database" in checks

@patch('src.llm.client.GeminiClient.generate_content')
@patch('src.llm.client.GeminiClient.__aexit__')
@patch('src.llm.client.GeminiClient.__aenter__')
def test_health_endpoint_llm_healthy(mock_aenter, mock_aexit, mock_generate_content):
    """Test health endpoint when LLM is healthy"""
    # Mock the LLM client
    mock_client = AsyncMock()
    mock_aenter.return_value = mock_client
    mock_generate_content.return_value = "healthy"
    
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert data["checks"]["llm"]["status"] == "healthy"

@patch('src.llm.client.GeminiClient.generate_content')
@patch('src.llm.client.GeminiClient.__aexit__')
@patch('src.llm.client.GeminiClient.__aenter__')
def test_health_endpoint_llm_unhealthy(mock_aenter, mock_aexit, mock_generate_content):
    """Test health endpoint when LLM is unhealthy"""
    # Mock the LLM client to raise an exception
    mock_client = AsyncMock()
    mock_aenter.return_value = mock_client
    mock_generate_content.side_effect = LLMError("Connection failed")
    
    response = client.get("/health")
    assert response.status_code == 200  # Endpoint should still return 200, but with unhealthy status
    
    data = response.json()
    assert data["checks"]["llm"]["status"] == "unhealthy"
    assert data["status"] in ["unhealthy", "degraded"]

@patch('web3.Web3')
def test_health_endpoint_blockchain_healthy(mock_web3):
    """Test health endpoint when blockchain is healthy"""
    # Mock Web3 connection
    mock_instance = Mock()
    mock_instance.is_connected.return_value = True
    mock_instance.eth.block_number = 12345678
    mock_web3.return_value = mock_instance
    
    with patch.dict('os.environ', {'INFURA_API_KEY': 'test-key'}):
        response = client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data["checks"]["blockchain"]["status"] == "healthy"
        assert data["checks"]["blockchain"]["latest_block"] == 12345678

@patch('web3.Web3')
def test_health_endpoint_blockchain_unhealthy(mock_web3):
    """Test health endpoint when blockchain is unhealthy"""
    # Mock Web3 connection failure
    mock_instance = Mock()
    mock_instance.is_connected.return_value = False
    mock_web3.return_value = mock_instance
    
    with patch.dict('os.environ', {'INFURA_API_KEY': 'test-key'}):
        response = client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data["checks"]["blockchain"]["status"] == "unhealthy"

def test_health_endpoint_database_healthy():
    """Test health endpoint when database/state is healthy"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert data["checks"]["database"]["status"] == "healthy"

def test_health_endpoint_response_time():
    """Test that health endpoint includes response time"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert "response_time" in data
    assert isinstance(data["response_time"], float)
    assert data["response_time"] > 0

def test_health_endpoint_overall_status():
    """Test that overall status is healthy when all components are healthy"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    # If all checks pass, status should be healthy
    # If any check fails, status might be unhealthy or degraded
    assert "status" in data