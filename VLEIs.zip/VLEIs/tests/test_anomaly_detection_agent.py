"""
Unit tests for the Anomaly Detection Agent

This module contains tests for verifying the correct functionality of the 
anomaly_detection_agent including data processing, model integration,
alert generation, and state updates.
"""

import pytest
import sys
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.agents.esg import anomaly_detection_agent, AnomalyDetectionError
from src.state.models import AppState
from src.tools.registry import ToolRegistry


class TestAnomalyDetectionAgent:
    """Test cases for the anomaly_detection_agent function."""
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Create sample supplier data with Scope 3 data
        self.sample_supplier_data = {
            "company_name": "Test Company Ltd",
            "esg_rating": "AA",
            "report_year": 2023,
            "revenue": 1000000,
            "industry": "Technology",
            "employees": 500,
            "hq_location": "New York, NY",
            "scope3_data": [
                {
                    "timestamp": "2023-01-01T00:00:00Z",
                    "value": 100.0,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_1",
                    "confidence_score": 0.95
                },
                {
                    "timestamp": "2023-01-02T00:00:00Z",
                    "value": 102.5,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_1",
                    "confidence_score": 0.94
                },
                {
                    "timestamp": "2023-01-03T00:00:00Z",
                    "value": 98.7,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_1",
                    "confidence_score": 0.96
                },
                {
                    "timestamp": "2023-01-04T00:00:00Z",
                    "value": 101.2,
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_1",
                    "confidence_score": 0.93
                },
                {
                    "timestamp": "2023-01-05T00:00:00Z",
                    "value": 250.0,  # Anomalous value
                    "metric_type": "co2_emissions",
                    "supplier_id": "supplier_1",
                    "confidence_score": 0.95
                }
            ]
        }
        
        # Create initial AppState
        self.initial_state = AppState(
            workflow_data={
                "supplier_data": self.sample_supplier_data
            },
            processing_results={},
            agent_trace=[],
            errors=[]
        )
    
    def test_data_processing(self):
        """Test ESG metrics data extraction and processing."""
        # Test with valid data
        with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
            mock_registry = MagicMock()
            mock_tool = MagicMock()
            mock_tool.run.return_value = {
                "success": True,
                "anomaly_count": 1,
                "total_points": 5,
                "anomaly_percentage": 20.0,
                "results": [],
                "device": "cpu",
                "timestamp": 1234567890
            }
            mock_registry.get_tool.return_value = None  # Force creation of new tool
            mock_registry_class.return_value = mock_registry
            
            with patch('src.agents.esg.Scope3AnomalyPredictorTool') as mock_tool_class:
                mock_tool_class.return_value = mock_tool
                
                result = anomaly_detection_agent(self.initial_state)
                
                # Verify the function completed successfully
                assert result["workflow_status"] == "anomaly_detection_completed"
                
                # Verify the tool was called with the correct data
                mock_tool.run.assert_called_once()
                call_args = mock_tool.run.call_args[0][0]
                assert len(call_args) == 5  # 5 data points
    
    def test_model_integration(self):
        """Test anomaly detection model integration."""
        with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
            mock_registry = MagicMock()
            mock_tool = MagicMock()
            mock_result = {
                "success": True,
                "anomaly_count": 1,
                "total_points": 5,
                "anomaly_percentage": 20.0,
                "results": [
                    {
                        "timestamp": "2023-01-01T00:00:00Z",
                        "value": 100.0,
                        "anomaly_score": 0.1,
                        "is_anomaly": False,
                        "confidence": 0.95
                    },
                    {
                        "timestamp": "2023-01-05T00:00:00Z",
                        "value": 250.0,
                        "anomaly_score": 0.9,
                        "is_anomaly": True,
                        "confidence": 0.95
                    }
                ],
                "device": "cpu",
                "timestamp": 1234567890
            }
            mock_tool.run.return_value = mock_result
            mock_registry.get_tool.return_value = None  # Force creation of new tool
            mock_registry_class.return_value = mock_registry
            
            with patch('src.agents.esg.Scope3AnomalyPredictorTool') as mock_tool_class:
                mock_tool_class.return_value = mock_tool
                
                result = anomaly_detection_agent(self.initial_state)
                
                # Verify the processing results were updated
                assert "processing_results" in result
                assert "anomaly_detection" in result["processing_results"]
                assert result["processing_results"]["anomaly_detection"] == mock_result
    
    def test_alert_generation(self):
        """Test anomaly alert creation and management."""
        with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
            mock_registry = MagicMock()
            mock_tool = MagicMock()
            mock_result = {
                "success": True,
                "anomaly_count": 2,
                "total_points": 5,
                "anomaly_percentage": 40.0,
                "results": [],
                "device": "cpu",
                "timestamp": 1234567890
            }
            mock_tool.run.return_value = mock_result
            mock_registry.get_tool.return_value = None  # Force creation of new tool
            mock_registry_class.return_value = mock_registry
            
            with patch('src.agents.esg.Scope3AnomalyPredictorTool') as mock_tool_class:
                mock_tool_class.return_value = mock_tool
                
                result = anomaly_detection_agent(self.initial_state)
                
                # Verify agent trace was updated with alert information
                assert "agent_trace" in result
                assert len(result["agent_trace"]) == 1
                trace_entry = result["agent_trace"][0]
                assert trace_entry["agent"] == "anomaly_detection_agent"
                assert trace_entry["anomalies_detected"] == 2
                assert trace_entry["anomaly_percentage"] == 40.0
    
    def test_state_updates(self):
        """Test anomalies state field updates."""
        with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
            mock_registry = MagicMock()
            mock_tool = MagicMock()
            mock_result = {
                "success": True,
                "anomaly_count": 1,
                "total_points": 5,
                "anomaly_percentage": 20.0,
                "results": [],
                "device": "cpu",
                "timestamp": 1234567890
            }
            mock_tool.run.return_value = mock_result
            mock_registry.get_tool.return_value = None  # Force creation of new tool
            mock_registry_class.return_value = mock_registry
            
            with patch('src.agents.esg.Scope3AnomalyPredictorTool') as mock_tool_class:
                mock_tool_class.return_value = mock_tool
                
                result = anomaly_detection_agent(self.initial_state)
                
                # Verify state updates
                assert result["workflow_status"] == "anomaly_detection_completed"
                assert "processing_results" in result
                assert "anomaly_detection" in result["processing_results"]
                assert result["processing_results"]["anomaly_detection"]["anomaly_count"] == 1
    
    def test_no_supplier_data(self):
        """Test behavior when no supplier data is available."""
        state_without_data = AppState(
            workflow_data={},
            processing_results={},
            agent_trace=[],
            errors=[]
        )
        
        result = anomaly_detection_agent(state_without_data)
        
        # Verify the function handled the missing data gracefully
        assert result["workflow_status"] == "anomaly_detection_skipped"
        assert "No supplier data available for anomaly detection" in result["errors"]
    
    def test_no_scope3_data(self):
        """Test behavior when no Scope 3 data is available."""
        state_without_scope3 = AppState(
            workflow_data={
                "supplier_data": {
                    "company_name": "Test Company"
                }
            },
            processing_results={},
            agent_trace=[],
            errors=[]
        )
        
        result = anomaly_detection_agent(state_without_scope3)
        
        # Verify the function handled the missing data gracefully
        assert result["workflow_status"] == "anomaly_detection_skipped"
        assert "No Scope 3 data found for anomaly detection" in result["errors"]
    
    def test_tool_failure(self):
        """Test behavior when the anomaly detection tool fails."""
        with patch('src.agents.esg.ToolRegistry') as mock_registry_class:
            mock_registry = MagicMock()
            mock_tool = MagicMock()
            mock_tool.run.return_value = {
                "success": False,
                "error": "Model loading failed"
            }
            mock_registry.get_tool.return_value = None  # Force creation of new tool
            mock_registry_class.return_value = mock_registry
            
            with patch('src.agents.esg.Scope3AnomalyPredictorTool') as mock_tool_class:
                mock_tool_class.return_value = mock_tool
                
                result = anomaly_detection_agent(self.initial_state)
                
                # Verify the function handled the tool failure gracefully
                assert result["workflow_status"] == "anomaly_detection_failed"
                assert "Anomaly detection failed: Model loading failed" in result["errors"]


if __name__ == "__main__":
    pytest.main([__file__])