"""
Unit tests for the Centralized Error Handling Node
"""

import pytest
from datetime import datetime
from src.agents.core import handle_error_node
from src.state.models import AppState
from src.utils.error_handling import BaseVLEIError, DataValidationError, APIFailureError


def test_error_processing():
    """Test error handling and logging"""
    # Create initial state with errors
    state = AppState(
        workflow_status="processing",
        errors=["Test error 1", "Test error 2"]
    )
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify error processing
    assert "error_log" in result
    assert len(result["error_log"]) > 0
    
    # Check the last error log entry
    last_log = result["error_log"][-1]
    assert "request_id" in last_log
    assert "timestamp" in last_log
    assert last_log["agent"] == "handle_error_node"
    assert last_log["action"] == "error_processing"
    assert "processed_errors" in last_log


def test_state_updates():
    """Verify error state modifications"""
    # Create initial state
    initial_state = AppState(
        workflow_status="processing",
        task_queue=["task1", "task2", "task3"],
        errors=[]
    )
    
    # Call the error handling node
    result = handle_error_node(initial_state)
    
    # Verify state updates
    assert result["workflow_status"] == "FAILED"
    assert result["task_queue"] == []
    assert "error_log" in result
    assert len(result["error_log"]) > 0


def test_workflow_termination():
    """Test graceful workflow stopping"""
    # Create initial state with tasks
    state = AppState(
        workflow_status="running",
        task_queue=["task1", "task2", "task3"]
    )
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify workflow termination
    assert result["workflow_status"] == "FAILED"
    assert result["task_queue"] == []  # Task queue should be cleared
    
    # Check that agent trace was updated
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 0
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "handle_error_node"
    assert last_trace["action"] == "workflow_terminated"


def test_exception_handling():
    """Test various exception scenarios"""
    # Create state with string errors (AppState.errors expects strings)
    state = AppState(
        workflow_status="processing",
        errors=[
            "DataValidationError: Invalid data format (field=test_field, value=invalid_value)",
            "APIFailureError: API service unavailable (status_code=503, url=https://api.example.com/test)",
            "String error"
        ]
    )
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify all error types are handled
    assert "error_log" in result
    assert len(result["error_log"]) > 0
    
    # Check that all errors were processed
    last_log = result["error_log"][-1]
    assert "processed_errors" in last_log
    assert len(last_log["processed_errors"]) == 3
    
    # Check error messages
    processed_errors = last_log["processed_errors"]
    error_messages = [error["message"] for error in processed_errors]
    assert "DataValidationError: Invalid data format (field=test_field, value=invalid_value)" in error_messages
    assert "APIFailureError: API service unavailable (status_code=503, url=https://api.example.com/test)" in error_messages
    assert "String error" in error_messages


def test_error_log_structure():
    """Test that error logs have the correct structure"""
    # Create initial state
    state = AppState(
        workflow_status="running",
        task_queue=["task1", "task2"],
        errors=["Test error"]
    )
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Check error log structure
    assert "error_log" in result
    assert len(result["error_log"]) > 0
    
    last_log = result["error_log"][-1]
    
    # Check required fields
    required_fields = ["request_id", "timestamp", "agent", "action", "processed_errors"]
    for field in required_fields:
        assert field in last_log
    
    # Check timestamp format
    try:
        datetime.fromisoformat(last_log["timestamp"])
    except ValueError:
        pytest.fail("Timestamp is not in valid ISO format")
    
    # Check UUID format for request_id
    assert isinstance(last_log["request_id"], str)
    assert len(last_log["request_id"]) > 0


def test_agent_trace_logging():
    """Test that agent trace is properly updated"""
    # Create initial state
    state = AppState(
        workflow_status="running",
        agent_trace=[{"agent": "test_agent", "action": "test_action"}]
    )
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify agent trace was updated
    assert "agent_trace" in result
    assert len(result["agent_trace"]) > 1  # Should have at least the original + new entry
    
    # Check the last trace entry
    last_trace = result["agent_trace"][-1]
    assert last_trace["agent"] == "handle_error_node"
    assert last_trace["action"] == "workflow_terminated"
    assert "request_id" in last_trace
    assert "timestamp" in last_trace


def test_empty_state_handling():
    """Test handling of empty state"""
    # Create minimal state
    state = AppState()
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify basic functionality
    assert result["workflow_status"] == "FAILED"
    assert result["task_queue"] == []
    assert "error_log" in result


def test_error_handler_failure_recovery():
    """Test recovery when error handler itself fails"""
    # This is a bit contrived, but we can simulate a scenario where
    # the error handling might have issues by passing problematic data
    
    # Create state that might cause issues
    state = AppState(
        workflow_status="running",
        # Add some data that might cause serialization issues
        workflow_data={"circular_ref": {}}
    )
    
    # Create circular reference
    state.workflow_data["circular_ref"]["self"] = state.workflow_data["circular_ref"]
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Should still return a valid result even if there were issues
    assert "workflow_status" in result
    assert "task_queue" in result
    assert "error_log" in result


def test_consistent_return_structure():
    """Test that the function returns a consistent structure"""
    # Create initial state
    state = AppState()
    
    # Call the error handling node
    result = handle_error_node(state)
    
    # Verify all expected keys are present
    expected_keys = {"workflow_status", "task_queue", "error_log", "agent_trace"}
    assert expected_keys.issubset(result.keys())
    
    # Verify types
    assert isinstance(result["workflow_status"], str)
    assert isinstance(result["task_queue"], list)
    assert isinstance(result["error_log"], list)
    assert isinstance(result["agent_trace"], list)


def test_request_id_generation():
    """Test that request IDs are properly generated"""
    # Create initial state
    state = AppState()
    
    # Call the error handling node multiple times
    results = [handle_error_node(state) for _ in range(3)]
    
    # Extract request IDs
    request_ids = []
    for result in results:
        error_log = result["error_log"]
        if error_log:
            last_entry = error_log[-1]
            if "request_id" in last_entry:
                request_ids.append(last_entry["request_id"])
    
    # Verify we have request IDs
    assert len(request_ids) == 3
    
    # Verify they are unique
    assert len(set(request_ids)) == 3  # All unique