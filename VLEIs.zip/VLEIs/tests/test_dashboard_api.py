"""
Test suite for dashboard API endpoints.
This module tests:
1. Dashboard API functionality
2. Response formatting for both frontend and CLI consumers
3. API performance under load
4. Cache invalidation and updates
"""

import os
import sys
import pytest
import asyncio
import json
from datetime import datetime
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from main import app
from src.api.dashboard.cache import DashboardCache
from src.api.dashboard.service import DashboardService


@pytest.fixture
def client():
    """Create a test client for the FastAPI app"""
    from fastapi.testclient import TestClient
    return TestClient(app)


def test_dashboard_health_endpoint(client):
    """Test dashboard health check endpoint"""
    response = client.get("/api/v1/dashboard/health")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "dashboard_api" in data["data"]["service"]
    assert data["data"]["status"] == "operational"


def test_dashboard_metrics_endpoint(client):
    """Test dashboard metrics endpoint"""
    response = client.get("/api/v1/dashboard/metrics")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "api_response_time" in data["data"]
    assert "accuracy" in data["data"]
    assert "system_health" in data["data"]


def test_dashboard_esg_scores_endpoint(client):
    """Test ESG scores endpoint"""
    response = client.get("/api/v1/dashboard/esg-scores")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "esg_scores" in data["data"]
    assert "supplier_compliance" in data["data"]


def test_dashboard_carbon_data_endpoint(client):
    """Test carbon data endpoint"""
    response = client.get("/api/v1/dashboard/carbon-data")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "carbon_emissions" in data["data"]
    assert "reduction_targets" in data["data"]


def test_dashboard_provenance_data_endpoint(client):
    """Test provenance data endpoint"""
    response = client.get("/api/v1/dashboard/provenance-data")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "nodes" in data["data"]
    assert "edges" in data["data"]
    assert "paths" in data["data"]


def test_consolidated_dashboard_data_endpoint(client):
    """Test consolidated dashboard data endpoint"""
    response = client.get("/api/v1/dashboard/consolidated")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "data" in data
    assert "metrics" in data["data"]
    assert "esg_scores" in data["data"]
    assert "carbon_data" in data["data"]
    assert "provenance_data" in data["data"]


def test_cache_invalidation_endpoint(client):
    """Test cache invalidation endpoint"""
    response = client.post("/api/v1/dashboard/cache/invalidate")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "Cache invalidated successfully" in data["message"]


def test_cli_friendly_response_format(client):
    """Test that API responses are CLI-friendly JSON"""
    response = client.get("/api/v1/dashboard/consolidated")
    assert response.status_code == 200
    
    # Check that response is valid JSON
    data = response.json()
    
    # Verify structure is consistent and parseable
    assert "status" in data
    assert "message" in data
    assert "timestamp" in data
    assert "data" in data
    
    # Verify data structure
    assert isinstance(data["data"], dict)
    assert "metrics" in data["data"]
    assert "esg_scores" in data["data"]
    
    # Check that all values are JSON serializable
    json.dumps(data)


def test_response_format_consistency(client):
    """Test that all dashboard endpoints return consistent response format"""
    endpoints = [
        "/api/v1/dashboard/health",
        "/api/v1/dashboard/metrics",
        "/api/v1/dashboard/esg-scores",
        "/api/v1/dashboard/carbon-data",
        "/api/v1/dashboard/provenance-data",
        "/api/v1/dashboard/consolidated"
    ]
    
    for endpoint in endpoints:
        response = client.get(endpoint)
        assert response.status_code == 200
        
        data = response.json()
        assert "status" in data
        assert "message" in data
        assert "timestamp" in data


@patch('src.api.dashboard.service.dashboard_cache')
def test_cache_functionality(mock_cache, client):
    """Test cache functionality"""
    # Mock cache behavior
    mock_cache.get.return_value = None
    mock_cache.set.return_value = True
    
    response = client.get("/api/v1/dashboard/metrics")
    assert response.status_code == 200
    
    # Verify cache was checked
    mock_cache.get.assert_called()
    
    # Verify data was cached
    mock_cache.set.assert_called()


def test_error_handling(client):
    """Test error handling in dashboard API"""
    # Temporarily patch a service method to raise an exception
    with patch('src.api.dashboard.service.DashboardService.get_system_metrics') as mock_method:
        mock_method.side_effect = Exception("Test error")
        
        response = client.get("/api/v1/dashboard/metrics")
        assert response.status_code == 200  # Should still return 200 with error in body
        
        data = response.json()
        assert data["status"] == "error"
        assert "Failed to retrieve metrics data" in data["message"]


def test_realtime_polling_endpoint(client):
    """Test real-time polling endpoint"""
    response = client.get("/api/v1/dashboard/polling/realtime")
    assert response.status_code == 200
    
    data = response.json()
    assert data["status"] == "success"
    assert "data" in data
    assert "metrics" in data["data"]
    assert "esg_scores" in data["data"]


if __name__ == "__main__":
    pytest.main([__file__])