"""
Phase 1 Integration Test - Comprehensive end-to-end test validating live, integrated architecture

This test validates that the entire system works correctly in an integrated manner,
including API endpoints, LangGraph workflow execution, agent coordination,
credential processing, blockchain interactions, and data validation.
"""

import pytest
import httpx
import asyncio
import os
from typing import Dict, Any
import re
from src.state.models import AppState


# Test data for integration testing
TEST_SUPPLIER_DATA = {
    "company_name": "Test Company Ltd",
    "esg_rating": "AA",
    "report_year": 2023,
    "revenue": 1000000,
    "industry": "Technology",
    "employees": 500,
    "hq_location": "New York, NY"
}

# Configuration for testing
TEST_CONFIG = {
    "processing_timeout": 30,
    "verification_depth": "standard",
    "report_format": "json"
}


@pytest.fixture(scope="module")
def api_base_url():
    """Get the base URL for the API"""
    return os.getenv("API_BASE_URL", "http://localhost:8000")


@pytest.fixture(scope="module")
def http_client():
    """Create an HTTP client for testing"""
    client = httpx.AsyncClient(timeout=30.0)
    yield client
    asyncio.run(client.aclose())


@pytest.mark.asyncio
async def test_end_to_end_integration_stream_endpoint(http_client, api_base_url):
    """
    Test the complete end-to-end integration using the /ingest/stream endpoint.
    This test validates:
    1. API endpoint accessibility
    2. JSON data ingestion
    3. LangGraph workflow execution
    4. Pydantic model validation of response
    5. Final status validation
    6. Agent trace validation
    7. Blockchain transaction hash validation
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response status
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse JSON response
    response_data = response.json()
    
    # Validate response structure
    assert "status" in response_data, "Response missing 'status' field"
    assert "message" in response_data, "Response missing 'message' field"
    assert "final_state" in response_data, "Response missing 'final_state' field"
    
    # Validate response values
    assert response_data["status"] == "success", f"Expected status 'success', got '{response_data['status']}'"
    assert len(response_data["message"]) > 0, "Response message is empty"
    
    # Validate final state structure using Pydantic model
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate final status
    assert app_state.workflow_status in ["completed", "success", "finished"], \
        f"Expected completed workflow status, got '{app_state.workflow_status}'"
    
    # Validate agent trace
    assert isinstance(app_state.agent_trace, list), "Agent trace should be a list"
    assert len(app_state.agent_trace) > 0, "Agent trace should not be empty"
    
    # Validate that agent trace contains expected information
    for trace_entry in app_state.agent_trace:
        assert "agent" in trace_entry, "Agent trace entry missing 'agent' field"
        assert "action" in trace_entry, "Agent trace entry missing 'action' field"
        assert "timestamp" in trace_entry, "Agent trace entry missing 'timestamp' field"
    
    # Validate blockchain transaction information
    assert isinstance(app_state.blockchain_log, list), "Blockchain log should be a list"
    
    # If there are blockchain transactions, validate their format
    for transaction in app_state.blockchain_log:
        assert "transaction_hash" in transaction, "Blockchain log entry missing 'transaction_hash' field"
        assert "timestamp" in transaction, "Blockchain log entry missing 'timestamp' field"
        assert "status" in transaction, "Blockchain log entry missing 'status' field"
        
        # Validate transaction hash format (should be a hex string of 64 characters)
        transaction_hash = transaction["transaction_hash"]
        assert isinstance(transaction_hash, str), "Transaction hash should be a string"
        assert re.match(r"^0x[a-fA-F0-9]{64}$", transaction_hash), \
            f"Invalid transaction hash format: {transaction_hash}"
    
    # Validate processing results
    assert isinstance(app_state.processing_results, dict), "Processing results should be a dict"
    assert len(app_state.processing_results) >= 0, "Processing results should exist"
    
    # Validate that no errors occurred
    assert isinstance(app_state.errors, list), "Errors should be a list"
    # Note: Some warnings or non-critical errors might be acceptable
    # but critical errors should fail the workflow
    
    # Validate task queue is empty (indicating workflow completion)
    assert isinstance(app_state.task_queue, list), "Task queue should be a list"
    # In a completed workflow, the task queue should be empty or contain only completion markers


@pytest.mark.asyncio
async def test_end_to_end_integration_with_minimal_data(http_client, api_base_url):
    """
    Test the end-to-end integration with minimal data to ensure robustness.
    """
    # Prepare minimal test data
    minimal_data = {
        "supplier_data": {
            "company_name": "Minimal Test Company"
        }
    }
    
    # Send POST request to /ingest/stream endpoint
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=minimal_data
    )
    
    # Validate response
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse and validate response
    response_data = response.json()
    assert response_data["status"] == "success", f"Expected status 'success', got '{response_data['status']}'"
    
    # Validate final state
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate workflow completion
    assert app_state.workflow_status in ["completed", "success", "finished"], \
        f"Expected completed workflow status, got '{app_state.workflow_status}'"


@pytest.mark.asyncio
async def test_data_flow_validation(http_client, api_base_url):
    """
    Validate that data flows correctly through the entire system.
    """
    # Prepare test data with specific values we can trace
    traceable_data = {
        "supplier_data": {
            "company_name": "Traceable Company",
            "esg_rating": "AAA",
            "report_year": 2024,
            "custom_id": "TRACE_001"
        },
        "config": {
            "trace_id": "integration_test_001"
        }
    }
    
    # Send POST request
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=traceable_data
    )
    
    # Validate response
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate that our traceable data made it through the system
    assert app_state.workflow_data is not None, "Workflow data should not be None"
    assert isinstance(app_state.workflow_data, dict), "Workflow data should be a dict"
    
    # Check that configuration was processed
    assert app_state.config is not None, "Config should not be None"
    assert isinstance(app_state.config, dict), "Config should be a dict"


@pytest.mark.asyncio
async def test_performance_validation(http_client, api_base_url):
    """
    Measure end-to-end system performance.
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Measure execution time
    start_time = asyncio.get_event_loop().time()
    
    # Send POST request
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    end_time = asyncio.get_event_loop().time()
    execution_time = end_time - start_time
    
    # Validate response
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Performance assertion (should complete within reasonable time)
    assert execution_time < 30.0, f"Execution took too long: {execution_time:.2f} seconds"
    
    # Log performance for monitoring
    print(f"End-to-end execution time: {execution_time:.2f} seconds")


@pytest.mark.asyncio
async def test_credential_verification_status(http_client, api_base_url):
    """
    Test credential verification status in the final state.
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate credentials list exists
    assert isinstance(app_state.credentials, list), "Credentials should be a list"
    
    # If credentials exist, validate their structure
    for credential in app_state.credentials:
        # Check required fields
        assert "id" in credential, "Credential missing 'id' field"
        assert "issuer" in credential, "Credential missing 'issuer' field"
        assert "subject" in credential, "Credential missing 'subject' field"
        assert "credential_status" in credential, "Credential missing 'credential_status' field"
        assert "verification_status" in credential, "Credential missing 'verification_status' field"


@pytest.mark.asyncio
async def test_blockchain_transaction_hash_validity(http_client, api_base_url):
    """
    Validate blockchain transaction hash format and validity.
    """
    # Prepare test data
    test_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": TEST_CONFIG
    }
    
    # Send POST request
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=test_data
    )
    
    # Validate response
    assert response.status_code == 200, f"Expected status 200, got {response.status_code}"
    
    # Parse response
    response_data = response.json()
    final_state = response_data["final_state"]
    app_state = AppState(**final_state)
    
    # Validate blockchain log entries
    for transaction in app_state.blockchain_log:
        # Validate transaction hash format
        transaction_hash = transaction.get("transaction_hash", "")
        assert isinstance(transaction_hash, str), "Transaction hash should be a string"
        
        # Ethereum transaction hashes are 66 characters (0x + 64 hex chars)
        assert len(transaction_hash) == 66, f"Transaction hash wrong length: {len(transaction_hash)}"
        assert transaction_hash.startswith("0x"), "Transaction hash should start with '0x'"
        
        # Validate hex characters after 0x prefix
        hex_part = transaction_hash[2:]
        assert all(c in "0123456789abcdefABCDEF" for c in hex_part), \
            f"Invalid hex characters in transaction hash: {transaction_hash}"


@pytest.mark.asyncio
async def test_error_scenario_handling(http_client, api_base_url):
    """
    Test system behavior under various error conditions.
    """
    # Test with empty supplier data
    empty_data = {
        "supplier_data": {}
    }
    
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=empty_data
    )
    
    # Should still succeed even with empty data (defensive programming)
    assert response.status_code == 200, f"Expected status 200 for empty data, got {response.status_code}"
    
    # Test with malformed config
    malformed_data = {
        "supplier_data": TEST_SUPPLIER_DATA,
        "config": "not_a_dict"  # This should be handled gracefully
    }
    
    response = await http_client.post(
        f"{api_base_url}/ingest/stream",
        json=malformed_data
    )
    
    # Should handle gracefully or return appropriate error
    assert response.status_code in [200, 422], \
        f"Expected status 200 or 422 for malformed data, got {response.status_code}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])