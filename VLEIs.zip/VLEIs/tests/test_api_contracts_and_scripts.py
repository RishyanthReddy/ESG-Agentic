"""
Test suite for API contracts and demo scripts.
This module tests:
1. API schema compliance
2. Demo script execution
3. Curl command functionality
4. Mock accuracy
"""

import os
import sys
import subprocess
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

# Add src to path to import the main app
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from main import app

client = TestClient(app)

def test_api_root_endpoint():
    """Test the root endpoint returns expected response"""
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()
    assert response.json()["message"] == "Welcome to the ESG Intelligence Platform"


def test_api_health_endpoint():
    """Test the health endpoint returns expected structure"""
    response = client.get("/health")
    assert response.status_code == 200
    
    data = response.json()
    assert "status" in data
    assert "timestamp" in data
    assert "components" in data
    
    # Check status is one of the expected values
    assert data["status"] in ["healthy", "degraded", "unhealthy"]
    
    # Check components structure
    components = data["components"]
    if "llm" in components:
        assert "status" in components["llm"]
    
    if "blockchain" in components:
        assert "status" in components["blockchain"]


def test_api_ingest_json_endpoint():
    """Test the JSON ingestion endpoint with valid data"""
    test_data = {
        "supplier_data": {
            "name": "Test Company",
            "esg_score": 75
        },
        "config": {
            "verification_required": True
        }
    }
    
    response = client.post("/ingest/json", json=test_data)
    # We expect this to fail in testing environment due to missing dependencies
    # but the endpoint should still be properly structured
    assert response.status_code in [200, 500]


def test_api_ingest_json_invalid_data():
    """Test the JSON ingestion endpoint with invalid data"""
    invalid_data = "not a json object"
    
    response = client.post("/ingest/json", json=invalid_data)
    assert response.status_code == 422


def test_api_verify_endpoint_not_found():
    """Test the verify endpoint with a non-existent report ID"""
    response = client.get("/verify/non-existent-report-id")
    assert response.status_code == 404


def test_health_check_script_execution():
    """Test that the health_check.sh script executes without errors"""
    # Skip this test if not in a Unix-like environment
    if os.name == 'nt':  # Windows
        pytest.skip("Skipping shell script test on Windows")
    
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'health_check.sh')
    
    # Check if script exists
    assert os.path.exists(script_path), "health_check.sh script not found"
    
    # Make script executable
    os.chmod(script_path, 0o755)
    
    # Try to execute the script
    try:
        result = subprocess.run([script_path], capture_output=True, text=True, timeout=10)
        # Script should execute without errors (even if API is not running)
        # We're just testing that it doesn't crash
    except subprocess.TimeoutExpired:
        pytest.fail("health_check.sh script timed out")
    except Exception as e:
        pytest.fail(f"health_check.sh script failed with error: {e}")


def test_full_system_status_script_execution():
    """Test that the full_system_status.sh script executes without errors"""
    # Skip this test if not in a Unix-like environment
    if os.name == 'nt':  # Windows
        pytest.skip("Skipping shell script test on Windows")
    
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'full_system_status.sh')
    
    # Check if script exists
    assert os.path.exists(script_path), "full_system_status.sh script not found"
    
    # Make script executable
    os.chmod(script_path, 0o755)
    
    # Try to execute the script
    try:
        result = subprocess.run([script_path], capture_output=True, text=True, timeout=15)
        # Script should execute without errors (even if API is not running)
        # We're just testing that it doesn't crash
    except subprocess.TimeoutExpired:
        pytest.fail("full_system_status.sh script timed out")
    except Exception as e:
        pytest.fail(f"full_system_status.sh script failed with error: {e}")


def test_api_test_suite_script_execution():
    """Test that the api_test_suite.sh script executes without errors"""
    # Skip this test if not in a Unix-like environment
    if os.name == 'nt':  # Windows
        pytest.skip("Skipping shell script test on Windows")
    
    script_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'api_test_suite.sh')
    
    # Check if script exists
    assert os.path.exists(script_path), "api_test_suite.sh script not found"
    
    # Make script executable
    os.chmod(script_path, 0o755)
    
    # Try to execute the script
    try:
        result = subprocess.run([script_path], capture_output=True, text=True, timeout=20)
        # Script should execute without errors
        # We're just testing that it doesn't crash
    except subprocess.TimeoutExpired:
        pytest.fail("api_test_suite.sh script timed out")
    except Exception as e:
        pytest.fail(f"api_test_suite.sh script failed with error: {e}")


def test_frontend_fallback_documentation_exists():
    """Test that the frontend fallback documentation exists"""
    doc_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', 'frontend_fallback.md')
    assert os.path.exists(doc_path), "frontend_fallback.md documentation not found"
    
    # Check that the file has content
    with open(doc_path, 'r') as f:
        content = f.read()
        assert len(content) > 0, "frontend_fallback.md is empty"
        assert "# Frontend Fallback Documentation" in content, "Missing expected title"


def test_env_example_exists():
    """Test that the .env.example file exists"""
    env_example_path = os.path.join(os.path.dirname(__file__), '..', 'demo_scripts', '.env.example')
    assert os.path.exists(env_example_path), ".env.example file not found"
    
    # Check that the file has content
    with open(env_example_path, 'r') as f:
        content = f.read()
        assert len(content) > 0, ".env.example is empty"
        assert "API_BASE_URL" in content, "Missing expected environment variable"


if __name__ == "__main__":
    pytest.main([__file__])