# INFURA API Key Usage Guide

This document explains how to use the INFURA_API_KEY that is already configured in your project.

## Current Setup

Your project already has the INFURA_API_KEY configured in the `.env` file:

```
INFURA_API_KEY=a23df3b3c6554ff18e7edf36bcc341ce
```

## How the System Uses the INFURA_API_KEY

The system automatically loads environment variables from the `.env` file through the `config.py` module. The [InfuraBlockchainTool](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/provenance.py#L18-L133) in [src/tools/provenance.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/provenance.py) uses this key to connect to the Sepolia testnet:

```python
# In config.py
class Settings(BaseSettings):
    # ... other settings
    INFURA_API_KEY: Optional[str] = None

# In src/tools/provenance.py
from config import settings

class InfuraBlockchainTool(BaseTool):
    def __init__(self):
        # Get Infura API key from settings (loaded from .env file)
        self.infura_api_key = settings.INFURA_API_KEY
        # ...
```

## Using the Tool

To use the InfuraBlockchainTool in your code:

```python
from src.tools.provenance import InfuraBlockchainTool

# The tool automatically uses the INFURA_API_KEY from your .env file
tool = InfuraBlockchainTool()

# Check connection info
info = tool.get_connection_info()
print(f"Connected to: {info['network']}")

# Use the tool to log data to the blockchain
result = tool.run("sha256-hash-of-your-data", "your-private-key")
print(f"Transaction hash: {result['transaction_hash']}")
```

## Verification

You can verify that your INFURA_API_KEY is working by running the demo scripts:

```bash
# Show how the key is loaded from environment
python demo_infura_usage.py

# Simple connection test
python use_infura_example.py
```

## Security Notes

1. The INFURA_API_KEY in your `.env` file is already masked in logs for security
2. Never commit your `.env` file to version control
3. If you need a new key, you can get one from [Infura Dashboard](https://infura.io/dashboard)

## Troubleshooting

If you encounter connection issues:

1. Verify the INFURA_API_KEY in your `.env` file is correct
2. Check your internet connection
3. Ensure you have the required dependencies installed:
   ```bash
   pip install web3==6.12.0 python-dotenv
   ```

The system is already configured and ready to use the Sepolia testnet via Infura!