"""
Demo script for the upgraded Provenance Agent
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.agents.provenance import provenance_agent
from src.state.models import AppState, vLEICredential
from src.tools.provenance import InfuraBlockchainTool
from src.tools.registry import ToolRegistry
import hashlib
import json


def demo_environment_setup():
    """Demonstrate that the required environment variables are properly loaded"""
    print("Environment Setup Demo")
    print("=" * 50)
    
    # Show that the INFURA_API_KEY is available
    infura_api_key = os.getenv("INFURA_API_KEY")
    if infura_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = infura_api_key[:5] + "..." + infura_api_key[-5:]
        print(f"INFURA_API_KEY found in environment: {masked_key}")
    else:
        print("WARNING: INFURA_API_KEY not found in environment!")
    
    # Show that the private key is available
    private_key = os.getenv("TEST_PRIVATE_KEY")
    if private_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = private_key[:5] + "..." + private_key[-5:]
        print(f"TEST_PRIVATE_KEY found in environment: {masked_key}")
    else:
        print("WARNING: TEST_PRIVATE_KEY not found in environment!")
    
    print()
    return infura_api_key and private_key


def demo_tool_initialization():
    """Demonstrate initializing the InfuraBlockchainTool"""
    print("Tool Initialization Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool - it will automatically use the INFURA_API_KEY from environment
        tool = InfuraBlockchainTool()
        
        # Show connection information
        connection_info = tool.get_connection_info()
        print(f"Network: {connection_info['network']}")
        print(f"Chain ID: {connection_info['chain_id']}")
        print(f"Endpoint: {connection_info['endpoint']}")
        print(f"Connected: {connection_info['connected']}")
        
        # Register the tool
        registry = ToolRegistry()
        registry.register_tool(tool)
        print("Tool registered successfully!")
        
        print("\nTool successfully initialized and connected to Sepolia testnet!")
        return tool
        
    except Exception as e:
        print(f"ERROR: Failed to initialize tool: {e}")
        return None


def demo_data_hashing():
    """Demonstrate data hashing functionality"""
    print("\nData Hashing Demo")
    print("=" * 50)
    
    # Create sample data
    sample_data = {
        "company": "Test Corp",
        "metrics": {
            "emissions": 1000,
            "energy_consumption": 5000
        },
        "timestamp": "2023-01-01T00:00:00Z",
        "verified": True
    }
    
    # Serialize data consistently
    data_json = json.dumps(sample_data, sort_keys=True, separators=(',', ':'))
    print(f"Sample data: {data_json[:100]}...")
    
    # Create SHA-256 hash
    data_hash = hashlib.sha256(data_json.encode('utf-8')).hexdigest()
    print(f"SHA-256 hash: {data_hash}")
    
    return data_hash


def demo_state_serialization():
    """Demonstrate state serialization for blockchain logging"""
    print("\nState Serialization Demo")
    print("=" * 50)
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Demo Corp",
            "test_data": "blockchain logging demo",
            "timestamp": "2023-06-01T12:00:00Z"
        }
    )
    
    # Create state with credential
    state = AppState(
        current_credential=credential,
        workflow_status="processing",
        workflow_step=2,
        config={"blockchain_private_key": "test-key-placeholder"}
    )
    
    print(f"State workflow status: {state.workflow_status}")
    print(f"State workflow step: {state.workflow_step}")
    print(f"Current credential issuer: {credential.issuer}")
    print(f"Current credential subject: {credential.subject}")
    
    return state


def demo_provenance_agent():
    """Demonstrate the upgraded provenance agent"""
    print("\nProvenance Agent Demo")
    print("=" * 50)
    
    # Create a test credential
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "company": "Demo Corp",
            "test_data": "provenance agent demo",
            "timestamp": "2023-06-01T12:00:00Z"
        }
    )
    
    # Create state with credential
    state = AppState(
        current_credential=credential,
        workflow_status="processing",
        workflow_step=2,
        config={"blockchain_private_key": os.getenv("TEST_PRIVATE_KEY")}
    )
    
    print("Running provenance agent...")
    try:
        result = provenance_agent(state)
        
        print(f"Workflow status: {result['workflow_status']}")
        if 'blockchain_log' in result and result['blockchain_log']:
            log_entry = result['blockchain_log'][-1]  # Get the latest entry
            print(f"Data hash: {log_entry['data_hash']}")
            print(f"Transaction hash: {log_entry['transaction_hash']}")
            print(f"Status: {log_entry['status']}")
        else:
            print("No blockchain log entries found")
            
        return result
        
    except Exception as e:
        print(f"ERROR: Failed to run provenance agent: {e}")
        return None


def demo_selective_logging():
    """Demonstrate selective data logging optimization"""
    print("\nSelective Logging Demo")
    print("=" * 50)
    
    print("The upgraded provenance agent implements selective logging by:")
    print("1. Creating snapshots of only relevant state data")
    print("2. Using SHA-256 hashing for efficient data fingerprinting")
    print("3. Logging only the hash to the blockchain (not the full data)")
    print("4. Maintaining an audit trail in the state's blockchain_log")
    
    # Show what gets logged selectively
    print("\nExample of selective data snapshot:")
    snapshot_example = {
        "timestamp": "2023-06-01T12:00:00Z",
        "workflow_status": "processing",
        "workflow_step": 2,
        "credential_id": "123e4567-e89b-12d3-a456-426614174000",
        "credential_issuer": "did:example:issuer",
        "credential_subject": "did:example:subject"
    }
    
    print(json.dumps(snapshot_example, indent=2))


def main():
    """Main demo function"""
    print("Upgraded Provenance Agent Demo")
    print("=" * 60)
    print("This demo shows the upgraded features of the ProvenanceAgent")
    print("for logging data events to the Ethereum Sepolia testnet.\n")
    
    # Demo environment setup
    has_keys = demo_environment_setup()
    if not has_keys:
        print("Demo cannot proceed without required environment variables")
        return
    
    # Demo tool initialization
    tool = demo_tool_initialization()
    if not tool:
        print("Demo cannot proceed without tool initialization")
        return
    
    # Demo data hashing
    demo_data_hashing()
    
    # Demo state serialization
    demo_state_serialization()
    
    # Demo selective logging
    demo_selective_logging()
    
    # Demo provenance agent
    demo_provenance_agent()
    
    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("The upgraded ProvenanceAgent includes:")
    print("- Enhanced state snapshots for selective logging")
    print("- SHA-256 data fingerprinting")
    print("- Real InfuraBlockchainTool integration")
    print("- Transaction hash appending to state.blockchain_log")
    print("- Comprehensive error handling and logging")


if __name__ == "__main__":
    main()