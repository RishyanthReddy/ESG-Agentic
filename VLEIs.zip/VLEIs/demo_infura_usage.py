#!/usr/bin/env python3
"""
Demo script showing how to use the InfuraBlockchainTool with INFURA_API_KEY from environment
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.tools.provenance import InfuraBlockchainTool
from src.tools.registry import ToolRegistry


def demo_environment_setup():
    """Demonstrate that the INFURA_API_KEY is properly loaded from the environment"""
    print("Environment Setup Demo")
    print("=" * 30)
    
    # Show that the INFURA_API_KEY is available
    infura_api_key = os.getenv("INFURA_API_KEY")
    if infura_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = infura_api_key[:5] + "..." + infura_api_key[-5:]
        print(f"INFURA_API_KEY found in environment: {masked_key}")
    else:
        print("ERROR: INFURA_API_KEY not found in environment!")
        return False
    
    print()
    return True


def demo_tool_initialization():
    """Demonstrate initializing the InfuraBlockchainTool"""
    print("Tool Initialization Demo")
    print("=" * 30)
    
    try:
        # Initialize the tool - it will automatically use the INFURA_API_KEY from environment
        tool = InfuraBlockchainTool()
        
        # Show connection information
        connection_info = tool.get_connection_info()
        print(f"Network: {connection_info['network']}")
        print(f"Chain ID: {connection_info['chain_id']}")
        print(f"Endpoint: {connection_info['endpoint']}")
        print(f"Connected: {connection_info['connected']}")
        
        print("\nTool successfully initialized and connected to Sepolia testnet!")
        return tool
        
    except Exception as e:
        print(f"ERROR: Failed to initialize tool: {e}")
        return None


def demo_tool_registration():
    """Demonstrate registering the tool in the registry"""
    print("\nTool Registration Demo")
    print("=" * 30)
    
    # Get the registry instance
    registry = ToolRegistry()
    registry.clear()  # Clear any existing tools for demo purposes
    
    # Create and register the tool
    tool = InfuraBlockchainTool()
    registry.register_tool(tool)
    
    # List registered tools
    tools = registry.list_tools()
    print("Registered tools:")
    for name, description in tools.items():
        print(f"  - {name}: {description}")
    
    # Retrieve the tool
    retrieved_tool = registry.get_tool("infura_blockchain")
    if retrieved_tool:
        print(f"\nSuccessfully retrieved tool: {retrieved_tool.name}")
    else:
        print("\nERROR: Failed to retrieve tool from registry!")


def main():
    """Main demo function"""
    print("INFURA_API_KEY Usage Demo")
    print("=" * 50)
    print("This demo shows how the InfuraBlockchainTool automatically")
    print("uses the INFURA_API_KEY from your .env file.\n")
    
    # Demo environment setup
    if not demo_environment_setup():
        return
    
    # Demo tool initialization
    tool = demo_tool_initialization()
    if not tool:
        return
    
    # Demo tool registration
    demo_tool_registration()
    
    print("\n" + "=" * 50)
    print("Demo completed successfully!")
    print("The InfuraBlockchainTool is ready to use with your INFURA_API_KEY.")


if __name__ == "__main__":
    main()