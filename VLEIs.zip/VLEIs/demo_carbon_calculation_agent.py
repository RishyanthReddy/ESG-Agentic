"""
Demo script for the Carbon Calculation Agent
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.agents.esg import carbon_calculation_agent
from src.state.models import AppState
from src.tools.registry import ToolRegistry
from src.tools.esg import ClimatiqApiTool


def demo_environment_setup():
    """Demonstrate that the CLIMATIQ_API_KEY is properly loaded from the environment"""
    print("Environment Setup Demo")
    print("=" * 50)
    
    # Show that the CLIMATIQ_API_KEY is available
    climatiq_api_key = os.getenv("CLIMATIQ_API_KEY")
    if climatiq_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = climatiq_api_key[:5] + "..." + climatiq_api_key[-5:]
        print(f"CLIMATIQ_API_KEY found in environment: {masked_key}")
    else:
        print("WARNING: CLIMATIQ_API_KEY not found in environment!")
        return False
    
    print()
    return True


def demo_agent_initialization():
    """Demonstrate initializing the Carbon Calculation Agent"""
    print("Agent Initialization Demo")
    print("=" * 50)
    
    try:
        # Initialize the Climatiq API tool
        climatiq_tool = ClimatiqApiTool()
        
        # Register the tool
        registry = ToolRegistry()
        registry.register_tool(climatiq_tool)
        print("ClimatiqApiTool registered successfully!")
        
        return True
        
    except Exception as e:
        print(f"ERROR: Failed to initialize agent dependencies: {e}")
        return False


def demo_data_extraction():
    """Demonstrate activity data extraction from supplier data"""
    print("Data Extraction Demo")
    print("=" * 50)
    
    # Example supplier data with explicit activity data
    supplier_data_explicit = {
        "company_name": "EcoTech Solutions",
        "activity_data": [
            {
                "activity_id": "electricity-energy_source_grid-average",
                "amount": 10000,
                "unit": "kwh",
                "region": "US"
            },
            {
                "activity_id": "passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                "amount": 5000,
                "unit": "km",
                "region": "US"
            }
        ]
    }
    
    print("Example 1: Supplier data with explicit activity data")
    print(f"  Company: {supplier_data_explicit['company_name']}")
    print(f"  Activities: {len(supplier_data_explicit['activity_data'])}")
    for i, activity in enumerate(supplier_data_explicit['activity_data']):
        print(f"    Activity {i+1}: {activity['activity_id']}")
        print(f"      Amount: {activity['amount']} {activity['unit']}")
        print(f"      Region: {activity['region']}")
    
    # Example supplier data with ESG metrics
    supplier_data_esg = {
        "company_name": "Green Manufacturing Inc.",
        "esg_metrics": {
            "energy_consumption_kwh": 50000,
            "vehicle_distance_km": 10000
        },
        "hq_location": "EU"
    }
    
    print("\nExample 2: Supplier data with ESG metrics")
    print(f"  Company: {supplier_data_esg['company_name']}")
    print(f"  HQ Location: {supplier_data_esg['hq_location']}")
    print("  ESG Metrics:")
    for metric, value in supplier_data_esg['esg_metrics'].items():
        print(f"    {metric}: {value}")
    
    print()


def demo_tool_integration():
    """Demonstrate Climatiq API tool integration"""
    print("Tool Integration Demo")
    print("=" * 50)
    
    # Create state with activity data
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Test Company",
                "activity_data": [
                    {
                        "activity_id": "electricity-energy_source_grid-average",
                        "amount": 1000,
                        "unit": "kwh",
                        "region": "US"
                    }
                ]
            }
        }
    )
    
    print("Processing carbon footprint calculation...")
    
    try:
        # Run the agent
        result = carbon_calculation_agent(state)
        
        if result["workflow_status"] == "carbon_calculation_completed":
            print("  Carbon calculation completed successfully!")
            print(f"  Activities processed: {result['processing_results']['carbon_calculation']['activities_processed']}")
            print(f"  Total CO2e: {result['processing_results']['carbon_calculation']['total_co2e']} kg")
            
            # Show detailed carbon footprint data
            carbon_footprints = result["processing_results"]["carbon_metrics"]["carbon_footprints"]
            for i, cf in enumerate(carbon_footprints):
                print(f"  Activity {i+1}:")
                print(f"    Activity ID: {cf['activity_id']}")
                print(f"    Amount: {cf['amount']} {cf['unit']}")
                print(f"    CO2e: {cf['co2e']} {cf['co2e_unit']}")
        else:
            print(f"  Carbon calculation failed: {result.get('errors', ['Unknown error'])}")
            
    except Exception as e:
        print(f"  ERROR: Failed to demonstrate tool integration: {e}")
    
    print()


def demo_metrics_aggregation():
    """Demonstrate carbon metrics calculation and storage"""
    print("Metrics Aggregation Demo")
    print("=" * 50)
    
    # Create state with multiple activities
    state = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Multi-Activity Corp",
                "activity_data": [
                    {
                        "activity_id": "electricity-energy_source_grid-average",
                        "amount": 5000,
                        "unit": "kwh",
                        "region": "US"
                    },
                    {
                        "activity_id": "passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                        "amount": 2000,
                        "unit": "km",
                        "region": "US"
                    },
                    {
                        "activity_id": "freight_transport-road_vehicle_type_all-fuel_source_all-weight_na-distance_na-unknown",
                        "amount": 1000,
                        "unit": "ton*km",
                        "region": "GLO"
                    }
                ]
            }
        },
        processing_results={
            "existing_metric": "existing_value"
        }
    )
    
    print("Processing multiple activities for carbon calculation...")
    
    try:
        # Run the agent
        result = carbon_calculation_agent(state)
        
        if result["workflow_status"] == "carbon_calculation_completed":
            print("  Carbon calculation completed successfully!")
            
            # Show processing results
            processing_results = result["processing_results"]
            print("  Processing Results:")
            print(f"    Existing metric: {processing_results['existing_metric']}")
            print(f"    Total CO2e: {processing_results['carbon_metrics']['total_carbon_footprint']['co2e']} kg")
            
            # Show individual carbon footprints
            print("  Individual Carbon Footprints:")
            for i, cf in enumerate(processing_results["carbon_metrics"]["carbon_footprints"]):
                print(f"    {i+1}. {cf['activity_id']}: {cf['co2e']} kg CO2e")
        else:
            print(f"  Carbon calculation failed: {result.get('errors', ['Unknown error'])}")
            
    except Exception as e:
        print(f"  ERROR: Failed to demonstrate metrics aggregation: {e}")
    
    print()


def demo_validation_logic():
    """Demonstrate carbon calculation validation and quality checks"""
    print("Validation Logic Demo")
    print("=" * 50)
    
    # Test with valid data
    print("Test 1: Valid activity data")
    state_valid = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Valid Company",
                "activity_data": {
                    "activity_id": "electricity-energy_source_grid-average",
                    "amount": 1000,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        }
    )
    
    try:
        result = carbon_calculation_agent(state_valid)
        print(f"  Result: {result['workflow_status']}")
        if result["workflow_status"] == "carbon_calculation_completed":
            print(f"  CO2e calculated: {result['processing_results']['carbon_metrics']['total_carbon_footprint']['co2e']} kg")
    except Exception as e:
        print(f"  ERROR: {e}")
    
    # Test with invalid data
    print("\nTest 2: Invalid activity data")
    state_invalid = AppState(
        workflow_data={
            "supplier_data": {
                "company_name": "Invalid Company",
                "activity_data": {
                    "activity_id": "invalid_activity",
                    "amount": 1000,
                    "unit": "kwh",
                    "region": "US"
                }
            }
        }
    )
    
    try:
        result = carbon_calculation_agent(state_invalid)
        print(f"  Result: {result['workflow_status']}")
        if "errors" in result:
            print(f"  Errors: {result['errors']}")
    except Exception as e:
        print(f"  ERROR: {e}")
    
    print()


def main():
    """Main demo function"""
    print("Carbon Calculation Agent Demo")
    print("=" * 60)
    print("This demo shows the features of the Carbon Calculation Agent for")
    print("orchestrating carbon footprint calculations.\n")
    
    # Demo environment setup
    if not demo_environment_setup():
        print("Demo cannot proceed without CLIMATIQ_API_KEY")
        return
    
    # Demo agent initialization
    if not demo_agent_initialization():
        print("Demo cannot proceed without agent initialization")
        return
    
    # Demo data extraction
    demo_data_extraction()
    
    # Demo tool integration
    demo_tool_integration()
    
    # Demo metrics aggregation
    demo_metrics_aggregation()
    
    # Demo validation logic
    demo_validation_logic()
    
    print("=" * 60)
    print("Demo completed successfully!")
    print("The Carbon Calculation Agent includes:")
    print("- Agent Framework: LangGraph agent patterns for ESG calculations")
    print("- Data Extraction: Supplier data parsing and activity identification")
    print("- Tool Orchestration: ClimatiqApiTool integration and result processing")
    print("- Metrics Aggregation: Carbon metrics calculation and storage")
    print("- Validation Logic: Carbon calculation validation and quality checks")


if __name__ == "__main__":
    main()