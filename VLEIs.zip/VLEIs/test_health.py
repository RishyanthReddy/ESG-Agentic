import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Try to fix the TestClient import issue
try:
    from fastapi.testclient import TestClient
    from main import app
    client = TestClient(app)
    
    def test_health_endpoint():
        response = client.get("/health")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
except Exception as e:
    print(f"Error initializing TestClient: {e}")
    # Try direct import
    try:
        import starlette.testclient
        from main import app
        client = starlette.testclient.TestClient(app)
        
        def test_health_endpoint():
            response = client.get("/health")
            print(f"Status Code: {response.status_code}")
            print(f"Response: {response.json()}")
    except Exception as e2:
        print(f"Error with direct import: {e2}")
        def test_health_endpoint():
            print("Could not initialize TestClient")

if __name__ == "__main__":
    test_health_endpoint()