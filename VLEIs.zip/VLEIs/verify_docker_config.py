"""
Simple verification script for Docker configuration
"""

import os
from pathlib import Path


def test_docker_files():
    """Test that Docker files exist and have correct structure"""
    print("Testing Docker configuration...")
    
    # Check Dockerfile exists
    dockerfile_path = Path("Dockerfile")
    if not dockerfile_path.exists():
        print("❌ Dockerfile not found")
        return False
    print("✓ Dockerfile exists")
    
    # Check docker-compose.yml exists
    compose_path = Path("docker-compose.yml")
    if not compose_path.exists():
        print("❌ docker-compose.yml not found")
        return False
    print("✓ docker-compose.yml exists")
    
    # Check requirements.txt exists
    req_path = Path("requirements.txt")
    if not req_path.exists():
        print("❌ requirements.txt not found")
        return False
    print("✓ requirements.txt exists")
    
    # Check .env file exists
    env_path = Path(".env")
    if not env_path.exists():
        print("❌ .env file not found")
        return False
    print("✓ .env file exists")
    
    # Check Dockerfile content
    with open(dockerfile_path, "r") as f:
        dockerfile_content = f.read()
    
    if "FROM python:3.11-slim as builder" not in dockerfile_content:
        print("❌ Multi-stage build not properly configured")
        return False
    print("✓ Multi-stage build configured")
    
    if "USER appuser" not in dockerfile_content:
        print("❌ Non-root user not configured")
        return False
    print("✓ Non-root user configured")
    
    if "HEALTHCHECK" not in dockerfile_content:
        print("❌ Health check not configured")
        return False
    print("✓ Health check configured")
    
    # Check docker-compose content
    with open(compose_path, "r") as f:
        compose_content = f.read()
    
    if "redis:" not in compose_content:
        print("❌ Redis service not found in docker-compose")
        return False
    print("✓ Redis service configured")
    
    if "volumes:" not in compose_content:
        print("❌ Volumes not configured in docker-compose")
        return False
    print("✓ Volumes configured")
    
    print("\n🎉 All Docker configuration tests passed!")
    return True


def test_required_files():
    """Test that all required project files exist"""
    print("\nTesting required project files...")
    
    required_files = [
        "main.py",
        "config.py",
        "requirements.txt",
        "Dockerfile",
        "docker-compose.yml",
        ".env"
    ]
    
    missing_files = []
    for file_name in required_files:
        file_path = Path(file_name)
        if not file_path.exists():
            missing_files.append(file_name)
        else:
            print(f"✓ {file_name} exists")
    
    if missing_files:
        print(f"❌ Missing files: {missing_files}")
        return False
    
    print("\n🎉 All required files present!")
    return True


if __name__ == "__main__":
    docker_ok = test_docker_files()
    files_ok = test_required_files()
    
    if docker_ok and files_ok:
        print("\n🎉 Docker configuration verification successful!")
        exit(0)
    else:
        print("\n❌ Docker configuration verification failed!")
        exit(1)