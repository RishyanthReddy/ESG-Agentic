"""
Demo script for the Climatiq API Tool
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.tools.esg import ClimatiqApiTool, ActivityData
from src.tools.registry import ToolRegistry


def demo_environment_setup():
    """Demonstrate that the CLIMATIQ_API_KEY is properly loaded from the environment"""
    print("Environment Setup Demo")
    print("=" * 50)
    
    # Show that the CLIMATIQ_API_KEY is available
    climatiq_api_key = os.getenv("CLIMATIQ_API_KEY")
    if climatiq_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = climatiq_api_key[:5] + "..." + climatiq_api_key[-5:]
        print(f"CLIMATIQ_API_KEY found in environment: {masked_key}")
    else:
        print("WARNING: CLIMATIQ_API_KEY not found in environment!")
        return False
    
    print()
    return True


def demo_tool_initialization():
    """Demonstrate initializing the ClimatiqApiTool"""
    print("Tool Initialization Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool - it will automatically use the CLIMATIQ_API_KEY from environment
        tool = ClimatiqApiTool()
        
        print("ClimatiqApiTool successfully initialized!")
        print(f"API endpoint: {tool.base_url}")
        
        # Register the tool
        registry = ToolRegistry()
        registry.register_tool(tool)
        print("Tool registered successfully!")
        
        return tool
        
    except Exception as e:
        print(f"ERROR: Failed to initialize tool: {e}")
        return None


def demo_activity_data_validation():
    """Demonstrate activity data validation"""
    print("\nActivity Data Validation Demo")
    print("=" * 50)
    
    # Valid activity data
    valid_activities = [
        {
            "name": "Passenger vehicle travel",
            "data": ActivityData(
                activity_id="passenger_vehicle-fuel_type_petrol-engine_size_na-distance_na-na-unknown",
                amount=100,
                unit="km",
                region="US"
            )
        },
        {
            "name": "Electricity consumption",
            "data": ActivityData(
                activity_id="electricity-energy_source_grid-average",
                amount=100,
                unit="kwh",
                region="US"
            )
        }
    ]
    
    for activity in valid_activities:
        print(f"Validating: {activity['name']}")
        print(f"  Activity ID: {activity['data'].activity_id}")
        print(f"  Amount: {activity['data'].amount} {activity['data'].unit}")
        print(f"  Region: {activity['data'].region}")
        print()


def demo_unit_conversion():
    """Demonstrate unit conversion functionality"""
    print("Unit Conversion Demo")
    print("=" * 50)
    
    tool = ClimatiqApiTool()
    
    # Test various unit conversions
    conversions = [
        ("Weight", 1000, "g", "kg", 1.0),
        ("Distance", 1, "mile", "km", 1.60934),
        ("Energy", 1, "mwh", "kwh", 1000.0),
    ]
    
    for conversion_type, amount, from_unit, to_unit, expected in conversions:
        result = tool._convert_unit(amount, from_unit, to_unit)
        print(f"{conversion_type}: {amount} {from_unit} = {result:.5f} {to_unit}")
    
    print()


def demo_carbon_calculation():
    """Demonstrate carbon footprint calculation"""
    print("Carbon Calculation Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool
        tool = ClimatiqApiTool()
        
        # Example activities for carbon calculation - using simpler activity IDs that should work
        activities = [
            {
                "description": "Consuming 100 kWh of electricity",
                "data": {
                    "activity_id": "electricity-energy_source_grid-average",
                    "amount": 100,
                    "unit": "kwh",
                    "region": "US",
                    "data_version": "24.24"
                }
            }
        ]
        
        for activity in activities:
            print(f"Calculating carbon footprint for: {activity['description']}")
            result = tool.run(activity["data"])
            
            if result["success"]:
                print(f"  CO2e: {result['co2e']:.4f} {result['co2e_unit']}")
                print(f"  Calculation method: {result['calculation_method']}")
                print(f"  Calculation origin: {result['calculation_origin']}")
            else:
                print(f"  Calculation failed: {result.get('error', 'Unknown error')}")
            
            print()
            
    except Exception as e:
        print(f"ERROR: Failed to demonstrate carbon calculation: {e}")


def demo_caching():
    """Demonstrate caching functionality"""
    print("Caching Demo")
    print("=" * 50)
    
    try:
        tool = ClimatiqApiTool()
        
        activity_data = {
            "activity_id": "electricity-energy_source_grid-average",
            "amount": 50,
            "unit": "kwh",
            "region": "US",
            "data_version": "24.24"
        }
        
        print("Making first request (no cache)...")
        result1 = tool.run(activity_data)
        
        print("Making second request (should use cache)...")
        result2 = tool.run(activity_data)
        
        if result1["success"] and result2["success"]:
            print(f"First result CO2e: {result1['co2e']:.4f} {result1['co2e_unit']}")
            print(f"Second result CO2e: {result2['co2e']:.4f} {result2['co2e_unit']}")
            print("Results should be identical (cached)")
        else:
            print("One or both requests failed")
            
    except Exception as e:
        print(f"ERROR: Failed to demonstrate caching: {e}")


def main():
    """Main demo function"""
    print("Climatiq API Tool Demo")
    print("=" * 60)
    print("This demo shows the features of the ClimatiqApiTool for")
    print("real-time carbon footprint calculations.\n")
    
    # Demo environment setup
    if not demo_environment_setup():
        print("Demo cannot proceed without CLIMATIQ_API_KEY")
        return
    
    # Demo tool initialization
    tool = demo_tool_initialization()
    if not tool:
        print("Demo cannot proceed without tool initialization")
        return
    
    # Demo activity data validation
    demo_activity_data_validation()
    
    # Demo unit conversion
    demo_unit_conversion()
    
    # Demo carbon calculation
    demo_carbon_calculation()
    
    # Demo caching
    demo_caching()
    
    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("The ClimatiqApiTool includes:")
    print("- Real-time carbon footprint calculations using Climatiq API")
    print("- Activity data validation with Pydantic models")
    print("- Unit conversion utilities for various units")
    print("- Redis caching for emission factors")
    print("- Comprehensive error handling")


if __name__ == "__main__":
    main()