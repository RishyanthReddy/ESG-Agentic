"""
Final test script to verify the health endpoint works correctly
"""
import requests
import time
import os

def test_health_endpoint():
    """
    Test the health endpoint by making a request to it
    """
    print("Testing health endpoint...")
    
    # Wait a moment for the server to start
    time.sleep(2)
    
    try:
        # Make a request to the health endpoint
        response = requests.get("http://localhost:8000/health", timeout=10)
        
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print("Health check successful!")
            print(f"Overall status: {data['status']}")
            print(f"Response time: {data['response_time']:.2f}s")
            
            # Print individual check results
            for check_name, check_result in data['checks'].items():
                print(f"{check_name}: {check_result['status']}")
                
            return True
        else:
            print(f"Health check failed with status code: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("Could not connect to the server. Make sure the server is running.")
        return False
    except Exception as e:
        print(f"Error testing health endpoint: {e}")
        return False

if __name__ == "__main__":
    success = test_health_endpoint()
    if success:
        print("\n✓ Health endpoint test passed!")
    else:
        print("\n✗ Health endpoint test failed!")