#!/usr/bin/env python3
"""
Demo script showcasing the Verification Agent
"""

import sys
import os

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.agents.verification import verification_agent
from src.state.models import AppState, vLEICredential, VerificationStatus
from src.tools.verification import GleifVerifierTool
from src.tools.registry import ToolRegistry


def demo_verification_agent():
    """Demonstrate the verification agent functionality"""
    print("Verification Agent Demo")
    print("=" * 30)
    
    # Create a credential to verify
    print("Creating a vLEI credential for verification...")
    credential = vLEICredential(
        issuer="did:web:example.com",
        subject="did:lei:549300A6XUSR882F7N34:entity",
        claims={
            "lei": "549300A6XUSR882F7N34",
            "organization": "Example Corp",
            "country": "US"
        }
    )
    
    print(f"Credential ID: {credential.id}")
    print(f"Issuer: {credential.issuer}")
    print(f"Subject: {credential.subject}")
    print(f"Initial verification status: {credential.verification_status}")
    print()
    
    # Create initial state
    print("Creating initial application state...")
    state = AppState(
        current_credential=credential,
        credentials=[credential],
        workflow_status="verification_pending"
    )
    print(f"Initial workflow status: {state.workflow_status}")
    print()
    
    # Register the GleifVerifierTool in the tool registry
    print("Registering GleifVerifierTool in the tool registry...")
    registry = ToolRegistry()
    verifier_tool = GleifVerifierTool()
    registry.register_tool(verifier_tool)
    print("Tool registered successfully!")
    print()
    
    # Run the verification agent
    print("Running verification agent...")
    result = verification_agent(state)
    print()
    
    # Show results
    print("Verification Results:")
    print("-" * 20)
    print(f"Workflow status: {result['workflow_status']}")
    
    if "processing_results" in result and "verification_result" in result["processing_results"]:
        verification_result = result["processing_results"]["verification_result"]
        print(f"Verified: {verification_result['verified']}")
        if "reason" in verification_result:
            print(f"Reason: {verification_result['reason']}")
        print(f"Timestamp: {verification_result['timestamp']}")
    
    # Show updated credential status
    if result["credentials"]:
        updated_credential = result["credentials"][0]
        print(f"Updated credential verification status: {updated_credential.verification_status}")
    
    # Show agent trace
    if result["agent_trace"]:
        trace = result["agent_trace"][-1]  # Get the last trace entry
        print(f"Agent: {trace['agent']}")
        print(f"Action: {trace['action']}")
        print(f"Verified: {trace['verified']}")
    
    print()
    print("Demo completed successfully!")


if __name__ == "__main__":
    demo_verification_agent()