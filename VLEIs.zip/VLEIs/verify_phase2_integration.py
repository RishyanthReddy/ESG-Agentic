"""
Simple verification script for Phase 2 Integration Test
"""

import os
from pathlib import Path


def test_integration_test_file():
    """Test that the Phase 2 integration test file exists and has required components"""
    print("Testing Phase 2 Integration Test configuration...")
    
    # Check test file exists
    test_path = Path("tests/test_phase2_integration.py")
    if not test_path.exists():
        print("❌ Phase 2 integration test file not found")
        return False
    print("✓ Phase 2 integration test file exists")
    
    # Check test file content
    try:
        with open(test_path, "r") as f:
            test_content = f.read()
        
        # Check for required imports
        required_imports = [
            "import pytest",
            "import httpx",
            "import asyncio",
            "from src.state.models import AppState"
        ]
        
        for import_stmt in required_imports:
            if import_stmt not in test_content:
                print(f"❌ Required import missing: {import_stmt}")
                return False
        print("✓ All required imports present")
        
        # Check for required test functions
        required_tests = [
            "test_end_to_end_integration_stream_endpoint",
            "test_end_to_end_integration_with_anomaly_detection",
            "test_data_flow_validation",
            "test_performance_validation",
            "test_regression_validation"
        ]
        
        for test_func in required_tests:
            if f"def {test_func}" not in test_content:
                print(f"❌ Required test function missing: {test_func}")
                return False
        print("✓ All required test functions present")
        
        # Check for unit tests
        unit_tests = [
            "test_test_data_generation",
            "test_mock_configuration"
        ]
        
        for test_func in unit_tests:
            if f"def {test_func}" not in test_content:
                print(f"❌ Required unit test missing: {test_func}")
                return False
        print("✓ All required unit tests present")
        
        # Check for test data
        if "TEST_SUPPLIER_DATA" not in test_content:
            print("❌ TEST_SUPPLIER_DATA not found in test file")
            return False
        print("✓ Test data present")
        
        # Check for scope3_data in test data
        if "scope3_data" not in test_content:
            print("❌ scope3_data not found in test data")
            return False
        print("✓ Scope 3 data present in test data")
        
        return True
        
    except Exception as e:
        print(f"❌ Error reading test file: {e}")
        return False


def test_pytest_httpx_installed():
    """Test that pytest-httpx is installed"""
    print("Testing pytest-httpx installation...")
    
    try:
        import pytest_httpx
        print("✓ pytest-httpx is installed")
        return True
    except ImportError:
        print("❌ pytest-httpx is not installed")
        return False


def main():
    """Main verification function"""
    print("Phase 2 Integration Test Verification")
    print("=" * 40)
    
    all_passed = True
    
    # Test integration test file
    if not test_integration_test_file():
        all_passed = False
    
    # Test pytest-httpx installation
    if not test_pytest_httpx_installed():
        all_passed = False
    
    print("=" * 40)
    if all_passed:
        print("✅ All Phase 2 integration tests verification passed!")
        return 0
    else:
        print("❌ Some verification tests failed!")
        return 1


if __name__ == "__main__":
    exit(main())