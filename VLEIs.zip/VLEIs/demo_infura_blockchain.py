"""
Demo script for the enhanced Infura Blockchain Tool
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.tools.provenance import InfuraBlockchainTool
from src.tools.registry import ToolRegistry
import hashlib


def demo_environment_setup():
    """Demonstrate that the INFURA_API_KEY is properly loaded from the environment"""
    print("Environment Setup Demo")
    print("=" * 50)
    
    # Show that the INFURA_API_KEY is available
    infura_api_key = os.getenv("INFURA_API_KEY")
    if infura_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = infura_api_key[:5] + "..." + infura_api_key[-5:]
        print(f"INFURA_API_KEY found in environment: {masked_key}")
    else:
        print("WARNING: INFURA_API_KEY not found in environment!")
        return False
    
    print()
    return True


def demo_tool_initialization():
    """Demonstrate initializing the InfuraBlockchainTool"""
    print("Tool Initialization Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool - it will automatically use the INFURA_API_KEY from environment
        tool = InfuraBlockchainTool()
        
        # Show connection information
        connection_info = tool.get_connection_info()
        print(f"Network: {connection_info['network']}")
        print(f"Chain ID: {connection_info['chain_id']}")
        print(f"Endpoint: {connection_info['endpoint']}")
        print(f"Connected: {connection_info['connected']}")
        
        print("\nTool successfully initialized and connected to Sepolia testnet!")
        return tool
        
    except Exception as e:
        print(f"ERROR: Failed to initialize tool: {e}")
        return None


def demo_transaction_building():
    """Demonstrate transaction building and signing"""
    print("\nTransaction Building Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool
        tool = InfuraBlockchainTool()
        
        # Sample data to hash
        sample_data = "This is sample ESG data for blockchain logging"
        
        # Create SHA-256 hash of the data
        data_hash = hashlib.sha256(sample_data.encode()).hexdigest()
        print(f"Sample data: {sample_data}")
        print(f"SHA-256 hash: {data_hash}")
        
        # For demo purposes, we won't actually send a transaction as it requires a real private key
        # But we can show what the transaction preparation would look like
        print("\nTransaction preparation would include:")
        print("- Nonce management")
        print("- Gas estimation with safety margin")
        print("- Dynamic gas pricing")
        print("- Data encoding for blockchain storage")
        
        return data_hash
        
    except Exception as e:
        print(f"ERROR: Failed in transaction building demo: {e}")
        return None


def demo_tool_registration():
    """Demonstrate registering the tool in the registry"""
    print("\nTool Registration Demo")
    print("=" * 50)
    
    # Get the registry instance
    registry = ToolRegistry()
    registry.clear()  # Clear any existing tools for demo purposes
    
    # Create and register the tool
    tool = InfuraBlockchainTool()
    registry.register_tool(tool)
    
    # List registered tools
    tools = registry.list_tools()
    print("Registered tools:")
    for name, description in tools.items():
        print(f"  - {name}: {description}")
    
    # Retrieve the tool
    retrieved_tool = registry.get_tool("infura_blockchain")
    if retrieved_tool:
        print(f"\nSuccessfully retrieved tool: {retrieved_tool.name}")
    else:
        print("\nERROR: Failed to retrieve tool from registry!")


def demo_gas_optimization():
    """Demonstrate gas optimization features"""
    print("\nGas Optimization Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool
        tool = InfuraBlockchainTool()
        
        # Show gas optimization features
        print("Gas optimization features:")
        print("- Dynamic gas price fetching with premium for faster confirmation")
        print("- Gas estimation with safety buffer")
        print("- Transaction receipt waiting with timeout")
        
        # Get web3 instance to show gas information
        web3 = tool.web3
        
        # Get current gas price
        gas_price = web3.eth.gas_price
        gas_price_gwei = web3.from_wei(gas_price, 'gwei')
        print(f"\nCurrent network gas price: {gas_price_gwei} Gwei")
        
        # Show how we would estimate gas for a transaction
        print("Gas estimation includes 20% safety buffer for reliability")
        print("Gas pricing includes 10% premium for faster confirmation")
        
    except Exception as e:
        print(f"ERROR: Failed in gas optimization demo: {e}")


def main():
    """Main demo function"""
    print("Enhanced Infura Blockchain Tool Demo")
    print("=" * 60)
    print("This demo shows the enhanced features of the InfuraBlockchainTool")
    print("for logging data provenance to the Ethereum Sepolia testnet.\n")
    
    # Demo environment setup
    if not demo_environment_setup():
        return
    
    # Demo tool initialization
    tool = demo_tool_initialization()
    if not tool:
        return
    
    # Demo transaction building
    data_hash = demo_transaction_building()
    
    # Demo gas optimization
    demo_gas_optimization()
    
    # Demo tool registration
    demo_tool_registration()
    
    print("\n" + "=" * 60)
    print("Demo completed successfully!")
    print("The enhanced InfuraBlockchainTool includes:")
    print("- Secure Infura API integration")
    print("- Dynamic gas optimization")
    print("- Transaction building and signing")
    print("- Receipt confirmation tracking")
    print("- Error handling and logging")


if __name__ == "__main__":
    main()