# Graph Serialization Tool

## Overview

The Graph Serialization Tool is a specialized tool for converting NetworkX graphs into structured JSON format optimized for 3D rendering engines like Three.js. This tool uses NetworkX's built-in serialization functions to convert graphs into JSON with nodes and links arrays, enhanced with visualization-specific properties for effective 3D rendering.

## Purpose

The tool serves as a bridge between NetworkX graph data structures and web-based 3D visualization libraries. It enables the transformation of complex supply chain provenance graphs into formats that can be directly consumed by Three.js and similar rendering engines, providing rich visualization capabilities for ESG data analysis.

## Implementation Details

### Core Components

The tool is implemented as `GraphSerializationTool` class that extends `BaseTool` and provides the following functionality:

1. **Graph Serialization**: Converts NetworkX graphs to JSON format using `networkx.node_link_data`
2. **Format Optimization**: Enhances graph data with visualization-specific properties
3. **Format Validation**: Ensures compatibility with Three.js and other 3D rendering engines
4. **Data Compression**: Provides optional compression for efficient web transfer
5. **Multiple Format Support**: Supports both standard JSON and Three.js optimized formats

### Serialization Process

1. **Graph Conversion**: Uses `networkx.node_link_data` to convert NetworkX graphs to node-link format
2. **Optimization**: Adds visualization properties like positions, colors, sizes, and labels
3. **Validation**: Ensures the resulting JSON is compatible with Three.js
4. **Compression**: Optionally compresses the JSON for efficient web transfer
5. **Output**: Returns structured JSON ready for 3D rendering

### Visualization Enhancements

The tool adds several visualization-specific properties to enhance the 3D rendering experience:

1. **Node Properties**:
   - Position coordinates (x, y, z)
   - Size and opacity values
   - Color mapping based on node type
   - Labels for display
   - Type information for styling

2. **Link/Edge Properties**:
   - Width and opacity values
   - Color mapping based on relationship type
   - Source and target node references

3. **Metadata**:
   - Format version information
   - Creation timestamp
   - Node and link counts
   - Format compatibility indicators

## Usage

### Basic Usage

```python
import networkx as nx
from src.tools.visualization import GraphSerializationTool

# Initialize the tool
tool = GraphSerializationTool()

# Create a sample graph
graph = nx.DiGraph()
graph.add_node("A", type="agent", name="Agent A")
graph.add_node("B", type="artifact", name="Artifact B")
graph.add_edge("A", "B", relationship="produced")

# Serialize to Three.js format
result = tool.run(graph, format="threejs")
json_string = result['serialized_graph']

# Serialize to standard JSON format
result = tool.run(graph, format="json")
json_string = result['serialized_graph']
```

### Advanced Usage with Optimization

```python
# Serialize with optimization and compression
result = tool.run(
    graph, 
    format="threejs", 
    optimize=True, 
    compress=True
)

# Access serialization metadata
print(f"Format: {result['format']}")
print(f"Size: {result['size']} characters")
print(f"Optimized: {result['optimized']}")
print(f"Compressed: {result['compressed']}")
```

### Integration with NetworkX Provenance Tool

```python
from src.tools.visualization import NetworkXProvenanceTool, GraphSerializationTool

# Create provenance graph
provenance_tool = NetworkXProvenanceTool()
provenance_result = provenance_tool.run(agent_traces, blockchain_logs)
graph = provenance_result['graph']

# Serialize for 3D visualization
serialization_tool = GraphSerializationTool()
visualization_data = serialization_tool.run(graph, format="threejs")
```

## API Reference

### GraphSerializationTool

#### Constructor

```python
GraphSerializationTool()
```

Initializes the Graph Serialization Tool.

#### Methods

##### run(graph, format, optimize, compress)

Execute the Graph Serialization Tool.

**Parameters:**
- `graph` (nx.Graph): NetworkX graph to serialize
- `format` (str): Output format ('threejs', 'json')
- `optimize` (bool): Whether to optimize for visualization
- `compress` (bool): Whether to compress the output

**Returns:**
- `Dict[str, Any]`: Result containing the serialized graph

**Example:**
```python
result = tool.run(graph, format="threejs", optimize=True, compress=False)
json_data = result['serialized_graph']
```

##### serialize_for_threejs(graph, optimize)

Serialize NetworkX graph to Three.js compatible JSON.

**Parameters:**
- `graph` (nx.Graph): NetworkX graph to serialize
- `optimize` (bool): Whether to optimize for visualization

**Returns:**
- `str`: JSON string compatible with Three.js

##### optimize_for_visualization(data)

Optimize graph data for 3D visualization.

**Parameters:**
- `data` (Dict[str, Any]): Graph data in node-link format

**Returns:**
- `Dict[str, Any]`: Optimized graph data for visualization

##### validate_threejs_compatibility(data)

Validate that the JSON data is compatible with Three.js.

**Parameters:**
- `data` (Dict[str, Any]): Graph data to validate

**Returns:**
- `bool`: True if compatible, False otherwise

##### compress_json(json_str)

Compress JSON string for efficient web transfer.

**Parameters:**
- `json_str` (str): JSON string to compress

**Returns:**
- `str`: Compressed JSON string

## Testing

### Unit Tests

Unit tests are located in `tests/test_graph_serialization.py` and cover:

- Tool initialization
- JSON format generation from graphs
- Three.js format generation
- Format validation
- Data integrity during serialization
- Performance with various graph sizes

Run with:
```bash
python -m pytest tests/test_graph_serialization.py -v
```

### Integration Tests

Integration tests are located in `tests/test_graph_serialization_integration.py` and cover:

- Three.js compatibility validation
- Performance with complex supply chain graphs
- JSON size and transfer efficiency
- Visualization data completeness
- Format versioning and backwards compatibility

Run with:
```bash
python -m pytest tests/test_graph_serialization_integration.py -v
```

## Demo

A demo script is available at `demo_graph_serialization.py` to showcase the tool's functionality:

```bash
python demo_graph_serialization.py
```

## Supported Formats

### Three.js Optimized Format

The Three.js optimized format includes:

- Standard node-link structure from NetworkX
- Visualization-specific properties for nodes and links
- Metadata for rendering engines
- Color mapping based on node types and relationships
- Position coordinates for 3D layout

### Standard JSON Format

The standard JSON format includes:

- Pure NetworkX node-link data structure
- All original graph attributes preserved
- No additional visualization properties
- Compatible with general JSON processing tools

## Performance Considerations

The tool is optimized for performance:

- Efficient serialization algorithms
- Minimal memory footprint
- Optional compression for web transfer
- Performance tested with large graphs

## Format Evolution

The tool supports format versioning and backwards compatibility:

- Version metadata in serialized output
- Consistent data structure across versions
- Clear migration paths for format changes
- Backwards compatibility with previous versions

## License

This tool is part of the VLEIs project and is subject to the same license terms.