# NetworkX Provenance Tool

## Overview

The NetworkX Provenance Tool is a sophisticated tool for constructing formal graph data models of supply chain data flow using the NetworkX library. This tool takes agent traces and blockchain logs to create NetworkX DiGraphs with suppliers, agents, and artifacts as nodes, representing the complete provenance of data and processes in the supply chain.

## Purpose

Supply chain data provenance is critical for ensuring transparency, traceability, and trustworthiness in ESG reporting. This tool creates a formal graph representation of the data flow, enabling:

- Visualization of the complete supply chain data flow
- Analysis of data relationships and dependencies
- Identification of data lineage and transformation processes
- Verification of data integrity through blockchain anchoring
- Auditing capabilities for compliance and verification

## Implementation Details

### Core Components

The tool is implemented as `NetworkXProvenanceTool` class that extends `BaseTool` and provides the following functionality:

1. **Graph Construction**: Creates NetworkX DiGraph from agent traces and blockchain logs
2. **Node Management**: Handles different node types (agents, artifacts, suppliers, blockchain entries)
3. **Edge Management**: Creates relationships between nodes based on data flow
4. **Attribute Management**: Enriches nodes and edges with metadata
5. **Validation**: Ensures graph integrity and completeness
6. **Serialization**: Converts graphs to various formats for storage and visualization

### Node Types

The tool supports the following node types:

1. **Agents**: Represent processing entities in the supply chain
2. **Artifacts**: Represent data objects (files, reports, credentials)
3. **Suppliers**: Represent external entities providing data or services
4. **Blockchain**: Represent entries recorded on the blockchain for immutable provenance

### Graph Construction Process

1. Parse agent traces to identify agents, input artifacts, and output artifacts
2. Parse blockchain logs to identify immutable records
3. Create nodes for each entity with rich metadata
4. Create directed edges representing data flow and relationships
5. Validate the resulting graph structure
6. Serialize the graph for storage or visualization

## Usage

### Basic Usage

```python
from src.tools.visualization import NetworkXProvenanceTool

# Initialize the tool
tool = NetworkXProvenanceTool()

# Prepare agent traces
agent_traces = [
    {
        "agent_id": "credential_agent_1",
        "agent_name": "Credential Verification Agent",
        "agent_role": "verification",
        "status": "completed",
        "timestamp": "2023-01-01T00:00:00Z",
        "input_artifacts": [...],
        "output_artifacts": [...]
    }
]

# Prepare blockchain logs
blockchain_logs = [
    {
        "transaction_hash": "0x1234567890abcdef",
        "data_hash": "abcdef1234567890",
        "account": "0xAccount123",
        "block_number": 1000000,
        "gas_used": 21000,
        "timestamp": "2023-01-01T00:01:00Z"
    }
]

# Create the provenance graph
result = tool.run(agent_traces, blockchain_logs)

# Access the graph
graph = result['graph']
print(f"Created graph with {result['node_count']} nodes and {result['edge_count']} edges")
```

### Integration with Tool Registry

```python
from src.tools.registry import ToolRegistry
from src.tools.visualization import NetworkXProvenanceTool

# Initialize registry
registry = ToolRegistry()

# Register the tool
provenance_tool = NetworkXProvenanceTool()
registry.register_tool(provenance_tool)

# Retrieve and use the tool
tool = registry.get_tool("networkx_provenance")
result = tool.run(agent_traces, blockchain_logs)
```

## API Reference

### NetworkXProvenanceTool

#### Constructor

```python
NetworkXProvenanceTool()
```

Initializes the NetworkX Provenance Tool.

#### Methods

##### run(agent_traces, blockchain_logs)

Execute the NetworkX Provenance Tool to create a provenance graph.

**Parameters:**
- `agent_traces` (List[Dict[str, Any]]): List of agent trace data
- `blockchain_logs` (List[Dict[str, Any]]): List of blockchain log data

**Returns:**
- `Dict[str, Any]`: Result containing the graph and metadata

**Example:**
```python
result = tool.run(agent_traces, blockchain_logs)
graph = result['graph']
```

##### create_provenance_graph(agent_traces, blockchain_logs)

Create a provenance graph from agent traces and blockchain logs.

**Parameters:**
- `agent_traces` (List[Dict[str, Any]]): List of agent trace data
- `blockchain_logs` (List[Dict[str, Any]]): List of blockchain log data

**Returns:**
- `nx.DiGraph`: NetworkX directed graph representing the provenance

##### validate_graph(graph)

Validate the structure of the provenance graph.

**Parameters:**
- `graph` (nx.DiGraph): The graph to validate

**Returns:**
- `Dict[str, Any]`: Validation results

##### serialize_graph(graph, format)

Serialize the graph to a string representation.

**Parameters:**
- `graph` (nx.DiGraph): The graph to serialize
- `format` (str): Serialization format ('json', 'graphml', 'gexf')

**Returns:**
- `str`: Serialized graph representation

## Testing

### Unit Tests

Unit tests are located in `tests/test_networkx_provenance.py` and cover:

- Tool initialization
- Node and edge creation logic
- Graph construction from trace data
- Graph validation
- Attribute management
- Serialization functionality

Run with:
```bash
python -m pytest tests/test_networkx_provenance.py -v
```

### Integration Tests

Integration tests are located in `tests/test_networkx_provenance_integration.py` and cover:

- Real data processing with actual agent traces and blockchain logs
- Graph quality and completeness validation
- Performance analysis with large datasets
- Visualization readiness
- Data integrity verification

Run with:
```bash
python -m pytest tests/test_networkx_provenance_integration.py -v
```

## Demo

A demo script is available at `demo_networkx_provenance.py` to showcase the tool's functionality:

```bash
python demo_networkx_provenance.py
```

## Graph Serialization Formats

The tool supports multiple serialization formats for different use cases:

1. **JSON**: Standard format for web applications and general use
2. **GraphML**: Standard XML-based format for graph exchange
3. **GEXF**: Format optimized for Gephi and other visualization tools

## Performance Considerations

The tool is optimized for performance with large datasets:

- Efficient graph construction algorithms
- Minimal memory footprint
- Scalable node and edge processing
- Performance tested with large datasets

## Future Extensions

Potential future enhancements include:

- Support for additional graph algorithms and analysis
- Integration with graph databases for persistence
- Real-time graph updates and streaming
- Advanced visualization capabilities
- Export to additional formats (CSV, RDF, etc.)

## License

This tool is part of the VLEIs project and is subject to the same license terms.