# EU CSRD Compliance Mapping Document

This document maps the European Union's Corporate Sustainability Reporting Directive (CSRD) requirements to the data points collected and reported by the ESG Intelligence Platform.

## Overview

The CSRD extends the scope of the previous Non-Financial Reporting Directive (NFRD) and introduces more detailed reporting requirements based on the European Sustainability Reporting Standards (ESRS). It applies to large companies and those listed on regulated markets, requiring them to disclose information on how sustainability issues affect their business and how their activities impact people and the environment.

## Key Requirements and System Data Mapping

### 1. Double Materiality Principle

**CSRD Requirement**: Companies must assess both "impact materiality" (how the company affects the environment and people) and "financial materiality" (how sustainability issues affect the company's business).

**System Data Points**:
- `claims.impacts` - Maps to impact materiality by capturing principal impacts on environment and people
- `claims.business_model` - Maps to financial materiality by describing how sustainability affects business
- `claims.strategies.climate_risks` - Details financial risks from sustainability issues

### 2. Cross-Cutting Disclosures (ESRS 1 and ESRS 2)

**CSRD Requirement**: General disclosures about business model, value chain, impact assessment, due diligence, and policies.

**System Data Points**:
- `claims.business_model` - Business model description
- `claims.value_chain` - Value chain information
- `claims.impacts` - Principal impacts assessment
- `claims.due_diligence` - Due diligence processes
- `claims.policies` - Sustainability policies

### 3. Environmental Disclosures

#### Climate Change (ESRS E1)
**CSRD Requirement**: Disclose greenhouse gas emissions, climate-related risks, and transition plans.

**System Data Points**:
- `claims.environmental.ghg_emissions` - Direct and indirect GHG emissions data
- `claims.strategies.climate_risks` - Climate-related risk assessment
- `claims.targets` - Emission reduction targets and transition plans

#### Pollution (ESRS E2)
**CSRD Requirement**: Report on air, water, and soil pollution, including substances of concern.

**System Data Points**:
- `claims.environmental.pollution` - Pollution data including SOx, NOx, and other pollutants

#### Water and Marine Resources (ESRS E3)
**CSRD Requirement**: Disclose water consumption, discharge, and impacts on marine ecosystems.

**System Data Points**:
- `claims.environmental.water` - Water consumption, withdrawal, and discharge data

#### Biodiversity and Ecosystems (ESRS E4)
**CSRD Requirement**: Report on land use, biodiversity impacts, and protection measures.

**System Data Points**:
- `claims.environmental.biodiversity` - Biodiversity impact assessments and protection measures

#### Resource Use and Circular Economy (ESRS E5)
**CSRD Requirement**: Disclose resource consumption, waste generation, and circularity metrics.

**System Data Points**:
- `claims.environmental.resources` - Resource use and circular economy metrics

### 4. Social Disclosures

#### Own Workforce (ESRS S1)
**CSRD Requirement**: Report on employment, health & safety, training, and diversity.

**System Data Points**:
- `claims.social.workforce` - Workforce demographics, health & safety, training data

#### Workers in Value Chain (ESRS S2)
**CSRD Requirement**: Disclose supply chain labor practices and due diligence.

**System Data Points**:
- `claims.social.value_chain_workers` - Supply chain worker conditions and practices

#### Affected Communities (ESRS S3)
**CSRD Requirement**: Report on community impacts, human rights, and stakeholder engagement.

**System Data Points**:
- `claims.social.communities` - Community impact assessments and engagement data

#### Consumers and End-Users (ESRS S4)
**CSRD Requirement**: Disclose product safety, lifecycle impacts, and consumer protection.

**System Data Points**:
- `claims.social.customers` - Product safety and customer protection data

### 5. Governance Disclosures (ESRS G1)

**CSRD Requirement**: Describe governance structures, policies, and procedures for sustainability.

**System Data Points**:
- `claims.governance.body` - Governance body composition and responsibilities
- `claims.governance.remuneration` - Executive remuneration policies
- `claims.governance.prevention` - Processes to prevent adverse impacts
- `claims.governance.breaches` - Reporting of breaches and corrective actions

## Implementation in System Architecture

### Data Collection
The system collects ESG data through verifiable credentials that contain structured claims about various aspects of a company's sustainability performance.

### Data Transformation
The [transformation_utils.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/transformation_utils.py) module contains functions that map internal data structures to regulatory formats including CSRD.

### Data Validation
The [CSRDReport](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/state/models.py#L124-L143) model in [models.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/state/models.py) provides validation of the data structure according to basic CSRD requirements.

### Reporting
The [regulatory_reporting_agent](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/reporting.py#L57-L311) in [reporting.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/agents/reporting.py) generates CSRD-compliant reports using Jinja2 templates.

## Future Enhancements

1. Enhanced validation rules based on specific ESRS requirements
2. Integration with external data sources for benchmarking
3. Automated gap analysis between collected data and CSRD requirements
4. Machine learning models for predicting materiality