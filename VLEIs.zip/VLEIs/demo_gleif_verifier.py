"""
Demo script for the GLEIF vLEI Verifier Tool
"""

import sys
import os

# Add src to path so we can import our modules
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.tools.verification import GleifVerifierTool
from src.state.models import vLEICredential
from loguru import logger


def main():
    """Main demo function"""
    logger.info("Starting GLEIF vLEI Verifier Tool Demo")
    
    # Initialize the tool
    tool = GleifVerifierTool()
    
    # Example 1: Valid LEI credential
    logger.info("Example 1: Verifying credential with valid LEI")
    credential1 = vLEICredential(
        issuer="did:web:example.com",
        subject="did:lei:HXB0UMUMDLF1QQF6UY42",
        claims={"lei": "HXB0UMUMDLF1QQF6UY42", "entity_name": "Apple Inc."},
        proof={"type": "Ed25519Signature2018"}
    )
    
    result1 = tool.run(credential1)
    logger.info(f"Verification result: {result1}")
    
    # Example 2: Invalid LEI credential
    logger.info("Example 2: Verifying credential with invalid LEI")
    credential2 = vLEICredential(
        issuer="did:web:example.com",
        subject="did:example:subject",
        claims={"lei": "INVALIDLEI123456789"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    result2 = tool.run(credential2)
    logger.info(f"Verification result: {result2}")
    
    # Example 3: Credential without LEI
    logger.info("Example 3: Verifying credential without LEI")
    credential3 = vLEICredential(
        issuer="did:web:example.com",
        subject="did:example:subject",
        claims={"other": "data"},
        proof={"type": "Ed25519Signature2018"}
    )
    
    result3 = tool.run(credential3)
    logger.info(f"Verification result: {result3}")
    
    logger.info("GLEIF vLEI Verifier Tool Demo completed")


if __name__ == "__main__":
    main()