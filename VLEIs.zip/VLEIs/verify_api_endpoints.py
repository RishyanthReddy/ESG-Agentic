"""
Simple verification script for API endpoints
"""

def test_api_models():
    """Test that the API models can be imported and used correctly"""
    try:
        # Test importing from main
        from main import IngestRequest, IngestResponse, app
        print("✓ Successfully imported API models and app")
        
        # Test IngestRequest model
        request_data = {
            "supplier_data": {"company": "Test Corp"},
            "config": {"timeout": 30}
        }
        
        request = IngestRequest(**request_data)
        assert request.supplier_data == {"company": "Test Corp"}
        assert request.config == {"timeout": 30}
        print("✓ IngestRequest model works correctly")
        
        # Test IngestResponse model
        response_data = {
            "status": "success",
            "message": "Test completed",
            "final_state": {"workflow_status": "completed"}
        }
        
        response = IngestResponse(**response_data)
        assert response.status == "success"
        assert response.message == "Test completed"
        assert response.final_state == {"workflow_status": "completed"}
        print("✓ IngestResponse model works correctly")
        
        # Test that app is a FastAPI instance
        from fastapi import FastAPI
        assert isinstance(app, FastAPI)
        print("✓ FastAPI app instance is correctly created")
        
        # Test that routes are registered
        routes = [route.path for route in app.routes]
        required_routes = ["/", "/health", "/ingest/stream", "/ingest/upload"]
        for route in required_routes:
            assert route in routes, f"Missing route: {route}"
        print("✓ All required API routes are registered")
        
        print("\n🎉 All API endpoint tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Error testing API endpoints: {e}")
        return False


if __name__ == "__main__":
    test_api_models()