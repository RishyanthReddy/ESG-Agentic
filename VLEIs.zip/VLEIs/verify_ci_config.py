"""
Simple verification script for CI workflow configuration
"""

import os
import yaml
from pathlib import Path


def test_workflow_file():
    """Test that the GitHub Actions workflow file exists and is valid"""
    print("Testing CI workflow configuration...")
    
    # Check workflow file exists
    workflow_path = Path(".github/workflows/ci.yml")
    if not workflow_path.exists():
        print("❌ CI workflow file not found")
        return False
    print("✓ CI workflow file exists")
    
    # Check workflow file structure
    try:
        with open(workflow_path, "r") as f:
            workflow_content = yaml.safe_load(f)
        
        # Check required keys
        if "name" not in workflow_content:
            print("❌ Workflow name missing")
            return False
        print("✓ Workflow name present")
        
        if "on" not in workflow_content:
            print("❌ Workflow triggers missing")
            return False
        print("✓ Workflow triggers present")
        
        if "jobs" not in workflow_content:
            print("❌ Workflow jobs missing")
            return False
        print("✓ Workflow jobs present")
        
        # Check for required jobs
        jobs = workflow_content.get("jobs", {})
        required_jobs = ["validate", "build", "test-unit", "test-integration"]
        for job in required_jobs:
            if job not in jobs:
                print(f"❌ Required job '{job}' missing")
                return False
        print("✓ All required jobs present")
        
    except Exception as e:
        print(f"❌ Error parsing workflow file: {e}")
        return False
    
    print("\n🎉 CI workflow configuration tests passed!")
    return True


def test_required_files():
    """Test that all required files for CI exist"""
    print("\nTesting required files for CI...")
    
    required_files = [
        ".github/workflows/ci.yml",
        "Dockerfile",
        "docker-compose.yml",
        "requirements.txt"
    ]
    
    missing_files = []
    for file_name in required_files:
        file_path = Path(file_name)
        if not file_path.exists():
            missing_files.append(file_name)
        else:
            print(f"✓ {file_name} exists")
    
    if missing_files:
        print(f"❌ Missing files: {missing_files}")
        return False
    
    print("\n🎉 All required CI files present!")
    return True


def test_docker_files():
    """Test that Docker files are properly configured for CI"""
    print("\nTesting Docker configuration for CI...")
    
    # Check Dockerfile
    try:
        with open("Dockerfile", "r") as f:
            dockerfile_content = f.read()
        
        if "FROM python:3.11-slim" not in dockerfile_content:
            print("❌ Python 3.11 slim base image not found")
            return False
        print("✓ Python 3.11 slim base image configured")
        
        if "HEALTHCHECK" not in dockerfile_content:
            print("❌ Health check not configured")
            return False
        print("✓ Health check configured")
        
    except Exception as e:
        print(f"❌ Error reading Dockerfile: {e}")
        return False
    
    # Check docker-compose.yml
    try:
        with open("docker-compose.yml", "r") as f:
            compose_content = yaml.safe_load(f)
        
        services = compose_content.get("services", {})
        if "esg-engine" not in services:
            print("❌ ESG engine service not found in docker-compose")
            return False
        print("✓ ESG engine service configured")
        
        if "redis" not in services:
            print("❌ Redis service not found in docker-compose")
            return False
        print("✓ Redis service configured")
        
    except Exception as e:
        print(f"❌ Error parsing docker-compose.yml: {e}")
        return False
    
    print("\n🎉 Docker configuration for CI tests passed!")
    return True


def test_test_files():
    """Test that test files exist for CI execution"""
    print("\nTesting test files for CI execution...")
    
    # Check that we have test files
    test_files = list(Path("tests").glob("test_*.py"))
    if len(test_files) == 0:
        print("❌ No test files found")
        return False
    print(f"✓ Found {len(test_files)} test files")
    
    # Check for specific test files mentioned in workflow
    required_test_files = [
        "test_docker_build.py",
        "test_api_integration.py",
        "test_docker_integration.py"
    ]
    
    missing_tests = []
    for test_file in required_test_files:
        test_path = Path("tests") / test_file
        if not test_path.exists():
            missing_tests.append(test_file)
        else:
            print(f"✓ {test_file} exists")
    
    if missing_tests:
        print(f"❌ Missing test files: {missing_tests}")
        return False
    
    print("\n🎉 Test files for CI execution present!")
    return True


if __name__ == "__main__":
    workflow_ok = test_workflow_file()
    files_ok = test_required_files()
    docker_ok = test_docker_files()
    tests_ok = test_test_files()
    
    if workflow_ok and files_ok and docker_ok and tests_ok:
        print("\n🎉 CI configuration verification successful!")
        exit(0)
    else:
        print("\n❌ CI configuration verification failed!")
        exit(1)