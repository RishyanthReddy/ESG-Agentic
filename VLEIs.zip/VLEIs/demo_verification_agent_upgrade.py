"""
Demo script for the upgraded verification agent with multi-tool logic
"""

import sys
import os

# Add src to path so we can import our modules
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.agents.verification import verification_agent
from src.state.models import AppState, vLEICredential, VerificationStatus
from loguru import logger


def main():
    """Main demo function"""
    logger.info("Starting upgraded Verification Agent Demo")
    
    # Example 1: GLEIF credential verification
    logger.info("Example 1: Verifying GLEIF credential")
    gleif_credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:lei:HXB0UMUMDLF1QQF6UY42",
        claims={"lei": "HXB0UMUMDLF1QQF6UY42", "entity_name": "Apple Inc."}
    )
    
    gleif_state = AppState(
        current_credential=gleif_credential,
        credentials=[gleif_credential]
    )
    
    gleif_result = verification_agent(gleif_state)
    logger.info(f"GLEIF verification result: {gleif_result['workflow_status']}")
    
    # Example 2: Azure credential verification
    logger.info("Example 2: Verifying Azure credential")
    azure_credential = vLEICredential(
        issuer="https://verifiedid.did.msidentity.com",
        subject="did:example:subject",
        claims={"appid": "test-app", "azp": "azure-app"}
    )
    
    azure_state = AppState(
        current_credential=azure_credential,
        credentials=[azure_credential]
    )
    
    azure_result = verification_agent(azure_state)
    logger.info(f"Azure verification result: {azure_result['workflow_status']}")
    
    # Example 3: Generic credential verification
    logger.info("Example 3: Verifying generic credential")
    generic_credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={"test": "value"}
    )
    
    generic_state = AppState(
        current_credential=generic_credential,
        credentials=[generic_credential]
    )
    
    generic_result = verification_agent(generic_state)
    logger.info(f"Generic verification result: {generic_result['workflow_status']}")
    
    logger.info("Upgraded Verification Agent Demo completed")


if __name__ == "__main__":
    main()