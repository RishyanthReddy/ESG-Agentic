#!/usr/bin/env python3
"""
Demo Script for the Finalization Agent

This script demonstrates the capabilities of the Finalization Agent for handling
all finalization tasks including report generation and signing.
"""

import sys
import os
from datetime import datetime
import uuid

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))

from src.agents.core import finalization_agent
from src.state.models import AppState, vLEICredential, GRIReport, SASBReport
from src.tools.registry import ToolRegistry
from src.tools.verification import SignReportTool


def demo_finalization_agent():
    """Demonstrate the finalization agent functionality"""
    print("Finalization Agent Demo")
    print("=" * 50)
    print("This demo showcases the features of the Finalization Agent")
    print("for handling all finalization tasks including report generation and signing.\n")
    
    # Display technology stack
    print("Technology Stack:")
    print("==================")
    print("Agent Orchestration: Advanced LangGraph agent coordination patterns")
    print("Workflow Management: Sequential and parallel task execution")
    print("State Finalization: Comprehensive state cleanup and finalization")
    print("Quality Assurance: Final validation and quality checks")
    print("Error Handling: Comprehensive finalization error management\n")
    
    # Create sample ESG data
    print("Creating sample ESG data...")
    credential = vLEICredential(
        issuer="did:example:issuer",
        subject="did:example:subject",
        claims={
            "organization": {
                "name": "Global Manufacturing Corp",
                "description": "A leading manufacturer committed to sustainable practices",
                "sector": "Manufacturing",
                "countries": ["US", "DE", "JP"],
                "employee_count": 5000
            },
            "policies": {
                "environmental": "Environmental Policy Statement",
                "social": "Social Responsibility Policy",
                "governance": "Corporate Governance Framework"
            },
            "governance": {
                "board_oversight": "Board oversees climate risks and opportunities",
                "ethics": "Code of Ethics Program"
            },
            "strategies": {
                "climate_risks": "Climate Risk Strategy",
                "resilience": "Climate Resilience Analysis"
            },
            "environmental": {
                "emissions": {"scope1": 1200, "scope2": 800},
                "energy": {"renewable_percentage": 35},
                "water": {"consumption": 75000}
            },
            "social": {
                "workforce": {"training_hours": 25000},
                "products": {"safety_incidents": 2},
                "data": {"breaches": 0}
            },
            "metrics": {
                "emissions": {"total_ghg": 2000},
                "intensity": {"ghg_per_employee": 0.4}
            },
            "targets": {
                "emission_reduction": "40% by 2030"
            }
        }
    )
    
    gri_report = GRIReport(
        company_name="Global Manufacturing Corp",
        report_year=2023,
        data={
            "general_disclosure": {
                "organization_name": "Global Manufacturing Corp",
                "reporting_period": "2023-01-01 to 2023-12-31"
            },
            "environmental": {
                "en15": {
                    "description": "GHG emissions intensity",
                    "value": 0.22,
                    "unit": "tonnes CO2e / USD million revenue"
                }
            }
        }
    )
    
    sasb_report = SASBReport(
        company_name="Global Manufacturing Corp",
        report_year=2023,
        data={
            "environment": {
                "air_quality": {
                    "description": "Impacts from stationary combustion",
                    "metrics": ["Total GHG emissions: 2000 tonnes CO2e"]
                }
            },
            "social": {
                "product_safety": {
                    "description": "Product safety incidents",
                    "metrics": ["Safety incidents: 2"]
                }
            }
        }
    )
    
    # Create initial state
    state = AppState(
        current_credential=credential,
        credentials=[credential],
        gri_reports=[gri_report],
        sasb_reports=[sasb_report],
        workflow_status="processing",
        task_queue=["finalization_task"],
        processing_results={
            "verification_result": {
                "verified": True,
                "timestamp": datetime.now().isoformat()
            }
        },
        agent_trace=[
            {
                "agent": "credential_agent",
                "action": "credential_processed",
                "timestamp": datetime.now().isoformat()
            },
            {
                "agent": "verification_agent",
                "action": "credential_verified",
                "timestamp": datetime.now().isoformat()
            }
        ]
    )
    print(f"Initial workflow status: {state.workflow_status}")
    print(f"Tasks in queue: {len(state.task_queue)}")
    print()
    
    # Register the SignReportTool in the tool registry
    print("Registering SignReportTool in the tool registry...")
    registry = ToolRegistry()
    registry.clear()  # Clear any existing tools
    sign_tool = SignReportTool()
    registry.register_tool(sign_tool)
    print("Tool registered successfully!")
    print()
    
    # Demonstrate finalization agent
    print("Running finalization agent...")
    result = finalization_agent(state)
    print()
    
    # Show results
    print("Finalization Results:")
    print("-" * 20)
    print(f"Workflow status: {result['workflow_status']}")
    print(f"Tasks in queue: {len(result['task_queue'])}")
    
    if result['workflow_status'] == 'finalized':
        print("✓ Finalization completed successfully!")
        
        # Show signed report details
        signed_report = result['signed_report']
        print(f"  Report signed: {signed_report['signed']}")
        print(f"  Report hash: {signed_report['report_hash'][:16]}...")
        print(f"  Signature: {signed_report['signature_info']['signature'][:16]}...")
        print(f"  Timestamp: {signed_report['timestamp_info']['timestamp']}")
        
        # Show agent trace
        if result["agent_trace"]:
            trace = result["agent_trace"][-1]  # Get the last trace entry
            print(f"  Agent: {trace['agent']}")
            print(f"  Action: {trace['action']}")
    else:
        print("✗ Finalization failed!")
        if "errors" in result and result["errors"]:
            print(f"  Error: {result['errors'][-1]}")
    
    # Show state management
    print("\nState Management:")
    print("-" * 15)
    print("The finalization agent ensures proper state management by:")
    print("  - Clearing the task queue to prevent further processing")
    print("  - Preserving previous processing results")
    print("  - Maintaining a complete agent trace")
    print("  - Performing comprehensive state cleanup")
    
    # Show quality assurance
    print("\nQuality Assurance:")
    print("-" * 15)
    print("The finalization agent implements quality assurance by:")
    print("  - Validating report generation success")
    print("  - Confirming report signing completion")
    print("  - Performing final validation checks")
    print("  - Ensuring data integrity throughout the process")
    
    # Show error handling
    print("\nError Handling:")
    print("-" * 15)
    print("The finalization agent provides robust error handling by:")
    print("  - Capturing and logging detailed error information")
    print("  - Gracefully handling failures in any step")
    print("  - Maintaining workflow integrity even during failures")
    print("  - Providing clear error messages for troubleshooting")
    
    print("\nDemo completed successfully!")


if __name__ == "__main__":
    demo_finalization_agent()