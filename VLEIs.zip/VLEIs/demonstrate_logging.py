"""
Demonstration script for structured logging with loguru and request_id context
"""

import os
import sys
import uuid
from loguru import logger


def setup_logging():
    """Setup structured logging configuration"""
    # Remove default logger
    logger.remove()
    
    # Add stdout logging with structured format
    logger.add(
        sys.stdout,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
        level="INFO",
        enqueue=True
    )
    
    # Add file logging with rotation
    logger.add(
        "logs/demo_{time:YYYY-MM-DD}.log",
        rotation="1 day",
        retention="7 days",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
        level="DEBUG",
        enqueue=True
    )


def process_request(request_id: str, data: dict):
    """Simulate processing a request with structured logging"""
    logger.info(f"Request {request_id}: Starting to process request")
    logger.info(f"Request {request_id}: Data received: {data}")
    
    try:
        # Simulate some processing
        logger.debug(f"Request {request_id}: Performing data validation")
        
        if 'error' in data:
            raise ValueError(f"Invalid data provided: {data['error']}")
        
        # Simulate successful processing
        result = {"status": "success", "processed_items": len(data)}
        logger.info(f"Request {request_id}: Processing completed successfully")
        logger.info(f"Request {request_id}: Result: {result}")
        return result
        
    except Exception as e:
        logger.error(f"Request {request_id}: Processing failed with error: {str(e)}")
        raise


def main():
    """Main demonstration function"""
    setup_logging()
    
    print("Structured Logging with Loguru Demonstration")
    print("=" * 50)
    
    # Example 1: Successful request
    print("\n1. Processing successful request:")
    request_id_1 = uuid.uuid4().hex[:8]
    data_1 = {"name": "Test Company", "esg_score": 85, "year": 2023}
    
    try:
        result_1 = process_request(request_id_1, data_1)
        print(f"   Result: {result_1}")
    except Exception as e:
        print(f"   Error: {e}")
    
    # Example 2: Failed request
    print("\n2. Processing failed request:")
    request_id_2 = uuid.uuid4().hex[:8]
    data_2 = {"error": "invalid_format", "details": "Missing required fields"}
    
    try:
        result_2 = process_request(request_id_2, data_2)
        print(f"   Result: {result_2}")
    except Exception as e:
        print(f"   Error handled: {e}")
    
    # Example 3: Multiple requests for traceability
    print("\n3. Processing multiple requests for traceability:")
    for i in range(3):
        request_id = uuid.uuid4().hex[:8]
        data = {"item_id": f"item_{i}", "value": i * 10}
        logger.info(f"Request {request_id}: Processing batch item {i}")
        process_request(request_id, data)
    
    print("\n" + "=" * 50)
    print("Demonstration completed. Check the logs/ directory for log files.")


if __name__ == "__main__":
    main()