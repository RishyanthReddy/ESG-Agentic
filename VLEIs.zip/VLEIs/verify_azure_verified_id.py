"""
Simple verification script for Azure Verified ID Tool implementation
"""

from src.tools.verification import AzureVerifiedIDTool
from src.tools.registry import ToolRegistry
import inspect


def test_azure_verified_id_tool_implementation():
    """Test that the Azure Verified ID Tool is properly implemented"""
    print("Testing Azure Verified ID Tool implementation...")
    
    # Check that the class exists
    try:
        tool = AzureVerifiedIDTool()
        print("✓ AzureVerifiedIDTool class exists")
    except Exception as e:
        print(f"❌ Failed to create AzureVerifiedIDTool: {e}")
        return False
    
    # Check that it inherits from BaseTool
    from src.tools.registry import BaseTool
    if not isinstance(tool, BaseTool):
        print("❌ AzureVerifiedIDTool does not inherit from BaseTool")
        return False
    print("✓ AzureVerifiedIDTool inherits from BaseTool")
    
    # Check required attributes
    required_attrs = ['name', 'description']
    for attr in required_attrs:
        if not hasattr(tool, attr):
            print(f"❌ AzureVerifiedIDTool missing required attribute: {attr}")
            return False
    print("✓ AzureVerifiedIDTool has required attributes")
    
    # Check attribute values
    if tool.name != "azure_verified_id":
        print(f"❌ AzureVerifiedIDTool name is incorrect: {tool.name}")
        return False
    print("✓ AzureVerifiedIDTool name is correct")
    
    if "azure" not in tool.description.lower() or "verified" not in tool.description.lower():
        print(f"❌ AzureVerifiedIDTool description is not descriptive enough: {tool.description}")
        return False
    print("✓ AzureVerifiedIDTool description is appropriate")
    
    # Check required methods
    required_methods = [
        '_get_access_token',
        '_make_azure_api_call',
        'issue_credential',
        'verify_credential',
        'check_request_status',
        'run'
    ]
    
    for method_name in required_methods:
        if not hasattr(tool, method_name):
            print(f"❌ AzureVerifiedIDTool missing required method: {method_name}")
            return False
        
        # Check that method is callable
        method = getattr(tool, method_name)
        if not callable(method):
            print(f"❌ AzureVerifiedIDTool method {method_name} is not callable")
            return False
    
    print("✓ AzureVerifiedIDTool has all required methods")
    
    # Check method signatures
    run_method = getattr(tool, 'run')
    sig = inspect.signature(run_method)
    params = list(sig.parameters.keys())
    
    if 'action' not in params:
        print("❌ AzureVerifiedIDTool run method missing 'action' parameter")
        return False
    print("✓ AzureVerifiedIDTool run method has correct signature")
    
    # Test basic functionality
    try:
        result = tool.run("invalid_action")
        if not isinstance(result, dict):
            print("❌ AzureVerifiedIDTool run method does not return a dict")
            return False
        print("✓ AzureVerifiedIDTool run method returns dict")
    except Exception as e:
        print(f"❌ AzureVerifiedIDTool run method failed: {e}")
        return False
    
    print("\n🎉 Azure Verified ID Tool implementation tests passed!")
    return True


def test_tool_registration():
    """Test that the tool can be registered in the tool registry"""
    print("\nTesting tool registration...")
    
    try:
        # Create tool and registry instances
        tool = AzureVerifiedIDTool()
        registry = ToolRegistry()
        
        # Register the tool
        registry.register_tool(tool)
        print("✓ AzureVerifiedIDTool can be registered")
        
        # Retrieve the tool
        retrieved_tool = registry.get_tool("azure_verified_id")
        if retrieved_tool is None:
            print("❌ AzureVerifiedIDTool cannot be retrieved after registration")
            return False
        print("✓ AzureVerifiedIDTool can be retrieved after registration")
        
        # Check that it's the same tool
        if retrieved_tool is not tool:
            print("❌ Retrieved tool is not the same instance")
            return False
        print("✓ Retrieved tool is the correct instance")
        
    except Exception as e:
        print(f"❌ Tool registration failed: {e}")
        return False
    
    print("\n🎉 Tool registration tests passed!")
    return True


def test_azure_configuration():
    """Test that Azure configuration is properly handled"""
    print("\nTesting Azure configuration...")
    
    try:
        tool = AzureVerifiedIDTool()
        
        # Check that configuration attributes exist
        config_attrs = [
            'api_base_url',
            'tenant_id',
            'client_id',
            'client_secret',
            'scope',
            'authority',
            'hub_url'
        ]
        
        for attr in config_attrs:
            if not hasattr(tool, attr):
                print(f"❌ AzureVerifiedIDTool missing configuration attribute: {attr}")
                return False
        
        print("✓ AzureVerifiedIDTool has all configuration attributes")
        
        # Check that configuration values are set (may be None)
        print(f"  - API Base URL: {getattr(tool, 'api_base_url', 'NOT SET')}")
        print(f"  - Tenant ID: {'SET' if getattr(tool, 'tenant_id', None) else 'NOT SET'}")
        print(f"  - Client ID: {'SET' if getattr(tool, 'client_id', None) else 'NOT SET'}")
        
    except Exception as e:
        print(f"❌ Azure configuration test failed: {e}")
        return False
    
    print("\n🎉 Azure configuration tests passed!")
    return True


if __name__ == "__main__":
    implementation_ok = test_azure_verified_id_tool_implementation()
    registration_ok = test_tool_registration()
    configuration_ok = test_azure_configuration()
    
    if implementation_ok and registration_ok and configuration_ok:
        print("\n🎉 All Azure Verified ID Tool verification tests passed!")
        exit(0)
    else:
        print("\n❌ Azure Verified ID Tool verification failed!")
        exit(1)