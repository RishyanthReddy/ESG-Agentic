import asyncio
import sys
import os
import time
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import check_llm_health, check_blockchain_health, check_database_health

async def test_health_checks():
    print("Testing health checks directly...")
    
    # Test LLM health
    print("\nTesting LLM health...")
    start_time = time.time()
    llm_status = await check_llm_health()
    llm_time = time.time() - start_time
    print(f"LLM Status: {llm_status}")
    print(f"LLM Response time: {llm_time:.2f}s")
    
    # Test Blockchain health
    print("\nTesting Blockchain health...")
    start_time = time.time()
    blockchain_status = await check_blockchain_health()
    blockchain_time = time.time() - start_time
    print(f"Blockchain Status: {blockchain_status}")
    print(f"Blockchain Response time: {blockchain_time:.2f}s")
    
    # Test Database health
    print("\nTesting Database health...")
    start_time = time.time()
    database_status = await check_database_health()
    database_time = time.time() - start_time
    print(f"Database Status: {database_status}")
    print(f"Database Response time: {database_time:.2f}s")

if __name__ == "__main__":
    asyncio.run(test_health_checks())