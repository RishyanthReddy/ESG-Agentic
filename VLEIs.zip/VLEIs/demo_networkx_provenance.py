"""
Demo script for the NetworkX Provenance Tool.

This script demonstrates the NetworkX Provenance Tool that constructs formal graph 
data models of supply chain data flow.
"""

import json
from datetime import datetime, timedelta
from src.tools.visualization import NetworkXProvenanceTool


def main():
    """Demonstrate the NetworkX Provenance Tool functionality."""
    print("=== NetworkX Provenance Tool Demo ===\n")
    
    # Initialize the NetworkX Provenance Tool
    print("1. Initializing NetworkX Provenance Tool")
    tool = NetworkXProvenanceTool()
    print(f"   Tool name: {tool.name}")
    print(f"   Description: {tool.description}\n")
    
    # Create sample agent traces
    print("2. Creating sample agent traces")
    agent_traces = [
        {
            "agent_id": "credential_verification_agent",
            "agent_name": "Credential Verification Agent",
            "agent_role": "verification",
            "status": "completed",
            "timestamp": (datetime.utcnow() - timedelta(minutes=30)).isoformat(),
            "input_artifacts": [
                {
                    "id": "vlei_credential_001",
                    "name": "vLEI Credential for Supplier A",
                    "type": "credential",
                    "size": 2048,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=35)).isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "verification_report_001",
                    "name": "Verification Report for Supplier A",
                    "type": "report",
                    "size": 4096,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=25)).isoformat()
                }
            ],
            "supplier_info": {
                "id": "supplier_corp_A",
                "name": "Supplier Corporation A",
                "location": "New York, NY",
                "certifications": ["ISO 14001", "ISO 45001"],
                "timestamp": (datetime.utcnow() - timedelta(minutes=40)).isoformat()
            }
        },
        {
            "agent_id": "carbon_calculation_agent",
            "agent_name": "Carbon Calculation Agent",
            "agent_role": "calculation",
            "status": "completed",
            "timestamp": (datetime.utcnow() - timedelta(minutes=20)).isoformat(),
            "input_artifacts": [
                {
                    "id": "verification_report_001",
                    "name": "Verification Report for Supplier A",
                    "type": "report",
                    "size": 4096,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=25)).isoformat()
                },
                {
                    "id": "shipment_data_001",
                    "name": "Shipment Data for Order XYZ",
                    "type": "data",
                    "size": 1024,
                    "hash": "1a2b3c4d5e6f7890",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=22)).isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "carbon_footprint_report_001",
                    "name": "Carbon Footprint Report for Order XYZ",
                    "type": "report",
                    "size": 3072,
                    "hash": "0987f6e5d4c3b2a1",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=15)).isoformat()
                }
            ]
        },
        {
            "agent_id": "reporting_agent",
            "agent_name": "Reporting Agent",
            "agent_role": "reporting",
            "status": "completed",
            "timestamp": (datetime.utcnow() - timedelta(minutes=10)).isoformat(),
            "input_artifacts": [
                {
                    "id": "carbon_footprint_report_001",
                    "name": "Carbon Footprint Report for Order XYZ",
                    "type": "report",
                    "size": 3072,
                    "hash": "0987f6e5d4c3b2a1",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=15)).isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "esg_compliance_report_001",
                    "name": "ESG Compliance Report for Q1 2024",
                    "type": "report",
                    "size": 8192,
                    "hash": "abcd1234ef567890",
                    "timestamp": (datetime.utcnow() - timedelta(minutes=5)).isoformat()
                }
            ]
        }
    ]
    print("   Created 3 sample agent traces\n")
    
    # Create sample blockchain logs
    print("3. Creating sample blockchain logs")
    blockchain_logs = [
        {
            "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
            "data_hash": "a1b2c3d4e5f67890",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 1234567,
            "gas_used": 21000,
            "timestamp": (datetime.utcnow() - timedelta(minutes=34)).isoformat()
        },
        {
            "transaction_hash": "0x1a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f7890",
            "data_hash": "f6e5d4c3b2a10987",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 1234572,
            "gas_used": 25000,
            "timestamp": (datetime.utcnow() - timedelta(minutes=24)).isoformat()
        },
        {
            "transaction_hash": "0x9f8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e",
            "data_hash": "0987f6e5d4c3b2a1",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 1234580,
            "gas_used": 30000,
            "timestamp": (datetime.utcnow() - timedelta(minutes=14)).isoformat()
        }
    ]
    print("   Created 3 sample blockchain logs\n")
    
    # Display the data
    print("4. Sample data details:")
    print("   Agent traces:")
    print(json.dumps(agent_traces, indent=4))
    print("\n   Blockchain logs:")
    print(json.dumps(blockchain_logs, indent=4))
    print()
    
    # Execute the tool
    print("5. Executing NetworkX Provenance Tool")
    result = tool.run(agent_traces, blockchain_logs)
    print("   Tool execution completed\n")
    
    # Display the result
    print("6. Execution result:")
    print(f"   Success: {result['success']}")
    print(f"   Nodes created: {result['node_count']}")
    print(f"   Edges created: {result['edge_count']}")
    print()
    
    if result['success']:
        # Display validation results
        print("7. Graph validation:")
        validation = result['validation']
        print(f"   Valid: {validation['is_valid']}")
        print(f"   Errors: {len(validation['errors'])}")
        print(f"   Warnings: {len(validation['warnings'])}")
        print(f"   Node types: {validation['node_types']}")
        print()
        
        # Show serialized graph
        print("8. Serialized graph (JSON, first 500 characters):")
        print(result['graph_json'][:500] + "...\n")
        
        # Show graph details
        graph = result['graph']
        print("9. Graph details:")
        print(f"   Graph name: {graph.graph.get('name', 'N/A')}")
        print(f"   Created at: {graph.graph.get('created_at', 'N/A')}")
        
        print("\n   Nodes:")
        for node_id, node_data in list(graph.nodes(data=True))[:5]:  # Show first 5 nodes
            print(f"     {node_id}: {node_data.get('type', 'N/A')} - {node_data.get('name', 'N/A')}")
        
        print("\n   Edges (first 5):")
        for edge in list(graph.edges(data=True))[:5]:  # Show first 5 edges
            source, target, data = edge
            print(f"     {source} -> {target} ({data.get('relationship', 'N/A')})")
        
        print(f"\n   ... and {graph.number_of_edges() - 5} more edges" if graph.number_of_edges() > 5 else "")
    
    print("\n10. Demo completed")
    print("\nNote: This tool constructs formal graph data models of supply chain data flow")
    print("     using NetworkX library. The graph represents the complete provenance of")
    print("     data and processes in the supply chain with suppliers, agents, and")
    print("     artifacts as nodes.")


if __name__ == "__main__":
    main()