"""
Demo script for the CarbonSutra API Tool
"""

import sys
import os
from dotenv import load_dotenv

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Load environment variables from .env file
load_dotenv()

from src.tools.esg import CarbonSutraTool, Scope3DataPoint
from src.tools.registry import ToolRegistry


def demo_environment_setup():
    """Demonstrate that the CARBONSUTRA credentials are properly loaded from the environment"""
    print("Environment Setup Demo")
    print("=" * 50)
    
    # Show that the CARBONSUTRA_API_KEY is available
    carbonsutra_api_key = os.getenv("CARBONSUTRA_API_KEY")
    carbonsutra_auth_token = os.getenv("CARBONSUTRA_AUTH_TOKEN")
    
    if carbonsutra_api_key:
        # Mask the key for security (show only first 5 and last 5 characters)
        masked_key = carbonsutra_api_key[:5] + "..." + carbonsutra_api_key[-5:]
        print(f"CARBONSUTRA_API_KEY found in environment: {masked_key}")
    else:
        print("WARNING: CARBONSUTRA_API_KEY not found in environment!")
        return False
    
    if carbonsutra_auth_token:
        # Mask the token for security (show only first 10 and last 5 characters)
        masked_token = carbonsutra_auth_token[:10] + "..." + carbonsutra_auth_token[-5:]
        print(f"CARBONSUTRA_AUTH_TOKEN found in environment: {masked_token}")
    else:
        print("WARNING: CARBONSUTRA_AUTH_TOKEN not found in environment!")
        return False
    
    print()
    return True


def demo_tool_initialization():
    """Demonstrate initializing the CarbonSutraTool"""
    print("Tool Initialization Demo")
    print("=" * 50)
    
    try:
        # Initialize the tool - it will automatically use the CARBONSUTRA credentials from environment
        tool = CarbonSutraTool()
        
        print("CarbonSutraTool successfully initialized!")
        print(f"API endpoint: {tool.base_url}")
        
        # Register the tool
        registry = ToolRegistry()
        registry.register_tool(tool)
        print("Tool registered successfully!")
        
        return tool
        
    except Exception as e:
        print(f"ERROR: Failed to initialize tool: {e}")
        return None


def demo_scope3_data_preparation():
    """Demonstrate Scope 3 data preparation"""
    print("\nScope 3 Data Preparation Demo")
    print("=" * 50)
    
    # Sample Scope 3 data points
    scope3_data_points = [
        Scope3DataPoint(
            timestamp="2023-01-01T00:00:00Z",
            value=1200.5,
            metric_type="co2e",
            supplier_id="supplier_001",
            confidence_score=0.92
        ),
        Scope3DataPoint(
            timestamp="2023-02-01T00:00:00Z",
            value=1150.2,
            metric_type="co2e",
            supplier_id="supplier_001",
            confidence_score=0.89
        ),
        Scope3DataPoint(
            timestamp="2023-03-01T00:00:00Z",
            value=1300.8,
            metric_type="co2e",
            supplier_id="supplier_001",
            confidence_score=0.95
        ),
        Scope3DataPoint(
            timestamp="2023-01-01T00:00:00Z",
            value=800.3,
            metric_type="co2e",
            supplier_id="supplier_002",
            confidence_score=0.87
        ),
        Scope3DataPoint(
            timestamp="2023-02-01T00:00:00Z",
            value=750.1,
            metric_type="co2e",
            supplier_id="supplier_002",
            confidence_score=0.85
        )
    ]
    
    print(f"Prepared {len(scope3_data_points)} Scope 3 data points:")
    for i, point in enumerate(scope3_data_points, 1):
        print(f"  {i}. {point.timestamp}: {point.value} {point.metric_type} "
              f"(Supplier: {point.supplier_id}, Confidence: {point.confidence_score})")
    
    print()
    return scope3_data_points


def demo_pathway_analysis():
    """Demonstrate decarbonization pathway analysis"""
    print("Decarbonization Pathway Analysis Demo")
    print("=" * 50)
    
    # Mock pathway data that would come from the API
    mock_pathways_data = {
        "scenarios": ["Baseline", "Conservative", "Moderate", "Aggressive", "Net Zero"],
        "best_pathway": "Aggressive",
        "reduction_potential": 45.2,
        "timeline_analysis": {
            "2025": 10.5,
            "2030": 25.8,
            "2035": 35.0,
            "2040": 42.7,
            "2050": 45.2
        },
        "confidence_score": 0.88
    }
    
    # Initialize tool to access analysis methods
    try:
        tool = CarbonSutraTool()
        
        # Perform pathway analysis
        analyzed_data = tool._analyze_pathways(mock_pathways_data)
        
        print("Pathway Analysis Results:")
        print(f"  Total scenarios evaluated: {analyzed_data['total_scenarios']}")
        print(f"  Recommended pathway: {analyzed_data['best_pathway']}")
        print(f"  Maximum reduction potential: {analyzed_data['reduction_potential']}%")
        print(f"  Analysis confidence: {analyzed_data['confidence_score']}")
        print("\n  Timeline projections:")
        for year, reduction in analyzed_data['timeline_analysis'].items():
            print(f"    {year}: {reduction}% reduction")
        
    except Exception as e:
        print(f"ERROR: Failed to perform pathway analysis: {e}")
    
    print()


def demo_visualization_generation():
    """Demonstrate visualization data generation"""
    print("Visualization Data Generation Demo")
    print("=" * 50)
    
    # Mock analysis data
    mock_analysis_data = {
        "current_emissions": [1200, 1150, 1300, 1250, 1180],
        "projected_emissions": [1100, 1050, 1150, 1100, 1020],
        "target_emissions": [900, 850, 950, 900, 820],
        "scenario_comparison": ["Current", "Projected", "Target"],
        "key_metrics": {
            "baseline_emissions": 1200,
            "projected_reduction": 180,
            "target_reduction": 380,
            "cost_savings": 125000,
            "roi_years": 2.8
        }
    }
    
    # Initialize tool to access visualization methods
    try:
        tool = CarbonSutraTool()
        
        # Generate visualization data
        visualization_data = tool._generate_visualizations(mock_analysis_data)
        
        print("Visualization Data Generated:")
        print(f"  Chart data points: {len(visualization_data['chart_data']['current_emissions'])}")
        print(f"  Scenario comparisons: {len(visualization_data['scenario_comparison'])}")
        print(f"  Key metrics available: {len(visualization_data['key_metrics'])}")
        
        print("\n  Key Business Metrics:")
        key_metrics = visualization_data['key_metrics']
        print(f"    Baseline emissions: {key_metrics.get('baseline_emissions', 'N/A')} tons CO2e")
        print(f"    Projected reduction: {key_metrics.get('projected_reduction', 'N/A')} tons CO2e")
        print(f"    Target reduction: {key_metrics.get('target_reduction', 'N/A')} tons CO2e")
        print(f"    Cost savings: ${key_metrics.get('cost_savings', 'N/A'):,}")
        print(f"    ROI: {key_metrics.get('roi_years', 'N/A')} years")
        
    except Exception as e:
        print(f"ERROR: Failed to generate visualization data: {e}")
    
    print()


def demo_caching_mechanism():
    """Demonstrate caching mechanism"""
    print("Caching Mechanism Demo")
    print("=" * 50)
    
    try:
        tool = CarbonSutraTool()
        
        # Sample Scope 3 data
        scope3_data = [
            {
                "timestamp": "2023-01-01T00:00:00Z",
                "value": 1000.0,
                "metric_type": "co2e",
                "supplier_id": "supplier_1"
            },
            {
                "timestamp": "2023-02-01T00:00:00Z",
                "value": 950.0,
                "metric_type": "co2e",
                "supplier_id": "supplier_1"
            }
        ]
        
        # Generate cache key
        cache_key = tool._get_cache_key(scope3_data)
        print(f"Cache key generated: {cache_key[:20]}...")
        
        # Try to get cached result (should be None initially)
        cached_result = tool._get_cached_result(scope3_data)
        print(f"Initial cache check: {'HIT' if cached_result else 'MISS'}")
        
        # Store a mock result
        mock_result = {
            "success": True,
            "analysis": {"reduction_potential": 25.0},
            "visualizations": {"chart_data": {}}
        }
        tool._cache_result(scope3_data, mock_result)
        print("Stored mock result in cache")
        
        # Try to get cached result again (should be found now)
        cached_result = tool._get_cached_result(scope3_data)
        print(f"Second cache check: {'HIT' if cached_result else 'MISS'}")
        
        if cached_result:
            print(f"Cached data reduction potential: {cached_result['analysis']['reduction_potential']}%")
        
    except Exception as e:
        print(f"ERROR: Failed to demonstrate caching: {e}")
    
    print()


def main():
    """Main demo function"""
    print("CarbonSutra API Tool Demo")
    print("=" * 60)
    print("This demo shows the features of the CarbonSutra API Tool for")
    print("advanced visualizations and actionable decarbonization insights.\n")
    
    # Demo environment setup
    if not demo_environment_setup():
        print("Demo cannot proceed without CARBONSUTRA credentials")
        return
    
    # Demo tool initialization
    tool = demo_tool_initialization()
    if not tool:
        print("Demo cannot proceed without tool initialization")
        return
    
    # Demo data preparation
    demo_scope3_data_preparation()
    
    # Demo pathway analysis
    demo_pathway_analysis()
    
    # Demo visualization generation
    demo_visualization_generation()
    
    # Demo caching mechanism
    demo_caching_mechanism()
    
    print("=" * 60)
    print("Demo completed successfully!")
    print("The CarbonSutra API Tool includes:")
    print("- API Integration: httpx==0.25.2 for CarbonSutra API communication")
    print("- Data Analysis: Advanced carbon pathway analysis algorithms")
    print("- Visualization: matplotlib==3.8.2, plotly==5.17.0 for decarbonization charts")
    print("- Scenario Modeling: Custom scenario generation and analysis")
    print("- Caching Strategy: Redis caching for pathway calculations")


if __name__ == "__main__":
    main()