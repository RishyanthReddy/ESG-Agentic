"""
Main entry point for the ESG Intelligence Platform
"""
from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Request, Response
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
import uvicorn
import os
import asyncio
import time
from typing import Dict, Any, Optional, List
import json
import sys
from datetime import datetime
from pydantic import BaseModel
import pandas as pd
import io

# Configure loguru for structured logging
logger.remove()  # Remove default handler

# Rate limiting
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

# Load environment variables
from dotenv import load_dotenv
from config import settings

# LLM Client
from src.llm.client import GeminiClient, LLMError

# Web3 for blockchain connectivity
from web3 import Web3

# Import graph and state
from src.graph.builder import graph
from src.state.models import AppState
from src.state.storage import report_storage
from src.tools.ingestion import FileUploadTool
from src.agents.ingestion import ingestion_agent

# Add dashboard routes
from src.api.dashboard.routes import router as dashboard_router

# Add the WebSocket router
from src.websockets import websocket_router
app.include_router(websocket_router, prefix="/api/v1", tags=["websockets"])

load_dotenv()

# Create rate limiter
limiter = Limiter(key_func=get_remote_address)

# Create FastAPI app
app = FastAPI(
    title="ESG Intelligence Platform",
    description="A platform for ESG verification and intelligence",
    version="0.1.0"
)

# Add dashboard router
app.include_router(dashboard_router)

# Add WebSocket router
from src.websockets import websocket_router
app.include_router(websocket_router, prefix="/api/v1", tags=["websockets"])

# Add rate limiting exception handler
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
class IngestRequest(BaseModel):
    """Request model for JSON data ingestion"""
    supplier_data: Dict[str, Any] = {}
    config: Optional[Dict[str, Any]] = None

class IngestResponse(BaseModel):
    """Response model for ingestion endpoints"""
    status: str
    message: str
    final_state: Dict[str, Any]

class VerificationResponse(BaseModel):
    """Response model for verification endpoint"""
    report_id: str
    report_data: Optional[Dict[str, Any]]
    vc_jwt: Optional[str]
    blockchain_hashes: List[str]
    verification_status: str
    message: str

@app.get("/")
async def root():
    """
    Root endpoint that returns a welcome message
    """
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Serving root endpoint")
    return {"message": "Welcome to the ESG Intelligence Platform"}

@app.get("/health")
async def health_check():
    """
    Health check endpoint that verifies the status of critical components:
    - LLM API connectivity
    - Blockchain node connection (via Infura)
    - Database availability
    
    Returns:
        JSON response with health status of all components
    """
    start_time = time.time()
    
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Health check initiated")
    
    # Initialize health status
    health_status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "components": {}
    }
    
    # Check LLM API connectivity
    try:
        llm_client = GeminiClient()
        # Test LLM connectivity with a simple prompt
        test_prompt = "Return the word 'OK' and nothing else."
        # Using asyncio.wait_for to implement timeout
        response = await asyncio.wait_for(llm_client.chat_completion(test_prompt), timeout=5.0)
        health_status["components"]["llm"] = {
            "status": "healthy",
            "response_time": round(time.time() - start_time, 3),
            "details": response[:50] + "..." if len(response) > 50 else response
        }
        logger.info(f"Request {request_id}: LLM API connectivity check passed")
    except asyncio.TimeoutError:
        health_status["status"] = "degraded"
        health_status["components"]["llm"] = {
            "status": "timeout",
            "error": "LLM API response timeout (5s)"
        }
        logger.warning(f"Request {request_id}: LLM API timeout during health check")
    except Exception as e:
        health_status["status"] = "degraded"
        health_status["components"]["llm"] = {
            "status": "unhealthy",
            "error": str(e)
        }
        logger.error(f"Request {request_id}: LLM API connectivity check failed: {str(e)}")
    
    # Check Blockchain connectivity (Infura)
    try:
        # Get Infura API key from settings
        infura_api_key = settings.INFURA_API_KEY
        if not infura_api_key:
            raise ValueError("INFURA_API_KEY not found in environment variables")
        
        # Configure Sepolia testnet endpoint (as used in InfuraBlockchainTool)
        infura_url = f"https://sepolia.infura.io/v3/{infura_api_key}"
        
        # Initialize Web3 connection
        w3 = Web3(Web3.HTTPProvider(infura_url))
        
        # Check connection
        if not w3.is_connected():
            raise ConnectionError("Failed to connect to Infura endpoint")
        
        # Get network info
        chain_id = w3.eth.chain_id
        latest_block = w3.eth.get_block('latest')
        
        health_status["components"]["blockchain"] = {
            "status": "healthy",
            "response_time": round(time.time() - start_time, 3),
            "details": {
                "network": "Sepolia Testnet",
                "chain_id": chain_id,
                "latest_block": latest_block['number']
            }
        }
        logger.info(f"Request {request_id}: Blockchain connectivity check passed")
    except Exception as e:
        health_status["status"] = "degraded"
        health_status["components"]["blockchain"] = {
            "status": "unhealthy",
            "error": str(e)
        }
        logger.error(f"Request {request_id}: Blockchain connectivity check failed: {str(e)}")
    
    # Overall status check
    component_statuses = [component["status"] for component in health_status["components"].values()]
    if "unhealthy" in component_statuses:
        health_status["status"] = "unhealthy"
    elif "timeout" in component_statuses or "degraded" in component_statuses:
        health_status["status"] = "degraded"
    
    logger.info(f"Request {request_id}: Health check completed with status: {health_status['status']}")
    return health_status

@app.get("/verify/{report_id}")
@limiter.limit("5/minute")
async def verify_report(request: Request, report_id: str) -> VerificationResponse:
    """
    Public endpoint to verify the authenticity of a report by its ID.
    
    This endpoint fetches the report's associated cryptographic proofs (VC JWT, blockchain hashes)
    from storage and returns them for third-party verification.
    
    Args:
        request (Request): The incoming request (used for rate limiting)
        report_id (str): The ID of the report to verify
        
    Returns:
        VerificationResponse: The report data and associated cryptographic proofs
        
    Raises:
        HTTPException: If the report is not found or verification fails
    """
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Verification request for report {report_id}")
    
    try:
        # Fetch report data from storage
        report_data = report_storage.get_report(report_id)
        if not report_data:
            logger.warning(f"Request {request_id}: Report {report_id} not found")
            raise HTTPException(
                status_code=404,
                detail=f"Report with ID {report_id} not found"
            )
        
        # Fetch cryptographic proofs from storage
        proofs = report_storage.get_proofs(report_id)
        if not proofs:
            logger.warning(f"Request {request_id}: Proofs for report {report_id} not found")
            raise HTTPException(
                status_code=404,
                detail=f"Cryptographic proofs for report {report_id} not found"
            )
        
        # Extract proof components
        vc_jwt = proofs.get("vc_jwt")
        blockchain_hashes = proofs.get("blockchain_hashes", [])
        
        logger.info(f"Request {request_id}: Successfully retrieved report {report_id} and proofs")
        
        return VerificationResponse(
            report_id=report_id,
            report_data=report_data,
            vc_jwt=vc_jwt,
            blockchain_hashes=blockchain_hashes,
            verification_status="success",
            message=f"Report {report_id} and associated cryptographic proofs retrieved successfully"
        )
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"Request {request_id}: Error during verification of report {report_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error during verification: {str(e)}"
        )

@app.post("/ingest/json", response_model=IngestResponse)
async def ingest_json_data(
    data: IngestRequest
):
    """
    Ingest JSON data and run the LangGraph workflow.
    
    Args:
        data: JSON data containing supplier information and optional configuration
        
    Returns:
        Final AppState after workflow execution
    """
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Starting JSON data ingestion")
    
    try:
        # Create initial AppState with task_queue initialized by ingestion agent
        initial_state = AppState(
            workflow_data={"supplier_data": data.supplier_data},
            config=data.config or {}
        )
        
        # Run the ingestion agent to process the data and populate the task queue
        ingestion_result = ingestion_agent(initial_state)
        
        # Create a new state with the updated values from the ingestion agent
        updated_state = initial_state.copy(update=ingestion_result)
        
        logger.info(f"Request {request_id}: Initial state created, running workflow")
        
        # Run the LangGraph workflow
        final_state_dict = graph.invoke(updated_state)
        
        # Convert AddableValuesDict to AppState if needed
        if hasattr(final_state_dict, 'dict'):
            # It's already an AppState
            final_app_state = final_state_dict
            final_state_dict = final_state_dict.dict()
        else:
            # It's an AddableValuesDict, merge with initial state
            initial_state_dict = updated_state.dict()
            # Merge the dictionaries
            merged_dict = {**initial_state_dict, **final_state_dict}
            final_state_dict = merged_dict
            final_app_state = AppState(**merged_dict)
        
        # Store reports and proofs for later verification
        stored_report_ids = report_storage.store_report_and_proofs(final_app_state)
        logger.info(f"Request {request_id}: Stored reports with IDs: {stored_report_ids}")
        
        logger.info(f"Request {request_id}: Workflow completed successfully")
        
        return IngestResponse(
            status="success",
            message="Data processed successfully",
            final_state=final_state_dict
        )
        
    except Exception as e:
        logger.error(f"Request {request_id}: Error during JSON data ingestion: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing data: {str(e)}")

@app.post("/ingest/file", response_model=IngestResponse)
async def ingest_file_upload(
    file: UploadFile = File(...),
    config: Optional[str] = Form(None)
):
    """
    Ingest file upload and run the LangGraph workflow.
    
    Args:
        file: Uploaded file (CSV/Excel)
        config: Optional configuration as JSON string
        
    Returns:
        Final AppState after workflow execution
    """
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Starting file upload ingestion")
    
    try:
        # Parse config if provided
        config_dict = {}
        if config:
            try:
                config_dict = json.loads(config)
            except json.JSONDecodeError:
                logger.warning(f"Request {request_id}: Invalid config JSON provided")
                config_dict = {}
        
        # Read file content
        file_content = await file.read()
        logger.info(f"Request {request_id}: File {file.filename} read successfully ({len(file_content)} bytes)")
        
        # Process file using FileUploadTool
        file_tool = FileUploadTool()
        supplier_data = file_tool.run(file_content, file.filename)
        logger.info(f"Request {request_id}: File processed into supplier_data format")
        
        # Create initial AppState with task_queue initialized by ingestion agent
        initial_state = AppState(
            workflow_data={
                "supplier_data": supplier_data,
                "file_upload_data": {
                    "content": file_content,
                    "name": file.filename
                }
            },
            config=config_dict
        )
        
        # Run the ingestion agent to process the data and populate the task queue
        ingestion_result = ingestion_agent(initial_state)
        
        # Create a new state with the updated values from the ingestion agent
        updated_state = initial_state.copy(update=ingestion_result)
        
        logger.info(f"Request {request_id}: Initial state created, running workflow")
        
        # Run the LangGraph workflow
        final_state = graph.invoke(updated_state)
        
        # Store reports and proofs for later verification
        stored_report_ids = report_storage.store_report_and_proofs(final_state)
        logger.info(f"Request {request_id}: Stored reports with IDs: {stored_report_ids}")
        
        logger.info(f"Request {request_id}: Workflow completed successfully")
        
        # Convert to dict for JSON serialization
        final_state_dict = final_state.dict()
        
        return IngestResponse(
            status="success",
            message="File processed successfully",
            final_state=final_state_dict
        )
        
    except Exception as e:
        logger.error(f"Request {request_id}: Error during file upload ingestion: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

if __name__ == "__main__":
    request_id = os.urandom(8).hex()
    logger.info(f"Request {request_id}: Starting ESG Intelligence Platform")
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=os.getenv("NODE_ENV") == "development"
    )