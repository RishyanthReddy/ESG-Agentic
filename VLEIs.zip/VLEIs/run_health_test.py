import asyncio
import aiohttp
import time
from main import app
import uvicorn
import threading
import requests
import time

def start_server():
    """Start the FastAPI server in a separate thread"""
    uvicorn.run(app, host="127.0.0.1", port=8001, log_level="error")

def test_health_endpoint():
    """Test the health endpoint"""
    # Give the server a moment to start
    time.sleep(2)
    
    try:
        response = requests.get("http://127.0.0.1:8001/health")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        return response.json()
    except Exception as e:
        print(f"Error testing health endpoint: {e}")
        return None

if __name__ == "__main__":
    # Start server in a separate thread
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    
    # Wait for server to start and test
    result = test_health_endpoint()
    
    if result:
        print("\nHealth check successful!")
        print(f"Overall status: {result['status']}")
        for check_name, check_result in result['checks'].items():
            print(f"{check_name}: {check_result['status']}")
    else:
        print("\nHealth check failed!")