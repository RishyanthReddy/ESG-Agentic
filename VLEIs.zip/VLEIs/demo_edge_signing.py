"""
Demo script for the Edge Signing Tool.

This script demonstrates the complete workflow of signing and verifying data files.
"""

import os
import tempfile
import json
from pathlib import Path
from scripts.sign_data import EdgeSigningTool


def main():
    """Demonstrate the Edge Signing Tool functionality."""
    print("=== Edge Signing Tool Demo ===\n")
    
    # Create a temporary directory for our demo files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Create a sample data file
        data_file = temp_path / "supplier_data.csv"
        data_file.write_text(
            "company_name,year,scope1_emissions,scope2_emissions,energy_consumption\n"
            "Global Manufacturing Inc,2023,1200,800,5000\n"
            "Green Solutions Ltd,2023,450,300,2100\n"
            "EcoTech Industries,2023,680,420,3200\n"
        )
        print(f"1. Created sample data file: {data_file}")
        print(f"   Content:\n{data_file.read_text()}")
        
        # Initialize the signing tool
        tool = EdgeSigningTool()
        print("2. Initialized Edge Signing Tool")
        
        # Generate keys
        tool.generate_keys()
        print("3. Generated RSA key pair")
        
        # Save keys
        private_key_path = temp_path / "private.key"
        public_key_path = temp_path / "public.pub"
        tool.save_keys(str(private_key_path), str(public_key_path))
        print(f"4. Saved private key to: {private_key_path}")
        print(f"   Saved public key to: {public_key_path}")
        
        # Sign the file
        print(f"5. Signing file: {data_file}")
        metadata = tool.sign_file(str(data_file), str(private_key_path))
        print("   File signed successfully")
        print(f"   File hash: {metadata['file_hash']}")
        print(f"   Signature algorithm: {metadata['signature_algorithm']}")
        print(f"   Signature length: {len(metadata['signature'])} characters")
        
        # Embed signature in file
        sig_file_path = tool.embed_signature_in_file(str(data_file), metadata)
        print(f"6. Signature metadata saved to: {sig_file_path}")
        
        # Display signature metadata
        print("   Signature metadata:")
        print(json.dumps(metadata, indent=2))
        
        # Verify the signature
        print(f"7. Verifying signature for: {data_file}")
        is_valid = tool.verify_signature(str(data_file), metadata, str(public_key_path))
        if is_valid:
            print("   ✅ Signature verification PASSED")
        else:
            print("   ❌ Signature verification FAILED")
        
        # Demonstrate tamper detection
        print("8. Testing tamper detection:")
        # Modify the original file
        with open(data_file, "a") as f:
            f.write("\nTampered Data,2023,100,100,100")
        print("   Tampered with original file")
        
        # Try to verify again
        is_valid = tool.verify_signature(str(data_file), metadata, str(public_key_path))
        if is_valid:
            print("   ❌ Tamper detection FAILED - signature still valid")
        else:
            print("   ✅ Tamper detection PASSED - signature correctly invalidated")
        
        # Clean up
        print("\n9. Demo completed. Temporary files will be automatically cleaned up.")


if __name__ == "__main__":
    main()