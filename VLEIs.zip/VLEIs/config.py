"""
Configuration module for the ESG Intelligence Platform
"""
import os
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Azure settings
    AZURE_TENANT_ID: Optional[str] = None
    AZURE_CLIENT_ID: Optional[str] = None
    AZURE_CLIENT_SECRET: Optional[str] = None
    
    # Verified ID settings
    AZURE_VERIFIED_ID_DID: Optional[str] = None
    AZURE_VERIFIED_ID_ENDPOINT: Optional[str] = None
    AZURE_VERIFIED_ID_SCOPE: Optional[str] = None
    AZURE_VERIFIED_ID_AUTHORITY: Optional[str] = None
    AZURE_VERIFIED_ID_HUB: Optional[str] = None
    
    # Callback settings
    AZURE_VERIFIED_ID_CALLBACK_URL: Optional[str] = None
    AZURE_VERIFIED_ID_CALLBACK_STATE: Optional[str] = None
    
    # Key Vault
    AZURE_KEY_VAULT_URL: Optional[str] = None
    
    # ESG Project specific
    ESG_CREDENTIAL_TYPE: Optional[str] = None
    ESG_ISSUER_NAME: Optional[str] = None
    
    # API Keys
    CLIMATIQ_API_KEY: Optional[str] = None
    INFURA_API_KEY: Optional[str] = None
    CARBONSUTRA_API_KEY: Optional[str] = None
    CARBONSUTRA_AUTH_TOKEN: Optional[str] = None
    GLAMA_API_KEY: Optional[str] = None
    
    # Redis settings for caching
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    
    # Development settings
    NODE_ENV: str = "development"
    DEBUG: bool = True
    PORT: int = 8000
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Create a settings instance
settings = Settings()