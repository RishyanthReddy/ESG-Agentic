"""
Debug script to test the LangGraph workflow execution
"""

from src.state.models import AppState
from src.graph.builder import graph

def test_simple_workflow():
    """Test a simple workflow execution"""
    # Create a minimal initial state
    initial_state = AppState()
    print("Initial state created successfully")
    print(f"Initial state type: {type(initial_state)}")
    print(f"Initial state task_queue: {initial_state.task_queue}")
    
    # Run the workflow
    try:
        final_state_dict = graph.invoke(initial_state)
        print("Workflow executed successfully")
        print(f"Final state type: {type(final_state_dict)}")
        
        # Try to handle the AddableValuesDict properly
        if hasattr(final_state_dict, 'dict'):
            # It's already an AppState
            final_app_state = final_state_dict
            final_state_dict = final_state_dict.dict()
        else:
            # It's an AddableValuesDict, merge with initial state
            initial_state_dict = initial_state.dict()
            # Merge the dictionaries
            merged_dict = {**initial_state_dict, **final_state_dict}
            final_state_dict = merged_dict
            final_app_state = AppState(**merged_dict)
            
        print(f"Final app state type: {type(final_app_state)}")
        print(f"Final app state task_queue: {final_app_state.task_queue}")
        return True
    except Exception as e:
        print(f"Error during workflow execution: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_simple_workflow()