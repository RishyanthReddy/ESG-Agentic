# Edge Signing Tool

This directory contains the implementation of the Edge Signing Tool as specified in Task 35 of the project plan.

## Overview

The Edge Signing Tool provides cryptographic signing capabilities for offline data files before ingestion. This ensures data provenance starts at the source by creating a digital signature that can be verified later in the processing pipeline.

## Features

- File hashing using SHA-256
- RSA-PSS digital signatures
- Key generation and management
- Signature embedding and verification
- Support for CSV and Excel files
- Tamper detection capabilities

## Components

### sign_data.py

A standalone script that provides command-line interface for:

1. Generating RSA key pairs
2. Signing data files
3. Verifying file signatures

### FileUploadTool Enhancement

The [src/tools/ingestion.py](file:///c%3A/Users/gadea/OneDrive/Desktop/VLEIs/src/tools/ingestion.py) file has been updated to include signature verification capabilities in the file upload process.

## Usage

### Command Line Interface

```bash
# Generate RSA key pair
python scripts/sign_data.py generate-keys private.key public.pub

# Sign a file
python scripts/sign_data.py sign data.csv private.key

# Verify a file signature
python scripts/sign_data.py verify data.csv data.csv.sig public.pub
```

### Programmatic Usage

```python
from scripts.sign_data import EdgeSigningTool

# Initialize the tool
tool = EdgeSigningTool()

# Generate keys
tool.generate_keys()

# Save keys to files
tool.save_keys("private.key", "public.key")

# Sign a file
metadata = tool.sign_file("data.csv", "private.key")

# Verify a file
is_valid = tool.verify_signature("data.csv", metadata, "public.key")
```

## Security

- Uses RSA-2048 keys with PSS padding
- SHA-256 hashing algorithm
- Secure key storage
- Tamper detection

## Testing

Unit tests and integration tests are available in the [tests/](file:///C%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests) directory:

- [tests/test_edge_signing.py](file:///C%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_edge_signing.py) - Unit tests
- [tests/test_edge_signing_integration.py](file:///C%3A/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_edge_signing_integration.py) - Integration tests

Run tests with:
```bash
python -m pytest tests/test_edge_signing.py -v
python -m pytest tests/test_edge_signing_integration.py -v
```