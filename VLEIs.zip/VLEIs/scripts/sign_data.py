#!/usr/bin/env python3
"""
Standalone script for cryptographically signing offline data files.

This script hashes file contents, signs with a private key, embeds the signature
in metadata, and can verify signed files. Part of the Edge Signing Tool implementation.
"""

import hashlib
import json
import os
import sys
from typing import Dict, Any, Optional
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend


class EdgeSigningTool:
    """Tool for signing and verifying data files at the edge."""
    
    def __init__(self, key_size: int = 2048):
        """
        Initialize the Edge Signing Tool.
        
        Args:
            key_size: Size of the RSA key in bits (default: 2048)
        """
        self.key_size = key_size
        self.private_key = None
        self.public_key = None
    
    def generate_keys(self) -> None:
        """Generate a new RSA key pair."""
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=self.key_size,
            backend=default_backend()
        )
        self.public_key = self.private_key.public_key()
    
    def save_keys(self, private_key_path: str, public_key_path: str) -> None:
        """
        Save the key pair to files.
        
        Args:
            private_key_path: Path to save the private key
            public_key_path: Path to save the public key
        """
        if not self.private_key or not self.public_key:
            raise ValueError("Keys not generated. Call generate_keys() first.")
        
        # Save private key
        private_pem = self.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        with open(private_key_path, 'wb') as f:
            f.write(private_pem)
        
        # Save public key
        public_pem = self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        with open(public_key_path, 'wb') as f:
            f.write(public_pem)
    
    def load_keys(self, private_key_path: str = None, public_key_path: str = None) -> None:
        """
        Load keys from files.
        
        Args:
            private_key_path: Path to the private key file
            public_key_path: Path to the public key file
        """
        if private_key_path and os.path.exists(private_key_path):
            with open(private_key_path, 'rb') as f:
                self.private_key = serialization.load_pem_private_key(
                    f.read(),
                    password=None,
                    backend=default_backend()
                )
        
        if public_key_path and os.path.exists(public_key_path):
            with open(public_key_path, 'rb') as f:
                self.public_key = serialization.load_pem_public_key(
                    f.read(),
                    backend=default_backend()
                )
    
    def hash_file(self, file_path: str) -> str:
        """
        Create SHA-256 hash of a file.
        
        Args:
            file_path: Path to the file to hash
            
        Returns:
            Hex digest of the file hash
        """
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            # Read and update hash in chunks of 4K
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def sign_file(self, file_path: str, private_key_path: str = None) -> Dict[str, Any]:
        """
        Sign a file with a private key.
        
        Args:
            file_path: Path to the file to sign
            private_key_path: Path to the private key file (optional if already loaded)
            
        Returns:
            Dictionary containing signature metadata
        """
        if private_key_path:
            self.load_keys(private_key_path=private_key_path)
        
        if not self.private_key:
            raise ValueError("Private key not loaded. Provide private_key_path or load keys first.")
        
        # Hash the file
        file_hash = self.hash_file(file_path)
        
        # Sign the hash
        signature = self.private_key.sign(
            file_hash.encode('utf-8'),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        # Create metadata
        metadata = {
            "file_path": file_path,
            "file_hash": file_hash,
            "signature": signature.hex(),
            "signature_algorithm": "RSA-PSS-SHA256"
        }
        
        return metadata
    
    def verify_signature(self, file_path: str, metadata: Dict[str, Any], 
                        public_key_path: str = None) -> bool:
        """
        Verify the signature of a file.
        
        Args:
            file_path: Path to the file to verify
            metadata: Metadata containing the signature
            public_key_path: Path to the public key file (optional if already loaded)
            
        Returns:
            True if signature is valid, False otherwise
        """
        if public_key_path:
            self.load_keys(public_key_path=public_key_path)
        
        if not self.public_key:
            raise ValueError("Public key not loaded. Provide public_key_path or load keys first.")
        
        # Hash the file
        file_hash = self.hash_file(file_path)
        
        # Check if the hash matches the one in metadata
        if file_hash != metadata.get("file_hash"):
            return False
        
        # Verify the signature
        try:
            signature = bytes.fromhex(metadata.get("signature"))
            self.public_key.verify(
                signature,
                file_hash.encode('utf-8'),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except Exception:
            return False
    
    def embed_signature_in_file(self, file_path: str, metadata: Dict[str, Any]) -> str:
        """
        Embed signature metadata in a file.
        For CSV files, adds a comment line at the beginning.
        For Excel files, adds a metadata sheet.
        
        Args:
            file_path: Path to the file to embed signature in
            metadata: Metadata to embed
            
        Returns:
            Path to the signed file
        """
        # For now, we'll create a separate .sig file containing the metadata
        sig_file_path = file_path + ".sig"
        with open(sig_file_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        return sig_file_path


def main():
    """Main function for command-line usage."""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python sign_data.py generate-keys <private_key_path> <public_key_path>")
        print("  python sign_data.py sign <file_path> <private_key_path>")
        print("  python sign_data.py verify <file_path> <signature_file_path> <public_key_path>")
        return
    
    command = sys.argv[1]
    tool = EdgeSigningTool()
    
    if command == "generate-keys":
        if len(sys.argv) != 4:
            print("Usage: python sign_data.py generate-keys <private_key_path> <public_key_path>")
            return
        
        private_key_path = sys.argv[2]
        public_key_path = sys.argv[3]
        
        print(f"Generating RSA key pair...")
        tool.generate_keys()
        tool.save_keys(private_key_path, public_key_path)
        print(f"Keys saved to {private_key_path} and {public_key_path}")
    
    elif command == "sign":
        if len(sys.argv) != 4:
            print("Usage: python sign_data.py sign <file_path> <private_key_path>")
            return
        
        file_path = sys.argv[2]
        private_key_path = sys.argv[3]
        
        if not os.path.exists(file_path):
            print(f"Error: File {file_path} does not exist")
            return
        
        print(f"Signing file {file_path}...")
        metadata = tool.sign_file(file_path, private_key_path)
        
        # Embed signature in file
        sig_file_path = tool.embed_signature_in_file(file_path, metadata)
        print(f"Signature embedded. Metadata saved to {sig_file_path}")
        
        # Also print metadata to stdout
        print("\nSignature metadata:")
        print(json.dumps(metadata, indent=2))
    
    elif command == "verify":
        if len(sys.argv) != 5:
            print("Usage: python sign_data.py verify <file_path> <signature_file_path> <public_key_path>")
            return
        
        file_path = sys.argv[2]
        signature_file_path = sys.argv[3]
        public_key_path = sys.argv[4]
        
        if not os.path.exists(file_path):
            print(f"Error: File {file_path} does not exist")
            return
        
        if not os.path.exists(signature_file_path):
            print(f"Error: Signature file {signature_file_path} does not exist")
            return
        
        # Load metadata
        with open(signature_file_path, 'r') as f:
            metadata = json.load(f)
        
        print(f"Verifying signature for {file_path}...")
        is_valid = tool.verify_signature(file_path, metadata, public_key_path)
        
        if is_valid:
            print("Signature is VALID")
        else:
            print("Signature is INVALID")
    
    else:
        print(f"Unknown command: {command}")
        print("Available commands: generate-keys, sign, verify")


if __name__ == "__main__":
    main()