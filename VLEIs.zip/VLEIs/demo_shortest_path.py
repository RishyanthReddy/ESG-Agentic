#!/usr/bin/env python3
"""
Demo script for the ShortestPathTool.

This script demonstrates how to use the ShortestPathTool to find shortest paths
in supply chain provenance graphs.
"""

import sys
import os

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import networkx as nx
from src.tools.visualization import ShortestPathTool, NetworkXProvenanceTool


def demo_basic_shortest_path():
    """Demonstrate basic shortest path functionality."""
    print("=== Basic Shortest Path Demo ===")
    
    # Create a simple weighted graph
    graph = nx.Graph()
    graph.add_edge("A", "B", weight=4, relationship="connected_to")
    graph.add_edge("B", "C", weight=2, relationship="connected_to")
    graph.add_edge("A", "C", weight=10, relationship="connected_to")
    graph.add_edge("C", "D", weight=3, relationship="connected_to")
    graph.add_edge("B", "D", weight=8, relationship="connected_to")
    
    # Initialize the tool
    tool = ShortestPathTool()
    
    # Find shortest path
    result = tool.run(graph, "A", "D", weight="weight")
    
    if result["success"]:
        print(f"Shortest path from {result['source']} to {result['target']}:")
        print(f"Path: {' -> '.join(result['path'])}")
        print(f"Total weight: {result['path_length']}")
        print(f"Number of nodes: {result['node_count']}")
        print(f"Number of edges: {result['edge_count']}")
        
        print("\nPath edges:")
        for i, edge in enumerate(result['path_edges']):
            print(f"  {i+1}. {edge['source']} -> {edge['target']}")
            if edge['data']:
                print(f"     Data: {edge['data']}")
    else:
        print(f"Error: {result['error']}")


def demo_supply_chain_provenance():
    """Demonstrate shortest path in a supply chain provenance graph."""
    print("\n=== Supply Chain Provenance Demo ===")
    
    # Create sample agent traces
    agent_traces = [
        {
            "agent_id": "supplier_1",
            "agent_name": "Raw Materials Co.",
            "agent_role": "supplier",
            "status": "active",
            "timestamp": "2023-06-01T10:00:00Z",
            "input_artifacts": [],
            "output_artifacts": [
                {
                    "id": "raw_material_1",
                    "name": "Steel Ingot",
                    "type": "raw_material",
                    "size": 500,
                    "hash": "hash12345",
                    "timestamp": "2023-06-01T10:00:00Z"
                }
            ],
            "supplier_info": {
                "id": "supplier_a",
                "name": "Raw Materials Co.",
                "location": "New York, USA",
                "certifications": ["ISO 9001", "ISO 14001"],
                "timestamp": "2023-06-01T10:00:00Z"
            }
        },
        {
            "agent_id": "manufacturer_1",
            "agent_name": "Precision Parts Ltd.",
            "agent_role": "manufacturer",
            "status": "active",
            "timestamp": "2023-06-02T14:30:00Z",
            "input_artifacts": [
                {
                    "id": "raw_material_1",
                    "name": "Steel Ingot",
                    "type": "raw_material",
                    "size": 500,
                    "hash": "hash12345",
                    "timestamp": "2023-06-01T10:00:00Z"
                }
            ],
            "output_artifacts": [
                {
                    "id": "component_1",
                    "name": "Gear Assembly",
                    "type": "component",
                    "size": 50,
                    "hash": "hash67890",
                    "timestamp": "2023-06-02T14:30:00Z"
                }
            ]
        },
        {
            "agent_id": "distributor_1",
            "agent_name": "Global Distributors Inc.",
            "agent_role": "distributor",
            "status": "active",
            "timestamp": "2023-06-03T09:15:00Z",
            "input_artifacts": [
                {
                    "id": "component_1",
                    "name": "Gear Assembly",
                    "type": "component",
                    "size": 50,
                    "hash": "hash67890",
                    "timestamp": "2023-06-02T14:30:00Z"
                }
            ],
            "output_artifacts": [
                {
                    "id": "shipment_1",
                    "name": "Component Shipment",
                    "type": "shipment",
                    "size": 55,
                    "hash": "hashabcde",
                    "timestamp": "2023-06-03T09:15:00Z"
                }
            ]
        }
    ]
    
    # Create sample blockchain logs
    blockchain_logs = [
        {
            "transaction_hash": "0x7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b",
            "data_hash": "hash12345",
            "account": "0xSupplierAccount",
            "block_number": 1234567,
            "gas_used": 21000,
            "timestamp": "2023-06-01T10:00:00Z"
        },
        {
            "transaction_hash": "0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b",
            "data_hash": "hash67890",
            "account": "0xManufacturerAccount",
            "block_number": 1234568,
            "gas_used": 25000,
            "timestamp": "2023-06-02T14:30:00Z"
        },
        {
            "transaction_hash": "0xb9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8",
            "data_hash": "hashabcde",
            "account": "0xDistributorAccount",
            "block_number": 1234569,
            "gas_used": 23000,
            "timestamp": "2023-06-03T09:15:00Z"
        }
    ]
    
    # Create provenance graph
    provenance_tool = NetworkXProvenanceTool()
    provenance_result = provenance_tool.run(agent_traces, blockchain_logs)
    
    if not provenance_result["success"]:
        print(f"Error creating provenance graph: {provenance_result['error']}")
        return
    
    graph = provenance_result["graph"]
    print(f"Created provenance graph with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges")
    
    # Show node types in the graph
    node_types = {}
    for node, data in graph.nodes(data=True):
        node_type = data.get("type", "unknown")
        node_types[node_type] = node_types.get(node_type, 0) + 1
    
    print("Node types in graph:")
    for node_type, count in node_types.items():
        print(f"  {node_type}: {count}")
    
    # Initialize the shortest path tool
    path_tool = ShortestPathTool()
    
    # Get some nodes to find paths between
    supplier_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "supplier"]
    agent_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "agent"]
    artifact_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "artifact"]
    blockchain_nodes = [n for n, data in graph.nodes(data=True) if data.get("type") == "blockchain"]
    
    if len(supplier_nodes) > 0 and len(artifact_nodes) > 0:
        print(f"\nFinding path from supplier {supplier_nodes[0]} to artifact {artifact_nodes[0]}")
        result = path_tool.run(graph, supplier_nodes[0], artifact_nodes[0])
        
        if result["success"]:
            print(f"Path found: {' -> '.join(result['path'])}")
            print(f"Path length (nodes): {result['node_count']}")
            print(f"Path edges: {result['edge_count']}")
            
            print("\nDetailed path edges:")
            for i, edge in enumerate(result['path_edges']):
                edge_data = edge.get('data', {})
                relationship = edge_data.get('relationship', 'unknown') if edge_data else 'unknown'
                print(f"  {i+1}. {edge['source']} -> {edge['target']} ({relationship})")
        else:
            print(f"Error finding path: {result['error']}")
    else:
        print("Not enough nodes of different types to demonstrate path finding")


def main():
    """Run all demos."""
    print("Shortest Path Tool Demo")
    print("=" * 50)
    
    demo_basic_shortest_path()
    demo_supply_chain_provenance()
    
    print("\n" + "=" * 50)
    print("Demo completed!")


if __name__ == "__main__":
    main()