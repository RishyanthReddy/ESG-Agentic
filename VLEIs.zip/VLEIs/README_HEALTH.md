# Health Monitoring Endpoint

## Overview

The Health Monitoring Endpoint provides real-time system status information for critical components of the ESG Intelligence Platform. This endpoint allows monitoring systems to check the health of the application and its dependencies.

## Endpoint

```
GET /health
```

## Response Format

The endpoint returns a JSON response with the following structure:

```json
{
  "status": "healthy|unhealthy|degraded",
  "timestamp": 1234567890.123,
  "checks": {
    "llm": {
      "status": "healthy|unhealthy",
      "response": "Response from LLM (if healthy)",
      "error": "Error message (if unhealthy)"
    },
    "blockchain": {
      "status": "healthy|unhealthy|unknown",
      "latest_block": 12345678,
      "error": "Error message (if unhealthy)"
    },
    "database": {
      "status": "healthy|unhealthy",
      "message": "Additional information",
      "error": "Error message (if unhealthy)"
    }
  },
  "response_time": 1.234
}
```

## Components Checked

1. **LLM API Connectivity**: Tests connectivity to the Gemini 2.0 Flash model via Glama API
2. **Blockchain Node Connection**: Tests connection to the Ethereum mainnet via Infura
3. **Database Availability**: Tests access to the state management system

## Implementation Details

- **Web Framework**: FastAPI health check endpoint
- **Health Checks**: Non-blocking async operations for all services
- **Timeout Management**: Configurable timeouts for each health check
- **Response Format**: Standardized JSON response for easy parsing by monitoring systems

## Usage

To check the health of the system, make a GET request to the `/health` endpoint:

```bash
curl http://localhost:8000/health
```

## Error Handling

The health endpoint is designed to be resilient and will return a 200 status code even if individual components are unhealthy. The overall system status will be reflected in the `status` field of the response:

- `healthy`: All components are functioning properly
- `degraded`: Some components are unhealthy but the system can still function
- `unhealthy`: Critical components are unhealthy and the system may not function properly

## Performance

Health checks are designed to be lightweight and fast. Each check has a timeout to prevent the overall health check from taking too long.