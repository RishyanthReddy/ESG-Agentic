"""
Deployment Configuration for ESG Intelligence Platform

This module contains configuration settings for different deployment environments:
- Cloud deployment (Modal, Vercel/Netlify)
- Local deployment (Docker Compose)
- CLI access endpoints
"""

import os
from typing import Dict, Any

class DeploymentConfig:
    """Configuration class for different deployment environments"""
    
    # Cloud deployment settings
    CLOUD_BACKEND_URL = os.getenv("CLOUD_BACKEND_URL", "https://esg-intelligence-platform.modal.run")
    CLOUD_FRONTEND_URL = os.getenv("CLOUD_FRONTEND_URL", "https://esg-dashboard.vercel.app")
    
    # Local deployment settings
    LOCAL_BACKEND_URL = os.getenv("LOCAL_BACKEND_URL", "http://localhost:8000")
    LOCAL_FRONTEND_URL = os.getenv("LOCAL_FRONTEND_URL", "http://localhost:8501")
    
    # Redis configuration for both environments
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
    
    # API endpoints
    API_ENDPOINTS = {
        "health": "/health",
        "ingest_json": "/api/v1/ingest/json",
        "ingest_csv": "/api/v1/ingest/csv",
        "verify": "/api/v1/verify",
        "dashboard": "/api/v1/dashboard",
        "websocket": "/api/v1/ws"
    }
    
    # CLI accessible endpoints for demonstration
    CLI_ENDPOINTS = {
        "health_check": "/health",
        "system_status": "/api/v1/status",
        "demo_ingest": "/api/v1/ingest/json",
        "demo_verify": "/api/v1/verify",
        "metrics": "/api/v1/dashboard/metrics"
    }
    
    # Deployment health check settings
    HEALTH_CHECK_TIMEOUT = int(os.getenv("HEALTH_CHECK_TIMEOUT", "30"))
    HEALTH_CHECK_RETRIES = int(os.getenv("HEALTH_CHECK_RETRIES", "3"))
    
    @classmethod
    def get_backend_url(cls, environment: str = "local") -> str:
        """
        Get the backend URL for the specified environment.
        
        Args:
            environment: "local" or "cloud"
            
        Returns:
            Backend URL string
        """
        if environment == "cloud":
            return cls.CLOUD_BACKEND_URL
        else:
            return cls.LOCAL_BACKEND_URL
    
    @classmethod
    def get_frontend_url(cls, environment: str = "local") -> str:
        """
        Get the frontend URL for the specified environment.
        
        Args:
            environment: "local" or "cloud"
            
        Returns:
            Frontend URL string
        """
        if environment == "cloud":
            return cls.CLOUD_FRONTEND_URL
        else:
            return cls.LOCAL_FRONTEND_URL
    
    @classmethod
    def get_api_endpoint(cls, endpoint_name: str) -> str:
        """
        Get the full API endpoint URL.
        
        Args:
            endpoint_name: Name of the endpoint
            
        Returns:
            API endpoint URL
        """
        return cls.API_ENDPOINTS.get(endpoint_name, "")
    
    @classmethod
    def get_cli_endpoint(cls, endpoint_name: str) -> str:
        """
        Get the full CLI endpoint URL.
        
        Args:
            endpoint_name: Name of the CLI endpoint
            
        Returns:
            CLI endpoint URL
        """
        return cls.CLI_ENDPOINTS.get(endpoint_name, "")