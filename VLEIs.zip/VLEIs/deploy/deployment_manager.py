"""
Deployment Manager for ESG Intelligence Platform

This module provides functionality to deploy and manage the platform in different environments:
- Cloud deployment (Modal backend, Vercel/Netlify frontend)
- Local deployment (Docker Compose)
- Health monitoring and fallback mechanisms
"""

import os
import sys
import subprocess
import time
import requests
from typing import Dict, Any, Optional
from pathlib import Path
import docker
from deploy.deployment_config import DeploymentConfig

class DeploymentManager:
    """Manager class for handling different deployment environments"""
    
    def __init__(self):
        self.config = DeploymentConfig()
        self.docker_client = None
        try:
            self.docker_client = docker.from_env()
        except Exception as e:
            print(f"Warning: Docker not available - {e}")
    
    def deploy_local(self) -> bool:
        """
        Deploy the application locally using Docker Compose.
        
        Returns:
            bool: True if deployment successful, False otherwise
        """
        try:
            print("Deploying application locally using Docker Compose...")
            
            # Check if docker-compose.yml exists
            compose_file = Path("docker-compose.yml")
            if not compose_file.exists():
                print("Error: docker-compose.yml not found")
                return False
            
            # Run docker-compose up
            result = subprocess.run(
                ["docker-compose", "up", "-d"],
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode != 0:
                print(f"Error deploying locally: {result.stderr}")
                return False
            
            print("Local deployment started successfully")
            return True
            
        except subprocess.TimeoutExpired:
            print("Error: Local deployment timed out")
            return False
        except Exception as e:
            print(f"Error deploying locally: {e}")
            return False
    
    def deploy_cloud(self) -> bool:
        """
        Deploy the application to cloud platforms.
        
        Returns:
            bool: True if deployment successful, False otherwise
        """
        try:
            print("Deploying application to cloud platforms...")
            
            # Deploy to Modal (backend)
            print("Deploying backend to Modal...")
            modal_result = subprocess.run(
                ["modal", "deploy", "modal_entrypoint.py"],
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if modal_result.returncode != 0:
                print(f"Error deploying to Modal: {modal_result.stderr}")
                return False
            
            print("Backend deployed to Modal successfully")
            
            # Note: Frontend deployment to Vercel/Netlify would typically be done
            # via their respective CLI tools or CI/CD pipelines
            print("Note: Frontend deployment to Vercel/Netlify should be done separately")
            
            return True
            
        except subprocess.TimeoutExpired:
            print("Error: Cloud deployment timed out")
            return False
        except Exception as e:
            print(f"Error deploying to cloud: {e}")
            return False
    
    def check_health(self, environment: str = "local") -> Dict[str, Any]:
        """
        Check the health of the deployed application.
        
        Args:
            environment: "local" or "cloud"
            
        Returns:
            Dict with health check results
        """
        backend_url = self.config.get_backend_url(environment)
        health_endpoint = self.config.get_api_endpoint("health")
        
        health_url = f"{backend_url}{health_endpoint}"
        
        try:
            print(f"Checking health of {environment} deployment at {health_url}...")
            
            response = requests.get(
                health_url,
                timeout=self.config.HEALTH_CHECK_TIMEOUT
            )
            
            return {
                "status": "healthy" if response.status_code == 200 else "unhealthy",
                "status_code": response.status_code,
                "response": response.json() if response.status_code == 200 else response.text,
                "url": health_url
            }
            
        except requests.exceptions.RequestException as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "url": health_url
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": f"Unexpected error: {e}",
                "url": health_url
            }
    
    def fallback_to_local(self) -> bool:
        """
        Fallback to local deployment if cloud deployment fails.
        
        Returns:
            bool: True if fallback successful, False otherwise
        """
        print("Falling back to local deployment...")
        return self.deploy_local()
    
    def get_deployment_status(self, environment: str = "local") -> Dict[str, Any]:
        """
        Get the status of the deployment.
        
        Args:
            environment: "local" or "cloud"
            
        Returns:
            Dict with deployment status information
        """
        if environment == "local" and self.docker_client:
            try:
                containers = self.docker_client.containers.list(
                    filters={"name": "esg-"}
                )
                
                container_status = {}
                for container in containers:
                    container_status[container.name] = {
                        "status": container.status,
                        "id": container.id
                    }
                
                return {
                    "environment": environment,
                    "containers": container_status,
                    "docker_available": True
                }
            except Exception as e:
                return {
                    "environment": environment,
                    "error": str(e),
                    "docker_available": False
                }
        else:
            # For cloud or when Docker is not available
            return {
                "environment": environment,
                "docker_available": False,
                "health_check": self.check_health(environment)
            }
    
    def stop_local_deployment(self) -> bool:
        """
        Stop the local Docker Compose deployment.
        
        Returns:
            bool: True if stopped successfully, False otherwise
        """
        try:
            print("Stopping local deployment...")
            
            result = subprocess.run(
                ["docker-compose", "down"],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode != 0:
                print(f"Error stopping local deployment: {result.stderr}")
                return False
            
            print("Local deployment stopped successfully")
            return True
            
        except subprocess.TimeoutExpired:
            print("Error: Stop local deployment timed out")
            return False
        except Exception as e:
            print(f"Error stopping local deployment: {e}")
            return False


def main():
    """Main function to demonstrate deployment functionality"""
    dm = DeploymentManager()
    
    if len(sys.argv) < 2:
        print("Usage: python deployment_manager.py [deploy-local|deploy-cloud|health-local|health-cloud|status-local|status-cloud|fallback|stop-local]")
        return
    
    command = sys.argv[1]
    
    if command == "deploy-local":
        success = dm.deploy_local()
        print(f"Local deployment {'successful' if success else 'failed'}")
        
    elif command == "deploy-cloud":
        success = dm.deploy_cloud()
        print(f"Cloud deployment {'successful' if success else 'failed'}")
        
    elif command == "health-local":
        health = dm.check_health("local")
        print(f"Local health check: {health}")
        
    elif command == "health-cloud":
        health = dm.check_health("cloud")
        print(f"Cloud health check: {health}")
        
    elif command == "status-local":
        status = dm.get_deployment_status("local")
        print(f"Local deployment status: {status}")
        
    elif command == "status-cloud":
        status = dm.get_deployment_status("cloud")
        print(f"Cloud deployment status: {status}")
        
    elif command == "fallback":
        success = dm.fallback_to_local()
        print(f"Fallback deployment {'successful' if success else 'failed'}")
        
    elif command == "stop-local":
        success = dm.stop_local_deployment()
        print(f"Stop local deployment {'successful' if success else 'failed'}")
        
    else:
        print(f"Unknown command: {command}")


if __name__ == "__main__":
    main()