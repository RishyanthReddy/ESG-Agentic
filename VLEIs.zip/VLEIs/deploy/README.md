# ESG Intelligence Platform Deployment System

This directory contains the deployment infrastructure for the ESG Intelligence Platform with fallback capabilities.

## Overview

The deployment system supports multiple environments:
- **Cloud Deployment**: Backend on Modal, Frontend on Vercel/Netlify
- **Local Deployment**: Docker Compose setup for local demonstration
- **Fallback Infrastructure**: Automatic fallback from cloud to local when needed

## Directory Structure

```
deploy/
├── deployment_config.py     # Deployment configuration settings
├── deployment_manager.py    # Main deployment manager class
└── README.md               # This file

demo_scripts/deployment/
├── cli_deploy.py           # CLI deployment tool
└── validate_deployment.sh  # Deployment validation script
```

## Deployment Environments

### Cloud Deployment
- **Backend**: Deployed to Modal with GPU support
- **Frontend**: Deployed to Vercel or Netlify
- **Command**: `python demo_scripts/deployment/cli_deploy.py --mode deploy --environment cloud`

### Local Deployment
- **Containerization**: Docker Compose with Redis and ESG Engine services
- **Command**: `python demo_scripts/deployment/cli_deploy.py --mode deploy --environment local`

## CLI Deployment Tool

The CLI deployment tool provides easy access to deployment operations:

```bash
# Deploy locally
python demo_scripts/deployment/cli_deploy.py --mode deploy --environment local

# Deploy to cloud
python demo_scripts/deployment/cli_deploy.py --mode deploy --environment cloud

# Check health
python demo_scripts/deployment/cli_deploy.py --mode health --environment local

# Get deployment status
python demo_scripts/deployment/cli_deploy.py --mode status --environment cloud

# Fallback to local deployment
python demo_scripts/deployment/cli_deploy.py --mode fallback

# Stop local deployment
python demo_scripts/deployment/cli_deploy.py --mode stop --environment local
```

## Configuration

Deployment configuration is managed through:
1. Environment variables in `.env` file
2. `DeploymentConfig` class in [deployment_config.py](file:///C:/Users/gadea/OneDrive/Desktop/VLEIs/deploy/deployment_config.py)
3. Docker Compose configuration in [docker-compose.yml](file:///C:/Users/gadea/OneDrive/Desktop/VLEIs/docker-compose.yml)
4. Modal configuration in [modal_entrypoint.py](file:///C:/Users/gadea/OneDrive/Desktop/VLEIs/modal_entrypoint.py)

## Fallback Mechanism

If cloud deployment fails, the system can automatically fallback to local deployment:
1. System detects cloud deployment failure
2. Automatically initiates local Docker Compose deployment
3. Redirects services to local endpoints
4. Maintains full functionality with local resources

## Testing

Deployment functionality is tested through:
- Unit tests in [tests/test_deployment.py](file:///C:/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_deployment.py)
- Integration tests in [tests/test_deployment_integration.py](file:///C:/Users/gadea/OneDrive/Desktop/VLEIs/tests/test_deployment_integration.py)

Run tests with:
```bash
python -m pytest tests/test_deployment.py -v
python -m pytest tests/test_deployment_integration.py -v
```

## Health Monitoring

The system continuously monitors deployment health:
- Health checks every 30 seconds
- Automatic failover on health check failures
- Detailed health status reporting via CLI
- Alerting system for critical failures

## API Endpoints

CLI-accessible endpoints for demonstration:
- `/health` - System health status
- `/api/v1/status` - System status information
- `/api/v1/ingest/json` - JSON data ingestion
- `/api/v1/verify` - Verification processes
- `/api/v1/dashboard/metrics` - Dashboard metrics

These endpoints work in both cloud and local environments.