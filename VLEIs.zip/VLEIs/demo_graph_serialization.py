"""
Demo script for the GraphSerializationTool.

This script demonstrates the GraphSerializationTool that converts NetworkX graphs
into structured JSON format for 3D rendering engines like Three.js.
"""

import json
import networkx as nx
from datetime import datetime
from src.tools.visualization import GraphSerializationTool, NetworkXProvenanceTool


def main():
    """Demonstrate the GraphSerializationTool functionality."""
    print("=== Graph Serialization Tool Demo ===\n")
    
    # Initialize the Graph Serialization Tool
    print("1. Initializing Graph Serialization Tool")
    serialization_tool = GraphSerializationTool()
    print(f"   Tool name: {serialization_tool.name}")
    print(f"   Description: {serialization_tool.description}\n")
    
    # Initialize the NetworkX Provenance Tool to create a sample graph
    print("2. Initializing NetworkX Provenance Tool to create sample graph")
    provenance_tool = NetworkXProvenanceTool()
    
    # Create sample agent traces
    agent_traces = [
        {
            "agent_id": "credential_verification_agent",
            "agent_name": "Credential Verification Agent",
            "agent_role": "verification",
            "status": "completed",
            "timestamp": datetime.utcnow().isoformat(),
            "input_artifacts": [
                {
                    "id": "vlei_credential_001",
                    "name": "vLEI Credential for Supplier A",
                    "type": "credential",
                    "size": 2048,
                    "hash": "a1b2c3d4e5f67890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "verification_report_001",
                    "name": "Verification Report for Supplier A",
                    "type": "report",
                    "size": 4096,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "supplier_info": {
                "id": "supplier_corp_A",
                "name": "Supplier Corporation A",
                "location": "New York, NY",
                "certifications": ["ISO 14001", "ISO 45001"],
                "timestamp": datetime.utcnow().isoformat()
            }
        },
        {
            "agent_id": "carbon_calculation_agent",
            "agent_name": "Carbon Calculation Agent",
            "agent_role": "calculation",
            "status": "completed",
            "timestamp": datetime.utcnow().isoformat(),
            "input_artifacts": [
                {
                    "id": "verification_report_001",
                    "name": "Verification Report for Supplier A",
                    "type": "report",
                    "size": 4096,
                    "hash": "f6e5d4c3b2a10987",
                    "timestamp": datetime.utcnow().isoformat()
                },
                {
                    "id": "shipment_data_001",
                    "name": "Shipment Data for Order XYZ",
                    "type": "data",
                    "size": 1024,
                    "hash": "1a2b3c4d5e6f7890",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ],
            "output_artifacts": [
                {
                    "id": "carbon_footprint_report_001",
                    "name": "Carbon Footprint Report for Order XYZ",
                    "type": "report",
                    "size": 3072,
                    "hash": "0987f6e5d4c3b2a1",
                    "timestamp": datetime.utcnow().isoformat()
                }
            ]
        }
    ]
    
    # Create sample blockchain logs
    blockchain_logs = [
        {
            "transaction_hash": "0x7f8e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e",
            "data_hash": "a1b2c3d4e5f67890",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 1234567,
            "gas_used": 21000,
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "transaction_hash": "0x1a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f78901a2b3c4d5e6f7890",
            "data_hash": "f6e5d4c3b2a10987",
            "account": "0x1234567890123456789012345678901234567890",
            "block_number": 1234572,
            "gas_used": 25000,
            "timestamp": datetime.utcnow().isoformat()
        }
    ]
    
    print("   Created sample agent traces and blockchain logs\n")
    
    # Create a provenance graph using the NetworkX Provenance Tool
    print("3. Creating provenance graph using NetworkX Provenance Tool")
    provenance_result = provenance_tool.run(agent_traces, blockchain_logs)
    
    if provenance_result['success']:
        graph = provenance_result['graph']
        print(f"   Graph created successfully with {graph.number_of_nodes()} nodes and {graph.number_of_edges()} edges\n")
    else:
        print(f"   Error creating graph: {provenance_result['error']}\n")
        return
    
    # Demonstrate different serialization formats
    print("4. Demonstrating different serialization formats")
    
    # Standard JSON format
    print("   a) Standard JSON format:")
    json_result = serialization_tool.run(graph, format="json", optimize=False, compress=False)
    if json_result['success']:
        print(f"      Serialized successfully ({json_result['size']} characters)")
        # Show first 300 characters
        print(f"      Sample: {json_result['serialized_graph'][:300]}...\n")
    else:
        print(f"      Error: {json_result['error']}\n")
    
    # Three.js optimized format
    print("   b) Three.js optimized format:")
    threejs_result = serialization_tool.run(graph, format="threejs", optimize=True, compress=False)
    if threejs_result['success']:
        print(f"      Serialized successfully ({threejs_result['size']} characters)")
        # Parse and show structure
        data = json.loads(threejs_result['serialized_graph'])
        print(f"      Structure: {len(data['nodes'])} nodes, {len(data['links'])} links")
        if 'metadata' in data:
            print(f"      Metadata: {data['metadata']}")
        print(f"      Sample node: {data['nodes'][0] if data['nodes'] else 'None'}")
        print(f"      Sample link: {data['links'][0] if data['links'] else 'None'}\n")
    else:
        print(f"      Error: {threejs_result['error']}\n")
    
    # Compressed format
    print("   c) Compressed JSON format:")
    compressed_result = serialization_tool.run(graph, format="json", optimize=False, compress=True)
    if compressed_result['success']:
        print(f"      Serialized successfully ({compressed_result['size']} characters)")
        compression_ratio = (json_result['size'] - compressed_result['size']) / json_result['size'] * 100
        print(f"      Compression ratio: {compression_ratio:.1f}% reduction\n")
    else:
        print(f"      Error: {compressed_result['error']}\n")
    
    # Show detailed structure of Three.js format
    print("5. Detailed structure of Three.js format:")
    if threejs_result['success']:
        data = json.loads(threejs_result['serialized_graph'])
        
        print("   Nodes:")
        for i, node in enumerate(data['nodes'][:3]):  # Show first 3 nodes
            print(f"     {node['id']}: {node.get('type', 'unknown')} - {node.get('name', 'unnamed')}")
            print(f"       Position: ({node['x']}, {node['y']}, {node['z']})")
            print(f"       Color: {node['color']}")
            print(f"       Size: {node['size']}")
            print(f"       Label: {node['label']}")
        
        if len(data['nodes']) > 3:
            print(f"     ... and {len(data['nodes']) - 3} more nodes")
        
        print("\n   Links:")
        for i, link in enumerate(data['links'][:3]):  # Show first 3 links
            print(f"     {link['source']} -> {link['target']} ({link.get('relationship', 'unknown')})")
            print(f"       Color: {link['color']}")
            print(f"       Width: {link['width']}")
        
        if len(data['links']) > 3:
            print(f"     ... and {len(data['links']) - 3} more links")
    
    print("\n6. Demo completed")
    print("\nNote: This tool converts NetworkX graphs into structured JSON format")
    print("     optimized for 3D rendering engines like Three.js. The serialized")
    print("     data includes visualization properties like positions, colors,")
    print("     sizes, and labels for nodes and links.")


if __name__ == "__main__":
    main()