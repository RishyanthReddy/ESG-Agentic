#!/usr/bin/env python3
"""
Example script demonstrating how to use the INFURA_API_KEY from the environment
"""

import os
from dotenv import load_dotenv
from web3 import Web3

# Load environment variables from .env file
load_dotenv()

def connect_to_sepolia():
    """
    Connect to the Sepolia testnet using Infura and the API key from environment variables
    """
    # Get the INFURA_API_KEY from environment variables
    infura_api_key = os.getenv("INFURA_API_KEY")
    
    if not infura_api_key:
        raise ValueError("INFURA_API_KEY not found in environment variables")
    
    # Create the Infura URL for Sepolia testnet
    infura_url = f"https://sepolia.infura.io/v3/{infura_api_key}"
    
    # Connect to the network
    web3 = Web3(Web3.HTTPProvider(infura_url))
    
    # Check connection
    if web3.is_connected():
        print(f"Successfully connected to Sepolia testnet")
        print(f"Chain ID: {web3.eth.chain_id}")
        return web3
    else:
        raise ConnectionError("Failed to connect to Sepolia testnet")

def get_latest_block_info(web3):
    """
    Get information about the latest block
    """
    latest_block = web3.eth.get_block('latest')
    print(f"Latest block number: {latest_block.number}")
    print(f"Block hash: {latest_block.hash.hex()}")
    print(f"Timestamp: {latest_block.timestamp}")
    return latest_block

def main():
    """
    Main function to demonstrate the usage of INFURA_API_KEY
    """
    print("Demonstrating usage of INFURA_API_KEY from .env file")
    print("=" * 50)
    
    try:
        # Connect to Sepolia
        web3 = connect_to_sepolia()
        
        # Get latest block info
        get_latest_block_info(web3)
        
        print("\n" + "=" * 50)
        print("Successfully demonstrated INFURA_API_KEY usage!")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()