#!/usr/bin/env python3
"""
Test script for Infura Blockchain Tool

This script tests the InfuraBlockchainTool implementation with real blockchain interactions.
It's designed to be run in the Modal GPU environment for behavior-driven testing.
"""

import os
import sys
import hashlib
from loguru import logger

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.tools.provenance import InfuraBlockchainTool, BlockchainError
from src.tools.registry import ToolRegistry


def test_tool_registration():
    """Test registering the blockchain tool in the registry"""
    logger.info("Testing tool registration...")
    
    # Get registry instance
    registry = ToolRegistry()
    registry.clear()  # Clear any existing tools
    
    # Create and register tool
    tool = InfuraBlockchainTool()
    registry.register_tool(tool)
    
    # Verify registration
    retrieved_tool = registry.get_tool("infura_blockchain")
    assert retrieved_tool is not None
    assert retrieved_tool.name == "infura_blockchain"
    
    logger.info("Tool registration test passed")


def test_blockchain_connection():
    """Test connection to the blockchain"""
    logger.info("Testing blockchain connection...")
    
    try:
        tool = InfuraBlockchainTool()
        logger.info(f"Connected to blockchain. Chain ID: {tool.web3.eth.chain_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to connect to blockchain: {e}")
        return False


def test_transaction_preparation():
    """Test transaction preparation without sending"""
    logger.info("Testing transaction preparation...")
    
    try:
        tool = InfuraBlockchainTool()
        
        # We can't actually prepare a transaction without a private key,
        # but we can verify the method exists
        assert hasattr(tool, '_prepare_transaction')
        logger.info("Transaction preparation method exists")
        return True
    except Exception as e:
        logger.error(f"Failed to prepare transaction: {e}")
        return False


def test_data_hashing():
    """Test data hashing functionality"""
    logger.info("Testing data hashing...")
    
    # Sample data to hash
    sample_data = "ESG Report Data - 2024"
    
    # Create SHA-256 hash
    data_hash = hashlib.sha256(sample_data.encode('utf-8')).hexdigest()
    
    logger.info(f"Sample data: {sample_data}")
    logger.info(f"SHA-256 hash: {data_hash}")
    
    # Verify hash format
    assert len(data_hash) == 64  # SHA-256 produces 64-character hex string
    assert all(c in '0123456789abcdef' for c in data_hash)
    
    logger.info("Data hashing test passed")
    return data_hash


def main():
    """Main test function"""
    logger.info("Starting Infura Blockchain Tool tests...")
    
    # Run tests
    test_tool_registration()
    test_data_hashing()
    
    # These tests require network connectivity
    if test_blockchain_connection():
        test_transaction_preparation()
        logger.info("All tests completed successfully!")
    else:
        logger.warning("Skipping blockchain-dependent tests due to connection failure")
        logger.info("Non-blockchain tests completed successfully!")


if __name__ == "__main__":
    main()